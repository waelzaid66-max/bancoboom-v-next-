--
-- PostgreSQL database dump
--

\restrict jZZSn1FTZZuTivnfhbPqOMz0ZRyU5MTYG0DrfbaKuQT38MJtTRRPjzVGYECeoY4

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: ad_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.ad_type AS ENUM (
    'featured',
    'native_feed',
    'top_search'
);


--
-- Name: audit_event_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.audit_event_type AS ENUM (
    'blocked_lead',
    'suspicious_click',
    'invalid_impression',
    'flagged_listing',
    'price_outlier',
    'spam_content',
    'rate_limit_exceeded',
    'shadow_ban',
    'admin_action'
);


--
-- Name: audit_severity; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.audit_severity AS ENUM (
    'info',
    'warning',
    'critical'
);


--
-- Name: body_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.body_type AS ENUM (
    'sedan',
    'suv',
    'hatchback',
    'coupe',
    'pickup',
    'van',
    'crossover',
    'minivan',
    'convertible'
);


--
-- Name: condition; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.condition AS ENUM (
    'new',
    'used'
);


--
-- Name: figures_source; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.figures_source AS ENUM (
    'seller_provided',
    'estimate'
);


--
-- Name: financing_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.financing_status AS ENUM (
    'new',
    'forwarded',
    'contacted',
    'closed',
    'rejected'
);


--
-- Name: finishing_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.finishing_type AS ENUM (
    'finished',
    'semi_finished',
    'core_shell',
    'super_lux'
);


--
-- Name: fuel_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.fuel_type AS ENUM (
    'petrol',
    'diesel',
    'hybrid',
    'electric',
    'natural_gas'
);


--
-- Name: global_supply_response_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.global_supply_response_status AS ENUM (
    'pending',
    'accepted',
    'rejected',
    'withdrawn'
);


--
-- Name: global_supply_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.global_supply_status AS ENUM (
    'open',
    'fulfilled',
    'closed',
    'cancelled'
);


--
-- Name: incoterms; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.incoterms AS ENUM (
    'exw',
    'fca',
    'fob',
    'cfr',
    'cif',
    'dap',
    'ddp'
);


--
-- Name: industrial_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.industrial_type AS ENUM (
    'factory',
    'warehouse',
    'machine',
    'production_line',
    'land',
    'raw_material'
);


--
-- Name: industry; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.industry AS ENUM (
    'food',
    'beverage',
    'plastic',
    'textile',
    'pharmaceutical',
    'chemical',
    'engineering',
    'other'
);


--
-- Name: investment_interest_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_interest_kind AS ENUM (
    'interest',
    'request_details',
    'contact'
);


--
-- Name: investment_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_status AS ENUM (
    'draft',
    'active',
    'under_offer',
    'closed'
);


--
-- Name: investment_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_type AS ENUM (
    'factory_sale',
    'business_sale',
    'production_line_investment',
    'franchise',
    'partnership'
);


--
-- Name: invoice_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invoice_status AS ENUM (
    'paid',
    'void'
);


--
-- Name: lead_action; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.lead_action AS ENUM (
    'whatsapp',
    'call',
    'chat',
    'finance_request'
);


--
-- Name: lead_billing_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.lead_billing_status AS ENUM (
    'charged',
    'failed',
    'not_billable'
);


--
-- Name: lead_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.lead_status AS ENUM (
    'new',
    'contacted',
    'closed'
);


--
-- Name: listing_category; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.listing_category AS ENUM (
    'car',
    'real_estate',
    'industrial'
);


--
-- Name: listing_link_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.listing_link_type AS ENUM (
    'feeds_into',
    'part_of',
    'compatible_with'
);


--
-- Name: listing_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.listing_status AS ENUM (
    'active',
    'sold',
    'archived',
    'draft',
    'pending_approval',
    'pending_review',
    'approved',
    'rejected',
    'flagged'
);


--
-- Name: media_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.media_type AS ENUM (
    'image',
    'video'
);


--
-- Name: notification_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.notification_type AS ENUM (
    'message',
    'lead',
    'system',
    'rfq',
    'new_match',
    'price_drop',
    'comment',
    'review',
    'investment',
    'global_supply',
    'booking',
    'payment_success',
    'payment_failed',
    'subscription_expiring'
);


--
-- Name: origin_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.origin_type AS ENUM (
    'local',
    'imported'
);


--
-- Name: ownership_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.ownership_type AS ENUM (
    'resale',
    'primary',
    'installment_ready'
);


--
-- Name: payment_intent_purpose; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_intent_purpose AS ENUM (
    'wallet_topup',
    'subscription'
);


--
-- Name: payment_intent_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_intent_status AS ENUM (
    'pending',
    'completed',
    'failed',
    'expired'
);


--
-- Name: payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_method AS ENUM (
    'vodafone_cash',
    'fawry',
    'instapay',
    'bank_transfer',
    'wallet'
);


--
-- Name: payment_mode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_mode AS ENUM (
    'cash',
    'seller_installment',
    'bank_finance'
);


--
-- Name: payment_provider; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_provider AS ENUM (
    'seller',
    'bank',
    'dealer',
    'supplier'
);


--
-- Name: promo_ad_transaction_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.promo_ad_transaction_type AS ENUM (
    'grant',
    'consume',
    'expire',
    'reset'
);


--
-- Name: property_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.property_type AS ENUM (
    'apartment',
    'villa',
    'townhouse',
    'twinhouse',
    'penthouse',
    'duplex',
    'studio',
    'chalet',
    'office',
    'clinic',
    'shop',
    'land'
);


--
-- Name: report_reason; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.report_reason AS ENUM (
    'fake_price',
    'wrong_data',
    'scam',
    'duplicate',
    'other'
);


--
-- Name: report_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.report_status AS ENUM (
    'open',
    'reviewing',
    'resolved',
    'dismissed'
);


--
-- Name: rfq_offer_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.rfq_offer_status AS ENUM (
    'pending',
    'accepted',
    'rejected',
    'withdrawn'
);


--
-- Name: rfq_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.rfq_status AS ENUM (
    'open',
    'awarded',
    'closed',
    'cancelled'
);


--
-- Name: shipping_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.shipping_method AS ENUM (
    'container',
    'bulk',
    'air'
);


--
-- Name: social_platform; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.social_platform AS ENUM (
    'instagram',
    'linkedin',
    'website',
    'whatsapp'
);


--
-- Name: staff_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.staff_role AS ENUM (
    'owner',
    'admin',
    'moderator',
    'support',
    'user'
);


--
-- Name: subscription_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.subscription_status AS ENUM (
    'active',
    'expired',
    'cancelled',
    'pending'
);


--
-- Name: support_ticket_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.support_ticket_status AS ENUM (
    'open',
    'closed'
);


--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.transaction_type AS ENUM (
    'wallet_topup',
    'boost_charge',
    'subscription_charge',
    'lead_charge',
    'refund',
    'adjustment'
);


--
-- Name: transmission; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.transmission AS ENUM (
    'manual',
    'automatic',
    'cvt'
);


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'individual',
    'dealer',
    'company',
    'enterprise',
    'financial_institution'
);


--
-- Name: zone_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.zone_type AS ENUM (
    'urban',
    'suburb',
    'coastal',
    'industrial',
    'new_city'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    ad_type public.ad_type DEFAULT 'native_feed'::public.ad_type NOT NULL,
    is_active boolean DEFAULT true,
    starts_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone NOT NULL,
    budget_total numeric,
    budget_spent numeric DEFAULT '0'::numeric NOT NULL,
    cost_per_impression numeric DEFAULT '0'::numeric NOT NULL,
    ranking_weight numeric DEFAULT '1'::numeric NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    billable_impressions integer DEFAULT 0 NOT NULL,
    boost_idempotency_key text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type public.audit_event_type NOT NULL,
    severity public.audit_severity DEFAULT 'warning'::public.audit_severity NOT NULL,
    actor_user_id uuid,
    subject_user_id uuid,
    listing_id uuid,
    ad_id uuid,
    ip text,
    device_id text,
    reason text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    guest_id uuid,
    check_in date NOT NULL,
    check_out date NOT NULL,
    nights integer NOT NULL,
    price_per_night numeric(14,2),
    total_price numeric(14,2),
    currency text DEFAULT 'EGP'::text NOT NULL,
    guests integer DEFAULT 1 NOT NULL,
    note text,
    status text DEFAULT 'requested'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: brands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    category public.listing_category DEFAULT 'car'::public.listing_category NOT NULL,
    name_ar text,
    country text,
    parent_company text,
    founded_year integer,
    logo_url text,
    is_active boolean DEFAULT true NOT NULL,
    is_premium boolean DEFAULT false NOT NULL,
    is_electric boolean DEFAULT false NOT NULL,
    is_commercial boolean DEFAULT false NOT NULL,
    popularity integer DEFAULT 0 NOT NULL,
    search_keywords jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: candidate_attribute_seen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.candidate_attribute_seen (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    candidate_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: candidate_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.candidate_attributes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category public.listing_category NOT NULL,
    attr_key text NOT NULL,
    sample_value text,
    usage_count integer DEFAULT 0 NOT NULL,
    user_count integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'candidate'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: car_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.car_variants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model_id uuid NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: company_follows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_follows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    follower_id uuid NOT NULL,
    company_user_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_company_follow_no_self CHECK ((follower_id <> company_user_id))
);


--
-- Name: company_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    about text,
    year_established integer,
    countries_import_from jsonb,
    countries_export_to jsonb,
    min_order_value numeric,
    min_order_unit text,
    monthly_capacity text,
    lead_time_days integer,
    certifications jsonb,
    website_url text,
    logo_url text,
    cover_url text,
    industry public.industry,
    hq_country text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    buyer_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    last_message_text text,
    last_message_at timestamp without time zone,
    buyer_unread integer DEFAULT 0 NOT NULL,
    seller_unread integer DEFAULT 0 NOT NULL,
    buyer_deleted_at timestamp without time zone,
    seller_deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: dedup_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dedup_keys (
    store_name text NOT NULL,
    dedup_key text NOT NULL,
    seen_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: email_provider_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_provider_config (
    provider text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    from_name text,
    from_email text,
    sending_domain text,
    reply_to text,
    public_app_url text,
    enc_api_key text,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: financing_branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financing_branches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    intermediary_id uuid NOT NULL,
    name text NOT NULL,
    city text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: financing_intermediaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financing_intermediaries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    contact_email text,
    contact_phone text,
    notes text,
    owner_user_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: financing_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financing_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lead_id uuid NOT NULL,
    status public.financing_status DEFAULT 'new'::public.financing_status NOT NULL,
    intermediary_id uuid,
    branch_id uuid,
    assigned_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: financing_seats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financing_seats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    intermediary_id uuid NOT NULL,
    branch_id uuid,
    user_id uuid NOT NULL,
    role text DEFAULT 'agent'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: finishing_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finishing_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    name_ar text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: global_supply_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_supply_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    buyer_id uuid NOT NULL,
    product_text text NOT NULL,
    category public.listing_category,
    industry public.industry,
    quantity numeric,
    unit text,
    destination_country text NOT NULL,
    budget_max numeric,
    currency text DEFAULT 'EGP'::text NOT NULL,
    incoterms public.incoterms,
    notes text,
    status public.global_supply_status DEFAULT 'open'::public.global_supply_status NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: global_supply_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_supply_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    country_of_origin text,
    moq numeric,
    shipping_time_days integer,
    incoterms public.incoterms,
    delivery_estimate text,
    price_quote numeric,
    currency text DEFAULT 'EGP'::text NOT NULL,
    message text,
    status public.global_supply_response_status DEFAULT 'pending'::public.global_supply_response_status NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: industrial_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.industrial_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    name_ar text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: industries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.industries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    name_ar text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interactions (
    listing_id uuid NOT NULL,
    views integer DEFAULT 0,
    clicks integer DEFAULT 0,
    whatsapp_clicks integer DEFAULT 0,
    call_clicks integer DEFAULT 0,
    finance_requests integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: investment_interests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_interests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    investment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    kind public.investment_interest_kind DEFAULT 'interest'::public.investment_interest_kind NOT NULL,
    message text,
    contact_phone text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: investment_opportunities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_opportunities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id uuid NOT NULL,
    investment_type public.investment_type NOT NULL,
    title text NOT NULL,
    description text,
    industry public.industry,
    location text NOT NULL,
    location_id uuid,
    total_value_amount numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    expected_roi_pct numeric,
    payback_years numeric,
    revenue_range_min numeric,
    revenue_range_max numeric,
    cost_structure_note text,
    growth_potential_note text,
    figures_source public.figures_source DEFAULT 'seller_provided'::public.figures_source NOT NULL,
    cover_url text,
    status public.investment_status DEFAULT 'active'::public.investment_status NOT NULL,
    is_flagged boolean DEFAULT false NOT NULL,
    flag_reason text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_number text NOT NULL,
    user_id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    amount numeric NOT NULL,
    status public.invoice_status DEFAULT 'paid'::public.invoice_status NOT NULL,
    line_items jsonb,
    issued_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: lead_billing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_billing (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lead_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    buyer_id uuid,
    listing_id uuid,
    action_type public.lead_action NOT NULL,
    status public.lead_billing_status NOT NULL,
    amount_charged numeric DEFAULT '0'::numeric NOT NULL,
    transaction_id uuid,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: lead_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    buyer_id uuid,
    seller_id uuid NOT NULL,
    action_type public.lead_action NOT NULL,
    status public.lead_status DEFAULT 'new'::public.lead_status,
    buyer_name text,
    buyer_phone text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: lead_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    viewer_clerk_id text NOT NULL,
    listing_id uuid NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: listing_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_attributes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    specs jsonb NOT NULL,
    brand_id uuid,
    model_id uuid,
    variant_id uuid,
    fuel_type public.fuel_type,
    condition public.condition,
    body_type public.body_type,
    transmission public.transmission,
    property_type public.property_type,
    finishing_type public.finishing_type,
    ownership_type public.ownership_type,
    industrial_type public.industrial_type,
    industry public.industry,
    property_type_id uuid,
    finishing_type_id uuid,
    ownership_type_id uuid,
    industrial_type_id uuid,
    industry_id uuid,
    delivery_time_days integer,
    origin_type public.origin_type,
    country_of_origin text,
    shipping_method public.shipping_method
);


--
-- Name: listing_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    author_id uuid NOT NULL,
    parent_id uuid,
    body text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: listing_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    from_listing_id uuid NOT NULL,
    to_listing_id uuid NOT NULL,
    relation public.listing_link_type NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_listing_link_no_self CHECK ((from_listing_id <> to_listing_id))
);


--
-- Name: listing_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_media (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    type public.media_type NOT NULL,
    url text NOT NULL,
    thumbnail_url text,
    is_thumbnail boolean DEFAULT false,
    sort_order integer DEFAULT 0
);


--
-- Name: listings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    title text NOT NULL,
    description text,
    category public.listing_category NOT NULL,
    base_price_cash numeric NOT NULL,
    location text NOT NULL,
    location_id uuid,
    latitude numeric(10,7),
    longitude numeric(10,7),
    status public.listing_status DEFAULT 'active'::public.listing_status,
    trust_score integer DEFAULT 0,
    is_duplicate boolean DEFAULT false,
    duplicate_of_id uuid,
    is_flagged boolean DEFAULT false NOT NULL,
    flag_reason text,
    bumped_at timestamp without time zone,
    is_request boolean DEFAULT false NOT NULL,
    saves_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    city text NOT NULL,
    area text NOT NULL,
    slug text NOT NULL,
    zone_type public.zone_type DEFAULT 'urban'::public.zone_type NOT NULL,
    latitude numeric(10,7),
    longitude numeric(10,7),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    body text NOT NULL,
    media_url text,
    media_kind text,
    reactions jsonb,
    reply_to_id uuid,
    listing_ref_id uuid,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    brand_id uuid NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    body_type public.body_type,
    year_start integer,
    year_end integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.notification_type NOT NULL,
    in_app boolean DEFAULT true NOT NULL,
    email boolean DEFAULT true NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.notification_type NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    data jsonb,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: ownership_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ownership_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    name_ar text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: payment_intents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_intents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    amount numeric NOT NULL,
    method public.payment_method NOT NULL,
    purpose public.payment_intent_purpose NOT NULL,
    status public.payment_intent_status DEFAULT 'pending'::public.payment_intent_status NOT NULL,
    provider_ref text,
    plan_id uuid,
    completed_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: payment_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_options (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    mode public.payment_mode NOT NULL,
    down_payment numeric,
    monthly_payment numeric,
    duration_months integer,
    is_islamic_compliant boolean DEFAULT false,
    provider public.payment_provider DEFAULT 'seller'::public.payment_provider NOT NULL,
    provider_name text,
    annual_rate_pct numeric,
    profit_rate_pct numeric
);


--
-- Name: payment_provider_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_provider_config (
    provider text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    mode text DEFAULT 'test'::text NOT NULL,
    public_key text,
    integration_ids text,
    api_base text,
    enc_secret_key text,
    enc_hmac_secret text,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: pending_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pending_locations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    raw_name text NOT NULL,
    normalized text NOT NULL,
    iso_country_code text,
    suggested_parent_id uuid,
    suggested_type text,
    occurrence_count integer DEFAULT 1 NOT NULL,
    confidence_score numeric(4,3),
    source text,
    status text DEFAULT 'pending'::text NOT NULL,
    merged_into_id uuid,
    first_seen_at timestamp without time zone DEFAULT now(),
    last_seen_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    name_ar text,
    audience public.user_role DEFAULT 'dealer'::public.user_role NOT NULL,
    is_baseline boolean DEFAULT false NOT NULL,
    monthly_price numeric DEFAULT '0'::numeric NOT NULL,
    listing_quota integer,
    active_listing_cap integer,
    boost_price numeric DEFAULT '0'::numeric NOT NULL,
    cpl_whatsapp numeric DEFAULT '0'::numeric NOT NULL,
    cpl_call numeric DEFAULT '0'::numeric NOT NULL,
    cpl_chat numeric DEFAULT '0'::numeric NOT NULL,
    cpl_finance_request numeric DEFAULT '0'::numeric NOT NULL,
    ranking_weight numeric DEFAULT '1'::numeric NOT NULL,
    features jsonb,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: price_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_observations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid,
    category public.listing_category NOT NULL,
    segment_key text NOT NULL,
    location_key text,
    price numeric(14,2) NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    source text DEFAULT 'listing_publish'::text NOT NULL,
    observed_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: promo_ad_campaign_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_ad_campaign_config (
    id text DEFAULT 'singleton'::text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    verified_monthly_amount numeric(12,2) DEFAULT '10000'::numeric NOT NULL,
    unverified_monthly_amount numeric(12,2) DEFAULT '5000'::numeric NOT NULL,
    duration_months integer DEFAULT 4 NOT NULL,
    campaign_version integer DEFAULT 1 NOT NULL,
    starts_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT promo_cfg_amounts_nonneg CHECK (((verified_monthly_amount >= (0)::numeric) AND (unverified_monthly_amount >= (0)::numeric))),
    CONSTRAINT promo_cfg_duration_range CHECK (((duration_months >= 1) AND (duration_months <= 24))),
    CONSTRAINT promo_cfg_singleton CHECK ((id = 'singleton'::text))
);


--
-- Name: promo_ad_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_ad_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    campaign_version integer NOT NULL,
    month_index integer NOT NULL,
    amount numeric(12,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: promo_ad_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_ad_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.promo_ad_transaction_type NOT NULL,
    amount numeric(12,2) NOT NULL,
    balance_after numeric(12,2) NOT NULL,
    campaign_version integer NOT NULL,
    reference_type text,
    reference_id uuid,
    description text,
    idempotency_key text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: property_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.property_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    name_ar text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: push_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    platform text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: rate_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    counter_name text NOT NULL,
    bucket_key text NOT NULL,
    event_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: reference_developers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reference_developers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    local_name text,
    iso_country_code text DEFAULT 'EG'::text NOT NULL,
    aliases jsonb DEFAULT '[]'::jsonb NOT NULL,
    search_keywords jsonb DEFAULT '[]'::jsonb NOT NULL,
    search_blob text DEFAULT ''::text NOT NULL,
    popularity integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: reference_places; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reference_places (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    global_id text NOT NULL,
    parent_id uuid,
    place_type text NOT NULL,
    iso_country_code text,
    name_en text NOT NULL,
    name_ar text,
    local_name text,
    slug text NOT NULL,
    aliases jsonb DEFAULT '[]'::jsonb NOT NULL,
    search_keywords jsonb DEFAULT '[]'::jsonb NOT NULL,
    search_blob text DEFAULT ''::text NOT NULL,
    developer_id uuid,
    latitude numeric(10,7),
    longitude numeric(10,7),
    geohash text,
    postal_code text,
    timezone text,
    currency text,
    language text,
    popularity integer DEFAULT 0 NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    source text,
    source_url text,
    confidence_score numeric(4,3),
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    reporter_user_id uuid,
    reason public.report_reason NOT NULL,
    details text,
    status public.report_status DEFAULT 'open'::public.report_status NOT NULL,
    resolved_by_user_id uuid,
    resolution_note text,
    created_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone
);


--
-- Name: rfq_offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfq_offers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rfq_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    price_quote numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    lead_time_days integer,
    moq numeric,
    message text,
    status public.rfq_offer_status DEFAULT 'pending'::public.rfq_offer_status NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: rfqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfqs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    buyer_id uuid NOT NULL,
    category public.listing_category NOT NULL,
    title text NOT NULL,
    description text,
    quantity numeric,
    unit text,
    target_price_max numeric,
    destination_country text,
    industry public.industry,
    industrial_type public.industrial_type,
    status public.rfq_status DEFAULT 'open'::public.rfq_status NOT NULL,
    deadline timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: saved_listings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_listings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: saved_searches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_searches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    query text,
    category public.listing_category,
    filters jsonb,
    price_min numeric,
    price_max numeric,
    alerts_enabled boolean DEFAULT true NOT NULL,
    last_notified_listing_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: seller_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seller_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    seller_id uuid NOT NULL,
    author_id uuid NOT NULL,
    rating integer NOT NULL,
    body text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT rating_range CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: stories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    listing_id uuid,
    media_url text NOT NULL,
    caption text,
    created_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: story_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.story_views (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    story_id uuid NOT NULL,
    viewer_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status public.subscription_status DEFAULT 'active'::public.subscription_status NOT NULL,
    price_paid numeric DEFAULT '0'::numeric NOT NULL,
    starts_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    auto_renew boolean DEFAULT false NOT NULL,
    transaction_id uuid,
    cancelled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: support_ticket_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_ticket_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_id uuid NOT NULL,
    author_user_id uuid,
    is_admin boolean DEFAULT false NOT NULL,
    body text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    subject text NOT NULL,
    category text,
    status public.support_ticket_status DEFAULT 'open'::public.support_ticket_status NOT NULL,
    last_reply_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.transaction_type NOT NULL,
    amount numeric NOT NULL,
    balance_after numeric NOT NULL,
    payment_method public.payment_method,
    reference_type text,
    reference_id uuid,
    description text,
    idempotency_key text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: upload_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.upload_claims (
    object_path text NOT NULL,
    clerk_id text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: user_behavior; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_behavior (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    session_id text,
    listing_id uuid,
    action text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: user_social_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_social_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    platform public.social_platform NOT NULL,
    value text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_number text GENERATED ALWAYS AS (('BNC-'::text || upper(SUBSTRING(replace((id)::text, '-'::text, ''::text) FROM 1 FOR 12)))) STORED,
    clerk_id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    role public.user_role DEFAULT 'individual'::public.user_role NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    staff_role public.staff_role DEFAULT 'user'::public.staff_role NOT NULL,
    is_verified boolean DEFAULT false,
    wallet_balance numeric DEFAULT '0'::numeric NOT NULL,
    promo_ad_balance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    promo_ad_balance_expires_at timestamp without time zone,
    is_shadow_banned boolean DEFAULT false NOT NULL,
    quality_score integer,
    company_details jsonb,
    created_at timestamp without time zone DEFAULT now(),
    deleted_at timestamp without time zone
);


--
-- Data for Name: ads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ads (id, listing_id, seller_id, ad_type, is_active, starts_at, expires_at, budget_total, budget_spent, cost_per_impression, ranking_weight, impressions, billable_impressions, boost_idempotency_key, created_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, event_type, severity, actor_user_id, subject_user_id, listing_id, ad_id, ip, device_id, reason, metadata, created_at) FROM stdin;
981693f0-44b5-45ec-9987-5ab6944bb311	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "eb8340ca-f626-4d1a-b314-bf60dc27f040", "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.805082
59a0e43f-ac72-4723-b53d-7e692a31e0dc	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:17.878224
e61369b8-442f-4784-96bd-a8397c5bbdc0	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:01.062509
564ef5d6-4dcd-4f12-be89-0e86a2a23d05	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:01.063981
21983c01-278f-4291-8343-67e8dc5e23dd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_3eaa0703-0659-4c04-b925-986331af66db", "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:41.941283
f0e5f274-e9c1-463a-8cc1-195bb42cdd73	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:41.953635
c32dd2ab-906e-4f60-a3d9-089c722f2a04	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.540019
4c41fc5d-d073-40d1-94da-f3e0a7011e0c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.569909
02f84e3a-0dff-4537-b30f-3f9d6d7dae08	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.600696
6d85f4dd-2033-4cc8-b51e-2b3d267f9577	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.632546
0c494d08-2b35-4ff8-8e58-a7aea2988f6e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.658783
e0d627b8-c07a-4b16-9cab-fa2c12c56cb7	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.676334
4ac82595-2504-4463-8b0d-118c01d00aef	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.712665
27c11f6e-dfa5-4691-ab85-9f4f513a78c3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.748075
23556009-cc71-4dc9-837b-7faa84ba60f7	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.765453
01ff32f0-90bc-44dc-a778-af86c41aafa3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:58.850764
2ede0658-47d2-404f-be17-ec3c48069749	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.16208
6d061c88-bca8-4c30-944c-6b0d1be87e66	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.163256
d8d9fae8-3647-442e-bb5f-95a5268676b2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.194399
f14218ba-6710-4270-a225-f719fd81dd9d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.194855
8f724474-d661-49fe-9176-02f062c3d44e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.236801
1cc30303-a20b-4702-a9a1-eb1a13fcc455	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.097794
b2b4d77e-08b5-4fa3-a4dd-b13352748cc3	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.099273
07615689-7fe7-4913-b8bd-296f2fc69157	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.142501
c190310e-8951-412c-bb8b-d848167b527b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.143489
15ae191b-9c8d-4640-ba5e-51d9111d5083	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.282548
f445af25-d2b9-4cb1-9bff-0d44c4bc867e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.283278
63d604bc-5ef0-47df-b03d-9864a841c919	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.348043
be280161-cd05-4784-8fa5-cacd7e8c2756	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.348614
9d7ff076-da1b-4c1f-b539-a46ea9ab835b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.389955
519bcb17-7fc7-47a9-a9bb-3de29a3f6761	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.390699
a5c18699-b78d-4ab7-8c46-a31f07bd971b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.418508
ba457fac-2e76-4d24-b859-7648dd1b3cc1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.419524
18d5e048-78d5-47f3-be5f-68d63273a1e8	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.479455
56f3c77c-e502-48ea-9137-87d15d3a0bf2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.479422
50076bc7-14d4-4163-b372-b1668c77edd3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.537221
0a1a159c-df40-4534-858b-277e934e9d81	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.537594
7898a239-fbfa-43a0-8072-1bdd1a46c3b8	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:16.565214
8e3eb9c3-caa8-42cb-9719-1a8e17244a4e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:16.565233
d85b79a3-6a62-470d-906b-6d7124929da6	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.237511
0b7d9158-94d4-4274-9829-0a2a96b18293	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.280058
10593c8b-7d67-4347-9771-4077dc5cba2a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.351497
8d4d23db-66eb-4077-9797-b5fe1a0d71bf	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.351611
51599619-c460-490f-b6a7-5ee2003a008f	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.395937
15cbceb2-eee7-4945-a647-ed1ea019b061	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.396778
98ee3968-61f1-4fcd-be99-1d576aba1c62	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.422958
4e138afb-fe80-442d-acd9-ed377657f5cc	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.423268
67bf5698-ce4a-4e58-a052-d3cc0c26da92	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_819b6137-92d1-4cc6-9b43-0d065ed82080", "intermediary_id": "aafb54ab-d397-4d79-9267-2b7fc058131d"}	2026-07-19 14:01:22.426741
b43c4c1c-c192-49d1-8991-bf25d3e74ed5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "aafb54ab-d397-4d79-9267-2b7fc058131d"}	2026-07-19 14:01:22.438197
ed46fe15-cb6e-4689-a972-6b2c262a744d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_85deee52-8574-4961-9707-1b29d5c9ab51", "intermediary_id": "20757826-fcfe-4d75-9519-7426140d1793"}	2026-07-19 14:01:22.589584
a0564579-abab-4769-b3c3-d02d6bd54544	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "e658b8a3-22b4-428a-bc63-7df500868bc3", "intermediary_id": "20757826-fcfe-4d75-9519-7426140d1793"}	2026-07-19 14:01:22.608341
cf123ab2-a09b-4c00-a397-b941106a1742	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "e658b8a3-22b4-428a-bc63-7df500868bc3", "intermediary_id": null}	2026-07-19 14:01:22.624219
48a29345-21f6-4f50-8dca-ca6a455bf38b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:17:00.406646
e5618897-801d-4cdc-b0ac-b791bba3576b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:17:00.452041
aa437024-85cf-445e-874d-7c5d3c5fe3ac	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_d99ebd0a-0c81-4f92-8a1a-1690ad8775b7", "intermediary_id": "80876595-c765-49a1-a127-1bbcb84b09e0"}	2026-07-19 19:17:09.055095
247d783a-dbcc-47c4-a9f4-5bfa16fb4127	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "40306d17-d340-4eb7-9aac-7c399943129f", "intermediary_id": null}	2026-07-19 19:17:09.087943
d3f4e4c0-a546-4934-98ce-85ed92dec08e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:26.178999
65ea875b-921e-4432-8a19-31d8cdf7cfaf	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:26.17991
403290da-5efb-411a-84e1-8e604a801b91	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 14:01:26.26163
2d0afe94-85e9-4d41-8e1c-ae2d9d04e073	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 14:01:26.261702
9965ad58-081e-4f5a-aaea-bce628619f7e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.227744
3429fce3-61ad-4dd1-ae1d-42c660a9d767	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "e13bb1ff-f001-4031-b975-3886dffe9604"}	2026-07-20 12:18:19.298871
bd879fe5-d0a4-4710-a18d-8c9b2981b4d3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_45c54ee5-0d51-4807-aed6-7bf13e47843c", "intermediary_id": "a6ce423c-1e5d-48ca-85ee-ca733de91a4a"}	2026-07-20 00:27:41.622487
56d0b809-edc1-4379-8bfe-4a74f41bf068	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "a6ce423c-1e5d-48ca-85ee-ca733de91a4a"}	2026-07-20 00:27:41.631144
d1060ae8-d7fa-4712-bd1c-d49cb30245cd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.28003
3f9584cd-7ad3-4c78-8793-bc6e2447533d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.302142
734d4030-ed06-4578-97fb-c9f1e159d859	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.302628
9bb159bd-e5c2-467c-90c7-abcee1adad2b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:36.318163
d4c75683-488b-4e9b-8177-c86d6072ed50	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:36.318302
beac1d35-9e78-426c-bfe6-962cd8cd215d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_75931718-6d12-43c2-af5a-514f4cb1af26", "intermediary_id": "5ca5cb6d-5280-4538-8139-d0825aadf6d0"}	2026-07-20 00:27:41.643072
a95e52e6-44da-41d6-9e92-e0af01d5633a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "5909326b-ceaa-413e-b64d-bf4e0f449e11", "intermediary_id": "5ca5cb6d-5280-4538-8139-d0825aadf6d0"}	2026-07-20 00:27:41.6529
8134bbd3-0766-4ff3-bd36-198f6d72ef32	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "65fe6fc9-ced8-4da5-a89d-569cdc2c9cd7"}	2026-07-20 00:27:41.706532
26017102-d001-4e82-92f5-f6caa0e368bd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "3fdf86fb-85b0-4937-afdc-0144581f5876", "intermediary_id": "65fe6fc9-ced8-4da5-a89d-569cdc2c9cd7"}	2026-07-20 00:27:41.711885
725a0358-a4d1-45b5-9fd2-f9dfe94534f9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_0d215474-a3ce-44a7-a850-073d36330db9", "intermediary_id": "1572df1a-8b29-44ca-a982-ae83d7d1bac3"}	2026-07-20 00:57:27.436222
2ca9442d-2eb6-4561-aa3d-d8d1103c464b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_0c74be58-9221-4dbc-a6b3-f04a1a3b6221", "intermediary_id": "2a32330f-069b-49f1-8749-329174787eed"}	2026-07-19 18:58:43.586257
018c48a4-ac3b-4ac2-b581-e5c43b694cc1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "2a32330f-069b-49f1-8749-329174787eed"}	2026-07-19 18:58:43.592291
4693ac97-b8ea-4f79-9f85-ecb8e8121db2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_42c3b3ca-b3e0-4489-9fe5-93605e8471b8", "intermediary_id": "1d327b6e-5b48-4d28-8069-c8a85f89c79e"}	2026-07-19 18:58:43.603556
6bac47b1-95df-4cce-8334-e3b928251135	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "189c89aa-09d0-48f7-b068-f04e05f578c7", "intermediary_id": "1d327b6e-5b48-4d28-8069-c8a85f89c79e"}	2026-07-19 18:58:43.610439
72d65e88-6ef1-4ae8-a80a-941d72bad35f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "189c89aa-09d0-48f7-b068-f04e05f578c7", "intermediary_id": null}	2026-07-19 18:58:43.619506
b2a7234d-1f2e-475d-b52f-2f7755f09e26	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.218971
7c0c9a01-cbcf-411d-a9a2-457488d784bd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.219182
51e6ff92-67d7-4ed3-a89f-38355e8a5373	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:44.626435
4312dfec-f229-4fc0-bd04-3957529ca6be	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:44.626439
cef475f7-68eb-460a-93e3-0f04d972b48f	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.541792
858d9fbd-1d63-4121-bfbc-92f145b4839b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.569588
7cfa5bd6-9be9-4d1c-b002-a289a6401065	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.600697
6ff81744-8515-451b-880c-7d3821a854c2	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.633273
cd8f46f1-573e-4f7d-858a-06f7897ebe79	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:51.153069
6c601933-98b2-4a53-b652-bcda73cfe9b4	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:51.154567
6514dd55-0b85-40b9-8314-bc8a47e42103	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 18:58:51.209244
3962aa4e-0090-476d-80e4-e478248224c8	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 18:58:51.209239
ff865fcd-b489-466a-9a0a-7e7e7419ba2e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.659769
492642ec-d4f1-4919-a319-37422ce87bac	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.675819
90997086-e2ec-414f-9248-d1621e3fffb3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.712668
de41cf94-788a-471a-a49a-e8306a80b154	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:50.749926
5b872f5e-3154-4649-afa5-ea4435d49a80	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:16:50.765329
87dc44b6-b1e0-427a-ad21-0a7307890c10	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:16:58.850749
07089654-7c35-4c8c-9b19-33aa67704a67	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-19 19:17:00.407179
e5503547-afc3-468e-aca2-db5f5c7930f2	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-19 19:17:00.45236
af9945ff-8b18-4ea0-8f2f-c9fb66200a14	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "80876595-c765-49a1-a127-1bbcb84b09e0"}	2026-07-19 19:17:09.05929
cd4ff18f-3101-4c71-93b9-0b004abdbb5b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_1c8f1385-1a47-41b5-bbec-f9ccf2133781", "intermediary_id": "ef05d081-7400-4295-990a-fb7baad4f486"}	2026-07-19 19:17:09.072896
354b363b-6592-486b-a900-5fbaeabe11f1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "40306d17-d340-4eb7-9aac-7c399943129f", "intermediary_id": "ef05d081-7400-4295-990a-fb7baad4f486"}	2026-07-19 19:17:09.079643
a097e6ba-fa4e-41c5-9665-41cade9f6ab2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.118642
ffbfc87d-da61-4650-b88e-5d59af895ddc	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.150949
87eb2eac-e89c-468a-a8d2-fab252bd762d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.119052
e5620c56-9a65-4974-819f-5287fa20d813	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.149783
ac383283-bf4c-47fe-a170-b88c2062ca60	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.187746
c5c89838-1aed-47ed-8e6f-bfb875386b30	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.187732
6d36d820-2da9-4563-84de-1e6ad0148f34	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.252071
e8fee967-e671-44fd-9138-2ba96f6162de	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.225974
e6cd4f8e-aaa6-4582-9160-8372d55a8ac2	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.253125
910a1f35-280c-47b3-b4c4-701622a28879	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.334588
54fbcb60-6bfe-4f25-a073-009733b69891	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.334564
33ad16e9-5842-4420-a5fa-050fd49175b5	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.377802
eeaca931-fefd-464e-a19c-1f9e778f4d92	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.380406
4650aa60-6603-4dba-9fd8-83e3a25a9826	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.400341
1b7bf3bb-36ef-4888-aed9-6e9478401c13	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.403289
29cd0b6e-99c3-4fa2-9c51-a9b5c57bfcab	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:33.303054
84d48963-6b12-4195-ab1e-a27fef3a84e4	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:33.303993
b392d966-c79d-456e-9c31-d60c5bb71e7d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_372c0057-dd7a-49a7-8a33-343ffb6b6b52", "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.581606
23f8a3ec-53c6-4994-99c5-348e684d8656	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_c4587b3b-8894-4934-87f7-bbbb220dff6e", "intermediary_id": "272477c8-f90f-48be-96ed-f8a4b173f5d1"}	2026-07-20 00:57:27.498878
c04572c3-e0b6-4fc8-9f37-792e66a1a67f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.587685
d8a0b73b-08fb-4653-bd45-261df6b9c21b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:17.989916
150e6002-b127-47e4-984a-51a8ea68efcf	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:42.924718
14a087b9-6078-4845-a1b6-a878c3acf81a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:42.924344
a5654e71-57c2-4b13-b0be-5e7b86cf45f2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_29bb1dc0-9ba2-4a22-be1e-6bbc5b50c4ab", "intermediary_id": "08afa46d-7221-4c39-8cc8-28a6ca351592"}	2026-07-20 12:38:19.00209
9b91a3b9-06ab-4b16-a25f-2572e49a2af8	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:37.217263
edad7ab4-ddf3-4d55-82ca-a232bb8a1f1d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "5909326b-ceaa-413e-b64d-bf4e0f449e11", "intermediary_id": null}	2026-07-20 00:27:41.660709
1936561c-d7c4-4400-a922-5909003dc2c3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_c262506d-5e9e-4524-b127-18e386075683", "intermediary_id": "65fe6fc9-ced8-4da5-a89d-569cdc2c9cd7"}	2026-07-20 00:27:41.700241
fc84aa83-f8c9-4015-b0d6-9ff3d391b02c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "25c63507-095f-46fb-b072-d6516de68862", "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.8773
6acf5b5f-c080-4a7a-8830-28a703f17ef2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "c5a7d919-7d29-4b60-87b1-5c535305fd6e", "branch_id": null, "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.861874
50f7dabf-9d3b-4f35-8cae-39fd1bd54ab0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "23253086-957d-4f73-8651-f2e805ab510c", "branch_id": null, "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:42.00372
66c7f2c0-4671-4891-9e3b-6f9924ffe78c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:46.989327
3cb97162-fbc1-4685-b8a1-d256edda2403	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:46.99046
0d7d4b75-0932-4829-936a-2a3935a65fcf	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:02:47.042737
4241a32c-314f-4bd4-968a-9bbeee29f59d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:02:47.04278
c959929a-63d6-4c6c-9a53-36b9b525555d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.638342
352cfcf2-858a-46a7-8847-82089a75a9c8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "55b5f212-a03a-41c2-82ed-273fbbddf9b2", "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.642412
ce2e54a9-4a04-400e-8ba5-e4a963247dcf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "561f82a2-ccaf-4efc-9f40-fd5469b27c6e", "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.647934
d19788c0-75d0-408f-b535-aa746eb44c8b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "3705b43d-cc4b-4c9a-826b-54e32d74b5fe"}	2026-07-20 00:02:53.435395
f4784961-ea2d-4c83-96c3-24b8e9718316	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_4cdcd156-7c2e-4ecf-affb-b15586c84e9f", "intermediary_id": "3705b43d-cc4b-4c9a-826b-54e32d74b5fe"}	2026-07-20 00:02:53.433515
202423ca-8a06-4b68-943b-ef267a3aca31	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_e26140ac-a3e6-42a7-9b64-d67df3d751ab", "intermediary_id": "1992d789-ecb1-4deb-8c05-d970a615e2c8"}	2026-07-20 00:02:53.452165
22185f90-7c5d-4857-abce-88af5654f431	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "b693d70f-fd3f-47e8-914a-3e668541b903", "intermediary_id": "1992d789-ecb1-4deb-8c05-d970a615e2c8"}	2026-07-20 00:02:53.461102
ca2a5fb9-f63e-4e41-bd7d-8cae388028bd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "b693d70f-fd3f-47e8-914a-3e668541b903", "intermediary_id": null}	2026-07-20 00:02:53.472058
3950319d-63ea-4f90-a7a7-33438c01e71f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_ccd3fbc1-08c0-41d3-87b4-e8928eeae9f5", "intermediary_id": "3ec3c7a6-7afb-4adb-b119-df7908196b2a"}	2026-07-20 00:02:53.510245
a214e9a8-0817-47fa-a49b-aacfd34b00a2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "3ec3c7a6-7afb-4adb-b119-df7908196b2a"}	2026-07-20 00:02:53.515398
9d16a1d8-2a3e-41c5-bbdb-8006297febb5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "93309ae7-9e24-4be8-8b5c-2d5dd16b6dfb", "intermediary_id": "3ec3c7a6-7afb-4adb-b119-df7908196b2a"}	2026-07-20 00:02:53.520646
51b0a540-93c2-4789-925b-5718dc04cdfc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "1b3d2fa0-7b48-48d9-ace4-e924ed22b5d3", "intermediary_id": "3ec3c7a6-7afb-4adb-b119-df7908196b2a"}	2026-07-20 00:02:53.525748
73ae395d-9c00-42f2-95dc-408bfe19a999	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "0398e25f-2c6a-48ca-9016-b9782101fd12", "user_id": "5457be12-e955-4be2-a230-6071f48f24b9", "intermediary_id": "3ec3c7a6-7afb-4adb-b119-df7908196b2a"}	2026-07-20 00:02:53.534505
869d5c48-5520-4c31-995b-e7e95bf10ad1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "b2a4b6f9-efbd-4771-a8b5-3f71c588a056", "intermediary_id": "3ec3c7a6-7afb-4adb-b119-df7908196b2a"}	2026-07-20 00:02:53.555078
641c5f1b-ecee-45bd-b36e-e4903b1cf337	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_8558d822-bead-4403-b914-a720b99888ac", "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.586932
d21843f0-8a3e-4850-ae5c-ca47915539bf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.59594
10e31cb9-60a4-484e-88dc-6f9a5071c1f8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "55b7d753-1395-4de4-8792-d7ac03cebbef", "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.60206
ea44ef54-44f9-4814-9bc2-4992d7d4957a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "888b2df4-f8d1-49b4-b264-a39f0410bcae", "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.605515
35a7b021-9f93-4db8-a835-feece6fa7ca1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "e20ea0fc-36bf-47fc-bf1e-c785e592c9b4", "user_id": "4c164b73-a0f6-4f6a-b68c-830c899adfb5", "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.610324
0ef19c59-55d5-4643-bf82-0e41b8baf888	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "fa034b71-938b-49ed-aea6-bce633953533", "user_id": "26364842-7f47-41f4-ab36-cc974bfa337a", "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.616124
880693ef-27c1-4e59-9f1d-81334d63e0e8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "303bac97-41b9-438f-9bf2-9f221e42ce5e", "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.635834
8e580ffe-2159-4654-bf36-5394bd68c6c7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "303bac97-41b9-438f-9bf2-9f221e42ce5e", "branch_id": null, "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.656649
72fae058-9642-41f4-8767-d3a2f5434446	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "7c641e45-5b07-4dbd-ae94-4c94c256f374", "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.673553
281fb42a-5717-4839-a38a-8a0ae61b28a7	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.445474
07ccb881-dd22-40f7-9634-8c3c1d1448e4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_bac932b6-6450-4800-b2aa-7dea58ec030b", "intermediary_id": "1a292e5d-ec7b-4da4-81e1-0ef424bc877d"}	2026-07-20 12:18:19.389934
1fd32135-4826-4239-a9a0-eb5055bd3424	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:17.914811
26cbfc72-b7ba-44fd-b4e0-f442b08f895f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "eb8340ca-f626-4d1a-b314-bf60dc27f040", "branch_id": null, "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.818839
cec572fe-eae8-4219-988c-b54cb8b0da88	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_8be7279c-86bf-43af-bd1f-96dd4650535e", "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.78936
12f38663-cfb8-4a9e-87b2-83cd1faa5847	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.796662
085271eb-f7f5-4844-badd-ecd0dcb1f33e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "65d168f5-e412-494f-981c-cc1ce8603788", "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.802693
55da41e6-67f3-4f14-8797-200f8c86755f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "727b1a5d-e7db-4884-84d8-2f70bf3c9bc0", "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.808432
6cb80105-55b0-46cf-af87-0067742804e9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "e98a8eda-50b0-41f5-8641-397bac2d0f53", "user_id": "811af06c-806c-4502-bc65-4f2c8dc1a9c8", "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.815356
31be5f3e-b099-456e-b3ff-a802c6110904	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f09ed2c6-6585-4d2e-9c93-e8d1f5f1c1cf", "user_id": "ac1ec81b-a316-4d0b-af6d-0cfd97f9fbd5", "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.821499
16db9c50-f355-4aa7-8317-9311c22f7bfb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "c5a7d919-7d29-4b60-87b1-5c535305fd6e", "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.836086
f87545ce-4a8f-4e71-bebf-52e5b7bfbb1c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "69d6a89b-d617-4f4d-b332-c0bd028ea0e1"}	2026-07-20 00:27:42.030632
a757e62a-e8ef-4f41-bda0-9b39cc2ef86d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_b60759f8-c32d-479f-a22a-767dbe72f6ef", "intermediary_id": "5965b534-e89d-419e-91ea-e24b82119897"}	2026-07-20 00:27:42.048518
36612d44-d3d7-4a9e-8a3a-7159dff5c285	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "eb8340ca-f626-4d1a-b314-bf60dc27f040", "branch_id": null, "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.825132
570db16f-4062-43cc-bcad-da151d4e3112	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "eb8340ca-f626-4d1a-b314-bf60dc27f040", "branch_id": null, "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.836045
84390f34-b0ba-40de-bcf2-fd552d45e5fa	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_59495ff7-9cc4-4bfa-acf7-be30da1be382", "intermediary_id": "37f85e30-bb96-4c8b-aa4a-d80e822e0a9b"}	2026-07-20 00:57:27.842933
1641a6c0-6aff-46a2-a84e-97c0e1763a42	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "37f85e30-bb96-4c8b-aa4a-d80e822e0a9b"}	2026-07-20 00:57:27.84775
ea5a456a-50ec-46a3-a5a6-74e574f0c0b9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:17.951032
71902455-faab-4192-8587-b226d721d3b6	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:17.989045
3a491b09-6199-43f0-b4e6-efb9ce6e9613	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "97f6e2cd-fd65-4e0a-b72a-e622b9c40ccd", "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.326619
752c322e-f252-4726-b4bb-728af7c29a04	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:37.273858
18bde003-e8ae-48cf-a2cd-e9d7e4fdaa9d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_b8785f1c-0641-4a82-b3c9-e4bb82fb3b2a", "intermediary_id": "0e036c6d-60a9-4466-a0b3-06ad0a172261"}	2026-07-20 00:28:11.333113
3da7c838-d2bd-4f59-a0b3-ab6da95baa71	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "2b34011c-bc3a-4e0f-94c7-088514b5a353", "user_id": "e23047c0-e1ed-4cec-9922-2d35954cdb7a", "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.659966
dae1f296-e36d-44ad-9f14-57f49d9d79ee	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "b62c269e-3133-4a76-b5e2-5e4c2e78cb64", "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.676303
b50728d1-0b76-4faf-bf48-5ebeb4ca9791	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "48e2fdcc-6cec-4e4d-912c-83b093fa589e", "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.716018
7d44caef-3e9e-4088-95ff-b5e4a13a6d5d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "b62c269e-3133-4a76-b5e2-5e4c2e78cb64", "branch_id": null, "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.694765
a2bc971d-7683-4d5a-a3f1-ebc061fd6917	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "48e2fdcc-6cec-4e4d-912c-83b093fa589e", "branch_id": null, "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.725401
29f55301-94f6-4240-84c9-4dbd8bf1b6a6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_2c5cad7b-76d5-4bc4-a48f-a7e932e24fbc", "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.742689
c4f0b0e9-f3b7-4fa8-a007-3d7f6fdf51a5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.74756
337ea0fc-c283-43dc-95a5-0ad2a821ef9f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "34cae1ab-e50e-442f-8ec7-8ac7427f67df", "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.752301
b168c612-c294-4b87-b4e7-77fa6d0545d6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "db83b375-4321-4df4-8ab4-9ee092ad8535", "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.757419
3783b39e-8874-40cc-80ca-d33e4cc724ca	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "01072e63-1ab4-46d0-a072-ba600adb3d1b", "user_id": "5669388b-9959-4514-8cc3-c94c31edb584", "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.763351
c85f2cda-5ed4-42c6-a8a6-caae0a876eb1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "bfca50b5-9d08-4306-bfb6-e065b801a343", "user_id": "38492f29-9241-4623-853d-fe4aecbc3273", "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.768879
749f5490-0bad-4951-a5a6-4a0b7d740876	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "48cddbc8-69b3-45b1-944e-a52c7e9fce18", "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.784638
7268116e-c2b5-48d8-8bdf-d3a7e5571cda	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "48cddbc8-69b3-45b1-944e-a52c7e9fce18", "branch_id": null, "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.796833
b4706200-f826-4be7-8f1a-f311caad2c75	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "dda15a92-cb6a-4d05-9a29-15d891bc01be"}	2026-07-20 00:28:11.822842
ad0237f6-04d3-49b6-94cc-3229fce2f76e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_de9901f4-0a69-4759-a4ec-6121d4cd72a9", "intermediary_id": "4742a744-0042-4a95-8add-7589a7342c67"}	2026-07-20 12:52:41.57752
7e3c4511-9407-40f2-9024-484e77301ef6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_85a9a9bf-f724-4854-b4a9-cef28a04482d", "intermediary_id": "c717c05a-f70c-47a5-9ba0-4ca623fb6bbd"}	2026-07-20 00:57:26.930048
303b414f-954c-40c1-9870-b6522e917af3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "21f91c2a-8103-415d-a1b7-b16b3136ce1e", "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:41.958203
2090d199-2dc8-4922-b0a1-3170f6947188	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "d44161a5-19f1-42e3-83e2-d32575c06520", "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:41.963417
c214131a-6479-4722-8c24-d821537fd0ef	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "3e85c913-73f3-4b0b-9097-b2bda069eca1", "user_id": "37af22a1-fff5-4537-8d0f-9bfb28a32dce", "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:41.968616
609da1b8-c1a7-484e-a2d9-5df5378418d0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "7c641e45-5b07-4dbd-ae94-4c94c256f374", "branch_id": null, "intermediary_id": "b41206e0-4f52-40b9-b278-19e293a72465"}	2026-07-20 00:02:53.686433
64a9a22e-050d-40a0-8814-98a533e35446	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_c734bdfe-0a10-4baf-ab3b-e79f4795ee43", "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.701452
efa5bfec-a971-40b2-b22b-bdcf1650b893	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.711658
10ef8d9a-c48d-4f70-9826-fb953cf4fed2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "67e13eb6-652a-41af-a604-85e27e7f9bfa", "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.810712
6e2fae50-1b21-446e-85e4-5d35df7b5e36	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "da9494c6-f867-4406-b2da-45a93a89b503", "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.815747
7e5a2c28-3442-4d1a-9b05-9691d23367e7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "10621efd-fb30-4698-8e5c-87f9ccce93e0", "user_id": "f53329bc-a23a-4d44-8fb5-e5a8da765e7c", "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.820782
1b9568fd-1ca5-4f36-97bf-3cefbeaa9d14	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "94a54337-c755-4808-838d-d93d50afeb95", "user_id": "b3aca438-3a05-491a-8118-efe4bd206dac", "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.825563
0ff7e37f-5659-4fdc-b0ed-96466cd7b8af	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "04eac0cb-40ee-4b1e-8071-0d8a28d5f54f", "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.841974
99e3f1c6-5aa6-4dd9-bfbb-8f20ccd00825	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "9ec25a52-cadc-4b71-8712-192eb0a622fb", "user_id": "aa5ea8ff-d496-44f9-931f-998919801af5", "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:41.973793
165193aa-2985-47e8-869d-e25c7f332fdc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "23253086-957d-4f73-8651-f2e805ab510c", "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:41.990407
c6467c31-e692-4dc5-814b-db568fb04f1e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "c717c05a-f70c-47a5-9ba0-4ca623fb6bbd"}	2026-07-20 00:57:26.940429
c3c5c213-a103-4a7e-bbda-5cfbbb1a1e7e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "393ca3aa-c012-4e7c-9d75-795352bef6ed", "intermediary_id": "1572df1a-8b29-44ca-a982-ae83d7d1bac3"}	2026-07-20 00:57:27.444365
f02a9406-450a-4d8e-b502-b81f98a0c4ab	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "393ca3aa-c012-4e7c-9d75-795352bef6ed", "intermediary_id": null}	2026-07-20 00:57:27.456318
9b996a3d-ae8b-4406-8cfa-8f0f64420452	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "272477c8-f90f-48be-96ed-f8a4b173f5d1"}	2026-07-20 00:57:27.503212
014f3209-69b4-4b2a-b086-538f5b138978	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "e5c9399e-223b-4e34-9959-7786e163164a", "intermediary_id": "272477c8-f90f-48be-96ed-f8a4b173f5d1"}	2026-07-20 00:57:27.508458
178a5afb-a84f-42a0-bc1d-67fd122671b2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "5a4aabf8-de72-4e03-a370-9e15a9ac40a4", "intermediary_id": "272477c8-f90f-48be-96ed-f8a4b173f5d1"}	2026-07-20 00:57:27.513043
525cd0af-4705-4a64-8117-83160907cf18	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "0e036c6d-60a9-4466-a0b3-06ad0a172261"}	2026-07-20 00:28:11.33683
940b9be2-4f0a-420e-97c3-a04cbfe65633	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_f6c1aed8-3c25-4402-bd9b-5c58d72bbfa6", "intermediary_id": "cf063eef-5f26-4b25-8de5-5f0b4dbcb601"}	2026-07-20 00:28:11.346712
d0f11307-5db0-46ae-a210-c112c0103164	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "c876d18c-9899-459a-8018-bcfb3a0171a4", "intermediary_id": "cf063eef-5f26-4b25-8de5-5f0b4dbcb601"}	2026-07-20 00:28:11.484203
efc75ef2-7d70-4f52-bfc7-d07729a37154	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "48cddbc8-69b3-45b1-944e-a52c7e9fce18", "branch_id": null, "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.803144
89437295-29f1-4b06-8cdb-e7907cdfb15f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "48cddbc8-69b3-45b1-944e-a52c7e9fce18", "branch_id": null, "intermediary_id": "ca3635aa-ff9e-47cb-ab82-537cc4ee3117"}	2026-07-20 00:28:11.812597
28113641-ca44-4b6a-9a5c-97d151cbc5aa	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_b1c178ef-aa54-4190-ae9e-c54eb606e0ab", "intermediary_id": "dda15a92-cb6a-4d05-9a29-15d891bc01be"}	2026-07-20 00:28:11.820742
3293ad01-bd8e-432c-ade6-ceb4cfc64b16	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "af003bb1-5df0-4a88-83c7-08c13c55cf4e", "user_id": "9165690a-60c1-4ed2-90f1-3ca427e111cd", "intermediary_id": "272477c8-f90f-48be-96ed-f8a4b173f5d1"}	2026-07-20 00:57:27.519502
1b7f4ed2-7aee-4462-ab61-dfd241b41049	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "6fc6cb5a-c237-4675-926c-4259c82ac395", "user_id": "d6e615f8-c7b9-43d5-87e3-cef20dd9df9e", "intermediary_id": "272477c8-f90f-48be-96ed-f8a4b173f5d1"}	2026-07-20 00:57:27.524126
cb75519b-8fe2-419e-bf91-95c46d93ec8b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_72a86006-af31-4be4-80fd-ed4118c64a2d", "intermediary_id": "cd93f448-c115-468c-b91f-415a365235d9"}	2026-07-20 00:57:27.865319
8f70cbd1-345a-4deb-9a94-831e338c98ac	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.460666
75dd8f23-b6c4-41f2-b130-3d90effe9f03	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.780003
662bd7a1-b1a5-4c84-b853-68caeed2b4b2	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:17.847776
b7bb6a32-9638-409f-a46b-9675737c869c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:17.877981
50cc1188-39a7-41f9-9c18-c6a62134f1b2	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:17.911132
779d698e-6fbb-4a5c-b53e-8ca8643e58d4	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:17.94434
a23d5825-6104-4aad-91a2-efcc246c917b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:18.083256
3b2ff052-441c-4f6c-a91e-fca0a06a9aae	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:18.104422
e383e891-925a-42f7-a74e-3485c7e6165e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:26.733914
3fa0c642-9362-454d-b7b7-ec4e73db2885	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "073c6b57-9b70-4a0f-9c86-a15701ea8cc0", "intermediary_id": "1a292e5d-ec7b-4da4-81e1-0ef424bc877d"}	2026-07-20 12:18:19.451661
976e5cdb-8d71-4449-bdae-c986253f34be	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "4742a744-0042-4a95-8add-7589a7342c67"}	2026-07-20 12:52:41.587531
f9eaaf8f-7c15-4ebe-a4c8-97260a7dc793	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "23253086-957d-4f73-8651-f2e805ab510c", "branch_id": null, "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:42.010033
e7b82120-c43a-478b-bba4-d095a659e264	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "04eac0cb-40ee-4b1e-8071-0d8a28d5f54f", "branch_id": null, "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.852778
e39b9ba1-27e5-48e9-9ed9-e21a52e1533b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "04eac0cb-40ee-4b1e-8071-0d8a28d5f54f", "branch_id": null, "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.859509
7f6305eb-720d-40dc-be57-40a515b98657	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "04eac0cb-40ee-4b1e-8071-0d8a28d5f54f", "branch_id": null, "intermediary_id": "6f46e70f-e590-41d5-81bc-eaef5bb15dc0"}	2026-07-20 00:02:53.867706
94ec793e-5a61-46c3-b088-84d831354ac3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_3114d653-2c42-4c52-a7e9-599a17e754e3", "intermediary_id": "f5deec2f-d716-4748-860a-7041931c0b5d"}	2026-07-20 00:02:53.875669
3f5fddbb-602b-4fb1-882d-b2cf49d59554	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "23253086-957d-4f73-8651-f2e805ab510c", "branch_id": null, "intermediary_id": "c20eaae7-3fd8-4802-88b3-3a6e945a723e"}	2026-07-20 00:27:42.020124
7954f93e-382d-44cc-8a96-614edd13ccb7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_6babc3d5-1442-452c-bf70-8513408d91a1", "intermediary_id": "69d6a89b-d617-4f4d-b332-c0bd028ea0e1"}	2026-07-20 00:27:42.027463
1510e9d1-56ec-4eab-a7f8-6c4d27265f18	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.425693
b33d2f19-4ac3-4f98-9398-ff3f83322f1d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.463497
5a6f89ac-9af1-4d5e-84d9-be3649f5317e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "dc697365-9e02-4563-8748-1d9595a7c93a", "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.678707
07901104-b66d-4be9-8105-9ebe6d837d60	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "c876d18c-9899-459a-8018-bcfb3a0171a4", "intermediary_id": null}	2026-07-20 00:28:11.501562
4cf7e62d-f5fa-45e7-8bbb-e76f58221657	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_5f24f891-d264-44c7-b7de-a614a3607837", "intermediary_id": "723afd44-1a75-417a-9b89-0920035aa70b"}	2026-07-20 00:28:11.546819
16f916bb-2c6e-4932-8c6b-81f3c79dea14	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "723afd44-1a75-417a-9b89-0920035aa70b"}	2026-07-20 00:28:11.553367
4210b543-0a53-4bd2-84b8-5a5f4b1e622b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "b21898af-a8a0-48a0-8f2b-1d1530010a4f", "intermediary_id": "723afd44-1a75-417a-9b89-0920035aa70b"}	2026-07-20 00:28:11.557862
2d7785ef-fdfc-4e5b-9f68-fbf81672a58a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "f5a612f9-13b3-46e3-92e8-6aae29aa8b36", "intermediary_id": "723afd44-1a75-417a-9b89-0920035aa70b"}	2026-07-20 00:28:11.562966
54136ae9-606b-4701-8d79-16a4f78996d3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "de587465-6ec7-4d36-b232-618c673adcf5", "user_id": "d7eb7f62-668a-44dd-af5b-6ffb5feeddf0", "intermediary_id": "723afd44-1a75-417a-9b89-0920035aa70b"}	2026-07-20 00:28:11.568978
9c1b4c22-9478-4ae4-9cdd-8b584b7f68bd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "8c09c088-a2f4-4e66-936e-1bc3de8e0584", "user_id": "933efb46-88b2-48fe-b5a0-0bc1957216fc", "intermediary_id": "723afd44-1a75-417a-9b89-0920035aa70b"}	2026-07-20 00:28:11.574552
5ee710a4-9060-47d8-9dba-42afbf146f0b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "08099a37-3989-4717-ba9c-4f1c8559abc9", "intermediary_id": "723afd44-1a75-417a-9b89-0920035aa70b"}	2026-07-20 00:28:11.588385
73beeb31-70fa-40ab-b259-91d0abd4e36b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_fe892c5c-1181-4d10-bce8-daa8262673dc", "intermediary_id": "870e51df-56b8-4604-836d-e510bddc89e8"}	2026-07-20 00:28:11.842493
7bee0688-f070-42a2-8bf2-9be4abbc96ed	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "a7d687e6-5d50-4db4-b801-329bc1bf7b9b", "branch_id": null, "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.752882
cfe1b087-a135-456e-a18a-4f176089e8ac	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_e992a4af-8d8f-4c98-a19f-464ad5a8a86c", "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.767552
21436c1b-23a6-482c-98a2-a0c3bf393944	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.773269
58b6f76e-b851-4786-a807-86a043945177	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "a02bf6eb-6637-4e11-961b-9e50e501fce5", "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.777471
d94c063a-4b32-468d-89aa-d0a00e13e92a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "a2028bb8-0968-4362-afe0-87425233bccc", "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.78317
79edec83-873a-4487-9cfd-1b546eba4e25	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "2af29c6d-700d-4ec3-a624-11cd537dab14", "user_id": "ef7a6c91-9264-4888-8e79-10f4cc981065", "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.787404
e51948fe-389a-4838-9b3a-c6fc409c89e5	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.769294
50e66df3-2f8c-4d90-9503-c044c4af8bf4	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:35.680699
5ab6459f-e085-47ac-8125-d810cbc415b7	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:17.879267
7cd50f0c-ee10-405e-942c-e1c1e19f0fa6	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:17.910813
a5b1cebd-8380-4245-a3c7-e7a3c7c2eb49	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:17.945517
75080697-57d3-404b-8253-ae29c1091c6d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:17.967006
b7f30d1b-7696-4d81-9ccb-b9796d8cd338	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:17.989955
5beb09da-c271-4a46-8850-ae454ffd0e9f	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:18.045344
00ba79c8-d0cf-41ff-83d5-941ac6775cbb	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:18.085089
cdb06f10-823f-479c-9308-1902d0bad8d2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:18.105233
ca34e402-44c5-42cf-8d6f-5fff6001ae7c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:40.693693
f0356cff-c513-44d6-8fa2-958dba177524	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:40.73531
940bbf40-bc24-48c6-9967-0335927a61a5	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:25.693422
60f8d419-0259-45ed-8b84-f59158ae714e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:40.774648
b7d8649a-a526-4214-999f-457dd185b34c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "994f232f-7fc3-4069-b9ae-f50f2e9c5fd5"}	2026-07-20 12:34:41.92964
e6d40b0a-8414-4a33-9fd3-186467f36ba1	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:26.735311
cf7f334f-a9a9-4fbd-a6df-4211711e4804	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:26.787045
3d7651ff-0725-481b-957b-0d2cf0369c37	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "29f76205-7854-408e-a91b-1bcd8cb7484f", "intermediary_id": "65fe6fc9-ced8-4da5-a89d-569cdc2c9cd7"}	2026-07-20 00:27:41.71787
c004c008-c5e3-4ab9-8d55-35938089b725	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "214a216c-e915-4450-aab4-688ae05b7c68", "user_id": "570e8a46-9c44-4eaa-8f44-9205be2df98d", "intermediary_id": "65fe6fc9-ced8-4da5-a89d-569cdc2c9cd7"}	2026-07-20 00:27:41.724434
c96086bf-e698-4b83-8444-56ac359c1067	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "27aaa8b8-ad9a-4abf-b55b-806f13d4b9d8", "user_id": "73d4c30a-5dd6-4e6c-89c7-702991c85df6", "intermediary_id": "3ec3c7a6-7afb-4adb-b119-df7908196b2a"}	2026-07-20 00:02:53.5406
67137eae-1efb-4b67-af3e-3a422a45bfbc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "f5deec2f-d716-4748-860a-7041931c0b5d"}	2026-07-20 00:02:53.878596
66187a73-6b56-4d28-8fc6-65ebd7d1be2a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_f52a3b61-0e8f-4af2-afe9-32c527e8fa79", "intermediary_id": "ddfbd21f-d163-499a-9e2d-921b25f8ab9d"}	2026-07-20 00:02:53.897653
cf6df904-6f2a-4154-8ff4-5959a7e2197e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "3e112aa3-a031-4121-900f-f9acf6d1025e", "user_id": "3edef6f5-d5ee-4f7f-8ab4-3e278a8c0d3a", "intermediary_id": "65fe6fc9-ced8-4da5-a89d-569cdc2c9cd7"}	2026-07-20 00:27:41.730163
f348b5df-b3b2-4cd5-8b46-7db296b02911	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "15fa37d9-b1ae-47ad-b6e7-44dccf642427", "intermediary_id": "65fe6fc9-ced8-4da5-a89d-569cdc2c9cd7"}	2026-07-20 00:27:41.744371
b26ae176-fc0d-46e7-bef2-e8aeeabd2c81	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "25c63507-095f-46fb-b072-d6516de68862", "branch_id": null, "intermediary_id": "48cb6204-c32a-4dd6-b52f-a75bf6b43015"}	2026-07-20 00:27:41.892346
085d254b-6901-429c-b047-34f7659b56ca	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "6efcae6d-4435-4db8-b1a7-9d9bf978afa5", "user_id": "564465e4-caea-4c9e-9028-6318b377e933", "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.652785
de3a1939-6fe2-4487-abb8-325ca9f2e817	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_8eb43988-11dc-4a4d-bd0a-45465f12b5ce", "intermediary_id": "3709db49-ce14-4d6f-96eb-4a6a2b94f419"}	2026-07-20 00:28:11.634218
74438d31-d382-4ea5-a9a2-f2cf78c22c22	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "f0ea3b6c-e95f-4c27-88bd-d54e0284704b", "intermediary_id": "272477c8-f90f-48be-96ed-f8a4b173f5d1"}	2026-07-20 00:57:27.536317
5b74d5ef-4b98-47df-9511-86d227ac9fcb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_07685fd8-5982-429c-aa7c-f695c700b3de", "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.569735
f068d74d-668a-4733-8f03-d39a1e43fe7b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.575874
8a5af08d-02b3-4b98-a16c-dda3f2d3e882	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "2012ebb2-2373-4310-889e-7c2de9687443", "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.580302
ebbdce18-1d12-4e12-9244-2b09074a56aa	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "e9662fe3-ba18-4382-9780-960a9c7ffc52", "user_id": "04e1984f-ee3c-4572-b4aa-2d8d0d66c07c", "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.686299
cb6b2b67-802f-4890-b1c2-816dd3bc5877	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "241b6c17-2eac-4b91-b60a-f01bb91c182c", "user_id": "318a09ef-8fe3-44fd-805f-81a5cedb4553", "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.692664
c2429813-5a6b-4cc7-a8ce-6d94ba447276	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "9ae4248f-0a5c-46c6-87f8-a7fb6acc3599", "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.707352
6689695e-9113-4310-9b01-501769d4431d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:17.847799
2c28ff34-6758-48b0-bf28-0b2f3ca62383	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:17.967514
a3f79ba7-113f-4088-8cd9-73ca04f3ea9a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:17.989437
e7ba6276-46d8-44a7-aeed-c2adc3276ca3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:28:18.045293
eb8d8029-3d3d-441b-a590-0cdd2d0ef072	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "a7d687e6-5d50-4db4-b801-329bc1bf7b9b", "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.741406
2827e670-0a3c-40d1-9956-2e533b197d7d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "9ae4248f-0a5c-46c6-87f8-a7fb6acc3599", "branch_id": null, "intermediary_id": "6346c8fd-3d1a-42e7-b629-08323c8d93b2"}	2026-07-20 00:57:27.724318
4c6d3012-b73c-4a04-b04d-b7e1cca606aa	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "315bc8fa-1cb7-4372-b61f-b5f1ac6ddef1", "user_id": "919599e0-8c66-490a-9ee0-d6bf40ba55fc", "intermediary_id": "7cf6efab-3ccd-4ed9-a37b-3ef260825f5f"}	2026-07-20 00:57:27.792499
edee5649-6dd3-48ce-9a77-ba954896fc3c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.323654
17f77ab2-cf72-456f-ac72-b4e03f3ac1ca	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:25.694749
7fa4b302-0cbc-41ed-8393-00c850595091	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:18.114273
976ce25f-b3dc-4b40-b0c9-305fc391fc2e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:28:26.787053
76acd391-9ae9-4565-8a54-84cc58bc90d8	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:18.13851
7dc84d6f-6253-4003-afc7-a254572da112	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "2f921a2f-ac7f-4ff8-b9c3-bbc31baf9ce5", "branch_id": null, "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.70051
578e881c-a616-4d17-b8e3-cc5d26196d68	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.562688
39008b8c-7194-4b45-bba8-0a39f6323bf0	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.647499
9774f921-b397-4ece-8f8a-30bb7a950e46	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:37.274034
cd1f3991-d9b0-41aa-8334-31224349996f	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.531465
273a156e-a131-4757-9895-1129f19b3497	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.61806
bc06715b-34c2-4a42-b61c-46e1ef5febfd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.714164
ca344ee0-8861-4403-8db5-d79175d4979c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:37.838616
335192e5-96b7-4410-80da-bd9068aec109	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:37.941984
24fa7d0f-6262-4ddf-a280-6c162ea0c98f	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.150068
59e3869b-f5ab-467c-948c-bc6ef2552aeb	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.151345
72b4f1af-cec3-41a5-837c-07a04a528559	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.255994
36ecc222-59d3-495a-b10b-f488b28fb001	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.281618
c166dc92-97b0-4c3b-9438-e1846903f088	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.282108
6e056bfc-87fd-414f-b4bd-be481c193e06	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.300045
8278e695-9d5d-43e1-9208-e1ba73fbac12	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.300908
aef7dffc-7931-400f-a4d6-2ca98de660d5	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.331369
5be8d8f7-d098-4148-9948-23959d77f170	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "2f921a2f-ac7f-4ff8-b9c3-bbc31baf9ce5", "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.683805
6172e18a-3219-44e7-a289-61c1d67f37f2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "0133f4fe-01cb-42c2-a645-625931a73edc", "branch_id": null, "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.666884
5d3919f0-1fc6-4f57-a33c-1d781351a624	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:18.139154
8523c74a-5406-44d4-a011-59945c74f834	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.181085
00f76f38-ce18-4667-b1f7-c1a43888bc33	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.180914
c990edec-e37a-4597-8f27-d053b0fb39be	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.254796
620d2247-81c3-41c4-a8ce-cd163b8aafd8	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.331369
319e1fa4-b7c6-4dcc-8c67-05c2e09f5bf1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.376838
2f8267c8-2c65-4d11-8631-add45b396fc2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.377504
7ac60aa9-0a68-409e-89df-2421fb55ba5a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:35.398797
e734ce43-8e72-4d74-9491-a684d680d26b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:35.399667
bf02a894-164f-4a7e-9b89-533c35d21372	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.780419
46c28f73-011b-42d8-a91e-1b6e4bc509dc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "a5335ed7-4cb1-4f7f-839f-7a4df19eecec"}	2026-07-20 12:53:47.439683
b6bc8bde-e6d9-4542-ab4c-93b45a5ba9fe	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.531366
a6291d88-dc1c-4ba8-b741-20d3250ff613	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.647845
04896ac9-b781-49bf-aa29-939f41110ae9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:40.574481
385cdf64-16a9-4ea8-8a9b-4ccafb25dc9d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:40.574496
183e138b-f1b1-40ce-8574-82cff9c03fcf	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.532993
5cdb98c0-4439-4f8b-904a-fd0ea9a476c9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.617256
696d287e-7fd2-417d-bba8-caa0794b067d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.967783
e089dbdf-ff78-4630-80f4-bec8e9f958f9	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.991584
6e614be1-9723-494d-a677-254b493d96e8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.095094
2a751dbc-c18c-483c-8262-d3e7f561d763	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:37.840048
c380262e-b4e3-4b8e-a98a-4fa26ef7acca	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:45.917008
7a80841d-b79e-4f14-bd29-9ae2867225d5	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:45.917952
7b3ad8d0-3913-475d-a93b-0f03c86d52b4	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 00:57:45.968708
9315e90f-0295-472e-bd0b-ab576e314d02	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 00:57:45.969734
ee0b6ba0-7409-4ab8-ad90-598c9a3ef3c0	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:49.726518
7334a22c-95d7-412a-9173-0816839dfcb7	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:40.949698
e9683451-f79d-4ba2-b18c-2c6cbc51ca98	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:41.060574
51c3c3b2-e55e-4fc7-9c9b-0c26213a0448	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:41.079039
ffe401d9-e21f-4dc6-a11e-378a23ff0e08	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "44b24f13-3a62-4c95-92e2-6235c3e7588c", "intermediary_id": "388c503e-6ea0-436c-b375-710fcd06da0a"}	2026-07-20 12:34:41.951656
d6d15379-1ff1-4dea-b6c1-f6def13470d1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_7c0b31ca-3b9d-4e70-829e-3a18812744d7", "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.086492
86e43811-c6e4-4a42-9289-ab9b9db37bb7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_bf907a79-f1f2-44e5-aa5d-54d706eca707", "intermediary_id": "8a585301-eeb9-43bd-ae1e-c549771f0525"}	2026-07-20 01:00:00.11191
eafb51ed-8701-4910-aa94-cb81ba5a59da	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "8a585301-eeb9-43bd-ae1e-c549771f0525"}	2026-07-20 01:00:00.121552
130decc0-f689-432e-9313-34ed4dd28a95	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_af249e47-f2aa-470b-b3ca-86a278ec54be", "intermediary_id": "ca49f597-75bf-452a-b386-a19c9dda8549"}	2026-07-20 01:00:00.147253
3f758070-e6b7-460c-be26-ff6e72c6eb6a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "06859099-12f2-44cb-bdb8-40c69c6087be", "intermediary_id": "ca49f597-75bf-452a-b386-a19c9dda8549"}	2026-07-20 01:00:00.157632
b6d1da1d-1954-421e-961c-3f4888aabac5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "06859099-12f2-44cb-bdb8-40c69c6087be", "intermediary_id": null}	2026-07-20 01:00:00.169481
1a88ca87-e601-40d9-9bf2-9cdb4b980a3e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_a7ed7553-5667-4a44-827a-92db25906a9c", "intermediary_id": "b61377bc-bad1-4e32-8bdf-1e52248b1c2d"}	2026-07-20 01:00:00.209779
f60d31c3-8da7-4766-8986-7e248acf44d7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "b61377bc-bad1-4e32-8bdf-1e52248b1c2d"}	2026-07-20 01:00:00.214853
ca8748bb-a08d-4c8c-9317-a605c1a7f655	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "9d2b6dee-4f9c-44cd-bcb6-95338e158642", "intermediary_id": "b61377bc-bad1-4e32-8bdf-1e52248b1c2d"}	2026-07-20 01:00:00.221064
c1a59fad-8ae8-408e-8525-2eb82c2f0617	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "d59c9577-a250-4638-8fb6-9c321d491bc9", "intermediary_id": "b61377bc-bad1-4e32-8bdf-1e52248b1c2d"}	2026-07-20 01:00:00.226757
6ba15e5e-d8a7-4a1c-8bfd-4d398ad63bc8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "6a8c7b76-8857-44db-926a-8f1d4b3c9db4", "user_id": "4fb9b687-bf6e-48dd-828f-fdfa744351b7", "intermediary_id": "b61377bc-bad1-4e32-8bdf-1e52248b1c2d"}	2026-07-20 01:00:00.232885
2f41b26e-2898-4427-a3fe-7a5f06d07b62	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "ed811f16-5ffb-44b0-ad89-56934a0c7659", "user_id": "369d3fe5-eb70-4778-aff9-014f500e1ee3", "intermediary_id": "b61377bc-bad1-4e32-8bdf-1e52248b1c2d"}	2026-07-20 01:00:00.239173
c1183fdc-8a01-43df-92bb-959f90cec95d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "2740dd45-c3e0-4598-88b5-cb9712cac46e", "intermediary_id": "b61377bc-bad1-4e32-8bdf-1e52248b1c2d"}	2026-07-20 01:00:00.254412
0d22d1be-dea6-45c4-a72d-382046926e2c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_46a9e45d-8f8c-4bef-8225-ce8bd12aeaa1", "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.298673
78361a6d-919e-45a7-8e26-dc8da027aee9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.312328
4f5e2ca9-4441-4ca9-ae44-93ab38f8a685	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "462dc1c1-ead6-47ad-af15-eafd19b4435e", "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.318657
f3e56076-d1e4-4321-aaef-24bbfc065a0a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.0902
d7b0db00-fe9e-4e83-ba6b-a658f4bc0060	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "c0c04146-3bd7-4728-a1d2-c685ff67947e", "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.094908
365d6ade-36db-42ec-a09f-11ce12ea07bd	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:03.223254
ba1c3e79-f539-4184-be59-7fbf5731e3e9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_4ffdfd32-4a16-4bb4-a3dc-15faad434da4", "intermediary_id": "e13bb1ff-f001-4031-b975-3886dffe9604"}	2026-07-20 12:18:19.282673
4c4059fd-9ed0-4675-ad6c-6fb1dafae7b5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_1f6fb474-4b7e-4d77-8bc8-22e2df620b60", "intermediary_id": "ba358d6d-bbd8-41ab-a53b-4221ba3942bc"}	2026-07-20 12:18:19.313358
940d5240-c8e1-46ba-a72d-d25ac8d0a42c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "659150ca-2919-48db-883e-68b39280479e", "intermediary_id": "ba358d6d-bbd8-41ab-a53b-4221ba3942bc"}	2026-07-20 12:18:19.328791
30acd686-c8fd-43e5-b217-5e39faf2a417	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "659150ca-2919-48db-883e-68b39280479e", "intermediary_id": null}	2026-07-20 12:18:19.343604
1497ef3a-3585-4ce5-ada6-5dfebb8d4b9f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "1a292e5d-ec7b-4da4-81e1-0ef424bc877d"}	2026-07-20 12:18:19.39617
d7690227-8596-43f2-8d59-1c8da3680cf4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "213c290a-a26b-4800-8f1e-dbd99015d08e", "intermediary_id": "1a292e5d-ec7b-4da4-81e1-0ef424bc877d"}	2026-07-20 12:18:19.403187
9edf881c-89fa-4292-be0f-d9740a5a3f40	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "b8a555c2-a2e8-4f35-9327-12befdce4ff3", "intermediary_id": "1a292e5d-ec7b-4da4-81e1-0ef424bc877d"}	2026-07-20 12:18:19.409413
ae89a96e-f47a-4688-b294-17d2bf2c20e2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "cdd999e2-d258-4751-b222-800e514451d3", "user_id": "d2dd84c7-8ec4-4d64-b794-90bde86b5d2b", "intermediary_id": "1a292e5d-ec7b-4da4-81e1-0ef424bc877d"}	2026-07-20 12:18:19.416227
ac04cfba-de7a-4623-ae43-0600391ec0db	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "88e04602-4ec4-4b09-aa8f-6399abf396e9", "user_id": "1b604416-12c2-43cd-a544-37d29ec3d799", "intermediary_id": "1a292e5d-ec7b-4da4-81e1-0ef424bc877d"}	2026-07-20 12:18:19.422538
57eecce2-ef56-485d-9e31-895a4bc9b1b8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "e53bf542-f1a1-426e-b4de-b39b2e900775", "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.593818
91cf9bc1-625f-454b-8d33-d23e259647d3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "c63c0c8f-9bcd-4a43-894f-bdd910034280", "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.606967
a17baf75-26a0-436e-bf33-ea8d7a58d596	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "a042b232-fc32-4615-997e-d85d44850cc5", "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.323966
866f3b25-5341-49b8-a9c0-c340b9c00d12	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "4f67b3d4-8aaf-4372-be55-bb1a4c6cf913", "user_id": "62c26295-b354-4358-9258-e078942295f7", "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.329899
5d64b4a9-f2ed-4ac7-ba8c-124552a410ae	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "09ecae3c-36ac-48ca-9d30-2b1fc3a6df60", "user_id": "8112ded6-418e-4a46-ba81-e98956b1fe7c", "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.335374
79c30e00-78f8-4927-b5d9-be1bc3624987	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "ddc6d633-e89b-4849-8ebb-186d6d65f0f6", "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.351281
d278745b-28b7-4248-9173-57352b67665e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "f74be08f-3c81-4a58-b4c1-1e75df979fed", "branch_id": null, "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.40586
239249bf-f554-41a0-b9d9-8110e3507677	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_d2defaee-3833-45ff-845b-af894933b04a", "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.422628
34753c2b-8f56-4464-b587-09f9078da279	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.434688
4dfd314c-27de-4ec2-af37-a848a30152be	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "a127bb9d-1dcc-4111-a02e-485a9146f37c", "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.439175
1b9f43c6-46fb-4ef5-8303-f1033db75c37	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "dba8e5b6-a13d-43c9-b458-b5090b949422", "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.445281
184022d1-d9eb-4fa6-80ce-0903ef6b515e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "243b550f-ab17-4d3b-9d09-cbe65bcfe9e8", "user_id": "f1924b64-483f-4ebc-ad6e-8af76a0f91b1", "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.450153
a04480e0-5f80-45be-bf92-c75a4269ddba	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "645b4f0b-dd28-486c-a986-e77ba536b5e7", "user_id": "a5b53c9b-66ab-4f87-b844-ca4fe3843ff3", "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.45481
3e208cdd-bc80-4e58-8535-93169d669036	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "e2885f4d-8263-41cc-8962-a63a07bbd357", "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.469499
ec0a0386-2579-47c6-9af9-100ffe28a0ad	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "c3fa2af8-a346-4168-9c1b-52c43533f6e6"}	2026-07-20 01:00:00.508249
40b68931-6f7d-47eb-bbba-cb2bca9137e8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_64fbfe65-5f60-4b16-8511-fe2b50d6622e", "intermediary_id": "c3e88a38-8dab-4200-a2cb-c9335050bd85"}	2026-07-20 01:00:00.527505
bb8eeb0f-87b3-4abb-ae0d-4a2d5eeca07f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "ccc606ff-e650-4854-8c0c-4b1b70d78ef3", "user_id": "f1b2b259-c43a-4ee6-9bdb-30b39000d6ee", "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.613595
d6a322c3-41b9-44ab-a5d1-5a3c8860e6ff	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "5e5541b0-c1b6-4d78-9c54-888d99d107d6", "user_id": "06841662-beab-4713-bf49-1ccf52872c70", "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.620521
26a6e7bb-fadd-4cad-8834-1d3e19b2bac9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "0133f4fe-01cb-42c2-a645-625931a73edc", "intermediary_id": "3b730755-ac30-4cad-904e-3c76f431ceb5"}	2026-07-20 12:18:19.639485
a55231a9-5a1a-4d45-89b7-1462a9140708	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_96be3e55-f00a-48a1-96c5-6d9ffff84b1e", "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.717192
60d252aa-697e-4a1d-a3e1-17e6c833ac41	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.723837
a66d08b1-5bbc-4d29-8f2b-ea73946abdfe	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "232ab909-d48e-42f2-b688-6f4a8c6d8430", "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.728921
2ed43589-beb3-4255-81a2-0cfe95a0ef82	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.687014
3d079eff-9433-40a6-aa5e-5a0f67f9cc93	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.715375
a555cdd7-6453-4763-97dd-feea8b3e0844	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.708151
7e71c4dd-37c6-495a-93bb-00f0af262506	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:37.942456
0c95e2de-c653-4840-940f-fa4a2176bd39	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:40.693734
0b1c34ce-42d8-4684-9e8f-0789e76a566e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:40.734299
c09dc0de-8b3e-42bd-92fd-e42cb11b09d5	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:40.77393
20fc0323-947a-4c2f-b600-c6a6f86f8931	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "f74be08f-3c81-4a58-b4c1-1e75df979fed", "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.393938
7fd5d6e1-ee19-4319-b587-b36daf098f16	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "ddc6d633-e89b-4849-8ebb-186d6d65f0f6", "branch_id": null, "intermediary_id": "b0a65ad5-c230-4ac9-9bef-e53934c85ab6"}	2026-07-20 01:00:00.371526
940cc3f3-ab6e-482b-bec6-1477b2c6c032	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "ffa71b98-38cd-4a5f-81fe-1bf0eff2f1ae", "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.732697
0065c4da-da6e-4fb4-b437-71c2c1bbc7cc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "2d4eaf36-6f5e-430f-87df-0009f4122f23", "user_id": "996d4929-b4fd-4111-80e0-0a0d1485c4e0", "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.738621
14ea096e-47b4-4920-aa84-2c73d4c19085	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f9bbd58f-96c0-4e13-a64b-0e51119ac96c", "user_id": "a300ae26-91ff-43fa-9237-4d83f7a68041", "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.744511
20d0ce1b-c374-470d-98a0-a1d29195210b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "6d0b324f-203b-4576-8b6c-967cc19e9e14", "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.758547
f49d891e-08a4-4d31-9229-398af9239536	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.691284
43aa6a81-4de0-444b-a53b-c519845e2111	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.707858
029b26fa-53f6-4f75-9517-b788ad36af48	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:17.878217
e89cf5ab-cbc8-41d7-9872-1c1809817da7	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:17.914456
a8eaa308-f1ad-4ec2-8d0c-151ef1baca11	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:17.95102
eac0d124-4a6f-46dd-b0ab-58d1e858a4f3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:18.017278
eb279c9e-a62f-4330-94c8-ac6f49166abd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.767411
e46eea0d-999e-4039-904a-7e545292a736	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.818264
f5113f16-96de-4b40-8522-e7923329b7ea	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.915342
66cb304c-e8da-4c04-aafb-afa1e3f076c4	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:18.037876
4642a961-1922-458e-905e-1373a3031e8c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:18.017597
dc4f5aad-75c5-4918-a2bc-6feea12f2c1d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:18.03737
5445a9e5-73f3-4fa2-a422-5db969680490	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:18.072804
a491af2d-1dd7-4ab7-8881-d1164718f0bd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:18.113819
eb148a87-59fe-4f38-abfa-2ea1e976284c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:18.072364
4458f437-eefe-4423-b66f-7bf4fc6ab0f1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "89afa381-a106-4d6a-a32c-89575b39c648", "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.106408
9d1b8032-fa7c-40bc-850e-a0c198a74650	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_968bcb82-6e53-4313-8054-c26662d4a083", "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:34.957603
bebad5b0-874a-40f9-8685-5ce8d7bfe6ba	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "143ac762-842f-4188-aebe-95e7f28f2500", "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:34.968937
83ed4970-55c8-46c1-abe6-cfa75d99aa18	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:40.578914
080ea517-c67d-4a5e-a179-03c2e7a302bd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:40.804565
0a13d970-c943-435e-9bdd-91b6880ba245	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:40.824561
c0840e83-ce97-4ee8-b660-5e5da2e82504	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:40.803283
fb6bdbb6-1f6b-4f1e-8fd1-87b3f65dbbba	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:40.825157
b40d5ce0-787b-432f-ad26-f49de303b703	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:40.949181
59528638-ee75-49ef-9182-c1d781a67545	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:41.059919
58de8948-cdd2-4021-947a-a431db6b1c48	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:41.079576
391adffa-f306-47f6-ade1-54656e72b051	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "2eb4bc7a-efab-421c-a1e8-60cc88363e3b", "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:34.976036
525a7a9c-6cd5-4587-ba24-3d52e9de0220	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "abdfae1d-8131-4049-9807-be89948d3fe8", "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:35.055093
0418025c-a910-4ecb-8aec-4b4ee702094c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "abdfae1d-8131-4049-9807-be89948d3fe8", "branch_id": null, "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:35.067138
fe57128d-331e-4351-b942-356f533b6aac	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_c318f72d-7463-41d9-ae81-6340bfe8c6bf", "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.102665
8e1ffe75-762e-4028-9670-d7e404b44014	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.112891
6eb2f3d3-ca62-47e5-b493-9aa2d7a7081f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "44b24f13-3a62-4c95-92e2-6235c3e7588c", "intermediary_id": null}	2026-07-20 12:34:41.958579
5cdde584-bf3f-424c-8c28-3271ce88cb50	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_378d879f-d43d-47aa-a285-7583a50f61f1", "intermediary_id": "f5fcef75-415d-4cb8-9165-2209d2883546"}	2026-07-20 12:34:42.008566
6b97cdbd-61aa-4c30-9d71-aa34005b24b9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "f5fcef75-415d-4cb8-9165-2209d2883546"}	2026-07-20 12:34:42.013684
4afe4a34-490c-4eed-b2ae-bdd65a1df287	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "ce9dc689-777e-4d94-adbc-476cee09168c", "intermediary_id": "f5fcef75-415d-4cb8-9165-2209d2883546"}	2026-07-20 12:34:42.018532
0bcc0f79-2ad8-4eba-8b3b-c7c5b04b4fd7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "2572f575-380a-4e6d-892c-170c7dee5251", "intermediary_id": "f5fcef75-415d-4cb8-9165-2209d2883546"}	2026-07-20 12:34:42.023672
48ac66f5-c82a-4077-889d-4570e4405e2c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f7e21925-82a4-4a28-8d4f-35011122a14a", "user_id": "1f7b0c15-b88c-4f1b-873f-fde0948696a1", "intermediary_id": "f5fcef75-415d-4cb8-9165-2209d2883546"}	2026-07-20 12:34:42.030327
91ed088e-e114-4f70-9c8e-c996d291e91f	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:52.430807
00cabcc5-e32f-4e96-82ef-e8bf100996af	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:52.499786
04d1452d-b76a-4ac5-acb7-48c1a84335bd	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.442295
403fa35f-2095-4ba1-9801-4b3ecaeeb4f1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:56.714445
a5d2f45d-5f47-4cf0-9bc2-876275d4513a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:56.783924
b05fef65-1c06-40f5-968c-2cd1b9e01044	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:34:59.574367
6f77bd9c-60f8-4670-ab8c-aa12a1db931d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.299665
cf2eaca9-9328-4a74-beed-46a5aae177c9	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.529528
1e2b24b2-ae36-4b1d-bd12-49b0ddd37ec3	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.580173
6aeb8e47-3b41-4adb-a071-50b3f5e81d93	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "e2885f4d-8263-41cc-8962-a63a07bbd357", "branch_id": null, "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.48285
e7bdff25-f068-437b-afee-45435ecc47f8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "e2885f4d-8263-41cc-8962-a63a07bbd357", "branch_id": null, "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.488843
65eac98c-19f8-4a2e-a9dd-3ae19be195b0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "e2885f4d-8263-41cc-8962-a63a07bbd357", "branch_id": null, "intermediary_id": "b8498713-6154-4f56-901f-2eab90259bb9"}	2026-07-20 01:00:00.497231
56eef634-6e4d-43da-b060-9a11de742a30	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_fb107470-82dd-42e7-8786-a721dd54b7a3", "intermediary_id": "c3fa2af8-a346-4168-9c1b-52c43533f6e6"}	2026-07-20 01:00:00.505639
761f3f49-a0a4-4a90-9b99-7ab114fce981	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.380939
f8e89623-80af-41ed-9b1d-999d73320ea4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "1b0f1971-7602-4355-bc82-5e40bb700806", "branch_id": null, "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.30248
659f0cb4-9abe-47e5-bd7a-27127c58e636	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "6d0b324f-203b-4576-8b6c-967cc19e9e14", "branch_id": null, "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.781797
af9204f0-7ab4-4688-845a-16e4beae52e1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "6d0b324f-203b-4576-8b6c-967cc19e9e14", "branch_id": null, "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.790448
235b1c1b-32c8-41a5-9889-1090a8c6d0ec	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "6d0b324f-203b-4576-8b6c-967cc19e9e14", "branch_id": null, "intermediary_id": "353b87da-2cf1-4f45-884f-fd3c753d549d"}	2026-07-20 12:18:19.803495
75aafb4f-5067-4ec5-8b0f-2a8f63e1eef0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_eff43cc0-28f4-4024-9d84-b93ae8d47d5c", "intermediary_id": "e4b2b140-eaa5-46df-80a1-0976000f825b"}	2026-07-20 12:18:19.812307
69f2cd15-8bbb-4629-ae6f-4994116cc0d2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "e4b2b140-eaa5-46df-80a1-0976000f825b"}	2026-07-20 12:18:19.816814
d4c1674c-cd20-4820-8557-5d5f78611511	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_58f8bfdd-c6cd-488a-9369-5937c653e4ee", "intermediary_id": "48a7891b-06a1-4aae-afe6-8d835d3693e9"}	2026-07-20 12:18:19.836632
eda1dd6a-430e-49c5-b02c-1bab62be9ab2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_5cc55425-e027-4829-b085-614091bad1c6", "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.317473
001e9440-b7e0-45cf-b97e-33fca37c9639	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.321844
316f26f0-8639-4637-893b-a5ed02c5caf4	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.563811
57547b77-e8f2-4075-8db5-8c0344f67316	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.594377
f3d31c80-6ae3-4dfb-ab23-313d271c3200	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.817782
deda7311-398e-4777-b3fb-b9ee2b79f97b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:18:26.916369
6907e844-1fd5-4b14-8583-4f8768341266	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.96937
0a65ea63-e9e4-4492-9e79-8e19c380bcdd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:26.991809
642eadd8-afe6-4c0d-b4ca-506e5c68ac20	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:18:35.68049
be794435-6548-4661-ae7f-de7a373c571a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.184137
c3c2d074-cc9c-42c6-a252-3325ddc38169	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:40.581388
9d48a88d-2992-4d5d-8e25-f1ad6e2d7a57	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:45.453653
75430ad7-d857-43ad-96d1-baae818de7ea	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_55716e12-156b-49d0-b47b-7cb3c818bbee", "intermediary_id": "994f232f-7fc3-4069-b9ae-f50f2e9c5fd5"}	2026-07-20 12:34:41.924367
522dc529-bf86-459f-83b1-c6b5b4e5ef5a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "9d048119-bc78-4c8d-9891-09294a3f587d", "user_id": "1d7f9efd-ba3f-4867-8132-e358695f5e59", "intermediary_id": "f5fcef75-415d-4cb8-9165-2209d2883546"}	2026-07-20 12:34:42.03585
0dc8af96-0471-4567-8cea-608368c4110f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "4392bce5-446a-43f2-8c76-a25a17607c8e", "intermediary_id": "f5fcef75-415d-4cb8-9165-2209d2883546"}	2026-07-20 12:34:42.049651
b6ad4575-d6bb-49e9-877d-01b0d35eb29b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.430007
a434c021-57f5-4452-aea8-756e9b047baf	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.432321
6aae5725-51ee-4750-a12a-f2364479aa9f	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.460775
2895c7ad-4f92-4db7-85e4-fead7cd52243	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.461664
2794a7f8-2531-4c10-8f4c-db75dc9c1ef2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.499904
c24a99e8-85a2-4041-9046-feae136b55b9	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.501011
b266a54f-074d-42bc-8538-0ff21e421c0d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.545303
63457d11-010d-4544-9957-5c7623e3fab1	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.545663
7d6bfb02-6847-4f67-ad95-3599504cfcf1	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.571615
696ed142-fdee-4722-8268-844970f7fd6b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.572322
d1851558-30cc-453a-b8cb-d6bd254de0f9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.590854
6b306ad1-baea-43c5-a3dc-81af4858eea7	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.591211
3d54a2d4-8ad4-4a8a-9db5-1304ee396428	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.636668
298ddab1-992b-4460-96e4-42bea894a2b1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.636811
ebf4622c-2086-4bfb-b6db-676da860538d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.680959
21cbd78a-045a-440f-b591-400bae4e9d20	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.681033
f482188a-1855-47eb-a593-517d9049f976	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:10.69903
b350cd6f-47a7-4076-a7cd-ccb1cc34122a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:10.699372
a4dc633f-c37b-4ba2-8909-f8d0888655ca	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:17.179089
9eb7d46e-28e6-4356-b9f1-e2f74f567dd5	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:17.180535
bf0bb26c-c17c-41ca-8750-d0124aa45c5a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:20.990869
8260d722-577c-4b57-8748-25355826f178	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:20.99232
620a973f-0269-41e4-990d-abaada50b8cc	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 01:00:21.03933
0637cc2c-4c05-4dec-a9ac-576484ded6d5	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 01:00:21.039821
92aa66ab-50a8-40bf-ac39-078e1a9e8a7f	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.380906
4d86ecf1-f972-4737-9e34-2ceae24c676c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.42491
de0ea964-1f39-41ab-82a0-014a396169cb	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.480958
f3920a6a-b4aa-40ff-9ccb-afc998c4812a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:28.48074
e0a9e778-9e51-4d21-85ee-93522589f094	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.59492
b474e8dc-42ac-4878-aaa1-eece6cde460b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "f8f1b281-6aa7-4270-808c-0bc15db7b734", "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.100407
844fbf02-96f3-4e65-8e0f-bd93798f6b08	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "ce7baec0-985f-41a9-bce2-e4ae5e856e93", "user_id": "1ef165de-c7f4-4d33-b2c0-e07bb2d37504", "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.106678
5a1af03f-eb0a-43c6-b7f1-91003a6cbf27	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "116e6369-9437-4f1a-9370-075a9d756d53", "user_id": "b62838a1-f576-448b-b1c4-0cadeb16265a", "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.112657
ab6997f0-453b-48e8-bde0-19624ea8691d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "b71ba10b-f0d3-4d91-b4f1-e1bc8e773346", "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.124854
13a39cae-1f46-4006-9a05-a97aec1fe017	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "01b8f58d-9781-4ed0-a179-1b83f56c1502", "branch_id": null, "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.266664
28aaf239-8b68-4b7e-9586-b82d91a2bb93	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "01b8f58d-9781-4ed0-a179-1b83f56c1502", "branch_id": null, "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.274555
2554b342-6b12-4e5a-a2f7-933fc0f971cd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "01b8f58d-9781-4ed0-a179-1b83f56c1502", "branch_id": null, "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.294268
e36db013-aae2-41bb-8768-fd4bb627f675	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_5ce46622-2d0e-457e-9e2d-47f4a0368eb9", "intermediary_id": "6bb1cdf3-c1ae-4c8a-a161-b06c6a08e5eb"}	2026-07-20 12:34:42.303526
3e695973-de7a-434b-b937-25be61d87d39	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:49:28.529733
5795cbfa-72b2-4edc-9b40-30d3231a9cbc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "61315f29-9512-48bb-8962-cde96b07f319", "intermediary_id": "35b35a6d-efdb-4074-a63d-59265657da9c"}	2026-07-20 12:49:34.922066
1a4f1535-8b71-4d12-a665-8d4acf340495	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "08afa46d-7221-4c39-8cc8-28a6ca351592"}	2026-07-20 12:38:19.011888
1514e994-8caa-44da-966a-380eaf51277d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_ddc214f1-3c45-40bc-ad0d-c0dc2ce847a1", "intermediary_id": "4afbeffe-e6ca-40c3-8134-ea2f9cf92296"}	2026-07-20 12:38:19.021889
7f1671fd-f2fe-40c6-8f9b-ce1eab11aa15	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "9588f85f-4db5-4d8a-8218-2893182d6f58", "intermediary_id": "4afbeffe-e6ca-40c3-8134-ea2f9cf92296"}	2026-07-20 12:38:19.030826
a51211e1-247f-4314-8f07-1ee02b2bfea1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "9588f85f-4db5-4d8a-8218-2893182d6f58", "intermediary_id": null}	2026-07-20 12:38:19.042379
ef24ef57-727b-4631-87b4-2b8073ca8cbf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_a44589f2-a74b-42c8-a6bb-8b64b1b46111", "intermediary_id": "9d19bae9-738f-4973-8f79-0e1cd29d627e"}	2026-07-20 12:38:19.081623
d876188d-3b9b-4d01-98ef-4e77ee60eb99	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "9d19bae9-738f-4973-8f79-0e1cd29d627e"}	2026-07-20 12:38:19.095951
0444a988-5fd6-4b18-baba-548101d46e9d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "c3e022cc-77ac-429c-8c53-70813ecc9ae1", "intermediary_id": "9d19bae9-738f-4973-8f79-0e1cd29d627e"}	2026-07-20 12:38:19.10225
7a90fe18-7a4a-40e8-a8ed-791b60f365fc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "6b374af7-8bea-4e92-b5d2-5f456d3659ff", "intermediary_id": "9d19bae9-738f-4973-8f79-0e1cd29d627e"}	2026-07-20 12:38:19.107907
081d6235-0bac-4bd1-acc5-e0d416fb271d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "9ef9ba41-dd07-49e3-a5b9-85bc47caa00c", "user_id": "47c08233-d114-4d0e-8ecc-3c3bb1d6e480", "intermediary_id": "9d19bae9-738f-4973-8f79-0e1cd29d627e"}	2026-07-20 12:38:19.115066
a79b1481-9ac5-436d-8407-9bb6b9df583c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "8994b25f-d242-47b3-923b-ab59ae25212f", "user_id": "a10e09eb-17b4-424f-bbcf-02795aee72f5", "intermediary_id": "9d19bae9-738f-4973-8f79-0e1cd29d627e"}	2026-07-20 12:38:19.129056
5325da86-4442-4f8a-9072-44c4bc604fa5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "2ea68135-25c7-4907-a212-dc7a94666292", "intermediary_id": "9d19bae9-738f-4973-8f79-0e1cd29d627e"}	2026-07-20 12:38:19.149812
6031ba15-dfcf-4a75-ac26-acf99ef9344a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "1c400e8d-086c-4670-abaa-f0df4e584c5c", "branch_id": null, "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.267018
1612814d-cf7a-401d-91cc-34f6a24f4173	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "26325daa-ca2c-4877-a16a-c230793add3d", "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.1182
78ed828a-9a02-47f7-9940-ebb14f23f641	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "64f1c006-9d8a-4193-934d-c89ae0937c9d", "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.123627
c4af619e-7a4d-4e1c-849d-d8c08a3a51b4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "b5cefee6-35e1-48a5-8481-de5b16736da0", "user_id": "d5a5bd22-39da-4d70-9089-ce8e58d610a1", "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.13107
6ab7fe90-b111-41fb-9e67-c81a4bb62dc7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "ceda4120-ce4c-4d18-98f0-b2d17685353a", "user_id": "2ecfd915-b2a1-4436-8b69-b360a1559e17", "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.138169
d1dbba06-cc37-4734-a9e0-e03d68620ecc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "b04bef66-176a-467c-a260-6d4f344c374c", "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.156547
ab1b5dd1-30d2-4bee-ab13-0c89e983973a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "d40b5740-ac84-4da5-a1ab-3baec4288f64"}	2026-07-20 12:48:35.205615
097e038b-7184-47fe-a003-4e10be761a37	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_4e9e2d43-5731-49ac-8471-512e781c0f77", "intermediary_id": "eaf8f5f9-a58d-403a-973e-c2e780fcd355"}	2026-07-20 12:48:35.230788
2516e499-ca3b-4b37-bca8-6633d2841482	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:41.352521
3ccfb66c-c769-4e1a-94ba-438ab48d8003	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:41.384219
063a52ce-92ed-4111-85c1-3239bc8fe19b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:41.426048
d4b5c5cf-c2ba-47e1-bbb6-5ce0cf623960	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:41.472579
2e7f43ec-db1e-4b8e-96b5-54c91cf2ad76	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:47.176007
becaec10-a4a8-497f-bfd9-e6f0d49f89bc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "68020f67-624c-4c28-a9aa-3cf92e28f976", "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.15873
0f705f49-e994-4953-a033-86e725653342	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "b71ba10b-f0d3-4d91-b4f1-e1bc8e773346", "branch_id": null, "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.143659
ff7aa3c7-0128-4413-a3d8-f38e28168b7c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "6bb1cdf3-c1ae-4c8a-a161-b06c6a08e5eb"}	2026-07-20 12:34:42.305783
f9341da4-5295-410e-8d40-22268651bdf4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_7c29238e-b1c6-469c-8ab7-f49054641a01", "intermediary_id": "43393e2a-a788-4276-8bd3-82ee847ca9f8"}	2026-07-20 12:34:42.324424
bac8a708-6962-4e91-94bf-80f7e8f7c471	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.37738
9636dad4-1efe-45e6-9aa7-c0ad08b008bc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_99545461-bb4d-4eed-827a-720d1ad54083", "intermediary_id": "d436c1f7-2290-485f-9032-1b8c77867e2d"}	2026-07-20 12:49:34.884042
d78ed6ca-d104-4cc1-969b-9d0b6136f7dd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "61315f29-9512-48bb-8962-cde96b07f319", "intermediary_id": null}	2026-07-20 12:49:34.933315
723aa0f1-04ac-4ca3-9f22-766e7539c9bb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "db7150db-4287-40e7-b047-200c68d7ff6d", "intermediary_id": "f11bc6f2-54bd-43f5-bcd6-3c94ed388391"}	2026-07-20 12:49:35.006431
3bac835b-73fd-4754-8be6-6490d8d2b5cf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "322d8e90-fcd9-4c5b-8bc2-a105eedef1c4", "intermediary_id": "f11bc6f2-54bd-43f5-bcd6-3c94ed388391"}	2026-07-20 12:49:35.012552
b28efc68-0c65-416d-9058-7659ec7d9397	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "9d97bcaa-0688-440d-b4ae-a4faf25db000", "user_id": "ed507dd0-aa9c-4523-8642-a83465cc4d79", "intermediary_id": "f11bc6f2-54bd-43f5-bcd6-3c94ed388391"}	2026-07-20 12:49:35.01989
aa0449ad-73be-4932-a9b9-cf8745eb4e1c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "8c1b92a1-9b82-4eef-bf81-e985b298897f", "user_id": "d14593c9-461d-49f9-905d-b31aefb30498", "intermediary_id": "f11bc6f2-54bd-43f5-bcd6-3c94ed388391"}	2026-07-20 12:49:35.025606
50ab9c0b-313d-4f20-988f-8b0501c12331	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_8db9cabb-ae53-42ca-9fa7-b6af316e877c", "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.198254
dfbe4d75-32bf-47eb-937b-d11925d736e7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.203558
8d2e474f-8a65-4f2d-a611-89d02cd380cf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "d198f7b1-6898-42c0-81c6-3b7fae7dd382", "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.210312
f3144846-d076-429a-93f9-fff9a9a73093	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "579ab3a4-22a3-40aa-aa68-ff65990b52ee", "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.216122
9af2561a-beb5-473a-b065-b0fccf1da47a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "2f0e9c9b-a4f5-4530-88e5-4f706d6ee10a", "user_id": "1a407cce-1071-4386-a81e-9491f0da5107", "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.222944
14968da2-bc97-4cee-83c0-a9026181b3c5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "a865b51d-4699-45a0-a4da-0a1a6b354234", "user_id": "340b15fb-ea6a-4986-8cba-a00a6ef35b39", "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.230782
5ac2efc9-5560-4a00-9215-cf67aa8adb19	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "1c400e8d-086c-4670-abaa-f0df4e584c5c", "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.244687
a4de7cb9-eb32-45df-8dc8-cc059438d589	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "4c0ac1a8-36f2-4943-a7f9-e96d0b698812", "branch_id": null, "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.386209
62ec4e3a-dc03-48ca-ba70-286ca4a411a9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "4c0ac1a8-36f2-4943-a7f9-e96d0b698812", "branch_id": null, "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.393372
02a72a53-143c-4dcc-9d44-6304e72a630f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "4c0ac1a8-36f2-4943-a7f9-e96d0b698812", "branch_id": null, "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.404713
e5aafcf8-10ce-4f0d-9df1-e473158b5043	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_55faf878-00ec-4002-8f69-b7ba97c48a36", "intermediary_id": "c128301e-6f5b-45ee-84bf-4ddf4193dc2b"}	2026-07-20 12:38:19.412208
7362abf8-ce5d-4555-b4a3-89e9db371123	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "3339d137-72dd-4bd0-87b1-245fbd9263e4", "intermediary_id": "f11bc6f2-54bd-43f5-bcd6-3c94ed388391"}	2026-07-20 12:49:35.042417
41c94510-eec3-49a5-b97c-a78eaa00ff0b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_8f252f41-563a-45f5-84e8-a56ddbb7fe0a", "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.087044
4030c80f-ad1b-4cd0-a976-6a5451a8046a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:33.204807
b5706adc-ad6a-431a-8317-d3a28cea048b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "3f71ce13-069c-4000-a0e0-8e4ba3697c62", "user_id": "7f9047ec-8dfb-4801-b907-5a6bdc8dda97", "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.121301
ee6fb761-ca7f-40c8-9c0a-c8e721b3e881	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_3d2dfc31-684e-4faa-9438-b44e97d70290", "intermediary_id": "ae0c4958-34f9-48c4-b132-6664a435e729"}	2026-07-20 12:48:34.765826
e61e06ee-0dda-4127-b5ce-6bd961764e6b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "493d18c8-e980-4e9b-93e4-4885830db99c", "user_id": "1cd0e456-b1e3-4e1d-b39c-ea6ce7ec51f8", "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:34.983002
1bbbf6e0-1099-4021-9fe3-49f7f0857159	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f683a1f7-ee4f-4b88-8fa2-1ab677808dba", "user_id": "2ae424ec-02f8-42d4-8506-3952285ca05b", "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:34.990528
fd2be710-7fda-49a6-a9ad-1f95a985f02d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "e453adb5-3cb7-4fcc-a99c-0aafc2f9ae97", "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:35.007237
a24e5452-3cc4-47b3-be49-c47e3af620a9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "15b2ea21-625e-4de8-862d-e95125cee350", "branch_id": null, "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.15912
5ee80dab-8ac4-453b-96ec-8b199aadff4e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.42683
51b5ecc6-2848-48e5-a93f-fc5b60aaf9f8	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:41.352527
914a5990-4099-49a2-903d-98faf3f1314c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "89face93-e3b0-45bf-9cf6-71414a4c18c5", "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:21.080286
a584c403-fa68-4be7-b6e2-4f60c5626f67	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:47.176144
d0166193-d4a6-458e-9a57-9c6c23d12d88	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:23.178839
cb74b5ac-194b-4fd9-a98f-a349dc9fc568	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "1b0f1971-7602-4355-bc82-5e40bb700806", "intermediary_id": "7eb1aeb1-6f40-43f2-a1e9-d207ed429f5c"}	2026-07-20 12:38:19.284803
120ed45f-1a5d-4823-8d44-90fbf18e9816	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "c128301e-6f5b-45ee-84bf-4ddf4193dc2b"}	2026-07-20 12:38:19.415277
5213a403-8d0b-491f-9393-2764afe12674	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_4160bf19-d6b4-453b-923e-a4100613ef05", "intermediary_id": "821ea69f-ebdf-491b-92e0-5ff47d0a3be4"}	2026-07-20 12:38:19.433554
32406f4e-a1d3-4c76-8983-5488d0d1e274	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "68020f67-624c-4c28-a9aa-3cf92e28f976", "branch_id": null, "intermediary_id": "754a5651-3aee-42aa-b210-ef15ca1267d5"}	2026-07-20 12:34:42.173567
57f617c6-fc9e-42ed-b2d2-16961e7c8941	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_8ee9561b-b3d0-4874-a9b5-f59490005254", "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.192702
64482975-a3c2-4458-b89f-5190191497e3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.19886
2a5eab61-b29b-4518-a614-fea7db635338	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "62f62002-99e8-4bb1-881b-4f358169f188", "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.207569
6a3c9cf5-1210-4634-9a78-5bea32a986f8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "0af72d7e-8b6a-4807-8f1a-78a16a43a89b", "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.222557
70340f4d-8882-484f-be8f-7c6d0e5037ca	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f607436d-9418-46b4-a628-724e6be962f9", "user_id": "7f8cb3b8-1c2a-48dc-98f2-a7d74a0ec942", "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.227128
28081a2c-fe8f-4cce-9e15-67bf202ce02b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "fa8d108c-0105-4651-8768-7a167204395e", "user_id": "18d14263-b335-42e2-8409-771f2beb0a81", "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.232708
1aed172e-1b9c-4b71-a250-4de375a9320b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "01b8f58d-9781-4ed0-a179-1b83f56c1502", "intermediary_id": "6339df5a-2ea2-4aad-ac4e-fcf29d5dc855"}	2026-07-20 12:34:42.251531
1f226fe7-ac49-4b85-8075-6970d4c5ff1c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:38:33.206661
9afa5cf5-9399-497e-9716-b857332bc64f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "4784b1c0-4551-4cd9-9141-e3e7511e0976", "user_id": "03a28305-c3cb-4c4d-985c-3d533fa7bd02", "intermediary_id": "8b772f8a-2fad-4b36-acf5-8bebfeb0c33d"}	2026-07-20 12:52:41.690089
f4923db9-631c-4ef9-b32d-c98a2ed85629	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "12cb2d6a-84cd-403d-b8b5-81929d966b16", "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.824357
13c4616c-4162-4315-a868-bf84a60383b6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "d292108a-2e23-4124-8964-a0c4dbed30f7", "branch_id": null, "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.805654
3a117a42-4ebd-492a-84b1-edeae34774fa	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "1a73403b-706b-4753-9ec5-fa0b5f2e8f34", "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:41.896971
0f08d857-5393-4290-9db2-b4ee2c26fff0	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:22.892155
00a40f10-2861-46e2-89fa-0117af2d6b6b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "d436c1f7-2290-485f-9032-1b8c77867e2d"}	2026-07-20 12:49:34.896574
bbbb0732-7dc5-4227-a618-a4c127637d5f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_cb240c28-6dd8-4cb2-a752-5fdbc88b7896", "intermediary_id": "35b35a6d-efdb-4074-a63d-59265657da9c"}	2026-07-20 12:49:34.914278
068cc198-31d4-4eca-b8a3-2b1ae8e2cc26	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "45d69fe2-f898-4975-b891-c5d4508f5501", "branch_id": null, "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.199039
ab51dd00-f9d0-4e83-94cc-e6a645ce06e2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "ae0c4958-34f9-48c4-b132-6664a435e729"}	2026-07-20 12:48:34.772429
c1830a87-afa0-4a85-bd63-e426536e9be0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_957680ca-ac62-42c4-9dd1-a955cc4ba97e", "intermediary_id": "6d4981fc-ca01-4fad-bca4-b58b234023c0"}	2026-07-20 12:48:34.787669
a6863acc-e163-4ef5-9add-63a547c113eb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "b2e0cf92-1b07-4780-8d1f-a17684100300", "intermediary_id": "6d4981fc-ca01-4fad-bca4-b58b234023c0"}	2026-07-20 12:48:34.795946
b1712ef9-76f5-4426-8772-795c3b3fede7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "e453adb5-3cb7-4fcc-a99c-0aafc2f9ae97", "branch_id": null, "intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:35.033765
ed8a929c-3da6-47df-985b-a155dd2c350e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "b04bef66-176a-467c-a260-6d4f344c374c", "branch_id": null, "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.175914
4c74bbb0-8b92-4155-9470-d4ef79d93b82	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "b04bef66-176a-467c-a260-6d4f344c374c", "branch_id": null, "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.183366
dcd0f2da-5534-4e15-98e7-690c68617b87	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "b04bef66-176a-467c-a260-6d4f344c374c", "branch_id": null, "intermediary_id": "c401a2a9-9b2a-480a-95ce-341ff02fa50b"}	2026-07-20 12:48:35.193172
97b9d7f0-7df6-430f-9298-eeb2e64a72e1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_57d7a891-d498-40cf-8934-69e78ab835dd", "intermediary_id": "d40b5740-ac84-4da5-a1ab-3baec4288f64"}	2026-07-20 12:48:35.202935
8f2279fc-042c-4f62-b886-c4390fda6986	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_dd2d2398-553f-4370-a3ec-1297e116c8ca", "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.278058
9c2e08fb-2132-4052-8343-026d5a7cccca	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.284522
8dbaba9e-588d-4246-b0ad-89d32891312c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:53:53.483521
64a0a526-8f47-4664-930d-000e38241f90	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:41.383159
a8d75c67-db08-4b81-a559-3b5ca0fae45b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:41.42523
c29cce97-e63c-41a9-9241-f08dfcdd310c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:41.474763
1e1b9371-48fa-4b26-8bff-a876364a60f2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:41.506873
3b896758-1f3c-45d6-8a56-9328596c041b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:41.534876
4472c451-7fd1-421a-88d2-6db08088d98c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:41.591609
ea5d21f3-a3ea-4baf-8ce3-84ae93299287	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:51.844951
a7dcb9d6-c2d1-41dd-822f-64b5211922b4	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:51.909534
2bd39c22-4fdc-4a90-aad8-d8feb4567590	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_d0a30c60-8aba-4f52-bcef-d2d29d041b82", "intermediary_id": "388c503e-6ea0-436c-b375-710fcd06da0a"}	2026-07-20 12:34:41.94089
0d27b86a-dfcf-4bf0-973b-18690ae1e9b6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "df0eeb64-26df-4155-a212-41277f391142", "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.332325
ba8569da-2bb5-4ae2-a872-edbe5f2a8432	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "e3f30787-9301-4cf6-a7b1-36751c44f71b", "user_id": "63e7d11a-235b-46dc-b784-b37cf432e5ef", "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.33854
89d0129c-21aa-4e9c-bff7-f706b46cba0c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:56.7176
079f7cd5-ed12-413e-8932-f16ac53d3a15	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:56.782408
1051f6d3-37b2-4381-a0b2-c21c69f7a206	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "065d31e5-ca8e-46b9-9cbd-7b1b3a8ab881", "user_id": "af53a384-dfde-4949-8a6c-b89bc6df1a43", "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.343875
ed73eadb-acda-474b-b524-410d0d2a5795	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "4c0ac1a8-36f2-4943-a7f9-e96d0b698812", "intermediary_id": "8ddcee43-3406-4331-9473-514df6e7fb9d"}	2026-07-20 12:38:19.367579
3cbd5b4d-9a14-4ca5-99c6-d438defaac2f	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:34:59.574366
789ed072-8257-4a21-9d95-7f35b6b06f43	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.476034
5837ee7f-1944-45a9-ab8f-86eb43ee8894	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.497776
52d458d9-979a-4384-90ef-031c5695ebaf	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:38:37.216611
70d15335-b6ae-43f1-b958-6eceb7787ce7	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:23.154393
f1d6d9a3-645f-46ad-8b38-863c85bd609c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "9fb2c78c-dc86-474e-a89c-dbb189674502", "intermediary_id": "39aad24d-4a09-4058-a202-479319ca1725"}	2026-07-20 12:53:47.465674
636cbb15-3c48-40d9-9ad9-1a74997f3a5c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "cea0c7ce-54da-4e0d-855c-ea6b8602ff93", "branch_id": null, "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.672531
b5e91161-f426-415c-a994-3a46e0ef050a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "39870476-e1e3-41a6-a100-4587a7ed9a14"}	2026-07-20 12:53:47.820404
7b6f9723-cec3-48a7-9826-4f9c5ef5a404	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "b2e0cf92-1b07-4780-8d1f-a17684100300", "intermediary_id": null}	2026-07-20 12:48:34.807535
bea6e509-9721-428e-9e97-70d93d36de75	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_ddf9bdf9-9b3d-4730-bb46-268a50f6a46b", "intermediary_id": "daf66bbe-705a-4c5f-8dc2-7ea2c804fb27"}	2026-07-20 12:48:34.854587
363c8b78-41e3-47c1-a92e-69bb922fabd2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "daf66bbe-705a-4c5f-8dc2-7ea2c804fb27"}	2026-07-20 12:48:34.861792
8875f86c-6281-46c8-9552-b061fbe80112	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "e164bc45-cdcb-44fa-8412-dfb96b008749", "intermediary_id": "daf66bbe-705a-4c5f-8dc2-7ea2c804fb27"}	2026-07-20 12:48:34.868275
4d3e6c66-8436-4933-b816-eeaf42b15f82	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "ae457f27-f41f-4177-9497-c309ebdb8fae", "intermediary_id": "daf66bbe-705a-4c5f-8dc2-7ea2c804fb27"}	2026-07-20 12:48:34.874868
67cf792f-01a9-4a46-ba8b-41d555fc556c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "1d70937c-b5ce-4d16-b2bc-1d259dd860ad", "user_id": "c8adb596-ec92-4f12-8e53-7d6ae5008125", "intermediary_id": "daf66bbe-705a-4c5f-8dc2-7ea2c804fb27"}	2026-07-20 12:48:34.882941
a45defed-a6f4-413e-8acf-8a1b30192153	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "1a7d517c-2e4e-45f6-810c-0f32d06852ec", "user_id": "ddf21638-a4d9-4b0c-b8d1-c17bc1ca9205", "intermediary_id": "daf66bbe-705a-4c5f-8dc2-7ea2c804fb27"}	2026-07-20 12:48:34.889927
fd6f1eda-0482-4a91-aa5b-80e0efb1d47d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "e67ed5b9-a45c-4a90-bbad-100dd4291f0e", "intermediary_id": "daf66bbe-705a-4c5f-8dc2-7ea2c804fb27"}	2026-07-20 12:48:34.906921
b8fda829-7703-4ae7-b7de-86d1a43cbcf9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "ed2bf4e8-e929-48f0-a26d-1a2bc5aea6af"}	2026-07-20 12:48:34.963116
eed22b59-861a-48a0-b50e-d2f823c62be1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_a77b8c33-9695-426e-9d37-692968d2c6fb", "intermediary_id": "f11bc6f2-54bd-43f5-bcd6-3c94ed388391"}	2026-07-20 12:49:34.986752
b593aef7-a78f-4396-824d-b9af4aafc0d6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "f11bc6f2-54bd-43f5-bcd6-3c94ed388391"}	2026-07-20 12:49:35.001158
b15a4ec3-8bcf-4d37-befc-685f878d9e4b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "cba25eb4-7db7-49d8-b86b-8183533fedfb", "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.469897
7305bda3-69aa-4aa8-a02d-65b2f6fec37e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "cba25eb4-7db7-49d8-b86b-8183533fedfb", "branch_id": null, "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.488751
bcf5ef51-ad95-40fe-9f43-974a6ff85d1c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "cba25eb4-7db7-49d8-b86b-8183533fedfb", "branch_id": null, "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.498259
ce420c48-5f2f-46e1-8783-c11cb4bf54cd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "cba25eb4-7db7-49d8-b86b-8183533fedfb", "branch_id": null, "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.511068
aa6f15bc-5c3a-4f94-9755-c22390e83ff5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_2af719ba-f999-42ff-89d6-d484342dbba7", "intermediary_id": "a23fd5aa-dbcd-420c-a601-450abe242f41"}	2026-07-20 12:49:35.522248
0f5f5c85-07cd-419b-bbef-2e684b4c7fcc	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:41.506869
7dec288c-7580-4aac-bb78-3680dea8709f	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:41.535208
b83e888e-0e1c-4a7e-bd0d-c237ed2ed851	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:48:41.591252
9aae98b4-f5c6-4c13-a24d-44233c776880	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "a23fd5aa-dbcd-420c-a601-450abe242f41"}	2026-07-20 12:49:35.526457
b1d8440c-a08d-47f7-856e-b8b6b9a2c76a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_20e9768e-cb32-4c97-8962-a9a3d065f4c6", "intermediary_id": "aa86d7fd-8462-4746-9a0d-aec69cf7b256"}	2026-07-20 12:49:35.619145
0054e151-9fce-4c17-b2f6-ec642f3ca59e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_f2810884-0735-44d0-b801-9045f337f7e0", "intermediary_id": "40f99f49-ca23-441c-9c5f-58295d12fdc0"}	2026-07-20 12:53:47.838631
f6e52a53-f208-4750-b9ff-ba781903f098	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:51.844975
35745124-6e73-4e9c-846d-1659f26a9d88	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:48:51.910421
fa1f66ab-7aca-4bc3-ab1f-14bda8fa4e3a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:53:53.516829
242134d6-86d3-4caf-a75e-f82482fff924	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:53:53.606292
162003a0-1a01-4a13-a570-6d8d02da564b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "2b3f141b-ad36-4375-b845-e434482a173b", "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.100102
33a84d2c-0073-49fd-bc86-a5f4180e1b40	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "2327241d-66a7-4f19-acdc-cf72fe06e4d8", "user_id": "f2f98793-84ce-49c6-9107-7669586e6f09", "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.114147
3490a4fd-a1e6-45a5-966e-0b67ae24fecf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "15b2ea21-625e-4de8-862d-e95125cee350", "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.141304
bf72f08b-42b6-41f1-9d0f-643111b4676c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "45d69fe2-f898-4975-b891-c5d4508f5501", "intermediary_id": "924c1d9f-f81a-4f53-8e96-1f3b3e669892"}	2026-07-20 12:49:35.176964
22baf488-3c81-4959-9ddb-a81d295faa85	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "5b6b5232-fc9b-4e65-8721-50e31eb73b07", "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.290517
593b7616-c278-434b-86c6-1dd2f6e03070	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "7795ec4e-da23-4a8e-a8a5-d52f0761ac29", "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.296168
7a799eaf-dc3f-421a-9c7d-8f2f44530d5c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "ab654f1b-406b-4da6-be85-becbf5add82d", "user_id": "9161a286-8e78-4568-a92c-18043763a55f", "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.302996
f61bf382-87e3-4d4c-8c30-cf6437420f85	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "734183bb-56e7-41e8-aa69-effb86e7104f", "user_id": "06d16eba-deed-4bf1-acf7-f5607b1fe69f", "intermediary_id": "e43e579e-43b3-4c94-8c10-d0ed90950fa8"}	2026-07-20 12:49:35.450819
a172acaf-d41a-4fad-8fc5-790ea66190ee	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_a633c2eb-cd9f-4e15-80d5-e2fef80c3d1e", "intermediary_id": "cbd1a600-6435-431f-8bcf-33c1f4130fb4"}	2026-07-20 12:52:41.601498
03d81bd4-41f5-4e9a-bf41-1e6956c3e8b3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "2135c94c-1d85-4a37-bab7-a2dc8e0399a2", "intermediary_id": "cbd1a600-6435-431f-8bcf-33c1f4130fb4"}	2026-07-20 12:52:41.615255
f9f4a3d9-c5f5-4cea-b153-624eb278ed14	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "2135c94c-1d85-4a37-bab7-a2dc8e0399a2", "intermediary_id": null}	2026-07-20 12:52:41.626074
33fed560-a076-4672-911b-67424de551f7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_16af4f9b-d459-47ac-b530-f052298344ed", "intermediary_id": "8b772f8a-2fad-4b36-acf5-8bebfeb0c33d"}	2026-07-20 12:52:41.663069
97d27bc7-d41b-45dd-92bd-db865e895ea4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "8b772f8a-2fad-4b36-acf5-8bebfeb0c33d"}	2026-07-20 12:52:41.667854
91a147ac-e518-40af-8c3b-bf5c8f8c78fd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "1bc9a318-b902-4b98-9c07-ad8f92ec8320", "intermediary_id": "8b772f8a-2fad-4b36-acf5-8bebfeb0c33d"}	2026-07-20 12:52:41.673312
67d410ae-b092-457f-a251-a3ccf7a19db1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "709cf306-6a5c-46b8-bfff-513d59c1cab4", "intermediary_id": "8b772f8a-2fad-4b36-acf5-8bebfeb0c33d"}	2026-07-20 12:52:41.678324
65083859-54f6-4680-a4bd-ab7bcabc436b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "21666e73-5351-420c-a7c8-68429597b357", "user_id": "740ec279-fce6-4aaf-ac29-4959c34ff113", "intermediary_id": "8b772f8a-2fad-4b36-acf5-8bebfeb0c33d"}	2026-07-20 12:52:41.685354
9b9120b1-08bf-4e36-a9cd-2db9680a00e5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "c3ec5b16-fed5-4825-bc2f-4f464d6f1843", "intermediary_id": "8b772f8a-2fad-4b36-acf5-8bebfeb0c33d"}	2026-07-20 12:52:41.704986
05844e9a-ab32-4d03-abfe-a7503ff112b3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_4d95a3cb-b4f1-423d-895d-b574e1b4569c", "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.743644
b5f94a8a-6c50-49ec-a480-d07f1ce74c2b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.748666
f8001d04-cee2-4570-a196-bf5ba63425d3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "402560f6-2b61-4db0-831f-9193e17a07de", "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.753584
77f68445-d89f-4f2e-a976-9ee36b6759a7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "33973e2a-731f-48e9-91dd-3a966e684ea3", "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.759282
af8bb017-7c7b-4e23-9c41-07e205436f7a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "6c87d4cf-b613-427c-822b-ac2109d3d519", "user_id": "562e0991-5842-4148-afc0-34a4832c2749", "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.765082
004c08ae-6209-45eb-a48e-c70437baa595	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "370a59b3-2fa2-4886-b0f5-3543f29286e9", "user_id": "b2455978-41cf-431f-892b-c8bc326826ac", "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.772493
89f267e0-002d-4091-8ab3-cc585b87fbb9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "d292108a-2e23-4124-8964-a0c4dbed30f7", "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.787622
33db711d-d213-435b-a5d3-5b4813bf97c5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "12cb2d6a-84cd-403d-b8b5-81929d966b16", "branch_id": null, "intermediary_id": "9446f78a-63d4-4d06-b5aa-0bb00688a1d5"}	2026-07-20 12:52:41.841492
23b69368-50a6-4aa9-814c-26d32ac38c6c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_e3d3ffbb-5f16-4b53-82d8-6de61b986623", "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:41.88302
66cc13e0-1f83-49c5-83b6-c8e79b3ce925	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:41.888024
b41b3f8c-2d21-425e-bf24-621371f92e47	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "e1a1bfba-0bde-40d0-9cbd-fdc1c9ebb487", "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:41.894522
6dc5fa0f-62a9-4c56-902d-1cf46f8269e7	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.277937
de7e9af6-2fc3-4db6-8112-94f34d3a2620	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.323595
a88c7a0a-a44d-4f7a-b1d8-7aede27a51f1	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.350261
5e51e308-f54d-4684-adef-c7ccf238d10a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "9fb2c78c-dc86-474e-a89c-dbb189674502", "intermediary_id": null}	2026-07-20 12:53:47.479725
f4fbb98e-7ad1-47ee-85a0-cfd63151a5d0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_640cfbd9-fb5c-4716-baa3-ec0dae07ea50", "intermediary_id": "fae0b3e7-3fb9-46d7-a5dd-7835735e796a"}	2026-07-20 12:53:47.51985
c7603cac-f66e-415c-803d-2a378449e574	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "fae0b3e7-3fb9-46d7-a5dd-7835735e796a"}	2026-07-20 12:53:47.525744
98bb65b0-a76b-46c2-99a5-da52ec112a95	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.350444
fd36fb18-0618-4f91-adb1-12b6f03a075e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.376676
183ed5d2-d103-4488-bb3e-6da8e49966da	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.278438
cc342be8-4150-41c0-b0d9-d92ee68477d9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:49.724089
b373663a-2f6a-4051-99fd-4342d7e40588	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:52.430788
cbb5a3ef-6e7a-4a37-af8a-daf3f5bafcc3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:49:52.498977
860fa528-63ab-4ae8-9c7b-8d9d20ed3803	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_cf9899e4-76fc-4aa5-9621-6e9282b66f90", "intermediary_id": "fd169fd0-72c8-4907-a007-966eb92e4278"}	2026-07-20 12:50:31.048338
eb1352bc-2766-4426-95f3-446b8d8a01b5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "fd169fd0-72c8-4907-a007-966eb92e4278"}	2026-07-20 12:50:31.055169
a9a167ad-0d5d-402e-ab57-80d3ed94e439	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_e4093bae-e223-46f1-a56a-34eb6149d7dc", "intermediary_id": "44bbb3e7-0304-4265-8e33-26d7229847fe"}	2026-07-20 12:50:31.071
97dc7e8c-0e38-4cf2-b429-b6a457d2c593	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "a8dc01b3-c6a1-48df-836b-b5353c4adc6d", "intermediary_id": "44bbb3e7-0304-4265-8e33-26d7229847fe"}	2026-07-20 12:50:31.079581
2c94eefd-50ed-4660-8204-c8dc8181ff11	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "a8dc01b3-c6a1-48df-836b-b5353c4adc6d", "intermediary_id": null}	2026-07-20 12:50:31.089373
873c92d6-9b38-4fe6-8735-e934b30d1cc4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_7570a1f7-1052-4b28-b990-452910900c07", "intermediary_id": "befe3fcf-8d2f-48b2-b7d4-902ab1ff7dde"}	2026-07-20 12:50:31.135508
fbd10a9a-84af-400e-9921-902ef526feed	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "befe3fcf-8d2f-48b2-b7d4-902ab1ff7dde"}	2026-07-20 12:50:31.142953
3f901eca-1b01-478c-a58c-b860f045cd13	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "ebccdd61-23db-4155-88e5-52ac548b12c8", "intermediary_id": "befe3fcf-8d2f-48b2-b7d4-902ab1ff7dde"}	2026-07-20 12:50:31.150129
74138061-f8ff-4589-89ee-ed765077eb78	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "bf9542a7-369a-4ad4-b5ea-c379208bc57b", "intermediary_id": "befe3fcf-8d2f-48b2-b7d4-902ab1ff7dde"}	2026-07-20 12:50:31.15371
2ce81bdc-b150-4ea5-840a-a765a1743013	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "aaceb5af-670a-4b45-9c52-f1f86d838086", "user_id": "1e811dc9-ab35-4d6b-aee6-a080e67c2e55", "intermediary_id": "befe3fcf-8d2f-48b2-b7d4-902ab1ff7dde"}	2026-07-20 12:50:31.161104
a1f1a965-77c0-45e6-a3af-cbff6577a167	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "aa582b87-4cf4-4e0e-a8f7-ec641d11af5b", "user_id": "3b194078-268e-4846-9078-16eb2ab1668a", "intermediary_id": "befe3fcf-8d2f-48b2-b7d4-902ab1ff7dde"}	2026-07-20 12:50:31.168089
680036e8-6c03-48f3-b171-569d4a9cd6be	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_39541c76-3f98-4f5f-bfa9-479ca732d4b4", "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.217551
6c81b790-3655-4d9c-a5e9-e9e71798cb15	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.222906
a1e38536-ad4d-4317-909c-6fa1028ceb04	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "52f2ae1e-edd4-40db-802e-cc0c2ee81f6b", "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.228148
b9ccc5f3-54a0-400d-8e18-187b776890a0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "ab183ed6-3b5a-4066-8592-0db1da1e54de", "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.232301
21dc3b5f-fa02-4023-a987-41afda83db0b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "9e8d6ac9-c971-45f9-be97-9a8932d5f78f", "user_id": "309c8678-f28c-48d1-b319-a7f47c2bb92d", "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.237833
7be023e6-e9be-4fb6-aa7f-1c4ce1a0ffbd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f8a491f4-cf87-4a12-8e75-e85401d806e7", "user_id": "f37777bb-0d9a-48a8-8376-262bc96f1d72", "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.243872
1e660325-64a6-4c3f-a0fd-9422871574ba	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "ccee7fc1-bcc0-43f1-9ed7-341e9301f321", "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.256389
9198b730-cb75-4f46-9858-f8599a772171	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "3476fa96-29aa-4049-92da-3b6a8cc96fcc", "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.290385
3580b93c-34df-4fb1-8f32-f9cae1bdd578	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "ccee7fc1-bcc0-43f1-9ed7-341e9301f321", "branch_id": null, "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.274896
2d4bb383-16fe-4a10-b8e8-3a952d2b8067	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "3476fa96-29aa-4049-92da-3b6a8cc96fcc", "branch_id": null, "intermediary_id": "abb5d8b3-3ef4-4b70-b757-2c65ac4de748"}	2026-07-20 12:50:31.302368
36bc045f-4a85-40b9-89a9-59d7662a929f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_c7482d3b-55c5-410f-b731-6cd6a54d58d2", "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.316048
d614679f-4915-4b96-b5b7-e8b4d707e0d2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.320574
b20dbf67-3a81-45ae-8849-d57cfb75a23a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "f5e789ab-6e58-434e-908f-9522f72188c7", "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.325323
9c21d409-28b8-4578-a9a3-1d4cf3ea2a4f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "0a11e7f5-8796-4cd7-85b6-5254ccc13dad", "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.330132
3a0899b3-254a-4e5e-9990-af1566e2048b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.235341
8597dfe7-fbb5-444e-8aaa-a6eda6c78206	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.2835
2129b713-f198-4709-8be3-a14a2b58137a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.331391
5e5b3989-34d0-4650-b5d3-52e0ef5d18d0	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.359304
b26c4cb3-8dd9-4403-81f2-0e31081365ba	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.380814
b0df412b-823f-4c20-856d-67e897a51937	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.489744
095dfe62-94da-4cfc-bbb4-e156d2a90725	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.5087
8dab4e5c-0f1c-4497-aba2-e35bc9137a0c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.489346
b4cf234d-a994-41a1-818e-e49ca24f4181	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.511204
56ab4315-3dad-4939-a4a8-5e885c5a63f0	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:49.190411
b51ba058-407d-4eeb-8537-27e22cb5d531	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:49.250475
2582fe76-53c9-49c7-853b-a3d8d43e22fe	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.465456
b56cb701-734a-450b-b69c-47cd16b3ef13	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.595348
6e40c573-b5b1-4fd5-90c1-5ce520c39ed1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:39.929597
4bc23971-ec12-4db7-ab82-574cf70255f1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:49.347421
6822beae-e3ec-42b2-9c11-c11e32070aa1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:49.415053
0569017d-1e8b-4168-8056-1b7b59c2a11b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.19911
5802e7aa-082e-4906-beaf-a172d52acb6c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.201337
b0773cb1-04f7-4cd6-b2ab-c20da4ecc628	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "a30b0930-9e5a-46c3-9a94-0820f16701b4", "user_id": "4e1fa11c-47e5-4dd5-aa97-dc9ef7308263", "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.334563
879dbc92-f34d-4a94-a91d-67a6517c7939	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "49186414-d8b9-403e-a097-87bc0277b609", "user_id": "508984b8-0fe7-4f35-b7c8-d5caccf03eb7", "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.340415
18206b2d-e9d2-4bc2-baa9-eb87ad418309	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "4273e593-df49-4263-983d-98d8242f21ca", "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.362531
88565cdc-a1d2-4a87-891c-4e2af03a4247	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "4e34df9d-6ce8-48b7-bb58-200a5c55522b"}	2026-07-20 12:50:31.419387
8efda644-fb89-4e51-a27c-6da4f726a66c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_99c9137a-ce8a-4862-bf9c-0f5cb23d7e40", "intermediary_id": "9803dc4a-76b8-4495-b932-7b2cf2d19fdc"}	2026-07-20 12:50:31.439815
cc998956-6ced-4d23-a434-26d46da66288	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.236084
5f912a75-e732-41be-8dd5-e6e184a2b12a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.23702
b875f6fb-b611-4756-9546-fe32fbeac29c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.426464
a7af727f-dd56-4e36-b800-a1ae6b24dd7e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:45.476059
af22d1ed-a66f-4870-b7fe-3b68630a6dfa	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "4245e2af-8599-4870-b3ff-ecd0c8d9cda7", "user_id": "f9b27f4b-2b85-4c7a-af49-2ac5f2b068ca", "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:41.911112
b5252464-57c2-4765-b1aa-129eed7d84b8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f4040845-00d4-42c9-a1ca-ea757693a95a", "user_id": "3ce7e2a9-914c-4a2c-89e8-028d86d2f8cc", "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:41.917116
eaa404da-008f-408d-aee4-a8d09afe316e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "7ddfa734-32c1-4420-99cf-02c6092eb29e", "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:41.935532
f8c4a649-e531-41a0-8da1-8c58288d84c9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "7ddfa734-32c1-4420-99cf-02c6092eb29e", "branch_id": null, "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:42.093807
90e50764-7893-4d11-b211-24f91f3d9c7b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "7ddfa734-32c1-4420-99cf-02c6092eb29e", "branch_id": null, "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:42.100977
8381cb47-ee17-4114-a28a-3e464483c232	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "7ddfa734-32c1-4420-99cf-02c6092eb29e", "branch_id": null, "intermediary_id": "09f72326-cef3-40ff-839c-42c68119dd72"}	2026-07-20 12:52:42.112276
4fe53f03-7eaf-49e9-a33f-896818053b9c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_31269432-6a5b-4dbf-8131-6db1e065d281", "intermediary_id": "738b9c2b-3de0-4ed6-aac7-3c02203947b5"}	2026-07-20 12:52:42.121977
68ebb06f-af0d-468a-be34-6bc8ff58e4c0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "738b9c2b-3de0-4ed6-aac7-3c02203947b5"}	2026-07-20 12:52:42.127485
d3dc1899-fa2d-4c18-a774-ca3847bcd155	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_2bcda542-e428-49da-9e57-d3459c16f2b8", "intermediary_id": "65ece7ab-cef9-4fb7-a604-c2de8b445bf4"}	2026-07-20 12:52:42.147431
38651673-66bf-4ea5-be39-cbfd7a7f15c6	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:45.498795
56829517-a23b-4c67-bca1-9341e7ee2f14	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:54.73411
27ff3a9c-7fd4-4790-b615-f1cc4866a4bb	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:54.791306
83170120-0bf1-4bf5-bc95-0f9d1d09e0d1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "0b565a3d-6704-4165-a9e0-a38fcd069740", "branch_id": null, "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.231089
393f1826-d744-4425-9e42-2178f972f3f8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "0b565a3d-6704-4165-a9e0-a38fcd069740", "branch_id": null, "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.246608
38f5340b-67b2-4d6b-95f7-b86e0b37e8bb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_0445cee2-f1ee-45e9-b7d1-c522053b893f", "intermediary_id": "befa08a2-710d-46ce-9aa2-4578ab4f1236"}	2026-07-20 12:56:21.25513
0b307598-d034-4504-84ca-23259821bc50	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f4f01e03-be29-419b-ad02-2b0b8101ee7e", "user_id": "eb7d45c6-0c2a-4f86-9b62-6d99422dc0bd", "intermediary_id": "fae0b3e7-3fb9-46d7-a5dd-7835735e796a"}	2026-07-20 12:53:47.551044
36ec7888-f16a-4f75-99c7-31c88f1cad32	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "d807e122-832f-4b08-b94a-7d12095b6f3e", "intermediary_id": "fae0b3e7-3fb9-46d7-a5dd-7835735e796a"}	2026-07-20 12:53:47.56643
3dc89a5e-825c-4ee0-be5b-fc08d0d6b866	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "a83c51cc-1da4-48b6-801b-5864679ab9e6", "branch_id": null, "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.788052
c068a6c0-e4da-4378-bb85-76f742092277	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "a83c51cc-1da4-48b6-801b-5864679ab9e6", "branch_id": null, "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.796025
d4e01892-4a79-41c9-a420-f87c1125066d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "a83c51cc-1da4-48b6-801b-5864679ab9e6", "branch_id": null, "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.808423
eba4111a-e04d-4c11-9f62-fc2aaf70d157	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:22.943502
bc7ab0d0-4764-48a0-944b-62814e3c414b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:22.942781
d70dbd79-b4c6-4791-924f-7504eaaff5a3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:23.006409
7d28f52a-00e7-439b-bbe8-2fde22b9e721	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:23.055786
791170e6-7ce4-4718-a617-f91a7643dc2a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:40.404317
bc19ba23-4f6d-4627-b5bf-fde2590214cd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "fc6318f0-66f6-47ba-b1c8-a476d6ab2f3f", "intermediary_id": "d6a1565e-61a2-40a6-997a-876c7e2cc0d2"}	2026-07-20 13:33:14.401006
2ad272fc-2d0b-41dd-ad54-c628c619c41a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "4273e593-df49-4263-983d-98d8242f21ca", "branch_id": null, "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.377516
4907bff4-9f22-4a4b-b40f-2437a7813ed5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "4273e593-df49-4263-983d-98d8242f21ca", "branch_id": null, "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.38546
59901923-1f32-45f4-9304-5ed1c5608879	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "4273e593-df49-4263-983d-98d8242f21ca", "branch_id": null, "intermediary_id": "7054d495-948d-4c02-a5be-322295dd4168"}	2026-07-20 12:50:31.399596
87c44ef4-02c2-49e1-a851-48058337edf0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_77dfbdd9-7fe6-4123-a728-a76577e72e7b", "intermediary_id": "4e34df9d-6ce8-48b7-bb58-200a5c55522b"}	2026-07-20 12:50:31.415898
2127182e-55df-4122-a2aa-d3606327a8c0	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.428884
ca7e9a91-5e72-415d-a713-257848a71f7e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.459035
c5fde963-4790-4008-aca3-ee87794947ab	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.501965
6479424f-0ed8-4773-981b-dbbd1d791eae	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.54034
215b6242-873b-4009-b9bc-2c179ee61313	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.575198
f5592261-7d49-4de6-b348-2b44b118374c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.600495
66c5391a-a330-442e-b60d-092ad8f124b1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.661443
5f6af1e3-78de-44b0-851f-8512587bed52	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:54.732235
143bfd23-847a-4826-a6df-da78b1beb5b6	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:00.825238
10306555-bc91-42a3-9266-2f08766f0676	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:00.864323
ccb8ba81-01f1-4571-aec1-19dc71a04234	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:00.864916
df9db328-bb03-4696-8145-0c681bc4c00e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:00.911106
27a2db76-92a3-48ac-9011-82d7f6ca43f3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:00.911105
66901ce4-102f-48f2-affe-11f751c1325e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:00.953974
af3cedc1-7241-47fd-a039-4637dcdb1ee4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_e8e805ca-f232-4ac0-b68d-301aafc5d933", "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.603567
d7f421f7-84ea-4fbd-81f6-e0e884b347bb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "f3f1fa1b-0048-42ea-b158-8dd4ed90dee5", "branch_id": null, "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.707487
fbd49088-3db8-4730-8b82-081000ee8818	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_7e5b4971-860f-4374-ab94-4ee5a8cb68e6", "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.723636
9b2baa0a-565d-4671-8fbf-3713f7b71339	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.728912
2226e4d8-0d7e-420b-81c5-dba9525a1dc9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "d1aecd40-adf6-4bb2-8d2f-6a0f68e9293f", "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.73415
5854db4a-7c5e-4e15-a661-6b7d0227b5e3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "0d0f8a70-1346-477e-8ee3-9c3614874c9d", "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.738358
9fa61f2c-dc88-4a85-bea8-d3e4beb5749f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "ac706fa6-130f-44cb-9107-c3a786acdf9f", "user_id": "6e736c35-55d6-45c0-aaab-10c0827f81ef", "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.743854
70903b0c-61f3-42fb-a1c5-d80f79977893	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "16fdf275-0166-4ae6-a8fc-fc34a630b57b", "user_id": "dfd92428-7792-4e84-901f-801cf8798a85", "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.749505
422d856f-6f3e-4f40-a460-3932a3e1f460	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:00.956116
705f8288-ab4e-47aa-a241-738db7c63d76	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:01.009489
010f0c01-1597-4555-97e0-9b5b84e14ce0	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:01.054007
b4bc766f-6dc9-4d12-965c-56540ba21b9f	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:01.207113
bb1be8bb-2f10-4256-aaab-4354d34a990d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:01.255493
2d888e19-86e0-45d5-97a9-7054414360a2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:01.125117
094e9c60-1a04-4f2e-abbe-3803e77bc1a1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "9f827a0f-d7e5-4d4f-8dd7-8f4e834e828c", "branch_id": null, "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:21.061277
39b9c16e-960d-4a6f-b61d-99c30c4b0731	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "0b565a3d-6704-4165-a9e0-a38fcd069740", "branch_id": null, "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.222988
0de74e25-05e8-4849-98da-fae4d4f3df9b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "9cf1a42b-8b2f-4303-b4d2-91b0329ecaad", "intermediary_id": "befe3fcf-8d2f-48b2-b7d4-902ab1ff7dde"}	2026-07-20 12:50:31.183384
deffa4a4-4371-4451-b3f3-567e759437e0	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:00.827114
1582f8f9-fe35-4b5a-8707-cc5974754c8d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.428954
91c91edd-b191-4765-b5f0-0932b4fc96b1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.73396
d3c02712-7825-4422-b411-0c644fd1936c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.73496
3e8f9fa1-a60f-4c78-9eca-b5397e8292e7	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:22.852808
d848c2de-1347-43ef-89ff-db2d2c94c2aa	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:54.791886
75eb563e-c0ba-40cc-a30c-e3e43465fc40	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:36.077996
d6308aad-6cd3-4a8d-b42c-e8757c5c29cc	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.184137
ba4b703a-d9ae-4417-8453-a1f339cb9663	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.234435
2bcbec1f-ff57-44c0-8eb5-7618f02d859f	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.284564
ae0535f3-d5e2-4bb1-8bdb-dec16d90cac9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.329385
b1032289-bad9-4fc4-8fe5-fd0ce40a719d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.358737
163cc9ff-0056-4413-9326-f2cd75035e51	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:37.381516
36cb6556-74ab-400e-ab19-203fbb98a61e	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:37.442593
0f250b46-aabf-4319-b72c-62a71821e195	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.608477
687d3e6d-0acb-4447-8cd9-08108b69a6ae	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "3f41a151-90b3-4192-bad6-064a66c6eee4", "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.613022
6a7b9f8f-b068-4669-8692-b42bd72f10b2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:45.456288
80b08a70-cbc7-4394-8e23-3b6f78cf1dc0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "4ebb6b89-05bb-4c05-b2fb-ea503d8cf344", "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.619489
7e953dcc-c93a-436b-8d5e-71279adfd861	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "88b38220-d2d3-4541-b20e-3d0562c9d2ed", "user_id": "0972da5f-4283-4bc3-a315-d612322fea76", "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.62633
acbdc3a5-5c91-4dc2-98a3-15a098c0dddf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "d82cef69-fd98-451a-99f6-64e996e3ebb7", "user_id": "1da5234c-a6a8-492f-9526-6e9aefba973e", "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.633581
eac26bae-4d7f-43d0-ae74-06f1781a66b0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "cea0c7ce-54da-4e0d-855c-ea6b8602ff93", "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.650589
b363ea93-47b4-467e-ab3c-30ab2bfe6fa2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:50:49.190169
33b781d8-96b2-421f-a824-be37247a4d91	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:50:49.25048
537c1447-52bc-498b-bac1-3055e307f24b	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:40.405575
b15cb749-3823-4406-9d8f-45123e1bbd46	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:53:53.56294
c4692384-8f7e-45b6-ad48-093c53456972	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "15a88353-204f-4862-b9da-c2ecb0ff62c6", "branch_id": null, "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.653381
8e184367-5539-4556-8063-33f0537d38d8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_451316e7-1014-438b-a3b2-68579a01e706", "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.673456
9b30f1a9-12ef-46cd-9fd5-ffe4ff64a1ed	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.298173
53cd3fbb-3f24-40ae-8f0b-9df4d53833b8	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.329386
87a44bba-09d6-44ea-9223-6223ff4a2263	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.331046
04d5ca18-85a7-4b36-a5ef-c84642e77169	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.36862
441145d1-fc9b-4b69-b688-dae4fb05e0d3	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.369155
f100841d-0b38-4b07-9354-0e9c8f2624a6	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.416941
ee1b691c-1ebf-4f9a-ba6a-d970f671c363	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.417819
ba3abe74-f8ea-4dbb-99d8-460dff233eb9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.443937
2a732340-fb46-4ada-89ad-fc28f9e37a9c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.465911
c1dde7d5-a95e-47ad-8cff-0e4185932a88	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.528921
b37fa7bc-01f1-4356-a6b7-e5e50baedea6	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:33.580141
e26fcfbb-ecc1-4f90-99a3-612dd8b2a973	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:51:33.597834
33132e6b-4944-4dbd-94a0-730fce5e95f4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_d5852570-488b-4908-81af-ba42da19b7c6", "intermediary_id": "b74bdff5-fc3c-4540-b717-821f8121921b"}	2026-07-20 12:51:35.881356
683f414f-ec38-4dc5-ab84-99038540cc12	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "b74bdff5-fc3c-4540-b717-821f8121921b"}	2026-07-20 12:51:35.891328
1b985944-41a8-4a02-b3d6-80448d98ce80	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_92119a04-79d9-49be-92a4-21d9fca230a8", "intermediary_id": "13e5b9ad-b32f-4f92-bdb8-31634b4c0eb5"}	2026-07-20 12:51:35.909225
d3364f76-7cb5-4bd3-bd78-198ec5f16c03	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "9f5ac01e-6589-4d60-9777-50a655137cc6", "intermediary_id": "13e5b9ad-b32f-4f92-bdb8-31634b4c0eb5"}	2026-07-20 12:51:35.918581
a3ac6f63-10fd-4546-ad80-57b934fbfe13	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "9f5ac01e-6589-4d60-9777-50a655137cc6", "intermediary_id": null}	2026-07-20 12:51:35.926766
f2eda19f-5ab0-462f-a00e-28603a9a6ee2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_355d3fde-dc71-4525-b63c-6c1b45728e2e", "intermediary_id": "de19cdf8-77f4-4f3b-aa1b-353b17745376"}	2026-07-20 12:51:35.961941
c65c2e51-b28c-480b-8cd7-d8e0e74de478	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "de19cdf8-77f4-4f3b-aa1b-353b17745376"}	2026-07-20 12:51:35.967026
12578538-955c-4705-8962-c5fe5ac2da4a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "a7e76b2f-dd76-4c7e-966e-d323ff33d45a", "intermediary_id": "de19cdf8-77f4-4f3b-aa1b-353b17745376"}	2026-07-20 12:51:35.971718
28c37425-f050-44cd-bda0-11aa8351fb3a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.460559
dd11921d-49de-41d8-bb9f-014ebba11e69	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.501155
18b020d3-95ae-410f-a6c6-7f995d5fa530	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.540994
b2465904-63d8-4a1b-8c5f-8ba807be5353	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:57.464394
5e97f8e1-7811-4d9e-94b2-6dd7d6501358	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_27a59b66-049c-460c-83a8-89aad975acb5", "intermediary_id": "a5335ed7-4cb1-4f7f-839f-7a4df19eecec"}	2026-07-20 12:53:47.436023
af4e9e3b-d29a-4323-9c9b-95f1efcb6ea8	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_fd0b79cf-df65-4bde-8075-07de4a651417", "intermediary_id": "39aad24d-4a09-4058-a202-479319ca1725"}	2026-07-20 12:53:47.457884
a58bfcbf-1eb3-4f27-899d-85982bca0059	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "b91f75fc-4094-4d25-81ed-c90231105dca", "intermediary_id": "fae0b3e7-3fb9-46d7-a5dd-7835735e796a"}	2026-07-20 12:53:47.531062
ff65d866-6204-46d1-8edf-e8ab866a12d7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "6bbe2495-c159-4af0-b082-8f406382a614", "intermediary_id": "fae0b3e7-3fb9-46d7-a5dd-7835735e796a"}	2026-07-20 12:53:47.537247
07addae0-a898-49d5-8685-d42f7d75c6f4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "2a8c9955-6e09-4148-8b1a-14072015760a", "intermediary_id": "de19cdf8-77f4-4f3b-aa1b-353b17745376"}	2026-07-20 12:51:35.975965
f30b1ef8-f2e6-40eb-8644-99b4bd1535ed	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "a1a36453-c73a-4dbe-9487-dc8cde648977", "user_id": "21b8b550-f83d-4ccd-936c-72429123fff2", "intermediary_id": "de19cdf8-77f4-4f3b-aa1b-353b17745376"}	2026-07-20 12:51:35.982339
27ba9473-8a9f-470b-a921-418102a5dbda	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "30809693-51fa-4266-968e-4fed15520cad", "user_id": "5b42d70f-b651-4152-b6d5-16efbc6bbc7b", "intermediary_id": "de19cdf8-77f4-4f3b-aa1b-353b17745376"}	2026-07-20 12:51:35.987232
8a38ff8d-f5f9-414b-8299-22f62199b430	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "6bf8acbe-263a-4345-adac-4192d48713a1", "intermediary_id": "de19cdf8-77f4-4f3b-aa1b-353b17745376"}	2026-07-20 12:51:36.053912
283733d8-0e62-4013-acec-1619e8ef118d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_0a47b99a-b365-46ad-8534-45cc6a697862", "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.086232
0cb4aae2-ee65-4c93-9da1-c0818fa630e7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.092303
77518de8-f8f5-4c3f-8ac6-4cdab218d401	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "8ddc0316-5c07-459b-8345-79dac4759f7b", "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.097955
a7156a70-18bf-478e-9328-6ed5cb8aa6e5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "a500d9c2-d978-4429-972e-5041bf105848", "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.10407
878e0bbb-638b-4c99-932b-dfbcdb8b3466	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "27817a75-a67c-446b-9011-20d67256d06b", "user_id": "e20c853e-4932-4933-8920-527834e4e782", "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.110983
d000afde-960a-46a7-970c-6f317b075950	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "4aac3c3a-93bb-47c7-8925-2a3c256fd5a9", "user_id": "f989385c-31ac-4b3c-aff0-f59fd6bdab6f", "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.117954
09611398-c2b2-4236-9ec3-816a51d4b4be	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "f59261a7-ccd3-4a94-931a-19d5c6df4587", "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.13604
49a27097-2260-49ba-a9e6-263c13f1b863	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "bfeab530-e1b8-422c-923b-be48155586e1", "branch_id": null, "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.271554
2e3c96c2-2e65-4467-b907-9b63f0d14d3a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "bfeab530-e1b8-422c-923b-be48155586e1", "branch_id": null, "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.276762
abe552d9-436b-4896-ad9a-ea08f2b17cd9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "bfeab530-e1b8-422c-923b-be48155586e1", "branch_id": null, "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.290156
f41aa078-08c8-43ba-b508-cd102b6a05cc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_47544007-9729-4b54-bfa9-8062eca3a965", "intermediary_id": "749c3207-4306-4ac5-953d-973f23e2c734"}	2026-07-20 12:51:36.296938
a6e95fdb-036d-4516-95d3-50739270419f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "749c3207-4306-4ac5-953d-973f23e2c734"}	2026-07-20 12:51:36.302438
4b6ffaa7-8116-4f1a-98e4-3846823442a5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_555c8451-68fa-4c9e-bb5c-0f1ee4459673", "intermediary_id": "8cf67a6f-1b8c-43a1-bbb7-a2b404a0ee9b"}	2026-07-20 12:51:36.32189
9b60eb12-e418-44bc-8c54-4c6a05b3d98c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "81444bd7-b180-4720-8267-00b04e121fac", "user_id": "dc95c8ea-248d-4213-a779-c6a9534ae964", "intermediary_id": "fae0b3e7-3fb9-46d7-a5dd-7835735e796a"}	2026-07-20 12:53:47.544562
cb332d82-e19e-43b9-a89d-381e777ffa85	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "f3f1fa1b-0048-42ea-b158-8dd4ed90dee5", "intermediary_id": "916e00d1-b697-49e0-ada2-618b24f65a19"}	2026-07-20 12:53:47.689741
44e66b39-cfcb-408c-a688-d5f08fd7b9f7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "a83c51cc-1da4-48b6-801b-5864679ab9e6", "intermediary_id": "b6f69ef9-abcb-4bdd-8428-3e1fdbbbc92d"}	2026-07-20 12:53:47.770092
f0d2899d-f076-460f-8bda-9d7ef20e0bda	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:22.853228
6aa332b8-1423-4213-9ec1-b5f8b0038257	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:53:53.605783
e510b19c-41d1-438f-9290-a71af7fbd6b5	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:53:53.706569
7c1e90bb-c351-4f8a-b10c-7a16a0c58d65	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:40.349994
7c131b4d-39df-4051-92e6-e23374195e85	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:07.289161
74e9ab86-21ee-498c-a8f0-e4837639fd38	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:07.349209
69d65469-8936-4ca7-add9-b6b43a23ef5e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:07.350513
2d14d435-c9b5-488d-9549-597780412f3d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.256677
1e58c734-f89b-4458-86bb-852914287471	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.287357
e8703360-43c2-4749-a847-4591cf7b8da2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.324771
1bf84777-9755-4a93-b291-ad6dc6cd33b7	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.49628
a5b71732-875c-40f4-b166-8dc34aaf316c	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.515638
fc013700-7868-4f6a-9943-13fbe2944b7b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.574673
c7636986-4434-42eb-825d-da139fa431bd	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:52:45.601411
fdf0819e-bf5e-46bd-8530-c173e16c0b58	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:45.660543
78a32613-ce5f-4f3d-82fc-ced957ee2ac4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "5a28aebd-d8ba-425a-b6d6-b7dc9ff192fd", "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.169209
f65f705e-179b-47bf-a270-92007600c9a6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "f59261a7-ccd3-4a94-931a-19d5c6df4587", "branch_id": null, "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.153947
471c7e4d-4044-4d85-a2fe-f1baecd0c079	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "5a28aebd-d8ba-425a-b6d6-b7dc9ff192fd", "branch_id": null, "intermediary_id": "6ea0587d-33ba-4813-9820-75d914f71559"}	2026-07-20 12:51:36.18064
6bf87131-18b7-43f0-a530-2953ffc3c647	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_9e4e5fbc-080e-43ca-88bd-ca8fa5e80306", "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.197048
9a9a212d-fca7-467a-8c2a-b23d56e96003	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.201957
28dfaea8-87fd-47b9-aa5e-3b9acf0e92b1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "601d5869-a8ae-4cf4-8765-189788aed43f", "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.211845
14aa254c-ce12-40b6-8089-609ff827b117	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "bc216380-0a27-4de6-952f-0d7a07265127", "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.221451
7e0d0a8c-b0ed-4558-bc5c-a651d7b42853	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "c2a847d9-1d5d-4ded-9845-9ee05851def1", "user_id": "66fcb048-1127-45ed-8257-cfbeec6929bc", "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.233449
e9e6545e-ebd7-4a37-9509-69c6b0a4f132	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "85a19bf1-113c-4f92-bdda-f4477da72f30", "user_id": "b9409e56-a852-45b2-aa44-6c58a19af826", "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.239863
9431fecd-e8c2-4b07-a737-3b8555cd8778	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "bfeab530-e1b8-422c-923b-be48155586e1", "intermediary_id": "eaa7f403-b1d7-4804-bc50-4d91fa6bdb95"}	2026-07-20 12:51:36.254992
6790f2ad-de27-49ef-8176-edc7103777f7	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:52:57.46382
413de27f-84bb-447d-9317-75b179ef9f7f	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:39.927538
eafd36b5-ade3-4e4e-8307-7f04252d3236	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_bdf9278f-d505-49f1-8798-0fbfacf6c738", "intermediary_id": "39870476-e1e3-41a6-a100-4587a7ed9a14"}	2026-07-20 12:53:47.817037
5513c43c-636f-4386-862e-2100de418f74	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:01.010441
a5e01b89-298b-4787-9c56-ac6243e08753	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:01.053125
28e5bc84-804d-4b62-b774-5d63d52e86dc	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:01.125866
d48e97ed-b0ed-4f7c-a789-6bf162d4d9c4	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:49.345964
2ee627f0-36aa-465d-9012-225eaa4fbfcb	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:51:49.41366
302a3df5-2c40-4527-b67d-86dd9004e2a9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:01.205176
db41f481-bff9-4ed3-ae97-09ca6ff67df2	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:01.257114
3625ba88-b92b-4d3c-9943-6f2f49054b95	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:53:53.4818
f0124944-65e6-409d-bdde-3e9db746ea09	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:53:53.51799
292a4d64-a590-43b5-9d0c-c7c3294970e3	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:53:53.562573
9a1f1683-4adb-436f-b94d-f63c6c68f8e6	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:53:53.633811
d576cb69-ec37-4614-95a2-7add7c684708	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:53:53.655345
847cfd7c-ff3e-443b-b470-462019d5cc4a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:53:53.63429
eb9a5ca0-d344-4348-975f-2f62f52f9c1d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:53:53.654361
1371d316-2bd7-4ab4-8a7d-6d3cc13a38b1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:53:53.706687
d5ad4c59-efc3-4b90-9fb6-ea84998173fa	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:03.221726
84a4e6ee-0f3d-4280-9fd5-54d5f6e5eae0	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:22.88953
ab6c88ad-92f3-4402-91d4-59b3d9369d3d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:07.290762
db587b40-0f2c-471f-83d2-896472deeb21	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:23.00509
af83f1d2-4a0d-490c-82a8-636530bd5485	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:23.027838
bfe00aa1-ccb6-466b-a29d-ac05ba9b59ea	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.256678
578502c9-f98d-4e46-b5dc-fb1007e390f1	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.287828
c26cf238-81fe-4fea-af94-b0dce8bb061a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.3243
38340d1b-d775-48a3-beb1-31dda598a9e8	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.367036
20b150f4-9714-43b6-bd2a-e84e29f749f4	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.368286
ab33fc51-bc71-40b1-ba3b-0446f855112c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.392545
862b2988-0758-4449-8438-e41a16da1421	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.393922
5ff1b737-db83-4c8e-abd3-6b9c61fb123b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.411143
00ccf61a-a2a8-4ae3-a908-9600c24c075c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.411155
7e7d0221-b9fb-4942-b5ae-eb8dbb28c384	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:54:46.458684
91d9d26a-5da9-4a7e-9fbd-656d10115684	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.458776
82d107e0-4715-416a-86ba-aa9b725c3486	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.496431
5d05f494-6e78-4d76-8940-908e24f57993	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:54:46.51592
8f360043-bbfd-4dc9-9975-7d720a5ea885	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_7fd39804-224b-45b9-87c4-51de4056f1f3", "intermediary_id": "7047a6a3-1dae-4e0d-9279-d10e28598c11"}	2026-07-20 12:54:53.35978
2e5b5b90-7033-45d6-a469-df39e6e28bb8	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:03.529654
4b3cb565-fd35-41b7-9bab-48e86167029e	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:05.427649
1d6deb09-ce58-4a63-9644-7cf9e8d2187c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_358bc55f-80de-4beb-86c6-5b89d2a4eec0", "intermediary_id": "314fa1bd-756d-48a8-b707-d88b60d8b98d"}	2026-07-20 12:56:20.71055
239a753e-5fd2-414e-8fbf-99f711250a62	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "f732cb00-b27d-4ab8-be8e-8f0997a0a9c5", "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:21.006108
a487a529-8a45-4291-b9de-5da4ec20e182	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "afd17f9b-9c96-4535-9105-7c446814942d", "user_id": "d1fc6c39-3fb9-44de-a944-d515a8fa60ea", "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:21.012828
c94823c2-791d-4642-bab8-772f9bb986d3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "24136a9c-c485-4731-95c5-b8caa559e7c8", "user_id": "89171d1e-ade5-4450-98c3-d11e727edc03", "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:21.019296
580ac78b-541a-4215-864e-75646a30322c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "9f827a0f-d7e5-4d4f-8dd7-8f4e834e828c", "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:21.035364
82603e51-315c-4a2a-9ce2-616e8a444e01	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_d527eafa-dd76-4561-a0e1-c0be41d44396", "intermediary_id": "a3843709-c387-430d-9676-f3777879e90a"}	2026-07-20 12:54:53.382306
63149bae-9a77-40e5-bcb7-58f3550057f6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_765a1db6-bd7c-4527-93d6-88916822efc5", "intermediary_id": "1e2b061f-e0d6-4a4a-bcca-6fe9c2c170fd"}	2026-07-20 12:54:53.442095
b06f52e3-54b4-46ef-991c-96235db151f1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "1e2b061f-e0d6-4a4a-bcca-6fe9c2c170fd"}	2026-07-20 12:54:53.44754
837b96cd-795f-4bd6-85cd-f2585e9541f1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "796315b5-ba31-437c-ae05-4d3bd5a4cb4e", "intermediary_id": "1e2b061f-e0d6-4a4a-bcca-6fe9c2c170fd"}	2026-07-20 12:54:53.45296
f0fa8aba-e311-4775-9c8f-8650874225ea	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_19a5c049-6670-455b-abf2-e84ba87fb4fe", "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.530463
c1f86b2d-5ad8-4998-a741-4174874e3d00	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.536309
e8b0d380-cd06-4449-990b-d676c4962372	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "2b8bbd0a-869c-434f-9e6c-a07c73c5dab9", "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.54509
d2638848-a8df-4f42-a353-78222e9f7a9b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "af60f10d-64af-45e5-81bd-fbe5bf79f969", "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.55258
1b176881-cebb-4956-8034-a53e67a7213f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "afb9da10-8263-4701-98bd-56d960756363", "user_id": "5097e385-48ad-4623-ab3b-8f254460d40d", "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.563195
d318d355-1a5e-46c9-9da8-ff90540c9a85	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "fbabf3a4-8f68-482e-a95e-52b4ec1bbeac", "user_id": "748a5a31-c199-4242-a3dd-266b72a837f1", "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.570478
fda74daa-b469-4946-b8b2-7116cee35afd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "5470f9c2-e13d-406a-8321-a8d1deb61387", "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.588697
18011db2-850a-4a35-b29e-932f764ae042	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "5470f9c2-e13d-406a-8321-a8d1deb61387", "branch_id": null, "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.611076
ff9a420d-29fd-40f8-98c9-bef6b1776f83	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "37ca8073-b41e-4538-a515-d5f21576119a", "branch_id": null, "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.64338
19efb62b-5cdc-44d1-b797-f7b002eb1629	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_f8e38f84-25df-4623-a53a-6a5c3cd0deac", "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.679512
dbaab7fd-1ee9-4f0f-bfa2-32562ead19bf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.691126
5911cfdf-36bb-4634-9ee0-4cd3e4225519	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "8da17d91-f12d-436a-a399-7f4f7970c5bf", "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.694165
46463861-4ff0-451c-abd1-9a4eb7354a6e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "7c95dcea-b758-4e5b-afc3-5f874de71a73", "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.700968
b9c0abe0-1f66-4450-a9ab-bdc3c0bfe5a2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "19e0b7c0-7a6f-4625-96be-86f37507b95c", "user_id": "5db670bd-913a-4901-b2fe-b979a38222da", "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.706679
cf45d4ca-ffe8-4097-87f9-1821b90f34ab	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "7eca15ca-dac7-479b-a86d-f40e3c45e6fe", "user_id": "eadc1d36-553d-4507-adcd-0209110a1c5f", "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.712338
fcfbc826-618a-4c64-ad0c-a5c0016e002b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "80be474c-c709-46a8-9f58-69df97ac9e13", "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.730049
fefec9cf-7201-4f7b-8861-4a0576f2d36b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "80be474c-c709-46a8-9f58-69df97ac9e13", "branch_id": null, "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.751804
fa81d8cf-df87-412d-9c00-54d9bf392059	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "80be474c-c709-46a8-9f58-69df97ac9e13", "branch_id": null, "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.761185
3757a9ef-cc42-442a-a05c-eed94c399a08	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "80be474c-c709-46a8-9f58-69df97ac9e13", "branch_id": null, "intermediary_id": "aef8f0a1-e789-4ae3-a82d-42a66bab16e1"}	2026-07-20 12:54:53.775317
aa5263f2-472f-4ee0-baed-7728e91f3bca	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_d802732b-d4e7-4036-b2d2-8986eb50f669", "intermediary_id": "ed4de396-c2ad-4cdd-80a1-7e358a29e8e8"}	2026-07-20 12:54:53.78605
95156f5a-2053-4fff-ad84-38f2473c77ff	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "ed4de396-c2ad-4cdd-80a1-7e358a29e8e8"}	2026-07-20 12:54:53.792745
1b82f754-b935-4f59-807e-483f9bdb31db	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_72f6fee7-82a2-4f57-bddb-80bc3d2cbeee", "intermediary_id": "36b53be4-af64-4a60-8578-8e2b90e99362"}	2026-07-20 12:54:53.817527
1b68f647-6fef-439b-b6fc-a51107a736ca	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "314fa1bd-756d-48a8-b707-d88b60d8b98d"}	2026-07-20 12:56:20.718186
25c8b7ec-e2c2-4ef9-9ef0-d076f21d1144	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_2eb755f1-2c97-4b4a-9e3f-6264814f0b6e", "intermediary_id": "43d32927-c6f0-40d6-8d98-936aba40679c"}	2026-07-20 12:56:20.73433
438838c6-612c-4dd7-ace3-7b9640dd6e2b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "b41a5bf5-c0e3-4586-8f01-bf86e8add323", "intermediary_id": "43d32927-c6f0-40d6-8d98-936aba40679c"}	2026-07-20 12:56:20.742152
39507b13-c11c-4023-8c13-b6a0048e3a94	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "b41a5bf5-c0e3-4586-8f01-bf86e8add323", "intermediary_id": null}	2026-07-20 12:56:20.850195
d3a61887-a623-4ae2-a9f2-cc619fd0f888	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_ed7b759d-a479-4470-a18b-502b911f3fb8", "intermediary_id": "beef1b8d-fb44-41dc-b6de-bf8cb2853505"}	2026-07-20 12:56:20.905602
e58b44ee-979e-42ab-8f40-99efc638e296	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "beef1b8d-fb44-41dc-b6de-bf8cb2853505"}	2026-07-20 12:56:20.911494
d7133361-d873-4032-86ba-acce73db5087	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "6b0b19d0-ae2c-47b3-9fae-0d7b4b85c172", "intermediary_id": "beef1b8d-fb44-41dc-b6de-bf8cb2853505"}	2026-07-20 12:56:20.916491
385fe40d-a1da-454e-a84b-b7d854a3fcad	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "71f32ae5-7283-4d1d-8c70-9b4f1df00b4c", "intermediary_id": "beef1b8d-fb44-41dc-b6de-bf8cb2853505"}	2026-07-20 12:56:20.922261
22ca8ef6-1229-4089-b0dc-f043e97a943a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "3bb4baec-0fbd-4023-88ae-a524a3f55d1c", "user_id": "2642b00f-36a7-4a3e-ac66-00a472a1d47c", "intermediary_id": "beef1b8d-fb44-41dc-b6de-bf8cb2853505"}	2026-07-20 12:56:20.928133
261dce5b-9210-44e2-bf70-b718fe9553c5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "4b991662-35ac-48ee-a41d-78f55542b6fe", "user_id": "0044540e-edbe-4ce6-b9cc-6fbea2a3a2b7", "intermediary_id": "beef1b8d-fb44-41dc-b6de-bf8cb2853505"}	2026-07-20 12:56:20.933765
2e7efb18-806e-4668-9acb-d1900b9d9eb0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "d7dd3d89-df04-4400-a4ee-e9c2bebb1f49", "intermediary_id": "beef1b8d-fb44-41dc-b6de-bf8cb2853505"}	2026-07-20 12:56:20.947638
fb515b32-d3bd-4429-9403-d05e72c6503f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "befa08a2-710d-46ce-9aa2-4578ab4f1236"}	2026-07-20 12:56:21.259879
b1041c55-7633-4d07-bb6c-2c631a1fd9a0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_8a730186-08f9-4245-94de-d1c7f1da9607", "intermediary_id": "c77b73d0-4e60-4bed-a33a-e4da0d3aa474"}	2026-07-20 12:56:21.281542
e305f49f-45e4-478d-9d8a-5e070e3b3b32	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:23.028521
a1543692-4534-4d37-ae43-b5534bad2c9a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:23.055559
770d3952-c2a8-4162-998d-0cbfaf95ac2c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:23.103956
384079cf-6193-47eb-bf3c-57f688e01f41	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:36.079352
946ca366-982e-4727-8fb8-42109d00d297	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.4417
0c7e539c-7df2-4400-81a2-5b5ff6eade5f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "5457ac24-0c4b-4d76-8b50-32266d0e41f7", "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.446627
ea6edc9a-37bc-4d86-8270-7e8f39dcd256	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "f242f50a-c0d6-45c8-bfda-89c2e1166ac2", "branch_id": null, "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.617414
c7726476-316c-48b2-ba2a-3ce8d1f21a4c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "ab103258-e037-4be6-9ace-2f2d8f437b9a", "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.684089
a41c97a0-2a12-49b3-807c-4e9d9825b224	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "6e690b24-16b9-4fef-9cd2-fc9389f1e971", "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.689778
d805f33f-3899-4887-bb24-f9ddb72f6dbf	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "21aac252-52b1-445d-bc90-8cdfdc0431cd", "user_id": "a7868e04-acb8-458f-82af-a9c1b6d7f585", "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.694787
3e6ef456-5f1f-413f-9b94-a631d93219fc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "abc41756-f56f-401e-a12e-ced5e76b8db9", "user_id": "5cd1b420-1a72-423d-acac-2e2247f5dfb2", "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.700617
565e4a2f-4b32-4a51-8573-7fbca5a439aa	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "82c2eed4-5c2f-464b-98bd-4976dbd6cf9c", "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.715472
17772656-609c-4c2d-b620-85d83f157820	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "82c2eed4-5c2f-464b-98bd-4976dbd6cf9c", "branch_id": null, "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.730087
e9bf3071-df75-49f7-976a-966f40e9e9e4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "82c2eed4-5c2f-464b-98bd-4976dbd6cf9c", "branch_id": null, "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.738669
2001ceb4-0091-44ff-9ce8-51211a21d39f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "82c2eed4-5c2f-464b-98bd-4976dbd6cf9c", "branch_id": null, "intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.751281
3a264af7-bb77-4a25-8e82-be3a6fd17243	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "7047a6a3-1dae-4e0d-9279-d10e28598c11"}	2026-07-20 12:54:53.365844
ea1af08a-cc8b-4846-87f1-d58d79c77fe7	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "bd7683f1-fe7d-4229-ba78-947a40b97ac0", "intermediary_id": "a3843709-c387-430d-9676-f3777879e90a"}	2026-07-20 12:54:53.391527
944b2075-22e0-45a6-be51-c9fa391fa4ee	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "bd7683f1-fe7d-4229-ba78-947a40b97ac0", "intermediary_id": null}	2026-07-20 12:54:53.404013
896a6eae-a460-44b4-a590-75b74bec55c0	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "54bd78e5-0d4c-4f5f-904e-d895533d45b1", "intermediary_id": "1e2b061f-e0d6-4a4a-bcca-6fe9c2c170fd"}	2026-07-20 12:54:53.46176
ceafb0ee-334e-4f97-8cc2-00e2681fe879	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "395179f8-38b8-47ce-a8fb-a2d33c2abb8d", "user_id": "b871fb67-6145-4ea3-93b2-3c546c381cd6", "intermediary_id": "1e2b061f-e0d6-4a4a-bcca-6fe9c2c170fd"}	2026-07-20 12:54:53.46911
4d4f052f-dea0-40b9-bdfe-2d7f79412021	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "47d80592-0104-40ad-ba9d-4c45c28c0439", "user_id": "169147ce-3451-4bf7-ab8c-86983a16dd84", "intermediary_id": "1e2b061f-e0d6-4a4a-bcca-6fe9c2c170fd"}	2026-07-20 12:54:53.47524
7b8e3ad5-4619-4285-b59f-96bc55ca23c2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "72ca2dbd-4392-4a84-b516-fe8f5584564d", "intermediary_id": "1e2b061f-e0d6-4a4a-bcca-6fe9c2c170fd"}	2026-07-20 12:54:53.489593
102fab59-1959-403b-b482-3f84c7f0eb0d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "37ca8073-b41e-4538-a515-d5f21576119a", "intermediary_id": "d65bcb41-21ff-4da4-9a4c-e55a24ed26d7"}	2026-07-20 12:54:53.630098
3062f6b0-1e5c-4907-b3a7-cace2dcc0cb9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:03.529652
07ebea82-8738-40ae-855b-4d940304b7ca	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:05.426255
f22c2276-8aee-4755-a25b-09f234fcccd8	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:55:05.496322
578998c6-e355-4a86-ab23-47ec44460823	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:55:05.497988
b6404ffb-d52c-4a3f-a1b0-7d7d0ec6da30	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_a59c096e-1ef5-4892-bd8a-25232718d324", "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:20.991533
b1478bdd-da96-425b-9836-0c74b086fd2b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:20.997174
e0a48bd4-7ceb-4dc2-b26e-35ca980f3745	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "4d547bc5-b2e1-4f65-83d6-264e42ca491c", "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:21.002368
6788df83-4a75-4ff6-ae11-caaea53337a6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "89face93-e3b0-45bf-9cf6-71414a4c18c5", "branch_id": null, "intermediary_id": "2b31f767-3211-4b85-8d45-9002d8728de5"}	2026-07-20 12:56:21.106854
122fb1fa-aeec-412e-ada6-3812de74d84f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_1dbb8d3f-bbcc-4c38-96d9-79e7f802eaf4", "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.14696
c9944e72-ad1d-43fd-9d57-e18317e5ff41	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.158862
0d0b6561-0f80-4778-919b-d3c1b9d0ba9e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "ed265fcc-257e-4d2f-be90-46f884530672", "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.167667
5f53e6cc-6afb-4373-bd77-014e4a36d0d2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "7f5c2baf-735f-4e81-b028-655f1cb4c2d7", "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.173639
e982c82a-eeac-4a6b-a010-df6b33dfff40	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "3709ba79-db8d-4e50-a94d-e78c01a8d9a3", "user_id": "f4f2519c-94dc-4bbd-b232-0322325e33f5", "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.180898
11e69ec7-e247-43a8-9afe-85cdf944ca70	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "e37e318b-7bc1-4cb4-9571-c0b1243ce6c7", "user_id": "863b0ba5-9a6d-4911-b14d-92743978ba55", "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.187031
486202bf-a68e-4dd1-b1cc-337fceeb524c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "0b565a3d-6704-4165-a9e0-a38fcd069740", "intermediary_id": "1b3433ab-c47b-4ad2-8d25-3e1a673f5a36"}	2026-07-20 12:56:21.2024
f5a6613c-2b3d-41c9-9d53-f092df86cd28	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:23.104546
50ff3fa8-7d29-4be8-901d-aad5f393d3d8	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:23.153783
126bcf4f-ad52-4e5c-b692-08550571d92b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 12:56:23.179711
c8dcde12-f4cb-4401-86a9-7003dc719e0d	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 12:56:40.348401
b0d6eb3c-01a6-4959-9550-847d583787d5	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "c4f10480-4107-4c52-9525-7fab2968377c"}	2026-07-20 13:33:14.056618
300aebb0-dafc-4123-86c2-b3849aa15449	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_b6df94be-3c86-4825-bad5-27ccae2841d0", "intermediary_id": "7acc3a3d-38f3-4313-8a1c-0c95e85a9ab3"}	2026-07-20 13:33:14.087588
42893cc6-3937-4411-b744-48763997b6bb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "86ee860e-5fdc-4721-8dff-09648b6ca0a4", "intermediary_id": "7acc3a3d-38f3-4313-8a1c-0c95e85a9ab3"}	2026-07-20 13:33:14.096996
340c74b3-de66-403e-ae7a-795d61ade277	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "86ee860e-5fdc-4721-8dff-09648b6ca0a4", "intermediary_id": null}	2026-07-20 13:33:14.239704
a3d1340d-1ff7-4a54-af53-810e1df8ce4b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_0d8f83c2-b6d1-485e-b4de-fb83a5a94314", "intermediary_id": "d6a1565e-61a2-40a6-997a-876c7e2cc0d2"}	2026-07-20 13:33:14.352655
3a18d104-5b6b-49c8-8dbe-c8dd1b3f60a4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "d6a1565e-61a2-40a6-997a-876c7e2cc0d2"}	2026-07-20 13:33:14.357659
c1326160-be9f-4210-86ec-ef8edb7aa07d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "a159ada9-348c-4831-b05f-35a3664b6ff0", "intermediary_id": "d6a1565e-61a2-40a6-997a-876c7e2cc0d2"}	2026-07-20 13:33:14.363492
3cb478cb-48be-4321-aca9-fa23a8d84a6e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "d04b8a85-4cec-428c-b7f6-e5b18d7e7c6e", "intermediary_id": "d6a1565e-61a2-40a6-997a-876c7e2cc0d2"}	2026-07-20 13:33:14.371514
f8e0af08-96ab-4e17-80f9-3455e77d972b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_84bdba54-7a0d-4610-8741-4c2f5ccc7981", "intermediary_id": "421746ae-e5fb-4c65-ac09-6ec294b97285"}	2026-07-20 13:33:14.762742
950e60d3-8d17-4ad0-b824-f009def27c35	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "421746ae-e5fb-4c65-ac09-6ec294b97285"}	2026-07-20 13:33:14.765472
999f2400-614a-47e0-bd25-70db5cf9db68	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_cae25033-f1f1-4b49-a176-d30e56246298", "intermediary_id": "501c3026-eb0f-4eb3-8be6-dfaaabf9171a"}	2026-07-20 13:33:14.791519
027340dd-30d4-4779-b695-b2787a492444	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_4a3f5996-71da-4370-8f36-b0069e7ba420", "intermediary_id": "c4f10480-4107-4c52-9525-7fab2968377c"}	2026-07-20 13:33:14.045047
7ef0eda3-6d5e-4fb9-a65d-bdff583d47e1	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "f5d83702-9b1f-4293-9023-8efc1b016049", "user_id": "32ae1357-0b47-4419-9707-2ffbade34d88", "intermediary_id": "d6a1565e-61a2-40a6-997a-876c7e2cc0d2"}	2026-07-20 13:33:14.378241
4f4af861-daf2-4312-8a23-36f1da9c670e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "2daecf8e-afbb-4767-87c6-2c29175572cf", "user_id": "cd5f23b6-42c8-470b-b304-f2e72fbdf054", "intermediary_id": "d6a1565e-61a2-40a6-997a-876c7e2cc0d2"}	2026-07-20 13:33:14.383822
cbd0e7f2-c50f-4111-81b4-fc544b8795ac	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_15dea74c-fc00-471b-acde-b38c2bbdf7aa", "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.437449
059d91a5-cdc8-4f19-8e3f-7450a62f65c3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "d864ea45-533d-4a5e-b853-12fcd7d87b55", "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.454269
f602675d-89ad-45c3-9c1c-4200036160bc	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "58aeedf5-c811-4d31-9909-c71a3eae84bb", "user_id": "fae657bb-457e-4802-88c6-eca80f4d3a72", "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.461099
d1c48152-bd85-4302-b2b5-e03135818cf4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "e5fe4f60-08de-4ed0-bb5c-18d712460453", "user_id": "8c79a6b3-92f9-4eda-a4ee-3c4a26b1d335", "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.467093
28b457c9-4a93-4d77-814c-ebefaf628c3b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "f242f50a-c0d6-45c8-bfda-89c2e1166ac2", "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.485135
e818d91e-97f8-41f6-a984-4074b1799f25	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "15a88353-204f-4862-b9da-c2ecb0ff62c6", "intermediary_id": "c2f5e136-75d8-4779-b13b-1fb383d61fee"}	2026-07-20 13:33:14.637596
73a61647-5b8c-4a2f-8595-e2da8a4bbae2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "add85f87-13b8-4c6a-942c-6c8695fb723c"}	2026-07-20 13:33:14.678919
0e321488-a2c5-4696-b862-d86c94b8d814	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.059895
22ee79be-686c-4f6c-a8ed-3d3af25c722c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.092199
d3af7ffc-9a52-4123-a12b-a72939bd0063	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.132681
c76a6c50-4ab8-47af-8f50-bb63b39e43ff	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.201073
8926f289-a524-41d3-b62a-ca0d89ff1afc	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.220658
b2c46120-ba41-4bb9-b07c-83eeb3f55d3d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.257998
eecfd499-1072-40be-a66b-3ede80f990f1	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.302805
b97adffb-8f80-4a8f-84a0-c26794254642	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.327849
35254206-ade3-4752-a5e1-282894da5883	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.201309
c7e75c1b-a7f8-4ee9-96bd-2da6caabd758	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.220722
cc3e8210-d00c-46b5-a12b-efbebbdfdcf1	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.257417
0ced373d-c837-4f5e-9df6-34b44fbecc9d	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.061304
5f6a12dc-d3d8-46ee-a466-2987b9f7bc46	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.091737
2e550603-1f06-4b90-b6f7-48850a205037	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.131526
4b5c4fc3-e31d-4232-b327-e9b4c51d5b25	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.172416
01d2721b-d603-4654-a42c-ad3062ee5b16	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.17376
a5e821d6-442d-4cf2-9d4b-e59b0a731846	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:25.303175
0ec4d291-f7ae-4482-8944-afedda4b734c	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:25.326963
60dcef78-d335-44f3-8a36-f9941d0db7a2	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:32.806683
ec6a07de-18c0-46db-ab56-976c05b4d31a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:32.808717
0e1726f3-34c6-4269-b0d7-14bf39593aad	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:35.682007
c88c708b-60ae-49a7-81b3-a7a2729a52b0	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:35.683513
a50fc729-ebc3-415d-8f5e-037c844a0db7	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 13:33:35.748003
7f4c5eca-5a25-4e97-8bf5-8940888f70ee	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 13:33:35.747089
b2f2c4f5-43c3-43d3-b825-1739e677ed64	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Bank Partner_c2200f67-6f60-4c9f-9b57-b69e495e75aa", "intermediary_id": "dbd9f4e6-a4e3-4970-94cc-339396b47b3c"}	2026-07-20 18:22:14.520458
a80ed3ff-0cc9-4b1c-aa00-ed264cff982a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "dbd9f4e6-a4e3-4970-94cc-339396b47b3c"}	2026-07-20 18:22:14.532858
b3e4aabf-f262-408e-981b-175d40b8cf32	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "IM_b617497b-8d29-4b51-8906-604a0560f9e3", "intermediary_id": "27747d76-bc88-422d-968d-b3a2ee1196b6"}	2026-07-20 18:22:14.705316
2689c9e1-ed61-47ae-b379-f35bc4e5707b	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "38cbd84e-3272-4cc3-b2a6-74e4492bae2f", "intermediary_id": "27747d76-bc88-422d-968d-b3a2ee1196b6"}	2026-07-20 18:22:14.720031
7e7a6b22-4dac-491e-8dea-8a6dba170b23	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "closed", "lead_id": "38cbd84e-3272-4cc3-b2a6-74e4492bae2f", "intermediary_id": null}	2026-07-20 18:22:14.731671
1ac64e16-2a75-444a-aa81-596437e089fb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_bd4b0eb0-f6bc-493c-946c-71b3a80b3849", "intermediary_id": "008437b2-5935-4aa6-addc-3bf943025cb5"}	2026-07-20 18:22:14.774879
f19eca0e-734f-4c33-a81b-f5a896ad6f75	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "008437b2-5935-4aa6-addc-3bf943025cb5"}	2026-07-20 18:22:14.780362
4ae7158f-b05a-4a6a-9394-333a94453cb9	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "d45df254-731b-4c5b-97b1-f9d08ba730d5", "intermediary_id": "008437b2-5935-4aa6-addc-3bf943025cb5"}	2026-07-20 18:22:14.787757
6efcbd60-6987-4b0c-9afe-4fab3d560f31	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "ec56da99-484f-4418-a755-e990b82913ba", "intermediary_id": "008437b2-5935-4aa6-addc-3bf943025cb5"}	2026-07-20 18:22:14.795287
e6e315da-e7c6-44b5-88f1-0d7b992f21fb	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "1eb93281-7dfa-4770-8873-2c1a3f89b4ed", "user_id": "dc3bcfdf-8c09-4d33-84f7-9a24d31244f5", "intermediary_id": "008437b2-5935-4aa6-addc-3bf943025cb5"}	2026-07-20 18:22:14.803459
dc387193-913f-41f2-8239-fc2b01095070	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "09fec458-0bba-4e25-8028-5741066e5da0", "user_id": "2ef717d0-ed5e-4e01-affb-1370d8ee93e5", "intermediary_id": "008437b2-5935-4aa6-addc-3bf943025cb5"}	2026-07-20 18:22:14.810711
0b45683a-cf4d-462c-8a41-eb0bcbbbb62c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "ffc1b114-395c-4550-ad5b-7484b5a4d64f", "intermediary_id": "008437b2-5935-4aa6-addc-3bf943025cb5"}	2026-07-20 18:22:14.825632
f13e792e-22b0-4474-9a87-cb2c9fe654f4	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_21a22166-b46b-4986-abd2-1fc7ed38863b", "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.860415
c012dee0-f915-4870-b9a5-121af9ab0454	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.866479
57c57ba8-7c08-41dc-9b4d-d152f668c144	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "67f220f1-4447-4f07-974c-dddf2b0d8274", "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.873065
7d4c198e-879b-4da1-bf56-5e36b33b173c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "fbec2114-5b30-4b0c-9286-b73549e9a29c", "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.888766
4fe45f21-41f8-4a20-a6b3-43e62e638147	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "0b97657f-330b-4c30-be9f-395fa6b7b056", "user_id": "3cc1c3a1-aad7-4fef-8d65-f7752a7f1439", "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.900771
00c48661-0495-4648-b7bd-04c036f521bd	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "5b179527-c28b-4928-ad54-b7cfdafdae49", "user_id": "f8bebdba-a00d-4e94-af55-a67a1a90517c", "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.908561
43ebc37f-3a68-4500-b42f-0c3ba53e00ca	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "62b53fd2-1735-461b-b542-84bb90829fdd", "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.923834
52445270-0acd-4906-af99-df9034d28eab	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "c2355cbc-24ec-4a45-b5d2-16ce54d1357d", "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.958159
b1df57a3-5c78-4b6a-9447-6f0b1da93a67	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "62b53fd2-1735-461b-b542-84bb90829fdd", "branch_id": null, "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.941286
c4b94972-4aae-4e37-9f6a-cea8a4e43eb3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "c2355cbc-24ec-4a45-b5d2-16ce54d1357d", "branch_id": null, "intermediary_id": "888b0a41-3345-4103-8c7e-4f6f56f49d62"}	2026-07-20 18:22:14.973465
a21e5b5e-5c36-41f4-ac3e-de933b60572a	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "FI Bank_41f16358-f0d3-4def-93d0-8e9bdd047d87", "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:14.995415
55656360-b0e2-4e83-b68c-d0660d4c7c14	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.000537
d2271b04-a293-44e7-bbf7-ae6b9369d28e	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "4c8ec07a-b9df-4f1b-b5aa-3287d2d3a471", "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.007844
9700d874-a08f-42af-a51d-191d866561e3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_branch_create	{"branch_id": "77c27e5a-0fa6-48a4-8174-ecaff2d245c7", "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.014204
0661977b-d43f-4ba7-8a5f-8719e4f671e6	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "ed5907f7-0d17-4636-8c73-9cbb0cfd4594", "user_id": "ade64413-89fc-4c00-aeff-6b0f9d54ebd2", "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.021858
a45187f9-e9af-406c-af4b-ea41eb33cd17	admin_action	info	\N	\N	\N	\N	\N	\N	financing_seat_create	{"seat_id": "1f1f9f58-64c9-47f4-99cb-f3cff368a693", "user_id": "79e6ed0c-ae15-4f4e-ac80-0d61b4ed102c", "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.027121
94d18428-e8b0-46e0-8eb9-8e5e2eb99e3d	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_update	{"status": "forwarded", "lead_id": "06dd679f-f76f-4d6f-b908-7e1ef2709cce", "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.043245
197e2630-5ff2-4eb9-8de1-9e3c8b7c1de2	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "contacted", "lead_id": "06dd679f-f76f-4d6f-b908-7e1ef2709cce", "branch_id": null, "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.057293
898f9b5b-5865-4d53-b6b2-e85ff67d5d47	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "06dd679f-f76f-4d6f-b908-7e1ef2709cce", "branch_id": null, "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.064003
3b9be2c8-9e5f-4a24-826f-a9384a663f1f	admin_action	info	\N	\N	\N	\N	\N	\N	financing_request_institution_update	{"status": "closed", "lead_id": "06dd679f-f76f-4d6f-b908-7e1ef2709cce", "branch_id": null, "intermediary_id": "ae1d829f-1612-4fd5-990e-c057eafa7449"}	2026-07-20 18:22:15.307552
3dfb51c2-9803-498a-98a3-876c1fd46467	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Sleepy Bank_75262896-23d2-402d-ba3a-8b4ec09fad9a", "intermediary_id": "05783ce7-65f9-4890-8c4a-488e02edeb98"}	2026-07-20 18:22:15.317619
dc870da7-6091-4e5c-b618-3fc48c508fd3	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_update	{"intermediary_id": "05783ce7-65f9-4890-8c4a-488e02edeb98"}	2026-07-20 18:22:15.326227
ef40275a-bec5-4c09-a628-0fc6f3ce747c	admin_action	info	\N	\N	\N	\N	\N	\N	financing_intermediary_create	{"name": "Role Gate Bank_ad2beafa-7cc8-419b-8c94-f4ba2da6ec3e", "intermediary_id": "753201fe-ddb5-4d84-a604-7f5805455f75"}	2026-07-20 18:22:15.348826
5050e7de-e0c3-40e2-92ad-d24bb0b60199	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.155151
66a47eb2-335a-4598-9534-1d259928a8b9	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.156627
b7c257e7-afda-4b82-8010-123a5c65adf9	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.187425
96e813c0-b90c-457a-8490-a92353a0d0f5	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.189296
83d3879b-4bde-4e6c-bfd0-00a532dbbabf	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.228856
b17e8c9a-5152-4999-8d95-a5e751de5585	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.22961
90e50c32-0ebc-4f7b-9bbd-d53dc96c3d1a	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.277142
7ba387d4-11d9-42bc-800a-224b026f51f4	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.278652
dd5d1344-a91c-4652-a305-a836e6b0e616	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.305397
be03d422-1d31-4343-953d-e9d7cc0288cf	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.305985
47f4feb2-cd84-47f6-8851-14e2eb909223	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.328086
0dc1e029-38bb-4f40-a267-9cfcb6021c78	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.327613
66b1c84f-8c94-4500-ab04-138baf853160	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.363933
1266c240-b72c-437a-86ec-f4046f3db7f1	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.363934
12dd32f1-07b5-436b-88fe-311b878a3d2b	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.409674
92b45462-1f30-459b-abf6-79fc30f5b33f	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.409658
7014048a-6ca3-4063-9422-b7e6009bd9bd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:23.43393
9847a9b9-a39b-44c9-b5d3-5ba79ee84f2a	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:23.434336
83661a98-94f0-442c-af5c-58358bcf8cfd	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:35.185203
74e5986f-98dc-427e-b83c-31f2e1ee8274	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:35.186549
eead83be-8bc4-4a2c-af84-891623d94711	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:36.354201
1ae4c209-31e2-4b06-aaee-9d83de289266	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:36.354167
bcb433be-17fa-4f7d-8a63-7b21a108dfbc	price_outlier	info	\N	\N	\N	\N	\N	\N	price_outlier	{"spam_flags": [], "is_price_outlier": true}	2026-07-20 18:22:36.424059
ea8c1d5a-eeff-4747-8e6c-2effd945e5d4	flagged_listing	info	\N	\N	\N	\N	\N	\N	price_outlier	\N	2026-07-20 18:22:36.424523
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, listing_id, guest_id, check_in, check_out, nights, price_per_night, total_price, currency, guests, note, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brands (id, name, slug, category, name_ar, country, parent_company, founded_year, logo_url, is_active, is_premium, is_electric, is_commercial, popularity, search_keywords, created_at, updated_at) FROM stdin;
fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Toyota	toyota	car	تويوتا	Japan	Toyota Motor Corporation	1937	\N	t	f	f	f	98	["toyota", "تويوتا"]	2026-07-18 21:27:17.472594	2026-07-19 13:56:38.341
d8357d5e-3e5f-4d49-82c2-80f2db20fccc	Lexus	lexus	car	لكزس	Japan	Toyota Motor Corporation	1989	\N	t	t	f	f	84	["lexus", "لكزس", "لكسس"]	2026-07-18 21:27:18.147783	2026-07-19 13:56:38.416
3121b77a-cf02-4776-a3f6-8683a9a3e883	Honda	honda	car	هوندا	Japan	Honda Motor	1948	\N	t	f	f	f	90	["honda", "هوندا"]	2026-07-18 21:27:17.864199	2026-07-19 13:56:38.429
a7d66a42-a74c-4bfb-aac7-4022144bc7bf	Acura	acura	car	أكيورا	Japan	Honda Motor	1986	\N	t	t	f	f	55	["acura", "اكيورا", "أكيورا"]	2026-07-19 13:56:38.436942	2026-07-19 13:56:38.436942
bf1f20e8-073b-4963-a44f-8f41a0126e96	Nissan	nissan	car	نيسان	Japan	Nissan Motor	1933	\N	t	f	f	f	91	["nissan", "نيسان"]	2026-07-18 21:27:17.829398	2026-07-19 13:56:38.444
6eb4dbbb-16f2-4a64-8948-e555764e3d83	Infiniti	infiniti	car	إنفينيتي	Japan	Nissan Motor	1989	\N	t	t	f	f	62	["infiniti", "انفينيتي", "إنفينيتي"]	2026-07-19 13:56:38.452516	2026-07-19 13:56:38.452516
ac9aa9b0-5671-488a-9bd9-3df82d0992fe	Mazda	mazda	car	مازда	Japan	Mazda Motor	1920	\N	t	f	f	f	80	["mazda", "مازدا", "مازда"]	2026-07-19 13:56:38.461073	2026-07-19 13:56:38.461073
efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Mitsubishi	mitsubishi	car	ميتسوبيشي	Japan	Mitsubishi Motors	1970	\N	t	f	f	f	83	["mitsubishi", "ميتسوبيشي"]	2026-07-18 21:27:18.101083	2026-07-19 13:56:38.467
92a60b99-72c1-4e00-9570-192c7fad943d	Subaru	subaru	car	سوبارو	Japan	Subaru Corporation	1953	\N	t	f	f	f	66	["subaru", "سوبارو"]	2026-07-19 13:56:38.475147	2026-07-19 13:56:38.475147
ec5e2fe8-0d74-446c-b31d-868d58560867	Suzuki	suzuki	car	سوزوكي	Japan	Suzuki Motor	1909	\N	t	f	f	f	82	["suzuki", "سوزوكي"]	2026-07-19 13:56:38.482055	2026-07-19 13:56:38.482055
db5390e7-0e5d-4c6f-b832-bc66f8242cde	Daihatsu	daihatsu	car	دايهاتسو	Japan	Toyota Motor Corporation	1907	\N	t	f	f	f	52	["daihatsu", "دايهاتسو"]	2026-07-19 13:56:38.489862	2026-07-19 13:56:38.489862
4fa2afac-bb2f-4abd-8f7b-2b9399439b51	Isuzu	isuzu	car	إيسوزو	Japan	Isuzu Motors	1916	\N	t	f	f	t	70	["isuzu", "ايسوزو", "إيسوزو"]	2026-07-19 13:56:38.503506	2026-07-19 13:56:38.503506
0dd07e84-f886-4648-8a5b-5366bfe549a1	Hino	hino	car	هينو	Japan	Toyota Motor Corporation	1942	\N	t	f	f	t	48	["hino", "هينو"]	2026-07-19 13:56:38.511659	2026-07-19 13:56:38.511659
c9bcc02d-87c4-4717-8ee9-5a7959104e52	Hyundai	hyundai	car	هيونداي	South Korea	Hyundai Motor Group	1967	\N	t	f	f	f	96	["hyundai", "هيونداي", "هيونداى"]	2026-07-18 21:27:17.520783	2026-07-19 13:56:38.521
ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Kia	kia	car	كيا	South Korea	Hyundai Motor Group	1944	\N	t	f	f	f	95	["kia", "كيا"]	2026-07-18 21:27:17.582562	2026-07-19 13:56:38.533
fd390a49-b80a-4b5e-b990-1694d701edff	Genesis	genesis	car	جينيسيس	South Korea	Hyundai Motor Group	2015	\N	t	t	f	f	58	["genesis", "جينيسيس"]	2026-07-19 13:56:38.541498	2026-07-19 13:56:38.541498
d2695d39-af45-41d8-8882-268dcc8e2d80	SsangYong (KGM)	ssangyong	car	سانج يونج	South Korea	KG Mobility	1954	\N	t	f	f	f	45	["ssangyong", "kgm", "سانج يونج", "ssangyong (kgm)"]	2026-07-19 13:56:38.549283	2026-07-19 13:56:38.549283
ff874e82-8969-4196-aeef-2142b375a108	Mercedes-Benz	mercedes-benz	car	مرسيدس بنز	Germany	Mercedes-Benz Group	1926	\N	t	t	f	f	92	["mercedes", "mercedes-benz", "مرسيدس", "بنز", "مرسيدس بنز", "mercedes benz"]	2026-07-18 21:27:17.394266	2026-07-19 13:56:38.556
5f75c4a0-ed87-4135-8338-f13e994c941a	Mercedes-Maybach	maybach	car	مايباخ	Germany	Mercedes-Benz Group	1909	\N	t	t	f	f	40	["maybach", "مايباخ", "mercedes-maybach"]	2026-07-19 13:56:38.576775	2026-07-19 13:56:38.576775
021ed729-50a2-46b7-86d2-960eb2f84b38	BMW	bmw	car	بي إم دبليو	Germany	BMW Group	1916	\N	t	t	f	f	91	["bmw", "بي ام دبليو", "بمو", "بي إم دبليو"]	2026-07-18 21:27:17.306748	2026-07-19 13:56:38.582
c02301bf-3eac-4304-8306-32aff504d337	MINI	mini	car	ميني	United Kingdom	BMW Group	1959	\N	t	t	f	f	60	["mini", "ميني"]	2026-07-19 13:56:38.590956	2026-07-19 13:56:38.590956
efd772c5-ce5b-4b45-8ca8-fdcf7689c098	Audi	audi	car	أودي	Germany	Volkswagen Group	1909	\N	t	t	f	f	88	["audi", "اودي", "أودي"]	2026-07-18 21:27:17.441795	2026-07-19 13:56:38.602
9436bf35-b78d-42b7-a0ae-443cb2ceec72	Volkswagen	volkswagen	car	فولكس فاجن	Germany	Volkswagen Group	1937	\N	t	f	f	f	84	["volkswagen", "vw", "فولكس فاجن", "فولكسفاجن"]	2026-07-18 21:27:17.642799	2026-07-19 13:56:38.609
1dd5cb73-e65d-4884-97a4-c96ffc94fd83	Porsche	porsche	car	بورش	Germany	Volkswagen Group	1931	\N	t	t	f	f	76	["porsche", "بورش", "بورشه"]	2026-07-18 21:27:17.727624	2026-07-19 13:56:38.616
3c3f05b7-bc1c-4dc8-b4ba-7d5627bac975	Opel	opel	car	أوبل	Germany	Stellantis	1862	\N	t	f	f	f	64	["opel", "اوبل", "أوبل"]	2026-07-19 13:56:38.62803	2026-07-19 13:56:38.62803
ac221868-7721-44ce-85c0-b32ba9d337ad	Smart	smart	car	سمارت	Germany	Mercedes-Benz Group / Geely	1994	\N	t	f	t	f	42	["smart", "سمارت"]	2026-07-19 13:56:38.642349	2026-07-19 13:56:38.642349
7373ab06-3f4a-4058-8d7e-af7a21fa788d	Land Rover	land-rover	car	لاند روفر	United Kingdom	Tata Motors (JLR)	1948	\N	t	t	f	f	79	["land rover", "range rover", "لاند روفر", "رينج روفر"]	2026-07-18 21:27:17.757946	2026-07-19 13:56:38.649
be4fdf6b-daed-4c11-bc9c-54214a35c70b	Jaguar	jaguar	car	جاجوار	United Kingdom	Tata Motors (JLR)	1935	\N	t	t	f	f	62	["jaguar", "جاجوار", "جاكوار"]	2026-07-19 13:56:38.66331	2026-07-19 13:56:38.66331
e4f618de-0aa4-4288-98de-9ac7bc363627	Bentley	bentley	car	بنتلي	United Kingdom	Volkswagen Group	1919	\N	t	t	f	f	50	["bentley", "بنتلي"]	2026-07-19 13:56:38.67859	2026-07-19 13:56:38.67859
daa36da6-d262-47af-93c4-a4634f0fad59	Rolls-Royce	rolls-royce	car	رولز رويس	United Kingdom	BMW Group	1904	\N	t	t	f	f	52	["rolls royce", "rolls-royce", "رولز رويس"]	2026-07-19 13:56:38.68531	2026-07-19 13:56:38.68531
9c46e3db-823a-4ee5-bd62-896ca613f6ad	Aston Martin	aston-martin	car	أستون مارتن	United Kingdom	Aston Martin Lagonda	1913	\N	t	t	f	f	48	["aston martin", "استون مارتن", "أستون مارتن"]	2026-07-19 13:56:38.692249	2026-07-19 13:56:38.692249
9b1a0353-39c9-47aa-a671-962d2f1576eb	McLaren	mclaren	car	ماكلارين	United Kingdom	McLaren Group	1985	\N	t	t	f	f	44	["mclaren", "ماكلارين"]	2026-07-19 13:56:38.698872	2026-07-19 13:56:38.698872
01092beb-86ae-4ed5-81f2-efe9eb0fb717	MG	mg	car	إم جي	United Kingdom	SAIC Motor	1924	\N	t	f	f	f	86	["mg", "ام جي", "إم جي"]	2026-07-18 21:27:18.121573	2026-07-19 13:56:38.713
4d28e82a-1aa0-4654-86ca-836324dddb7c	Renault	renault	car	رينو	France	Renault Group	1899	\N	t	f	f	f	78	["renault", "رينو", "رينلت"]	2026-07-18 21:27:17.994229	2026-07-19 13:56:38.801
9a4722eb-e61a-46a5-8605-42defc479a6f	Peugeot	peugeot	car	بيجو	France	Stellantis	1810	\N	t	f	f	f	80	["peugeot", "بيجو"]	2026-07-18 21:27:17.971331	2026-07-19 13:56:38.809
e6384217-6e92-41f6-885a-7a26fa24d51b	Ford	ford	car	فورد	United States	Ford Motor Company	1903	\N	t	f	f	f	85	["ford", "فورد"]	2026-07-18 21:27:17.702315	2026-07-19 13:56:38.854
0002d55a-beea-4ca9-9ab7-912f5d625dbe	Chevrolet	chevrolet	car	شيفروليه	United States	General Motors	1911	\N	t	f	f	f	84	["chevrolet", "chevy", "شيفروليه", "شيفورليه"]	2026-07-18 21:27:17.66292	2026-07-19 13:56:38.875
111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Jeep	jeep	car	جيب	United States	Stellantis	1943	\N	t	f	f	f	82	["jeep", "جيب"]	2026-07-18 21:27:17.900369	2026-07-19 13:56:38.927
b8eed99a-b189-4336-8054-e7e981ccb2dd	Lotus	lotus	car	لوتس	United Kingdom	Geely	1948	\N	t	t	f	f	40	["lotus", "لوتس"]	2026-07-19 13:56:38.706525	2026-07-19 13:56:38.706525
1340288b-135d-48ef-b1a5-0e536fc6bab2	Ineos	ineos	car	إينيوس	United Kingdom	Ineos Automotive	2017	\N	t	f	f	f	30	["ineos", "grenadier", "اينيوس", "إينيوس"]	2026-07-19 13:56:38.72393	2026-07-19 13:56:38.72393
d3d8949a-a020-47ba-b6e7-b384d98138db	Ferrari	ferrari	car	فيراري	Italy	Ferrari N.V.	1939	\N	t	t	f	f	60	["ferrari", "فيراري"]	2026-07-19 13:56:38.730882	2026-07-19 13:56:38.730882
87e10d18-10d9-44dd-8878-89919827d52c	Lamborghini	lamborghini	car	لامبورجيني	Italy	Volkswagen Group (Audi)	1963	\N	t	t	f	f	58	["lamborghini", "لامبورجيني", "لمبرجيني"]	2026-07-19 13:56:38.741774	2026-07-19 13:56:38.741774
2c0387dc-9a3e-4a13-a326-cbf5e2869284	Maserati	maserati	car	مازيراتي	Italy	Stellantis	1914	\N	t	t	f	f	50	["maserati", "مازيراتي"]	2026-07-19 13:56:38.749181	2026-07-19 13:56:38.749181
c4a3964c-3657-4354-b69a-dbf4161c9313	Alfa Romeo	alfa-romeo	car	ألفا روميو	Italy	Stellantis	1910	\N	t	t	f	f	52	["alfa romeo", "الفا روميو", "ألفا روميو"]	2026-07-19 13:56:38.756819	2026-07-19 13:56:38.756819
92334d9b-b7c7-439e-b661-57d5df4f34a1	Fiat	fiat	car	فيات	Italy	Stellantis	1899	\N	t	f	f	f	68	["fiat", "فيات"]	2026-07-19 13:56:38.763347	2026-07-19 13:56:38.763347
9f4b932f-026c-495e-b346-e5c855b47051	Lancia	lancia	car	لانشيا	Italy	Stellantis	1906	\N	t	f	f	f	32	["lancia", "لانشيا"]	2026-07-19 13:56:38.776738	2026-07-19 13:56:38.776738
62284d2b-45b1-4a2c-abd8-9932f115261c	Abarth	abarth	car	أبارث	Italy	Stellantis	1949	\N	t	f	f	f	34	["abarth", "ابارث", "أبارث"]	2026-07-19 13:56:38.785739	2026-07-19 13:56:38.785739
74970a41-7585-4668-a95e-3fb64cc11af3	Pagani	pagani	car	باجاني	Italy	Pagani Automobili	1992	\N	t	t	f	f	28	["pagani", "باجاني"]	2026-07-19 13:56:38.795457	2026-07-19 13:56:38.795457
6e50b405-b8f4-433c-b811-a5208f849e68	Citroën	citroen	car	ستروين	France	Stellantis	1919	\N	t	f	f	f	66	["citroen", "citroën", "ستروين", "سيتروين"]	2026-07-19 13:56:38.816742	2026-07-19 13:56:38.816742
be9ca8b8-087f-43d0-a238-6fc64fd0442e	DS Automobiles	ds	car	دي إس	France	Stellantis	2014	\N	t	t	f	f	40	["ds", "دي اس", "ds automobiles", "دي إس"]	2026-07-19 13:56:38.82381	2026-07-19 13:56:38.82381
ad4b4b1f-b00e-47fe-bfe9-18405cca3e57	Alpine	alpine	car	ألبين	France	Renault Group	1955	\N	t	t	f	f	34	["alpine", "البين", "ألبين"]	2026-07-19 13:56:38.83373	2026-07-19 13:56:38.83373
f99a84ed-574f-4291-9032-a10a419adfb6	Bugatti	bugatti	car	بوجاتي	France	Bugatti Rimac	1909	\N	t	t	f	f	40	["bugatti", "بوجاتي"]	2026-07-19 13:56:38.841019	2026-07-19 13:56:38.841019
dc3428f5-e1d4-460a-9f35-b57b426970be	Dacia	dacia	car	داسيا	Romania	Renault Group	1966	\N	t	f	f	f	62	["dacia", "داسيا"]	2026-07-19 13:56:38.848211	2026-07-19 13:56:38.848211
30b15daa-7511-4fa4-920f-869f50cbea9a	Lincoln	lincoln	car	لينكون	United States	Ford Motor Company	1917	\N	t	t	f	f	50	["lincoln", "لينكون"]	2026-07-19 13:56:38.868235	2026-07-19 13:56:38.868235
bbb3bbcd-ff3f-41ca-9667-91b25746215f	GMC	gmc	car	جي إم سي	United States	General Motors	1911	\N	t	f	f	f	60	["gmc", "جي ام سي", "جي إم سي"]	2026-07-19 13:56:38.882352	2026-07-19 13:56:38.882352
0a3060ec-abdc-4490-b68d-c8b50d06b98e	Cadillac	cadillac	car	كاديلاك	United States	General Motors	1902	\N	t	t	f	f	58	["cadillac", "كاديلاك"]	2026-07-19 13:56:38.893579	2026-07-19 13:56:38.893579
9ac8c489-765f-4b7c-91af-93f1af922beb	Buick	buick	car	بويك	United States	General Motors	1903	\N	t	f	f	f	44	["buick", "بويك"]	2026-07-19 13:56:38.900274	2026-07-19 13:56:38.900274
933d78fe-bb48-409c-99f4-f021413b702e	Chrysler	chrysler	car	كرايسلر	United States	Stellantis	1925	\N	t	f	f	f	52	["chrysler", "كرايسلر"]	2026-07-19 13:56:38.908017	2026-07-19 13:56:38.908017
15201cab-b6c3-40c1-b879-febd1de95855	Dodge	dodge	car	دودج	United States	Stellantis	1900	\N	t	f	f	f	62	["dodge", "دودج"]	2026-07-19 13:56:38.920831	2026-07-19 13:56:38.920831
3aa0b4f3-7b91-47fb-a79f-07650f5a8eff	RAM	ram	car	رام	United States	Stellantis	2010	\N	t	f	f	t	56	["ram", "رام"]	2026-07-19 13:56:38.934189	2026-07-19 13:56:38.934189
88ad2a1e-ecde-41d4-8526-5f6026f65e48	Tesla	tesla	car	تسلا	United States	Tesla, Inc.	2003	\N	t	t	t	f	78	["tesla", "تسلا"]	2026-07-19 13:56:38.941383	2026-07-19 13:56:38.941383
6622553d-0496-4ddd-92f7-f8568253d23a	Rivian	rivian	car	ريفيان	United States	Rivian Automotive	2009	\N	t	f	t	f	40	["rivian", "ريفيان"]	2026-07-19 13:56:38.94829	2026-07-19 13:56:38.94829
3684c9ed-5887-4689-810a-1562382488a4	Lucid	lucid	car	لوسيد	United States	Lucid Group	2007	\N	t	t	t	f	42	["lucid", "لوسيد"]	2026-07-19 13:56:38.956201	2026-07-19 13:56:38.956201
8a6d1805-0443-4f3b-b969-a2512b858fa1	Fisker	fisker	car	فيسكر	United States	Fisker Inc.	2016	\N	t	f	t	f	26	["fisker", "فيسكر"]	2026-07-19 13:56:38.970703	2026-07-19 13:56:38.970703
4e46dd65-4776-469b-bf55-01d952585e72	Hummer	hummer	car	همر	United States	General Motors	1992	\N	t	f	t	f	48	["hummer", "همر"]	2026-07-19 13:56:38.978286	2026-07-19 13:56:38.978286
31240778-aed8-43bc-a585-35538f2c9940	Volvo	volvo	car	فولفو	Sweden	Geely	1927	\N	t	t	f	f	70	["volvo", "فولفو"]	2026-07-19 13:56:38.985187	2026-07-19 13:56:38.985187
05e237c3-b8a4-4c90-81f0-ff8477f14d41	Polestar	polestar	car	بولستار	Sweden	Geely / Volvo	2017	\N	t	t	t	f	44	["polestar", "بولستار"]	2026-07-19 13:56:38.992828	2026-07-19 13:56:38.992828
af448d69-53f8-42ff-8db9-bd72dd4adc8f	Koenigsegg	koenigsegg	car	كوينيجزيج	Sweden	Koenigsegg	1994	\N	t	t	f	f	26	["koenigsegg", "كوينجزيج", "كوينيجزيج"]	2026-07-19 13:56:39.004336	2026-07-19 13:56:39.004336
9a5680ec-d6bb-458d-a845-7e3af9ed512a	Škoda	skoda	car	شكودا	Czech Republic	Volkswagen Group	1895	\N	t	f	f	f	74	["skoda", "škoda", "شكودا", "سكودا"]	2026-07-19 13:56:39.01161	2026-07-19 13:56:39.01161
431c2457-1fdc-4156-90af-13c9d58d6887	SEAT	seat	car	سيات	Spain	Volkswagen Group	1950	\N	t	f	f	f	58	["seat", "سيات"]	2026-07-19 13:56:39.0192	2026-07-19 13:56:39.0192
5ce15cc4-5e0f-400b-873a-e53d2f361869	Cupra	cupra	car	كوبرا	Spain	Volkswagen Group	2018	\N	t	t	f	f	46	["cupra", "كوبرا"]	2026-07-19 13:56:39.026473	2026-07-19 13:56:39.026473
075ad456-1061-41ff-a75d-9637c720560e	Tata	tata	car	تاتا	India	Tata Motors	1945	\N	t	f	f	f	54	["tata", "تاتا"]	2026-07-19 13:56:39.033613	2026-07-19 13:56:39.033613
4199f7ae-882f-4fc0-984d-9b6da52eb043	Mahindra	mahindra	car	ماهيندرا	India	Mahindra & Mahindra	1945	\N	t	f	f	f	50	["mahindra", "ماهيندرا"]	2026-07-19 13:56:39.043027	2026-07-19 13:56:39.043027
509bf0d7-3d28-4a5c-998f-857df1145dd1	Proton	proton	car	بروتون	Malaysia	Geely / DRB-HICOM	1983	\N	t	f	f	f	42	["proton", "بروتون"]	2026-07-19 13:56:39.053879	2026-07-19 13:56:39.053879
f4b39113-79d9-4afd-a15d-3c8a923e5a3b	Perodua	perodua	car	بيرودوا	Malaysia	Perodua	1993	\N	t	f	f	f	34	["perodua", "بيرودوا"]	2026-07-19 13:56:39.061628	2026-07-19 13:56:39.061628
2a43cec0-79e6-431f-a130-5b539283d698	Lada	lada	car	لادا	Russia	AvtoVAZ	1966	\N	t	f	f	f	40	["lada", "لادا"]	2026-07-19 13:56:39.068537	2026-07-19 13:56:39.068537
65400ac9-ebc7-46cf-bdda-ea0d807f2401	BYD	byd	car	بي واي دي	China	BYD Auto	1995	\N	t	f	t	f	88	["byd", "بي واي دي"]	2026-07-19 13:56:39.076076	2026-07-19 13:56:39.076076
518dd78f-7bd1-46c6-8c93-e9665465a7e7	Denza	denza	car	دينزا	China	BYD Auto	2010	\N	t	t	t	f	40	["denza", "دينزا"]	2026-07-19 13:56:39.086169	2026-07-19 13:56:39.086169
7c9ab19c-c70f-4792-b3d2-1303530dd83a	Geely	geely	car	جيلي	China	Geely Holding	1986	\N	t	f	f	f	80	["geely", "جيلي"]	2026-07-19 13:56:39.093775	2026-07-19 13:56:39.093775
f581d6e3-e4e7-488e-bfd9-65020e86cab6	Zeekr	zeekr	car	زيكر	China	Geely Holding	2021	\N	t	t	t	f	56	["zeekr", "زيكر"]	2026-07-19 13:56:39.105555	2026-07-19 13:56:39.105555
83b32086-793e-4eb5-8611-d0859d9b4ba8	Lynk & Co	lynk-co	car	لينك آند كو	China	Geely Holding	2016	\N	t	f	f	f	44	["lynk", "lynk & co", "لينك", "لينك آند كو", "lynk co"]	2026-07-19 13:56:39.115792	2026-07-19 13:56:39.115792
9de73407-dd78-4d29-8a65-2def29e5ee56	Chery	chery	car	شيري	China	Chery Automobile	1997	\N	t	f	f	f	82	["chery", "شيري"]	2026-07-19 13:56:39.123424	2026-07-19 13:56:39.123424
2a8426cc-b290-4b80-a2d9-11b97ede56f5	Omoda	omoda	car	أومودا	China	Chery Automobile	2022	\N	t	f	f	f	58	["omoda", "اومودا", "أومودا"]	2026-07-19 13:56:39.136489	2026-07-19 13:56:39.136489
e8cdb6a9-e250-4300-9cb5-03f562eabf8d	Jaecoo	jaecoo	car	جايكو	China	Chery Automobile	2023	\N	t	f	f	f	52	["jaecoo", "جايكو"]	2026-07-19 13:56:39.148359	2026-07-19 13:56:39.148359
0d1e7328-bea5-47fe-9450-18f172b32274	Exeed	exeed	car	إكسيد	China	Chery Automobile	2017	\N	t	t	f	f	46	["exeed", "اكسيد", "إكسيد"]	2026-07-19 13:56:39.156401	2026-07-19 13:56:39.156401
ad52e066-58b2-4397-876f-40d1942b1294	Great Wall Motors	gwm	car	جريت وول	China	Great Wall Motors	1984	\N	t	f	f	f	70	["great wall", "gwm", "جريت وول", "great wall motors"]	2026-07-19 13:56:39.164236	2026-07-19 13:56:39.164236
be87cc45-47d1-49db-bc9e-43296357d41a	Haval	haval	car	هافال	China	Great Wall Motors	2013	\N	t	f	f	f	74	["haval", "هافال"]	2026-07-19 13:56:39.171953	2026-07-19 13:56:39.171953
23d551db-d955-4914-811a-6668519fc661	Tank	tank	car	تانك	China	Great Wall Motors	2021	\N	t	f	f	f	50	["tank", "تانك"]	2026-07-19 13:56:39.17915	2026-07-19 13:56:39.17915
7246c436-5559-4e98-9715-22d9161eb353	Ora	ora	car	أورا	China	Great Wall Motors	2018	\N	t	f	t	f	44	["ora", "اورا", "أورا"]	2026-07-19 13:56:39.187175	2026-07-19 13:56:39.187175
2a91e26f-61f8-4661-bd76-7a1d95a2686f	Changan	changan	car	شانجان	China	Changan Automobile	1862	\N	t	f	f	f	68	["changan", "شانجان", "شانجن"]	2026-07-19 13:56:39.19517	2026-07-19 13:56:39.19517
0421e5d2-cce5-4198-bf91-33b3f261ae5a	Deepal	deepal	car	ديبال	China	Changan Automobile	2022	\N	t	f	t	f	40	["deepal", "ديبال"]	2026-07-19 13:56:39.202905	2026-07-19 13:56:39.202905
8ccf5196-d2d9-4bdc-bf59-3357ca0258d2	GAC	gac	car	جي إيه سي	China	GAC Group	1997	\N	t	f	f	f	58	["gac", "trumpchi", "جي ايه سي", "جي إيه سي"]	2026-07-19 13:56:39.214774	2026-07-19 13:56:39.214774
22990773-ae8d-4d10-bb50-7399587fb282	Maxus	saic-maxus	car	ماكسوس	China	SAIC Motor	2011	\N	t	f	f	t	46	["maxus", "ماكسوس", "saic maxus"]	2026-07-19 13:56:39.225934	2026-07-19 13:56:39.225934
567c7233-d41c-43c3-97eb-d116dea9975c	Wuling	wuling	car	وولينج	China	SAIC-GM-Wuling	2002	\N	t	f	f	f	40	["wuling", "وولينج"]	2026-07-19 13:56:39.235375	2026-07-19 13:56:39.235375
b9b1637a-01e8-4b56-9ad0-181b7337a5b3	BAIC	baic	car	بايك	China	BAIC Group	1958	\N	t	f	f	f	48	["baic", "بايك"]	2026-07-19 13:56:39.243465	2026-07-19 13:56:39.243465
28053666-96e1-4a77-b975-3661aae53ed8	FAW	faw	car	فاو	China	FAW Group	1953	\N	t	f	f	f	42	["faw", "فاو"]	2026-07-19 13:56:39.258784	2026-07-19 13:56:39.258784
45f08023-1a55-48b0-96ab-116eaba0f588	Hongqi	hongqi	car	هونشي	China	FAW Group	1958	\N	t	t	f	f	40	["hongqi", "هونشي"]	2026-07-19 13:56:39.266533	2026-07-19 13:56:39.266533
4a20e336-c96b-4da2-9253-681db00bef2e	Dongfeng	dongfeng	car	دونجفينج	China	Dongfeng Motor	1969	\N	t	f	f	f	46	["dongfeng", "دونجفينج"]	2026-07-19 13:56:39.27368	2026-07-19 13:56:39.27368
a2e5c25d-6d96-4a4e-bd23-72ce81eaf3dc	Voyah	voyah	car	فوياه	China	Dongfeng Motor	2020	\N	t	t	t	f	34	["voyah", "فوياه"]	2026-07-19 13:56:39.281492	2026-07-19 13:56:39.281492
a20a6a83-5825-4e67-8be0-bd3df8736b57	JAC	jac	car	جاك	China	JAC Motors	1964	\N	t	f	f	f	44	["jac", "جاك"]	2026-07-19 13:56:39.289044	2026-07-19 13:56:39.289044
3e058944-e30e-4199-9bf9-cb451ef24808	Jetour	jetour	car	جيتور	China	Chery Automobile	2018	\N	t	f	f	f	56	["jetour", "جيتور"]	2026-07-19 13:56:39.297622	2026-07-19 13:56:39.297622
a3746630-a330-4795-b535-c369a4824588	Bestune	bestune	car	بيستون	China	FAW Group	2006	\N	t	f	f	f	34	["bestune", "بيستون"]	2026-07-19 13:56:39.304855	2026-07-19 13:56:39.304855
f8ae025f-f9a2-4bc2-b5ed-afda18e8b52a	NIO	nio	car	نيو	China	NIO Inc.	2014	\N	t	t	t	f	50	["nio", "نيو"]	2026-07-19 13:56:39.312686	2026-07-19 13:56:39.312686
8aa4932a-e9bb-446e-b53f-7469f046435e	XPeng	xpeng	car	إكس بينج	China	XPeng Motors	2014	\N	t	f	t	f	48	["xpeng", "اكس بينج", "إكس بينج"]	2026-07-19 13:56:39.324961	2026-07-19 13:56:39.324961
8b4230a6-64ee-4e48-92cf-f20880fdf3fc	Li Auto	li-auto	car	لي أوتو	China	Li Auto Inc.	2015	\N	t	f	t	f	46	["li auto", "lixiang", "لي اوتو", "لي أوتو"]	2026-07-19 13:56:39.334059	2026-07-19 13:56:39.334059
780a0b50-d0ed-41b2-83a0-c67caafe0837	Leapmotor	leapmotor	car	ليب موتور	China	Leapmotor / Stellantis	2015	\N	t	f	t	f	40	["leapmotor", "ليب موتور"]	2026-07-19 13:56:39.353357	2026-07-19 13:56:39.353357
1d22e1ac-c3f7-46d4-b279-eca36dffa11b	AITO	aito	car	أيتو	China	Seres / Huawei	2021	\N	t	f	t	f	40	["aito", "seres", "ايتو", "أيتو"]	2026-07-19 13:56:39.361268	2026-07-19 13:56:39.361268
86bbd487-9953-4b8a-b7b5-212f5a1382cc	Avatr	avatr	car	أفاتر	China	Changan / CATL / Huawei	2018	\N	t	t	t	f	32	["avatr", "افاتر", "أفاتر"]	2026-07-19 13:56:39.36995	2026-07-19 13:56:39.36995
19f32dde-0300-416c-a240-21959ff870d4	Skywell	skywell	car	سكاي ويل	China	Skywell	2019	\N	t	f	t	f	30	["skywell", "سكاي ويل"]	2026-07-19 13:56:39.377863	2026-07-19 13:56:39.377863
4b2f8c27-cd26-4162-9731-8ac1f6079d72	Foton	foton	car	فوتون	China	BAIC Group	1996	\N	t	f	f	t	44	["foton", "فوتون"]	2026-07-19 13:56:39.395945	2026-07-19 13:56:39.395945
f741de27-4e49-443e-9c10-59a9137f3aaa	VinFast	vinfast	car	فينفاست	Vietnam	Vingroup	2017	\N	t	f	t	f	40	["vinfast", "فينفاست"]	2026-07-19 13:56:39.542097	2026-07-19 13:56:39.542097
\.


--
-- Data for Name: candidate_attribute_seen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.candidate_attribute_seen (id, candidate_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: candidate_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.candidate_attributes (id, category, attr_key, sample_value, usage_count, user_count, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: car_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.car_variants (id, model_id, name, slug, created_at) FROM stdin;
028c92f2-1f14-4c92-a5d4-0eb1c2544015	da8105d9-48bc-4dfb-a32e-4b0ecdb8a413	M-Sport	x5-m-sport	2026-07-18 21:27:17.360259
65a765e0-d751-4d44-aad1-ab4e771e4495	da8105d9-48bc-4dfb-a32e-4b0ecdb8a413	xDrive40i	x5-xdrive40i	2026-07-18 21:27:17.368297
6d56a6fc-187b-4763-ad71-e2e1e03b661b	b454a2a0-40e5-4311-abb8-c3fb426b292e	M Package	330i-m-package	2026-07-18 21:27:17.38866
bc749f0a-6627-48cb-8e1b-cbffca51f8a0	cce6d52c-efed-476c-adec-a830439434d0	C180	c-class-c180	2026-07-18 21:27:17.406906
4526f117-c0e7-4f51-95ea-8e765e31ddfb	cce6d52c-efed-476c-adec-a830439434d0	C200	c-class-c200	2026-07-18 21:27:17.414074
c4869ed0-5a55-457b-a5a0-849201a73e73	cce6d52c-efed-476c-adec-a830439434d0	C300	c-class-c300	2026-07-18 21:27:17.418848
e4ecce3a-7114-48c6-a916-fa75a2558646	0ac20c8c-cfe0-4f22-881e-568fc9bd1126	AMG	gle-amg	2026-07-18 21:27:17.428627
f76ccc05-af9e-4baa-9df6-7c0ccaf2eec2	0ac20c8c-cfe0-4f22-881e-568fc9bd1126	GLE 450	gle-gle-450	2026-07-18 21:27:17.434156
68e4d42f-ef24-4d46-a7f8-5545a6218f69	d5980096-749a-4ef4-89f3-5e2fb56b570c	35 TFSI	a4-35-tfsi	2026-07-18 21:27:17.45742
c8511f77-a885-4e58-80b4-3a08ee2697c4	d5980096-749a-4ef4-89f3-5e2fb56b570c	40 TFSI	a4-40-tfsi	2026-07-18 21:27:17.464933
a09d6bbc-0c2b-42a9-a623-42f5b9908abc	c5e8c8af-9b5f-490b-af7d-5bdec92048f2	XLI	corolla-xli	2026-07-18 21:27:17.492131
12cd2edf-f127-43f2-a289-8d74a70af714	c5e8c8af-9b5f-490b-af7d-5bdec92048f2	GLI	corolla-gli	2026-07-18 21:27:17.498646
dd9465a9-020b-498e-b06d-6123bba759bd	c19f3a78-62d4-4ad4-8004-19196ab8bb85	VXR	fortuner-vxr	2026-07-18 21:27:17.510611
394d673c-f387-4e99-b143-8e93867d608f	c19f3a78-62d4-4ad4-8004-19196ab8bb85	GXR	fortuner-gxr	2026-07-18 21:27:17.516162
b072c094-b9c4-4326-91c8-7d2500c5a2ed	c684b989-28a1-41da-85a2-37c4ce13f550	GLS	tucson-gls	2026-07-18 21:27:17.540306
f372aea7-1125-4ab5-b997-b042102ce321	c684b989-28a1-41da-85a2-37c4ce13f550	Smart	tucson-smart	2026-07-18 21:27:17.544372
b699f4e3-ad49-48ad-b795-90b8ff266dde	1fd78677-c4f9-448f-96ea-2edbd3153ed7	CN7	elantra-cn7	2026-07-18 21:27:17.55712
ad50e678-9ab0-479c-bd9f-f8ac3f859021	1fd78677-c4f9-448f-96ea-2edbd3153ed7	AD	elantra-ad	2026-07-18 21:27:17.570802
afd59079-ad8d-4bdb-ae37-b09a2fdcd6c1	05de1c51-957d-483e-b96a-640249f3919d	Luxury	sportage-luxury	2026-07-18 21:27:17.596134
df701bff-5d5f-48df-8d18-9d8dcfcdf8b4	05de1c51-957d-483e-b96a-640249f3919d	EX	sportage-ex	2026-07-18 21:27:17.600987
ee71724e-9b6b-4948-9ae4-34d494c7ae35	c33e502d-3a1d-4bad-8b3c-b00f9a4c73ac	EX	cerato-ex	2026-07-18 21:27:17.634573
713578e2-b6b9-4e0b-b93c-9c869dc34a71	c33e502d-3a1d-4bad-8b3c-b00f9a4c73ac	Top	cerato-top	2026-07-18 21:27:17.638822
b4cec8e7-0e78-4e7d-bd8b-ad90330a6cc4	d59b1622-5ce6-4d12-b5d4-be8b02ec7e9c	R-Line	tiguan-r-line	2026-07-18 21:27:17.659564
63c8d26d-5a0c-45be-8cd2-1282047e9de3	89f5460c-16d2-4744-9e13-c9af1b0458a1	SS	camaro-ss	2026-07-18 21:27:17.671914
d7eb9755-5a0d-49c5-ae7a-94458a9fbfb3	89f5460c-16d2-4744-9e13-c9af1b0458a1	RS	camaro-rs	2026-07-18 21:27:17.676034
2b25569f-fe26-4830-990d-a0943a8383a1	74a2f759-e372-436d-b30c-14349b315970	SE	lanos-se	2026-07-18 21:27:17.695954
c719c747-8c5d-4a7a-8f48-5d3233b476eb	98170462-8262-4f5d-a32f-0057d2b93109	GT	mustang-gt	2026-07-18 21:27:17.710773
6005b08c-7832-45c4-bd48-23304d5177c6	98170462-8262-4f5d-a32f-0057d2b93109	EcoBoost	mustang-ecoboost	2026-07-18 21:27:17.719508
d2b0f881-327a-4755-985a-589a3f165a1c	fcdf28d8-f787-4278-a18e-1e776ed5af07	S	cayenne-s	2026-07-18 21:27:17.740526
95dc85e7-cda4-443c-8cbb-afd36c4555d0	fcdf28d8-f787-4278-a18e-1e776ed5af07	Turbo	cayenne-turbo	2026-07-18 21:27:17.746675
db4bd753-5700-46ab-8059-552640d62621	bfb3c9d6-ed86-4d4e-a24d-72258b2820e9	Vogue	range-rover-vogue	2026-07-18 21:27:17.806873
4b0d2842-5267-4bb0-93c0-eba0c4785d76	bfb3c9d6-ed86-4d4e-a24d-72258b2820e9	Sport	range-rover-sport	2026-07-18 21:27:17.823995
b1834b74-245d-47a4-b372-ffc032e3dc7c	be32c728-768a-471e-a522-9bbed28dd7e3	SV	x-trail-sv	2026-07-18 21:27:17.83958
13b7bfdc-a614-4596-9ac4-52121526c214	be32c728-768a-471e-a522-9bbed28dd7e3	SL	x-trail-sl	2026-07-18 21:27:17.855576
4d0da00e-01c1-495a-b130-b5c659dc3192	94499369-6cd2-4af5-8077-e8ea09eeec80	Touring	cr-v-touring	2026-07-18 21:27:17.887057
720925aa-3956-47bf-94fb-f5d885d84301	94499369-6cd2-4af5-8077-e8ea09eeec80	EX	cr-v-ex	2026-07-18 21:27:17.892216
51690ecb-212c-476d-b675-fd86b0ea11ae	c8939da5-7463-48b4-b452-feb46a50234a	Limited	grand-cherokee-limited	2026-07-18 21:27:17.911868
7e8a6342-6c2b-49fc-aa2f-41876957b609	c8939da5-7463-48b4-b452-feb46a50234a	Laredo	grand-cherokee-laredo	2026-07-18 21:27:17.966183
d31569ab-ce1a-4ae1-ba5b-5ba0c537acd5	d772ed47-685a-4383-b965-d989b4e52ae5	Active	208-active	2026-07-18 21:27:17.978415
57ccb849-97cb-4548-ba2c-f18f1eb2c36d	d772ed47-685a-4383-b965-d989b4e52ae5	Allure	208-allure	2026-07-18 21:27:17.982667
ccbf6a51-eec9-4364-9954-59dcc22b9f4f	5d18451e-a2fd-4e45-9173-5c27bd3683a2	PE	duster-pe	2026-07-18 21:27:18.082641
3ccf1d00-1862-4f72-b2f7-83bdbea1c774	5d18451e-a2fd-4e45-9173-5c27bd3683a2	SE	duster-se	2026-07-18 21:27:18.08896
53ee806e-f598-428e-a3fb-78555787ad53	368fa5bc-5cef-4813-9418-25b4584aaa0d	Highline	eclipse-cross-highline	2026-07-18 21:27:18.116142
5eb702b3-68cf-4b4d-b8ef-37a23dd3106f	cc9bb9e3-50ef-49d9-a295-686c186e959e	Luxury	zs-luxury	2026-07-18 21:27:18.136253
8dd8a1b4-df4c-405f-b07a-4026c81d53ac	cc9bb9e3-50ef-49d9-a295-686c186e959e	Comfort	zs-comfort	2026-07-18 21:27:18.142315
62221fb0-87d8-43e7-9b3a-a4e033546639	f686c84b-896c-49f0-b188-fed009c3aee4	Platinum	rx-350-platinum	2026-07-18 21:27:18.167665
\.


--
-- Data for Name: company_follows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_follows (id, follower_id, company_user_id, created_at) FROM stdin;
901d965c-4708-439b-925d-87fbc44cc1fd	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	2026-07-18 21:27:21.111821
24834e1d-e418-4811-9c1a-b2425b0b1db5	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	2026-07-18 21:27:21.115573
98537b98-4ba9-40c7-9bc4-89d2c93062eb	1b06f035-4e8a-4dd7-86e3-95299957f2b8	0f04b82a-797d-4bc6-afa3-b1857fca6608	2026-07-18 21:27:21.118662
88448116-0156-42ae-a37a-19c680ff2ab1	267d8854-2d0d-4988-89b2-bca9de35e789	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	2026-07-18 21:27:21.121786
a994ae31-6f32-4cd1-9fbf-8b7b2af6539e	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	2026-07-18 21:27:21.124998
7e1429ab-10bf-4c31-973a-5e61687bcee4	760eca0f-df82-4102-9263-2cc82898272b	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	2026-07-18 21:27:21.128955
\.


--
-- Data for Name: company_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_profiles (id, user_id, about, year_established, countries_import_from, countries_export_to, min_order_value, min_order_unit, monthly_capacity, lead_time_days, certifications, website_url, logo_url, cover_url, industry, hq_country, created_at, updated_at) FROM stdin;
5452fb5c-d7bd-4ad0-af56-f51217320041	1b06f035-4e8a-4dd7-86e3-95299957f2b8	موردون معتمدون لماكينات ومعدات الصناعة البلاستيكية مع خدمة ما بعد البيع.	2014	["Italy", "Turkey", "China"]	["Sudan", "Libya"]	100000	EGP	30 units	45	["ISO 9001", "CE"]	https://delta-machinery.example.com	\N	\N	engineering	Egypt	2026-07-18 21:27:21.059776	2026-07-18 21:27:21.091
111fc5ed-4948-47e4-9342-fecb6662721a	760eca0f-df82-4102-9263-2cc82898272b	مجموعة استثمارية في الأصول الصناعية والعقارية بالمدن الصناعية المصرية.	2005	[]	[]	\N	\N	\N	\N	["ISO 9001"]	\N	\N	\N	engineering	Egypt	2026-07-18 21:27:21.063589	2026-07-18 21:27:21.094
be370b79-c819-4218-980e-e40d9c208786	0f04b82a-797d-4bc6-afa3-b1857fca6608	شركة رائدة في تصنيع وتوريد المنتجات والخامات البلاستيكية منذ 2008، نخدم السوق المحلي والتصدير.	2008	["China", "Germany", "Saudi Arabia"]	["Libya", "Sudan", "Jordan", "Iraq"]	50000	EGP	500 tons	21	["ISO 9001", "ISO 14001", "CE"]	https://al-amal-industries.example.com	\N	\N	plastic	Egypt	2026-07-18 21:27:21.055533	2026-07-18 21:27:21.097
2f47ef2a-e1ea-4ef2-95b4-961740244b1d	7a1f2488-111c-445b-9169-35e6b7eb37b4	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	engineering	United Arab Emirates	2026-07-18 21:27:21.102584	2026-07-18 21:27:21.102584
d49e38ab-2680-4da0-afc3-931f927e0e7b	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	food	Egypt	2026-07-18 21:27:21.106211	2026-07-18 21:27:21.106211
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, listing_id, buyer_id, seller_id, last_message_text, last_message_at, buyer_unread, seller_unread, buyer_deleted_at, seller_deleted_at, created_at) FROM stdin;
1387a42e-f4b5-48c7-91d8-e4269bf13ebd	b91b906c-199e-4872-8bd7-aa305e61d456	f787718d-27d8-4877-82fd-b4ff2a25bdee	760eca0f-df82-4102-9263-2cc82898272b	تيا	2026-07-21 13:34:42.011	0	3	\N	\N	2026-07-21 13:34:27.059841
\.


--
-- Data for Name: dedup_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dedup_keys (store_name, dedup_key, seen_at) FROM stdin;
lead_dedup	f787718d-27d8-4877-82fd-b4ff2a25bdee:9322a87e-6899-4b8a-8399-280801afaff0	2026-07-21 13:33:10.167664
lead_dedup	f787718d-27d8-4877-82fd-b4ff2a25bdee:b91b906c-199e-4872-8bd7-aa305e61d456	2026-07-21 13:34:27.068311
\.


--
-- Data for Name: email_provider_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_provider_config (provider, enabled, from_name, from_email, sending_domain, reply_to, public_app_url, enc_api_key, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: financing_branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financing_branches (id, intermediary_id, name, city, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: financing_intermediaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financing_intermediaries (id, name, contact_email, contact_phone, notes, owner_user_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: financing_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financing_requests (id, lead_id, status, intermediary_id, branch_id, assigned_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: financing_seats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financing_seats (id, intermediary_id, branch_id, user_id, role, created_at) FROM stdin;
\.


--
-- Data for Name: finishing_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.finishing_types (id, slug, name, name_ar, sort_order, created_at) FROM stdin;
6ee9e3e2-72e5-4837-b5a6-fd3bc88d1ad2	finished	Finished	تشطيب كامل	0	2026-07-18 21:27:18.449324
eca44166-731d-49de-b6cc-d3b71b4116df	semi_finished	Semi-Finished	نصف تشطيب	1	2026-07-18 21:27:18.457512
a75fb52b-8d59-4a19-aa8a-48bf80fceec9	core_shell	Core & Shell	على المحارة	2	2026-07-18 21:27:18.460594
8fe2e71f-4c47-48bb-92fd-d0d68e560aca	super_lux	Super Lux	سوبر لوكس	3	2026-07-18 21:27:18.464101
\.


--
-- Data for Name: global_supply_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.global_supply_requests (id, buyer_id, product_text, category, industry, quantity, unit, destination_country, budget_max, currency, incoterms, notes, status, created_at, updated_at) FROM stdin;
efeaebe3-204f-4ac8-82fe-a438c137597c	267d8854-2d0d-4988-89b2-bca9de35e789	حبيبات بولي إيثيلين عالي الكثافة (HDPE) لصناعة العبوات	industrial	plastic	120	طن	Egypt	9500000	EGP	cif	مطلوب توريد شهري منتظم مع شهادات جودة.	open	2026-07-18 21:27:21.243925	2026-07-18 21:27:21.243925
d23a11ee-49f1-4efa-acbf-bb81ce1dda1d	760eca0f-df82-4102-9263-2cc82898272b	ألواح صلب مجلفن لمشاريع إنشائية	industrial	engineering	300	طن	Egypt	21000000	EGP	fob	يفضّل توريد على دفعات حسب جدول التنفيذ.	open	2026-07-18 21:27:21.243925	2026-07-18 21:27:21.243925
4e84e99a-19a0-4670-8f2a-0791878b6584	00ba65f0-e746-4c79-8026-09723e0a59f0	ماكينات تعبئة وتغليف أوتوماتيكية لخط أغذية	industrial	food	2	وحدة	Saudi Arabia	4500000	EGP	exw	مع التركيب والتدريب وضمان قطع الغيار.	open	2026-07-18 21:27:21.243925	2026-07-18 21:27:21.243925
\.


--
-- Data for Name: global_supply_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.global_supply_responses (id, request_id, supplier_id, country_of_origin, moq, shipping_time_days, incoterms, delivery_estimate, price_quote, currency, message, status, created_at, updated_at) FROM stdin;
aa40e1a5-f85f-44e5-8f1b-c5295170cde8	efeaebe3-204f-4ac8-82fe-a438c137597c	0f04b82a-797d-4bc6-afa3-b1857fca6608	Egypt	11	35	cif	5-12 أسابيع	6811661	EGP	عرض مبدئي قابل للتفاوض حسب الكمية وشروط الدفع.	pending	2026-07-18 21:27:21.247232	2026-07-18 21:27:21.247232
5c2f375b-5a75-4296-9c37-9f39c78314f9	efeaebe3-204f-4ac8-82fe-a438c137597c	7a1f2488-111c-445b-9169-35e6b7eb37b4	United Arab Emirates	38	34	cif	4-14 أسابيع	6451118	EGP	عرض مبدئي قابل للتفاوض حسب الكمية وشروط الدفع.	pending	2026-07-18 21:27:21.253603	2026-07-18 21:27:21.253603
c7a342d0-0fe5-43d4-8058-5307f9a2e84b	efeaebe3-204f-4ac8-82fe-a438c137597c	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	United Arab Emirates	47	19	dap	4-10 أسابيع	3049726	EGP	عرض مبدئي قابل للتفاوض حسب الكمية وشروط الدفع.	pending	2026-07-18 21:27:21.257416	2026-07-18 21:27:21.257416
02f0b38b-9309-4332-8743-da8a84902369	d23a11ee-49f1-4efa-acbf-bb81ce1dda1d	0f04b82a-797d-4bc6-afa3-b1857fca6608	China	5	46	fob	5-12 أسابيع	2821472	EGP	عرض مبدئي قابل للتفاوض حسب الكمية وشروط الدفع.	pending	2026-07-18 21:27:21.261527	2026-07-18 21:27:21.261527
d8dac26b-52d6-4eb8-8a02-4d323e629afe	d23a11ee-49f1-4efa-acbf-bb81ce1dda1d	7a1f2488-111c-445b-9169-35e6b7eb37b4	Egypt	46	41	cif	5-9 أسابيع	2539087	EGP	عرض مبدئي قابل للتفاوض حسب الكمية وشروط الدفع.	pending	2026-07-18 21:27:21.26491	2026-07-18 21:27:21.26491
1cf7efcd-95ae-4e53-9986-f0a37e9a447e	4e84e99a-19a0-4670-8f2a-0791878b6584	0f04b82a-797d-4bc6-afa3-b1857fca6608	United Arab Emirates	15	8	cif	7-11 أسابيع	3134096	EGP	عرض مبدئي قابل للتفاوض حسب الكمية وشروط الدفع.	pending	2026-07-18 21:27:21.268939	2026-07-18 21:27:21.268939
\.


--
-- Data for Name: industrial_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.industrial_types (id, slug, name, name_ar, sort_order, created_at) FROM stdin;
d6911aa7-ba35-459f-b8e9-3f2dfe9ddf1d	factory	Factory	مصنع	0	2026-07-18 21:27:18.482753
b5128ea8-3618-45d2-97de-13840dd2c639	warehouse	Warehouse	مخزن	1	2026-07-18 21:27:18.487555
03f6d74b-53e5-45f7-bc42-82242ae88163	machine	Machine	ماكينة	2	2026-07-18 21:27:18.491605
6d2e541d-fcfc-4547-abf9-9f9dab6f5c18	production_line	Production Line	خط إنتاج	3	2026-07-18 21:27:18.494825
97ec9344-d608-462e-b088-050b678b251c	land	Industrial Land	أرض صناعية	4	2026-07-18 21:27:18.509318
bc753110-9f83-4d91-9f35-31eb8e760f66	raw_material	Raw Material	مواد خام	5	2026-07-18 21:27:18.513814
\.


--
-- Data for Name: industries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.industries (id, slug, name, name_ar, sort_order, created_at) FROM stdin;
3ef4bc92-f961-4388-9d0c-39ed16a9b37a	food	Food	أغذية	0	2026-07-18 21:27:18.517657
f1ebee51-9bae-4382-8a13-d534b3b31295	beverage	Beverage	مشروبات	1	2026-07-18 21:27:18.521458
1bc39352-fc2c-46b8-9209-f96b46794ab6	plastic	Plastic	بلاستيك	2	2026-07-18 21:27:18.524828
a0c78644-eddf-48df-9c76-e0166c4fb457	textile	Textile	نسيج	3	2026-07-18 21:27:18.528762
d133db38-e6ca-40a2-bd99-5c97b492f05f	pharmaceutical	Pharmaceutical	أدوية	4	2026-07-18 21:27:18.533043
96823c8f-d84c-42ea-b51a-fc65f06a65b4	chemical	Chemical	كيماويات	5	2026-07-18 21:27:18.535991
23c701c7-83da-403b-9cdb-173b235fccab	engineering	Engineering	هندسية	6	2026-07-18 21:27:18.539695
86e4fe3e-4add-4b9b-bfa6-7b58512cb695	other	Other	أخرى	7	2026-07-18 21:27:18.543267
\.


--
-- Data for Name: interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interactions (listing_id, views, clicks, whatsapp_clicks, call_clicks, finance_requests, updated_at) FROM stdin;
ad7793eb-66af-4039-8267-c59488026824	56	66	9	15	0	2026-07-18 21:27:18.720483
fc570df0-e974-4c5a-abbe-d2df329e8ae3	212	45	11	12	6	2026-07-18 21:27:18.742565
afb9180b-6d35-4e8f-9858-897749ccb3d3	514	73	19	12	3	2026-07-18 21:27:18.759634
5c396975-c3f2-4970-b281-f8db7cfca1bf	586	6	5	20	3	2026-07-18 21:27:18.784755
25130e61-f0ac-4a2f-ab46-91ce6f54649f	480	6	9	5	2	2026-07-18 21:27:18.804075
85c4c348-d4f0-44ed-b814-60c0a881559e	722	34	13	20	10	2026-07-18 21:27:18.821685
f015cb68-23c1-45ac-8241-280405b54dcc	260	41	3	1	8	2026-07-18 21:27:18.844207
30cc6cc4-25df-481a-87a6-f0a2e4e82618	623	10	21	2	1	2026-07-18 21:27:18.864955
8ee87c30-45fd-451a-b437-c51e915da497	438	9	28	8	7	2026-07-18 21:27:18.898861
860a0fe8-c854-4af8-a524-fa1e53a8ed6d	66	51	30	14	2	2026-07-18 21:27:18.915562
f4b561b7-113d-4938-8330-e527db01404c	373	73	14	15	4	2026-07-18 21:27:18.93708
1da570ab-f9ec-45f3-b77a-c8c1b08d284a	52	36	1	19	9	2026-07-18 21:27:18.95844
38b5547f-3272-4752-adef-419278a5a379	314	17	12	18	0	2026-07-18 21:27:18.986125
4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	658	6	1	18	6	2026-07-18 21:27:19.006039
322f1d1d-f418-4a26-8e60-45d8c45858a9	551	47	5	12	5	2026-07-18 21:27:19.038962
6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	604	56	11	3	2	2026-07-18 21:27:19.065985
da4ea6a9-a539-457f-ab70-5e143be46366	570	80	26	7	7	2026-07-18 21:27:19.098077
dfa4da74-d198-413d-828c-f629a7b50189	371	22	3	16	8	2026-07-18 21:27:19.119188
ccc3c757-0782-4a1f-b2ac-31d59a9b307d	630	24	7	6	3	2026-07-18 21:27:19.142163
3086a988-b6a0-4e15-ab43-c09b98faafa7	117	14	9	19	4	2026-07-18 21:27:19.236749
9030afe9-63c8-4d9d-bac1-3dd49f4429e0	497	41	13	8	10	2026-07-18 21:27:19.251113
afdc4e90-2ad7-49e5-838c-3fbbee033f3d	672	17	19	14	1	2026-07-18 21:27:19.263933
09c8183b-d75c-4fad-ab84-55955aab44e2	650	21	1	4	2	2026-07-18 21:27:19.276547
55850d32-1a17-48c5-9363-a58459046358	618	67	1	17	3	2026-07-18 21:27:19.293476
b8677ab7-9b44-4c7a-bc7c-1bd54ecaa5ca	740	69	27	15	8	2026-07-18 21:27:19.308113
7adfddc0-5f2d-4e3a-823c-7ca55388ee69	332	32	23	4	7	2026-07-18 21:27:19.323471
8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	74	44	3	9	8	2026-07-18 21:27:19.342525
bed7ae5c-ed17-42e2-8ba4-747f178c546c	107	8	12	12	1	2026-07-18 21:27:19.359154
7294796b-3884-4742-abee-d13b457c610b	251	22	2	9	0	2026-07-18 21:27:19.489267
b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	187	42	12	7	6	2026-07-18 21:27:19.509847
9f249352-cd48-4c1d-b238-ca2a015a6f20	334	15	24	13	2	2026-07-18 21:27:19.538453
b7537c25-ddd0-4394-8e12-08015def429c	255	25	17	4	2	2026-07-18 21:27:19.553198
5ad12c3c-5a96-4a2b-89a4-566454a6869a	373	38	18	6	5	2026-07-18 21:27:19.572182
f7fc3936-4bc1-4375-b8c2-c173126959ea	464	13	3	10	7	2026-07-18 21:27:19.590738
58002df9-b711-4713-8047-f828c50d6718	482	49	23	6	7	2026-07-18 21:27:19.625044
906b9bd8-d0ca-4a6f-aec9-915686f8c48b	351	25	21	14	2	2026-07-18 21:27:19.649101
20644d0f-152c-4e29-9092-c14238b4a261	97	46	17	9	6	2026-07-18 21:27:19.664167
25a613fc-b24c-48c5-9dda-acf3c02a3542	400	47	15	1	7	2026-07-18 21:27:19.680233
fbc3778f-be9e-4548-b205-46f14e3b3faf	212	18	2	1	2	2026-07-18 21:27:19.693395
43911f51-805d-4b2c-add6-b328c2667a6e	113	7	7	3	2	2026-07-18 21:27:19.711891
240e7f63-766f-4fcc-b192-2df158c17999	128	17	5	3	3	2026-07-18 21:27:19.731469
35191d0c-d69e-4d03-93c6-fd48bfd5ab4f	40	24	15	3	0	2026-07-18 21:27:19.750602
714ecac9-fd70-4822-8c2c-df9ae1be7994	114	4	8	8	1	2026-07-18 21:27:19.775793
000bdfd3-ef1f-43e1-b6bc-40e82258ad3e	110	15	14	9	0	2026-07-18 21:27:19.793206
f543b945-c700-4357-97bb-2d5f5bb9d828	75	20	12	1	4	2026-07-18 21:27:19.810509
776e660f-a9f1-4129-b969-2fed1e1a6668	135	22	6	2	0	2026-07-18 21:27:19.830177
6f8a18b3-7b7a-4eda-800c-f5ae5a5cd290	120	17	10	9	0	2026-07-18 21:27:19.851826
d4ddac53-a22c-460b-96f2-481482d1bc95	107	29	9	8	4	2026-07-18 21:27:19.871735
e10511a8-45c3-4da3-bc6e-2b192c15bd24	72	27	12	10	3	2026-07-18 21:27:19.891994
188d6bfc-b83a-4299-8c55-d8d5505b9f4a	102	21	13	9	2	2026-07-18 21:27:19.911199
4c1792ba-c514-454d-a4b3-39f3aad9fa71	148	22	14	6	2	2026-07-18 21:27:19.927228
a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	110	8	0	0	0	2026-07-18 21:27:20.938257
ce85c9c5-65f2-4876-b98c-f11d7f183b25	155	29	0	0	0	2026-07-18 21:27:20.956511
5b43e47b-9ac6-4c33-ae58-75829f6bfe00	53	16	0	0	0	2026-07-18 21:27:20.977357
a89eab67-0e52-408d-8887-03d24cd3886d	178	21	0	0	0	2026-07-18 21:27:20.995178
d6ab50a9-fc95-4d3b-9959-b66badab140f	130	12	0	0	0	2026-07-18 21:27:21.013404
1e9b6e89-66ff-460b-a11f-bfa9d27e48d0	190	3	0	0	0	2026-07-18 21:27:21.031154
c9e5c75d-ac07-4dcf-a123-fea99cca404b	235	25	10	3	3	2026-07-18 21:52:07.03
a702bac0-04c2-4ca6-8642-086500203e18	332	48	17	13	8	2026-07-18 22:00:17.64399
e986f0a2-b346-485e-8409-3ac93ab1d516	634	40	24	20	1	2026-07-18 22:00:17.675972
11e3e025-ac43-4186-99c4-e90fce734514	781	34	24	2	3	2026-07-18 22:00:17.70622
7f5a475c-f641-4130-ad9d-316175ceddd8	216	60	4	9	3	2026-07-18 22:00:17.787919
bf1b64b0-40db-494e-8b66-509316a30724	392	63	10	11	9	2026-07-18 22:00:17.809276
64d60de9-2649-48e8-8636-bb76c8a0192e	445	47	9	1	10	2026-07-18 22:00:17.828069
37103385-9490-4954-9687-50f8ee9e0a26	743	29	2	11	4	2026-07-18 22:00:17.858035
1d10ee4e-0ea6-4334-bd44-cb11c2398322	167	67	1	17	10	2026-07-18 22:00:17.880979
34a62384-7311-43f7-9d85-75275232b454	150	79	7	3	2	2026-07-18 22:00:17.899967
b38f66dc-3e8a-4e27-b878-87b9ff283a56	677	13	8	17	6	2026-07-18 22:00:17.928374
a0f30ae4-e397-4606-ae72-5a45a95a5c33	564	13	19	11	6	2026-07-18 22:00:17.948252
0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	142	48	16	9	6	2026-07-18 22:00:17.96804
68870b9b-d774-47b3-862d-0c525aade4e0	327	75	30	20	3	2026-07-18 22:00:18.012288
8a1b4752-c8ad-4882-b9e1-40e845cdf053	451	78	22	11	9	2026-07-18 22:00:18.030369
cff450de-7e28-4ffa-afdc-d8a36a6aeadd	600	29	24	12	4	2026-07-18 22:00:18.086746
35b7f9d3-1632-4549-9c32-e00d1ac6b862	486	29	7	10	6	2026-07-18 22:00:18.124402
e069ac39-c738-4586-8629-31e0731e3f91	107	72	20	20	2	2026-07-18 22:00:18.137302
f4c6f1bb-adb7-41f4-983a-64676c47e514	339	24	20	9	0	2026-07-18 22:00:18.153931
3094a424-7f3d-4719-8d95-9991b9680048	563	67	29	18	5	2026-07-18 22:00:18.168956
4c73b269-e275-4bd2-898f-39a018826814	564	25	3	2	8	2026-07-18 22:00:18.198963
2c7e7e69-b413-4913-b965-00e13fa8f32d	309	18	11	13	1	2026-07-18 22:00:18.215597
bd1f899c-90a2-41d6-972f-a40762374777	758	14	27	10	0	2026-07-20 19:55:23.053
8c77c35d-3969-4fd0-933a-9558cc48fac5	80	40	12	19	10	2026-07-21 13:33:54.415
b91b906c-199e-4872-8bd7-aa305e61d456	670	79	5	18	8	2026-07-21 13:34:25.425
c3996838-428c-4cef-9199-176dd9d66848	764	80	17	15	10	2026-07-19 13:56:01.305305
29113513-b741-470e-847a-57ff621f0f19	479	73	26	13	2	2026-07-19 13:56:01.341729
59f4e92b-92ff-461f-ae08-dc2be8fbff30	119	12	24	15	10	2026-07-19 13:56:01.413627
c56c0b52-50c2-4459-b4c5-19d2c401aaf0	613	9	13	3	0	2026-07-19 13:56:01.455033
edf0deed-fa66-4c53-9ca3-5b87b10ec806	440	18	7	12	6	2026-07-19 13:56:01.48745
80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	278	48	28	14	9	2026-07-19 13:56:01.522994
6531a87f-7a51-454d-8dea-9660c3aa3fa3	609	71	17	17	7	2026-07-19 13:56:01.556467
1535dacc-8620-475f-863c-f5048d3f271f	568	23	19	8	1	2026-07-19 13:56:01.591735
ff6d88fd-14e9-45f9-a2ea-552c61e61f14	532	33	7	6	6	2026-07-19 13:56:01.62668
0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	86	56	22	19	1	2026-07-19 13:56:01.658676
0f2abacd-5388-4d16-88ba-19996ab07efc	111	46	2	19	0	2026-07-19 13:56:01.693268
228d2194-7cb3-4797-9cf6-9150f59e4b51	788	38	22	10	5	2026-07-19 13:56:01.728041
c5d495c4-7f15-4785-9ceb-444109eae4ca	563	57	24	9	8	2026-07-19 13:56:01.817175
f8828552-9e98-4c47-90ac-dfeafef6f259	465	55	17	13	6	2026-07-19 13:56:01.859305
bb9758f5-7491-4626-8264-f9b36e781015	463	46	30	6	5	2026-07-19 13:56:01.894312
f52e2c21-9f60-4a9d-9587-28c34be4313d	462	5	13	12	5	2026-07-19 13:56:01.928387
dd2a3f4a-84df-49f0-96bc-405d52e30e8b	529	72	11	6	0	2026-07-19 13:56:01.962445
594f7353-9eeb-4f9d-a91e-402097aa1aa0	410	46	20	15	5	2026-07-19 13:56:01.99007
4e8d01e8-dddd-4ba0-b88b-b0068d47ac54	684	57	7	10	7	2026-07-19 13:56:02.024731
7ca26c99-aec3-4064-89c6-6acbf346ba9a	330	69	12	1	1	2026-07-19 13:56:02.051926
adf38505-f2de-4fdd-a78e-4020df43ce5b	182	79	5	13	5	2026-07-19 13:56:02.079208
8c7883b1-f456-4a6a-8f42-18c0316a9ef7	788	44	28	15	9	2026-07-19 13:56:02.1064
5cba9a8c-3a15-4e7c-92ae-14de899b0403	698	67	26	16	8	2026-07-19 13:56:02.134988
ba60c889-76e4-4635-9a59-0ed305f1043e	310	70	2	14	1	2026-07-19 13:56:02.167856
24f1f647-642a-4a4f-b685-8f6cc62ca73a	105	18	12	6	3	2026-07-19 13:56:02.195431
320b6f96-0528-4430-9486-842cd3c10290	129	11	11	13	0	2026-07-19 13:56:02.228461
83bd6cf4-667f-46a9-9136-42841beb0ddd	371	31	12	15	2	2026-07-19 13:56:02.26528
956f7f0c-4c49-4849-8efc-1056cd1e46a7	261	32	23	15	3	2026-07-19 13:56:02.292953
7e2e36ae-710b-4f01-b415-163004df50d5	443	40	7	10	4	2026-07-19 13:56:02.40487
eb1e5cc7-3431-4e72-9563-be6c520c561c	485	13	6	10	0	2026-07-19 13:56:02.438365
3f8579ca-1469-4fff-8dd0-867327549e2a	141	30	20	6	2	2026-07-19 13:56:02.467357
5d5f76f9-8200-4cfb-b85f-eb3167ebe59c	181	12	14	8	7	2026-07-19 13:56:02.502817
e104a255-93b8-4ce3-b2a2-16ed2dc22047	160	50	19	1	6	2026-07-19 13:56:02.539219
5531056b-c81d-4971-b026-fbdc40516ee8	155	46	11	1	1	2026-07-19 13:56:02.565549
02ca95ed-3f23-4485-86bb-e822d2d20b9d	55	32	4	9	7	2026-07-19 13:56:02.600171
af29f0a0-62b7-48c4-8995-ae58a192b39f	418	48	8	11	8	2026-07-19 13:56:02.634067
37159531-b803-4b62-a764-209cae61eb8a	452	38	2	11	2	2026-07-19 13:56:02.689023
ee9c255d-593a-404e-ba7c-54f76e5c537c	412	44	15	5	0	2026-07-19 13:56:02.71568
7263ec34-aa0e-46ee-9603-dc3c7e555089	130	2	6	1	4	2026-07-19 13:56:02.750162
a0705f6e-b0e0-43fe-8352-90816e14fc59	183	22	12	1	3	2026-07-19 13:56:02.786356
ea279ba5-756f-456d-91d8-534388fb648a	24	24	14	6	5	2026-07-19 13:56:02.819487
9150cc73-01b3-47fe-a15c-042af82ed4a3	72	16	7	7	3	2026-07-19 13:56:02.85945
af09ae88-c0da-4079-a0f4-7aa7407ac1fc	190	15	12	10	4	2026-07-19 13:56:02.893549
925a9409-46ca-4049-a382-97f840540c9d	81	6	12	9	1	2026-07-19 13:56:02.930182
40de3002-ada5-468e-b583-788cfbeb2a35	14	27	5	1	0	2026-07-19 13:56:02.969124
8c21de11-dacc-42d7-b52b-2413d53bb5ae	35	16	13	2	4	2026-07-19 13:56:03.005509
e50a3b9d-cb4f-49df-bb51-a7a0ae37a8da	64	9	2	9	2	2026-07-19 13:56:03.045856
c5a76c3d-0b88-4859-b6d8-e557ebfaca65	137	18	10	9	4	2026-07-19 13:56:03.082183
67ce4494-36b1-42c3-af3e-fe2e6b4872d3	33	20	8	3	5	2026-07-19 13:56:03.114908
d625d165-7501-4c66-9601-fea4f5c5e94a	106	24	13	5	3	2026-07-19 13:56:03.148226
9322a87e-6899-4b8a-8399-280801afaff0	483	36	8	8	8	2026-07-21 13:33:04.853
7ce2d80c-5ea0-4739-aae0-b29c26a55acb	656	43	27	11	5	2026-07-21 13:34:10.807
\.


--
-- Data for Name: investment_interests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_interests (id, investment_id, user_id, kind, message, contact_phone, created_at, updated_at) FROM stdin;
cdc2513e-7466-4f0a-bd01-6c58e5a0b24e	a7416d80-2475-4e0e-8cf5-01b345ce120d	267d8854-2d0d-4988-89b2-bca9de35e789	request_details	مهتم بمزيد من التفاصيل المالية والقوائم.	\N	2026-07-18 21:27:21.204424	2026-07-18 21:27:21.204424
813225de-aee0-4320-a77f-895364433034	a7416d80-2475-4e0e-8cf5-01b345ce120d	00ba65f0-e746-4c79-8026-09723e0a59f0	request_details	مهتم بمزيد من التفاصيل المالية والقوائم.	\N	2026-07-18 21:27:21.208262	2026-07-18 21:27:21.208262
057a9a2d-8e01-4cc8-8b65-1d88709c551e	f48972dd-7068-4980-b69e-75b523689b62	267d8854-2d0d-4988-89b2-bca9de35e789	interest	\N	\N	2026-07-18 21:27:21.211908	2026-07-18 21:27:21.211908
30b32f87-d2c1-46bc-aeb0-3024c9aa5551	f48972dd-7068-4980-b69e-75b523689b62	00ba65f0-e746-4c79-8026-09723e0a59f0	request_details	مهتم بمزيد من التفاصيل المالية والقوائم.	\N	2026-07-18 21:27:21.216535	2026-07-18 21:27:21.216535
6bb4b6dc-d072-46f6-b8a3-8253fcf83cad	f48972dd-7068-4980-b69e-75b523689b62	1b06f035-4e8a-4dd7-86e3-95299957f2b8	contact	\N	+201026793466	2026-07-18 21:27:21.219566	2026-07-18 21:27:21.219566
46bdeed5-7a6a-4112-80ba-bae9d190ca70	4984f416-7fbb-4553-90ad-4230927dddd0	267d8854-2d0d-4988-89b2-bca9de35e789	contact	\N	+201035389375	2026-07-18 21:27:21.22377	2026-07-18 21:27:21.22377
10f55f1e-3c33-4bab-8e27-191c583416fa	4984f416-7fbb-4553-90ad-4230927dddd0	00ba65f0-e746-4c79-8026-09723e0a59f0	request_details	مهتم بمزيد من التفاصيل المالية والقوائم.	\N	2026-07-18 21:27:21.227139	2026-07-18 21:27:21.227139
d6100ee3-641a-4185-834a-2a97a834470b	4984f416-7fbb-4553-90ad-4230927dddd0	1b06f035-4e8a-4dd7-86e3-95299957f2b8	contact	\N	+201087163188	2026-07-18 21:27:21.230054	2026-07-18 21:27:21.230054
e284aceb-6dee-415d-93ce-b12fd3df94e5	dc9c8ae3-e74f-4fd9-b75c-fa2764c83921	267d8854-2d0d-4988-89b2-bca9de35e789	interest	\N	\N	2026-07-18 21:27:21.233685	2026-07-18 21:27:21.233685
8b9507cf-aa20-4282-9f7a-373073257811	f4015762-92e5-4d8e-a95b-d23b496e81c0	267d8854-2d0d-4988-89b2-bca9de35e789	contact	\N	+201095828108	2026-07-18 21:27:21.236676	2026-07-18 21:27:21.236676
b33b8360-e5d4-4f5f-9b9f-b6b46f8590b9	f4015762-92e5-4d8e-a95b-d23b496e81c0	00ba65f0-e746-4c79-8026-09723e0a59f0	request_details	مهتم بمزيد من التفاصيل المالية والقوائم.	\N	2026-07-18 21:27:21.240153	2026-07-18 21:27:21.240153
\.


--
-- Data for Name: investment_opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_opportunities (id, owner_id, investment_type, title, description, industry, location, location_id, total_value_amount, currency, expected_roi_pct, payback_years, revenue_range_min, revenue_range_max, cost_structure_note, growth_potential_note, figures_source, cover_url, status, is_flagged, flag_reason, created_at, updated_at) FROM stdin;
a7416d80-2475-4e0e-8cf5-01b345ce120d	0f04b82a-797d-4bc6-afa3-b1857fca6608	factory_sale	مصنع بلاستيك متكامل للبيع — 6 أكتوبر	مصنع حقن بلاستيك على مساحة 2400م² بترخيص ساري وخطوط إنتاج جاهزة للتشغيل الفوري. يشمل البيع الأرض والمباني والمعدات.	plastic	6th of October, Giza	\N	85000000	EGP	18.5	5.5	24000000	32000000	تكاليف تشغيل سنوية تقديرية ~19م ج.م تشمل الخامات والعمالة والطاقة.	إمكانية إضافة خط إنتاج ثالث لزيادة الطاقة 40%.	seller_provided	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	active	f	\N	2026-07-18 21:27:21.199886	2026-07-18 21:27:21.199886
f48972dd-7068-4980-b69e-75b523689b62	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	business_sale	سلسلة مطاعم للبيع — 4 فروع تعمل بالقاهرة	نشاط مطاعم قائم بأربعة فروع وعلامة تجارية مسجّلة وفريق عمل مدرّب. بيع كامل النشاط مع العقود والتراخيص.	food	Cairo	\N	42000000	EGP	22	4	30000000	38000000	هامش ربح تشغيلي ~21% وفق آخر قوائم مالية قدّمها البائع.	خطة توسّع لفرعين إضافيين في التجمع والشيخ زايد.	seller_provided	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	active	f	\N	2026-07-18 21:27:21.199886	2026-07-18 21:27:21.199886
4984f416-7fbb-4553-90ad-4230927dddd0	0f04b82a-797d-4bc6-afa3-b1857fca6608	production_line_investment	فرصة استثمار في خط إنتاج أغذية معلّبة	طرح حصة استثمارية لتمويل خط إنتاج جديد لتعليب الأغذية ضمن مصنع قائم. المستثمر يحصل على حصة من الأرباح.	food	10th of Ramadan City	\N	15000000	EGP	16	6	9000000	12000000	التقديرات مقدّمة من صاحب المصنع وتخضع للتفاوض والفحص النافي للجهالة.	طلب متزايد على المنتجات المعلّبة في أسواق التصدير.	seller_provided	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	active	f	\N	2026-07-18 21:27:21.199886	2026-07-18 21:27:21.199886
dc9c8ae3-e74f-4fd9-b75c-fa2764c83921	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	franchise	امتياز تجاري — سلسلة مخبوزات معروفة	فرصة الحصول على امتياز (فرنشايز) لافتتاح فرع لعلامة مخبوزات راسخة، مع دعم تشغيلي وتدريب كامل.	food	New Cairo	\N	3500000	EGP	25	3	4000000	6000000	رسوم امتياز مبدئية + إتاوة شهرية 6% من المبيعات حسب عقد المانح.	مناطق حصرية متاحة في القاهرة الجديدة والعاصمة الإدارية.	seller_provided	https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&q=80	active	f	\N	2026-07-18 21:27:21.199886	2026-07-18 21:27:21.199886
f4015762-92e5-4d8e-a95b-d23b496e81c0	760eca0f-df82-4102-9263-2cc82898272b	partnership	شراكة في شركة خدمات لوجستية ونقل	طرح حصة شراكة (40%) في شركة لوجستيات قائمة بأسطول نقل وعقود توريد سارية. شراكة تشغيلية أو صامتة.	engineering	Alexandria	\N	28000000	EGP	19	5	18000000	23000000	الأرقام وفق قوائم الشركة المدققة لآخر سنة مالية (مقدّمة من الشريك).	نمو متوقع مع توسّع التجارة الإلكترونية وخدمات الميل الأخير.	seller_provided	https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800&q=80	active	f	\N	2026-07-18 21:27:21.199886	2026-07-18 21:27:21.199886
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, invoice_number, user_id, transaction_id, amount, status, line_items, issued_at, created_at) FROM stdin;
bb3d554f-a565-4e00-81ad-8f44fc40b29a	INV-20260721-F3C15DE517C5	7a1f2488-111c-445b-9169-35e6b7eb37b4	f3c15de5-17c5-4e59-9dae-b0db2ca8386b	30.00	paid	[{"label": "Lead (finance_request)", "amount": "30.00"}]	2026-07-21 13:33:10.197495	2026-07-21 13:33:10.197495
2cb301a3-e182-45d6-a0e9-a6432b6aec8d	INV-20260721-D9EB4B3D4080	760eca0f-df82-4102-9263-2cc82898272b	d9eb4b3d-4080-4834-9802-d039fd0d9ff1	10.00	paid	[{"label": "Lead (chat)", "amount": "10.00"}]	2026-07-21 13:34:27.076949	2026-07-21 13:34:27.076949
\.


--
-- Data for Name: lead_billing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_billing (id, lead_id, seller_id, buyer_id, listing_id, action_type, status, amount_charged, transaction_id, created_at) FROM stdin;
8cb1b175-9893-49d6-8b7f-86d06d5b0a02	11294434-f541-484a-9ea1-9c771610bf39	7a1f2488-111c-445b-9169-35e6b7eb37b4	f787718d-27d8-4877-82fd-b4ff2a25bdee	9322a87e-6899-4b8a-8399-280801afaff0	finance_request	charged	30.00	f3c15de5-17c5-4e59-9dae-b0db2ca8386b	2026-07-21 13:33:10.197495
85a2212d-71de-4f8f-a112-f23a2362dbe2	5824c17b-4eb4-4462-ad5a-383aca96c077	760eca0f-df82-4102-9263-2cc82898272b	f787718d-27d8-4877-82fd-b4ff2a25bdee	b91b906c-199e-4872-8bd7-aa305e61d456	chat	charged	10.00	d9eb4b3d-4080-4834-9802-d039fd0d9ff1	2026-07-21 13:34:27.076949
\.


--
-- Data for Name: lead_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_history (id, listing_id, buyer_id, seller_id, action_type, status, buyer_name, buyer_phone, created_at, updated_at) FROM stdin;
2966a6b9-e99f-47ce-886c-f35faa9b8098	fc570df0-e974-4c5a-abbe-d2df329e8ae3	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	chat	new	Ahmed Hassan	+201077860085	2026-06-04 21:27:21.272	2026-07-18 21:27:21.386624
d6aa323e-7b75-4d9b-94a1-b7df545ce283	afb9180b-6d35-4e8f-9858-897749ccb3d3	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	finance_request	new	Ahmed Hassan	+201063429243	2026-06-08 21:27:21.272	2026-07-18 21:27:21.389837
cae12b08-7d28-488d-9fdf-8ba8bea7e855	afb9180b-6d35-4e8f-9858-897749ccb3d3	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	whatsapp	new	Omar Tarek	+201042269599	2026-06-08 21:27:21.272	2026-07-18 21:27:21.396633
8c6ec72b-a82d-4101-9fe0-a13fd9880d75	5c396975-c3f2-4970-b281-f8db7cfca1bf	00ba65f0-e746-4c79-8026-09723e0a59f0	7a1f2488-111c-445b-9169-35e6b7eb37b4	finance_request	new	Sara Adel	+201062426295	2026-06-01 21:27:21.272	2026-07-18 21:27:21.400567
602d2a00-2021-4124-a72a-91d967e52166	25130e61-f0ac-4a2f-ab46-91ce6f54649f	267d8854-2d0d-4988-89b2-bca9de35e789	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	whatsapp	new	Mohamed Khalil	+201076004603	2026-06-01 21:27:21.272	2026-07-18 21:27:21.40359
43bcc020-c5d5-4c02-a58a-d3718b316303	85c4c348-d4f0-44ed-b814-60c0a881559e	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	call	new	Ahmed Hassan	+201027818798	2026-06-13 21:27:21.272	2026-07-18 21:27:21.407198
9de955eb-283a-4c79-b495-2acf77acbf9c	85c4c348-d4f0-44ed-b814-60c0a881559e	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	call	new	Sara Adel	+201040910169	2026-06-13 21:27:21.272	2026-07-18 21:27:21.411121
74d33282-48cf-43b2-9e89-7bf35bccf200	f015cb68-23c1-45ac-8241-280405b54dcc	267d8854-2d0d-4988-89b2-bca9de35e789	00ba65f0-e746-4c79-8026-09723e0a59f0	whatsapp	new	Sara Adel	+201013203261	2026-06-13 21:27:21.272	2026-07-18 21:27:21.414016
ca02abfc-1cfe-422e-ba6c-ce8b9079c4e5	f015cb68-23c1-45ac-8241-280405b54dcc	267d8854-2d0d-4988-89b2-bca9de35e789	00ba65f0-e746-4c79-8026-09723e0a59f0	whatsapp	new	Mohamed Khalil	+201039673750	2026-06-13 21:27:21.272	2026-07-18 21:27:21.417594
beb9bd8b-ad61-49e0-8cf9-7608a0440c4c	30cc6cc4-25df-481a-87a6-f0a2e4e82618	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	chat	new	Omar Tarek	+201010195129	2026-06-01 21:27:21.272	2026-07-18 21:27:21.421735
214c2df1-0fc0-4341-a902-4d39dd1d4065	30cc6cc4-25df-481a-87a6-f0a2e4e82618	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	call	new	Ahmed Hassan	+201020650241	2026-06-01 21:27:21.272	2026-07-18 21:27:21.425078
21ebc0f2-9d37-4413-b7fc-c23578687941	8ee87c30-45fd-451a-b437-c51e915da497	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	chat	new	Mohamed Khalil	+201091819037	2026-06-14 21:27:21.272	2026-07-18 21:27:21.433086
c8670b78-3ff6-4b3e-9e66-6a258d26fbbb	f4b561b7-113d-4938-8330-e527db01404c	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	call	new	Ahmed Hassan	+201013940210	2026-05-26 21:27:21.272	2026-07-18 21:27:21.436419
f2eef746-4859-4613-8106-148786403ecc	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	00ba65f0-e746-4c79-8026-09723e0a59f0	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	whatsapp	new	Sara Adel	+201035600986	2026-06-05 21:27:21.272	2026-07-18 21:27:21.439611
364663e5-45f0-45e5-86ee-5e751065133c	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	00ba65f0-e746-4c79-8026-09723e0a59f0	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	call	new	Ahmed Hassan	+201062452238	2026-06-05 21:27:21.272	2026-07-18 21:27:21.442783
83fd3081-d790-4812-9c82-2a8a7615243f	38b5547f-3272-4752-adef-419278a5a379	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	whatsapp	new	Omar Tarek	+201082353296	2026-07-05 21:27:21.272	2026-07-18 21:27:21.446028
a39c1f4d-52df-4f83-bd57-d1046d470b7c	38b5547f-3272-4752-adef-419278a5a379	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	call	new	Omar Tarek	+201026118794	2026-07-05 21:27:21.272	2026-07-18 21:27:21.451457
6aebb168-5947-4a27-8906-b23a1b50fe0c	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	267d8854-2d0d-4988-89b2-bca9de35e789	00ba65f0-e746-4c79-8026-09723e0a59f0	chat	new	Mohamed Khalil	+201032005807	2026-06-25 21:27:21.272	2026-07-18 21:27:21.454636
132fdcda-268d-4c62-a37a-4da395f285e5	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	267d8854-2d0d-4988-89b2-bca9de35e789	00ba65f0-e746-4c79-8026-09723e0a59f0	finance_request	new	Ahmed Hassan	+201085676619	2026-06-25 21:27:21.272	2026-07-18 21:27:21.458107
9ffdf7b8-c6b0-492c-9adf-2ccbec2999cb	322f1d1d-f418-4a26-8e60-45d8c45858a9	00ba65f0-e746-4c79-8026-09723e0a59f0	1b06f035-4e8a-4dd7-86e3-95299957f2b8	finance_request	new	Omar Tarek	+201021253133	2026-06-29 21:27:21.272	2026-07-18 21:27:21.462655
2b210dca-71d0-4d55-a688-d1b613c5bee8	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	chat	new	Mohamed Khalil	+201077212030	2026-06-23 21:27:21.272	2026-07-18 21:27:21.465713
23aa7deb-d8ee-442d-b528-35f3e70149cb	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	finance_request	new	Omar Tarek	+201030229887	2026-06-23 21:27:21.272	2026-07-18 21:27:21.469222
08909966-16bd-4423-953a-183c98f5bd42	da4ea6a9-a539-457f-ab70-5e143be46366	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	whatsapp	new	Omar Tarek	+201081034282	2026-07-01 21:27:21.272	2026-07-18 21:27:21.472868
08997af9-a333-4b98-b043-41d04cc1afe0	dfa4da74-d198-413d-828c-f629a7b50189	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	chat	new	Ahmed Hassan	+201085958660	2026-06-27 21:27:21.272	2026-07-18 21:27:21.476515
961fadcc-e8d2-471d-b7be-8a4fcf2bf6cb	dfa4da74-d198-413d-828c-f629a7b50189	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	chat	new	Mohamed Khalil	+201085858752	2026-06-27 21:27:21.272	2026-07-18 21:27:21.480418
9a18f17d-5917-4d26-b23f-a5c4417f912a	ccc3c757-0782-4a1f-b2ac-31d59a9b307d	267d8854-2d0d-4988-89b2-bca9de35e789	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	finance_request	new	Sara Adel	+201028644147	2026-07-14 21:27:21.272	2026-07-18 21:27:21.48328
2fbac6e4-9c99-44db-9424-365f6e16d2fb	3086a988-b6a0-4e15-ab43-c09b98faafa7	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	call	new	Omar Tarek	+201097764265	2026-07-09 21:27:21.272	2026-07-18 21:27:21.486599
8c09b1bf-4480-4e4b-a1bb-262e5ca9ef76	3086a988-b6a0-4e15-ab43-c09b98faafa7	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	finance_request	new	Sara Adel	+201013591567	2026-07-09 21:27:21.272	2026-07-18 21:27:21.490759
14353437-86f9-4c0a-9370-d08a8f0f6687	9030afe9-63c8-4d9d-bac1-3dd49f4429e0	267d8854-2d0d-4988-89b2-bca9de35e789	00ba65f0-e746-4c79-8026-09723e0a59f0	whatsapp	new	Sara Adel	+201052551881	2026-06-23 21:27:21.272	2026-07-18 21:27:21.493522
631b0d9b-de3a-453d-9c1b-f62258340391	afdc4e90-2ad7-49e5-838c-3fbbee033f3d	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	finance_request	new	Mohamed Khalil	+201011301458	2026-07-14 21:27:21.272	2026-07-18 21:27:21.497003
6b7ec3c2-755c-4e4a-a021-4c3891fc1c9a	09c8183b-d75c-4fad-ab84-55955aab44e2	267d8854-2d0d-4988-89b2-bca9de35e789	760eca0f-df82-4102-9263-2cc82898272b	call	new	Mohamed Khalil	+201056748538	2026-06-22 21:27:21.272	2026-07-18 21:27:21.501374
d3c4eff2-d6a3-4e35-a7ff-4f60cebbba29	55850d32-1a17-48c5-9363-a58459046358	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	call	new	Mohamed Khalil	+201097187658	2026-06-29 21:27:21.272	2026-07-18 21:27:21.504978
34c28247-ba03-4df0-92d6-43f5b1980500	55850d32-1a17-48c5-9363-a58459046358	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	whatsapp	new	Sara Adel	+201044938452	2026-06-29 21:27:21.272	2026-07-18 21:27:21.508003
669066bd-c791-4500-862e-62bb83683cd5	ad7793eb-66af-4039-8267-c59488026824	00ba65f0-e746-4c79-8026-09723e0a59f0	1b06f035-4e8a-4dd7-86e3-95299957f2b8	whatsapp	new	Omar Tarek	+201015898617	2026-07-12 21:27:21.272	2026-07-18 21:27:21.510721
89faa3d0-e14d-49f4-9890-c982664e8f9f	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	call	new	Sara Adel	+201036503472	2026-07-04 21:27:21.272	2026-07-18 21:27:21.518695
a73f1389-5f91-41ab-8072-101e767844e0	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	whatsapp	new	Mohamed Khalil	+201028662674	2026-07-04 21:27:21.272	2026-07-18 21:27:21.522578
1d26a2f8-e392-4001-b0a1-bd2fc45c3761	b8677ab7-9b44-4c7a-bc7c-1bd54ecaa5ca	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	chat	new	Mohamed Khalil	+201092830575	2026-07-17 21:27:21.272	2026-07-18 21:27:21.530143
98ccd7ca-ff3e-41b5-916a-be79ca7745b7	b8677ab7-9b44-4c7a-bc7c-1bd54ecaa5ca	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	chat	new	Sara Adel	+201083520001	2026-07-17 21:27:21.272	2026-07-18 21:27:21.534502
f5528d41-27e9-4a8b-ab11-5a3c722fdc5e	7adfddc0-5f2d-4e3a-823c-7ca55388ee69	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	finance_request	new	Omar Tarek	+201085533545	2026-05-21 21:27:21.272	2026-07-18 21:27:21.588919
f4627bb3-5b31-4afe-bc57-be1a447cfdfe	7adfddc0-5f2d-4e3a-823c-7ca55388ee69	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	finance_request	new	Ahmed Hassan	+201064732473	2026-05-21 21:27:21.272	2026-07-18 21:27:21.592037
86678c5a-2f21-49dd-bf03-0675427c58b1	8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	call	new	Omar Tarek	+201019221537	2026-06-13 21:27:21.272	2026-07-18 21:27:21.594769
bd57820f-3f99-4c18-8694-20756d3bc2c3	8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	chat	new	Mohamed Khalil	+201029106907	2026-06-13 21:27:21.272	2026-07-18 21:27:21.597729
d9a7f009-2c2e-45e2-9a49-8a42422f82f5	bed7ae5c-ed17-42e2-8ba4-747f178c546c	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	chat	new	Sara Adel	+201056371947	2026-06-16 21:27:21.272	2026-07-18 21:27:21.600704
208d55c1-071e-4132-80d9-d4b3b2b2fb2b	bed7ae5c-ed17-42e2-8ba4-747f178c546c	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	chat	new	Ahmed Hassan	+201080165721	2026-06-16 21:27:21.272	2026-07-18 21:27:21.603798
e8bcef34-c735-46ed-a8e0-9526d7f8198f	7294796b-3884-4742-abee-d13b457c610b	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	whatsapp	new	Mohamed Khalil	+201057373999	2026-06-05 21:27:21.272	2026-07-18 21:27:21.606786
27057338-e103-4086-be15-cf98195aeaf1	b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	267d8854-2d0d-4988-89b2-bca9de35e789	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	whatsapp	new	Ahmed Hassan	+201013893175	2026-05-21 21:27:21.272	2026-07-18 21:27:21.609638
d8141ee8-a8b5-4074-895f-b19a5dd7b875	b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	267d8854-2d0d-4988-89b2-bca9de35e789	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	chat	new	Ahmed Hassan	+201071263628	2026-05-21 21:27:21.272	2026-07-18 21:27:21.612573
155a6d15-3195-4cbc-b487-5e384949bee8	9f249352-cd48-4c1d-b238-ca2a015a6f20	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	chat	new	Ahmed Hassan	+201030732550	2026-05-24 21:27:21.272	2026-07-18 21:27:21.615569
44d2d784-34e7-45d9-af90-e15db8a02656	5ad12c3c-5a96-4a2b-89a4-566454a6869a	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	finance_request	new	Omar Tarek	+201018474375	2026-07-02 21:27:21.272	2026-07-18 21:27:21.623633
ac9812bc-3c6e-46f1-8547-f8045c749cd3	5ad12c3c-5a96-4a2b-89a4-566454a6869a	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	chat	new	Ahmed Hassan	+201021352874	2026-07-02 21:27:21.272	2026-07-18 21:27:21.626926
f7773930-ac51-459b-923f-7aae651d922e	f7fc3936-4bc1-4375-b8c2-c173126959ea	267d8854-2d0d-4988-89b2-bca9de35e789	760eca0f-df82-4102-9263-2cc82898272b	call	new	Mohamed Khalil	+201099019758	2026-07-01 21:27:21.272	2026-07-18 21:27:21.631834
22f6077c-b84a-4c88-beab-a5edc4d9e742	f7fc3936-4bc1-4375-b8c2-c173126959ea	267d8854-2d0d-4988-89b2-bca9de35e789	760eca0f-df82-4102-9263-2cc82898272b	call	new	Mohamed Khalil	+201035300447	2026-07-01 21:27:21.272	2026-07-18 21:27:21.63476
af2b2c24-9162-45df-a91e-1c4482c80273	c9e5c75d-ac07-4dcf-a123-fea99cca404b	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	call	new	Mohamed Khalil	+201098571786	2026-07-10 21:27:21.272	2026-07-18 21:27:21.637708
b76eaa69-3ca8-4ee9-bc12-0fd0ee29a5b1	c9e5c75d-ac07-4dcf-a123-fea99cca404b	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	whatsapp	new	Ahmed Hassan	+201074003436	2026-07-10 21:27:21.272	2026-07-18 21:27:21.640611
40e2ba28-51ae-459b-b000-438f70928d72	58002df9-b711-4713-8047-f828c50d6718	00ba65f0-e746-4c79-8026-09723e0a59f0	7a1f2488-111c-445b-9169-35e6b7eb37b4	chat	new	Mohamed Khalil	+201044758259	2026-07-01 21:27:21.272	2026-07-18 21:27:21.643544
3262cc4e-1cdc-492d-acc5-df037a280f50	58002df9-b711-4713-8047-f828c50d6718	00ba65f0-e746-4c79-8026-09723e0a59f0	7a1f2488-111c-445b-9169-35e6b7eb37b4	finance_request	new	Mohamed Khalil	+201081036110	2026-07-01 21:27:21.272	2026-07-18 21:27:21.64651
17cb2080-09ac-40bf-8558-d65ba5e29949	906b9bd8-d0ca-4a6f-aec9-915686f8c48b	00ba65f0-e746-4c79-8026-09723e0a59f0	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	finance_request	new	Ahmed Hassan	+201035447260	2026-06-21 21:27:21.272	2026-07-18 21:27:21.649314
cd117de4-da68-494b-8fee-1b334a107b2a	20644d0f-152c-4e29-9092-c14238b4a261	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	whatsapp	new	Sara Adel	+201046875414	2026-07-02 21:27:21.272	2026-07-18 21:27:21.652164
362f2e93-1a84-43fa-9cba-1c2e9ac79e58	25a613fc-b24c-48c5-9dda-acf3c02a3542	267d8854-2d0d-4988-89b2-bca9de35e789	00ba65f0-e746-4c79-8026-09723e0a59f0	call	new	Mohamed Khalil	+201043026933	2026-07-03 21:27:21.272	2026-07-18 21:27:21.654902
c9a59efa-51c3-4a08-ae2a-96ed2037024a	fbc3778f-be9e-4548-b205-46f14e3b3faf	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	call	new	Ahmed Hassan	+201048339227	2026-07-13 21:27:21.272	2026-07-18 21:27:21.660412
bfa32eca-8d4f-44e3-96b8-89c2df553089	b7537c25-ddd0-4394-8e12-08015def429c	267d8854-2d0d-4988-89b2-bca9de35e789	00ba65f0-e746-4c79-8026-09723e0a59f0	call	new	Ahmed Hassan	+201032029018	2026-06-29 21:27:21.272	2026-07-18 21:27:21.663899
92b6e565-1cc2-44a5-bf39-acaacf78f3e9	43911f51-805d-4b2c-add6-b328c2667a6e	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	chat	new	Ahmed Hassan	+201099385305	2026-06-09 21:27:21.272	2026-07-18 21:27:21.816264
5aba663a-ee31-43fd-8a0a-8ea469dee094	43911f51-805d-4b2c-add6-b328c2667a6e	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	call	new	Ahmed Hassan	+201091347436	2026-06-09 21:27:21.272	2026-07-18 21:27:21.819631
6d117262-19a5-4a17-a86f-fbf6cb89dd4d	240e7f63-766f-4fcc-b192-2df158c17999	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	chat	new	Sara Adel	+201064487944	2026-05-27 21:27:21.272	2026-07-18 21:27:21.823178
ed36d7f4-eb1e-41d1-a242-fb66b8cc1c66	35191d0c-d69e-4d03-93c6-fd48bfd5ab4f	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	call	new	Sara Adel	+201099273229	2026-06-01 21:27:21.272	2026-07-18 21:27:21.827768
101e5276-d787-4ab6-9b24-2bf0260306c8	714ecac9-fd70-4822-8c2c-df9ae1be7994	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	call	new	Ahmed Hassan	+201017249456	2026-06-06 21:27:21.272	2026-07-18 21:27:21.833561
45aecc4e-2adb-405a-baf5-9f7b3c627869	714ecac9-fd70-4822-8c2c-df9ae1be7994	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	finance_request	new	Ahmed Hassan	+201048430000	2026-06-06 21:27:21.272	2026-07-18 21:27:21.836553
7b6be1eb-0df6-4dc1-887b-62d8ae1a685a	000bdfd3-ef1f-43e1-b6bc-40e82258ad3e	00ba65f0-e746-4c79-8026-09723e0a59f0	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	chat	new	Sara Adel	+201037053397	2026-06-05 21:27:21.272	2026-07-18 21:27:21.840319
85b62cfd-4610-4996-b858-95b6dedb9404	f543b945-c700-4357-97bb-2d5f5bb9d828	00ba65f0-e746-4c79-8026-09723e0a59f0	267d8854-2d0d-4988-89b2-bca9de35e789	chat	new	Ahmed Hassan	+201040638132	2026-05-25 21:27:21.272	2026-07-18 21:27:21.843544
524f4069-2bb8-4642-81fa-61881567de3e	776e660f-a9f1-4129-b969-2fed1e1a6668	267d8854-2d0d-4988-89b2-bca9de35e789	00ba65f0-e746-4c79-8026-09723e0a59f0	whatsapp	new	Sara Adel	+201010658425	2026-06-11 21:27:21.272	2026-07-18 21:27:21.846939
16389927-1c86-4466-8bb4-8b11f4c144f4	d4ddac53-a22c-460b-96f2-481482d1bc95	00ba65f0-e746-4c79-8026-09723e0a59f0	760eca0f-df82-4102-9263-2cc82898272b	chat	new	Ahmed Hassan	+201066566695	2026-07-01 21:27:21.272	2026-07-18 21:27:21.85159
51bbb26c-5eac-412b-8a17-1e1cbfc72a87	e10511a8-45c3-4da3-bc6e-2b192c15bd24	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	whatsapp	new	Omar Tarek	+201038330185	2026-07-05 21:27:21.272	2026-07-18 21:27:21.854848
b14fb5d8-9715-48d6-a07c-f6c096d9413c	e10511a8-45c3-4da3-bc6e-2b192c15bd24	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	chat	new	Mohamed Khalil	+201067808890	2026-07-05 21:27:21.272	2026-07-18 21:27:21.857794
7cd3c9da-5164-4089-bcdf-8f254645b6b8	6f8a18b3-7b7a-4eda-800c-f5ae5a5cd290	00ba65f0-e746-4c79-8026-09723e0a59f0	1b06f035-4e8a-4dd7-86e3-95299957f2b8	call	new	Ahmed Hassan	+201098202638	2026-06-28 21:27:21.272	2026-07-18 21:27:21.860803
da455c0f-1939-4de2-ad72-efed6fbcbeba	6f8a18b3-7b7a-4eda-800c-f5ae5a5cd290	00ba65f0-e746-4c79-8026-09723e0a59f0	1b06f035-4e8a-4dd7-86e3-95299957f2b8	finance_request	new	Mohamed Khalil	+201056752107	2026-06-28 21:27:21.272	2026-07-18 21:27:21.864187
6c7c9fdc-81be-4d70-bc70-1c8d3e99f9b7	188d6bfc-b83a-4299-8c55-d8d5505b9f4a	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	chat	new	Omar Tarek	+201023400395	2026-07-16 21:27:21.272	2026-07-18 21:27:21.867212
efc1df15-1e2e-41d9-962f-bb323a7168ca	188d6bfc-b83a-4299-8c55-d8d5505b9f4a	267d8854-2d0d-4988-89b2-bca9de35e789	7a1f2488-111c-445b-9169-35e6b7eb37b4	whatsapp	new	Ahmed Hassan	+201070912716	2026-07-16 21:27:21.272	2026-07-18 21:27:21.87054
0d8988f9-d640-4d48-9ffe-33c383d9041d	4c1792ba-c514-454d-a4b3-39f3aad9fa71	267d8854-2d0d-4988-89b2-bca9de35e789	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	call	new	Ahmed Hassan	+201036507715	2026-06-30 21:27:21.272	2026-07-18 21:27:21.873404
8d9009c4-baa6-4952-b762-d6dceb0dcbe8	a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	whatsapp	new	Mohamed Khalil	+201022964182	2026-07-14 21:27:21.272	2026-07-18 21:27:21.876248
467d6511-2fac-4945-bdd9-a4539a3b12e3	a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	finance_request	new	Ahmed Hassan	+201084076489	2026-07-14 21:27:21.272	2026-07-18 21:27:21.879157
d0c43d0d-ce75-4bbb-bf45-e7096e92979b	ce85c9c5-65f2-4876-b98c-f11d7f183b25	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	chat	new	Ahmed Hassan	+201074927547	2026-07-16 21:27:21.272	2026-07-18 21:27:21.882019
59ce4b5c-18af-4ddd-949d-d3c8c4a3f959	ce85c9c5-65f2-4876-b98c-f11d7f183b25	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	chat	new	Omar Tarek	+201096588076	2026-07-16 21:27:21.272	2026-07-18 21:27:21.884896
6b3884d5-3cd4-4564-88c8-9d44941f2a5f	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	whatsapp	new	Mohamed Khalil	+201078052713	2026-07-02 21:27:21.272	2026-07-18 21:27:21.888151
7a4c3316-4b89-4091-bf1f-cdf85ecac76b	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	finance_request	new	Sara Adel	+201073411293	2026-07-02 21:27:21.272	2026-07-18 21:27:21.891216
7df3a0bd-005d-4b9b-b1af-95a593d783e6	a89eab67-0e52-408d-8887-03d24cd3886d	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	call	new	Ahmed Hassan	+201025258244	2026-07-14 21:27:21.272	2026-07-18 21:27:21.894794
5f1060e1-7b82-4d5d-b287-7910eb1eb26f	a89eab67-0e52-408d-8887-03d24cd3886d	267d8854-2d0d-4988-89b2-bca9de35e789	1b06f035-4e8a-4dd7-86e3-95299957f2b8	whatsapp	new	Mohamed Khalil	+201071405203	2026-07-14 21:27:21.272	2026-07-18 21:27:21.897676
e591cc0f-77cf-4374-8beb-06f88162c0a5	d6ab50a9-fc95-4d3b-9959-b66badab140f	00ba65f0-e746-4c79-8026-09723e0a59f0	0f04b82a-797d-4bc6-afa3-b1857fca6608	chat	new	Omar Tarek	+201069177329	2026-07-04 21:27:21.272	2026-07-18 21:27:21.900754
61b3d5c6-5bca-450d-9af3-e11c6616b605	1e9b6e89-66ff-460b-a11f-bfa9d27e48d0	267d8854-2d0d-4988-89b2-bca9de35e789	0f04b82a-797d-4bc6-afa3-b1857fca6608	call	new	Ahmed Hassan	+201039129165	2026-06-29 21:27:21.272	2026-07-18 21:27:21.90365
11294434-f541-484a-9ea1-9c771610bf39	9322a87e-6899-4b8a-8399-280801afaff0	f787718d-27d8-4877-82fd-b4ff2a25bdee	7a1f2488-111c-445b-9169-35e6b7eb37b4	finance_request	new	\N	\N	2026-07-21 13:33:10.197495	2026-07-21 13:33:10.197495
5824c17b-4eb4-4462-ad5a-383aca96c077	b91b906c-199e-4872-8bd7-aa305e61d456	f787718d-27d8-4877-82fd-b4ff2a25bdee	760eca0f-df82-4102-9263-2cc82898272b	chat	new	\N	\N	2026-07-21 13:34:27.076949	2026-07-21 13:34:27.076949
\.


--
-- Data for Name: lead_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_tokens (id, viewer_clerk_id, listing_id, expires_at, used_at, created_at) FROM stdin;
53cb3323-a53e-4e3d-8333-99a02a734556	user_3GoXXJRSlm8kv8y3yZFITYNCIW3	9322a87e-6899-4b8a-8399-280801afaff0	2026-07-21 14:03:04.83	2026-07-21 13:33:10.197	2026-07-21 13:33:04.831332
75d6b0ff-7bd8-49d7-814a-d6ca4e5ed4e5	user_3GoXXJRSlm8kv8y3yZFITYNCIW3	8c77c35d-3969-4fd0-933a-9558cc48fac5	2026-07-21 14:03:54.369	\N	2026-07-21 13:33:54.370398
b44069a7-feef-4860-b568-5785429c718e	user_3GoXXJRSlm8kv8y3yZFITYNCIW3	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	2026-07-21 14:04:10.797	\N	2026-07-21 13:34:10.799048
5f465dfb-ee2f-42c1-b5a8-2e4d0feff6e8	user_3GoXXJRSlm8kv8y3yZFITYNCIW3	9322a87e-6899-4b8a-8399-280801afaff0	2026-07-21 14:04:19.599	\N	2026-07-21 13:34:19.600474
17486bb9-7958-4add-8165-f294d71dae2d	user_3GoXXJRSlm8kv8y3yZFITYNCIW3	b91b906c-199e-4872-8bd7-aa305e61d456	2026-07-21 14:04:25.4	2026-07-21 13:34:27.077	2026-07-21 13:34:25.402259
\.


--
-- Data for Name: listing_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_attributes (id, listing_id, specs, brand_id, model_id, variant_id, fuel_type, condition, body_type, transmission, property_type, finishing_type, ownership_type, industrial_type, industry, property_type_id, finishing_type_id, ownership_type_id, industrial_type_id, industry_id, delivery_time_days, origin_type, country_of_origin, shipping_method) FROM stdin;
c97ce2ac-d95e-4134-84df-5fa06dde5e28	e986f0a2-b346-485e-8409-3ac93ab1d516	{"year": 2024, "brand": "Mercedes-Benz", "color": "blue", "model": "C-Class", "seats": 7, "mileage": 89788, "variant": "C200", "condition": "used", "engine_cc": 4000, "fuel_type": "petrol", "transmission": "automatic"}	ff874e82-8969-4196-aeef-2142b375a108	cce6d52c-efed-476c-adec-a830439434d0	4526f117-c0e7-4f51-95ea-8e765e31ddfb	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
292b3059-9945-42b3-843d-76db4962d003	fc570df0-e974-4c5a-abbe-d2df329e8ae3	{"year": 2019, "brand": "Mercedes-Benz", "color": "blue", "model": "C-Class", "seats": 7, "mileage": 146143, "variant": "C200", "condition": "used", "engine_cc": 1600, "fuel_type": "diesel", "transmission": "manual"}	ff874e82-8969-4196-aeef-2142b375a108	cce6d52c-efed-476c-adec-a830439434d0	4526f117-c0e7-4f51-95ea-8e765e31ddfb	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1899dfe9-e76b-407d-bc86-f67220b4f514	5c396975-c3f2-4970-b281-f8db7cfca1bf	{"year": 2019, "brand": "Hyundai", "color": "blue", "model": "Tucson", "seats": 7, "mileage": 105453, "variant": "GLS", "condition": "used", "engine_cc": 2000, "fuel_type": "petrol", "transmission": "manual"}	c9bcc02d-87c4-4717-8ee9-5a7959104e52	c684b989-28a1-41da-85a2-37c4ce13f550	b072c094-b9c4-4326-91c8-7d2500c5a2ed	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
d537ff31-b21e-4ca9-b80e-edce05d229b7	25130e61-f0ac-4a2f-ab46-91ce6f54649f	{"year": 2022, "brand": "Kia", "color": "blue", "model": "Sportage", "seats": 7, "mileage": 161166, "variant": "Luxury", "condition": "used", "engine_cc": 3000, "fuel_type": "petrol", "transmission": "manual"}	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	05de1c51-957d-483e-b96a-640249f3919d	afd59079-ad8d-4bdb-ae37-b09a2fdcd6c1	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b94eceec-7c07-4d29-b02a-eb5e178dfbd5	85c4c348-d4f0-44ed-b814-60c0a881559e	{"year": 2023, "brand": "Volkswagen", "color": "black", "model": "Tiguan", "seats": 5, "mileage": 116678, "condition": "used", "engine_cc": 3000, "fuel_type": "diesel", "transmission": "manual"}	9436bf35-b78d-42b7-a0ae-443cb2ceec72	d59b1622-5ce6-4d12-b5d4-be8b02ec7e9c	\N	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
d019b6af-fea2-4eab-b517-64cf29ac2080	f015cb68-23c1-45ac-8241-280405b54dcc	{"year": 2024, "brand": "Chevrolet", "color": "silver", "model": "Camaro", "seats": 5, "mileage": 167417, "variant": "SS", "condition": "used", "engine_cc": 2500, "fuel_type": "petrol", "transmission": "automatic"}	0002d55a-beea-4ca9-9ab7-912f5d625dbe	89f5460c-16d2-4744-9e13-c9af1b0458a1	63c8d26d-5a0c-45be-8cd2-1282047e9de3	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
e273a742-bcdd-482e-91b1-730be3a40db8	8ee87c30-45fd-451a-b437-c51e915da497	{"year": 2022, "brand": "Porsche", "color": "blue", "model": "Cayenne", "seats": 7, "mileage": 85065, "condition": "used", "engine_cc": 3000, "fuel_type": "diesel", "transmission": "automatic"}	1dd5cb73-e65d-4884-97a4-c96ffc94fd83	fcdf28d8-f787-4278-a18e-1e776ed5af07	\N	diesel	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
a8531c2d-5fef-417e-b8ec-0af946d8e80f	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	{"year": 2019, "brand": "Land Rover", "color": "silver", "model": "Range Rover", "seats": 7, "mileage": 47441, "variant": "Vogue", "condition": "used", "engine_cc": 4000, "fuel_type": "hybrid", "transmission": "manual"}	7373ab06-3f4a-4058-8d7e-af7a21fa788d	bfb3c9d6-ed86-4d4e-a24d-72258b2820e9	db4bd753-5700-46ab-8059-552640d62621	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
45a1e61d-23c7-4b29-a846-b9d2114e49a9	f4b561b7-113d-4938-8330-e527db01404c	{"year": 2021, "brand": "Nissan", "color": "black", "model": "X-Trail", "seats": 5, "mileage": 109066, "condition": "used", "engine_cc": 2500, "fuel_type": "diesel", "transmission": "manual"}	bf1f20e8-073b-4963-a44f-8f41a0126e96	be32c728-768a-471e-a522-9bbed28dd7e3	\N	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
534095ea-4ae6-4827-97dd-5c0abbf1b30b	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	{"year": 2018, "brand": "Honda", "color": "red", "model": "CR-V", "seats": 5, "mileage": 17990, "variant": "Touring", "condition": "new", "engine_cc": 2000, "fuel_type": "diesel", "transmission": "manual"}	3121b77a-cf02-4776-a3f6-8683a9a3e883	94499369-6cd2-4af5-8077-e8ea09eeec80	4d0da00e-01c1-495a-b130-b5c659dc3192	diesel	new	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6f18d122-6b69-4440-b463-10792d09b8cd	38b5547f-3272-4752-adef-419278a5a379	{"year": 2021, "brand": "Jeep", "color": "black", "model": "Grand Cherokee", "seats": 7, "mileage": 127205, "condition": "used", "engine_cc": 4000, "fuel_type": "diesel", "transmission": "manual"}	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	c8939da5-7463-48b4-b452-feb46a50234a	\N	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5b52e092-357f-4155-9b0a-abb45aee3a18	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	{"year": 2019, "brand": "Audi", "color": "white", "model": "A4", "seats": 5, "mileage": 138496, "condition": "used", "engine_cc": 2500, "fuel_type": "hybrid", "transmission": "manual"}	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	d5980096-749a-4ef4-89f3-5e2fb56b570c	\N	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4b344842-62f4-40f9-a1b2-119be9859e11	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	{"year": 2022, "brand": "Toyota", "color": "red", "model": "Corolla", "seats": 7, "mileage": 155938, "variant": "XLI", "condition": "used", "engine_cc": 4000, "fuel_type": "diesel", "transmission": "automatic"}	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	c5e8c8af-9b5f-490b-af7d-5bdec92048f2	a09d6bbc-0c2b-42a9-a623-42f5b9908abc	diesel	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4ceb7f83-f23a-4bb6-ab66-a15a42301fa9	da4ea6a9-a539-457f-ab70-5e143be46366	{"year": 2018, "brand": "Hyundai", "color": "blue", "model": "Elantra", "seats": 7, "mileage": 59081, "condition": "used", "engine_cc": 4000, "fuel_type": "petrol", "transmission": "automatic"}	c9bcc02d-87c4-4717-8ee9-5a7959104e52	1fd78677-c4f9-448f-96ea-2edbd3153ed7	\N	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
eaf0e55c-0d7f-4c5d-8434-bd5359920c44	dfa4da74-d198-413d-828c-f629a7b50189	{"year": 2020, "brand": "Kia", "color": "silver", "model": "Cerato", "seats": 7, "mileage": 106271, "variant": "EX", "condition": "used", "engine_cc": 1600, "fuel_type": "hybrid", "transmission": "manual"}	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	c33e502d-3a1d-4bad-8b3c-b00f9a4c73ac	ee71724e-9b6b-4948-9ae4-34d494c7ae35	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
e8ab766a-90e7-4109-8cce-31bdb8a12e27	ccc3c757-0782-4a1f-b2ac-31d59a9b307d	{"year": 2024, "brand": "Chevrolet", "color": "silver", "model": "Lanos", "seats": 5, "mileage": 134094, "condition": "used", "engine_cc": 1600, "fuel_type": "petrol", "transmission": "manual"}	0002d55a-beea-4ca9-9ab7-912f5d625dbe	74a2f759-e372-436d-b30c-14349b315970	\N	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3d2cf196-516b-457b-9669-e19682ebcd15	3086a988-b6a0-4e15-ab43-c09b98faafa7	{"year": 2018, "brand": "Peugeot", "color": "blue", "model": "208", "seats": 7, "mileage": 134932, "condition": "used", "engine_cc": 2000, "fuel_type": "petrol", "transmission": "automatic"}	9a4722eb-e61a-46a5-8605-42defc479a6f	d772ed47-685a-4383-b965-d989b4e52ae5	\N	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8aa48b8c-9af0-4011-ad36-602957464e0a	9030afe9-63c8-4d9d-bac1-3dd49f4429e0	{"year": 2022, "brand": "Renault", "color": "blue", "model": "Duster", "seats": 5, "mileage": 97852, "condition": "used", "engine_cc": 2000, "fuel_type": "petrol", "transmission": "automatic"}	4d28e82a-1aa0-4654-86ca-836324dddb7c	5d18451e-a2fd-4e45-9173-5c27bd3683a2	\N	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
c5a11dbb-0fdb-46c5-9f95-7caff415acab	09c8183b-d75c-4fad-ab84-55955aab44e2	{"year": 2018, "brand": "MG", "color": "red", "model": "ZS", "seats": 5, "mileage": 9656, "variant": "Luxury", "condition": "new", "engine_cc": 2000, "fuel_type": "hybrid", "transmission": "manual"}	01092beb-86ae-4ed5-81f2-efe9eb0fb717	cc9bb9e3-50ef-49d9-a295-686c186e959e	5eb702b3-68cf-4b4d-b8ef-37a23dd3106f	hybrid	new	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7b094fa3-40a4-4614-b0ed-e39fe303e51a	55850d32-1a17-48c5-9363-a58459046358	{"year": 2019, "brand": "BMW", "color": "black", "model": "330i", "seats": 5, "mileage": 156126, "variant": "M Package", "condition": "used", "engine_cc": 2500, "fuel_type": "petrol", "transmission": "manual"}	021ed729-50a2-46b7-86d2-960eb2f84b38	b454a2a0-40e5-4311-abb8-c3fb426b292e	6d56a6fc-187b-4763-ad71-e2e1e03b661b	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1124b1d3-1ea6-4ba7-817f-b10bfd2e889f	b8677ab7-9b44-4c7a-bc7c-1bd54ecaa5ca	{"year": 2018, "brand": "Mercedes-Benz", "color": "red", "model": "GLE", "seats": 5, "mileage": 5133, "variant": "AMG", "condition": "new", "engine_cc": 3000, "fuel_type": "diesel", "transmission": "automatic"}	ff874e82-8969-4196-aeef-2142b375a108	0ac20c8c-cfe0-4f22-881e-568fc9bd1126	e4ecce3a-7114-48c6-a916-fa75a2558646	diesel	new	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
a67809a8-b502-4eda-b030-095c60c16c0b	bed7ae5c-ed17-42e2-8ba4-747f178c546c	{"area": 131, "view": "nile", "floor": 8, "rooms": 3, "compound": true, "bathrooms": 1, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Q4 2026", "property_type": "villa", "building_age_years": 0, "maintenance_per_year": 10126}	\N	\N	\N	\N	\N	\N	\N	villa	semi_finished	\N	\N	\N	33ee14cb-bcc0-4daf-b93a-823bd29c5a22	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
0b1c87e8-41f0-47d6-bdca-699804bb84d7	7294796b-3884-4742-abee-d13b457c610b	{"area": 493, "view": "pool", "floor": 17, "rooms": 5, "compound": true, "bathrooms": 2, "finishing": "core_shell", "furnished": true, "offer_type": "rent", "delivery_date": "Q4 2026", "property_type": "penthouse", "building_age_years": 15, "maintenance_per_year": 49075}	\N	\N	\N	\N	\N	\N	\N	penthouse	core_shell	\N	\N	\N	61d04884-0f14-427c-8f46-db591f317dc8	a75fb52b-8d59-4a19-aa8a-48bf80fceec9	\N	\N	\N	\N	\N	\N	\N
210a8bfb-3a84-428d-85df-f88d9be51be3	b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	{"area": 348, "view": "pool", "floor": 8, "rooms": 2, "compound": true, "bathrooms": 1, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Q3 2027", "property_type": "studio", "building_age_years": 1, "maintenance_per_year": 12143}	\N	\N	\N	\N	\N	\N	\N	studio	semi_finished	\N	\N	\N	133865ea-80c3-4043-9291-6bc7d55c0384	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
eb64ed78-7aa5-4518-a8de-f2c1d79e3683	b7537c25-ddd0-4394-8e12-08015def429c	{"area": 97, "view": "nile", "floor": 16, "rooms": 2, "compound": true, "bathrooms": 1, "finishing": "core_shell", "furnished": true, "offer_type": "rent", "delivery_date": "Ready to move", "property_type": "office", "building_age_years": 15, "maintenance_per_year": 29896}	\N	\N	\N	\N	\N	\N	\N	office	core_shell	\N	\N	\N	999b4b99-c31d-45b8-afba-290cf802d617	a75fb52b-8d59-4a19-aa8a-48bf80fceec9	\N	\N	\N	\N	\N	\N	\N
867e097d-317d-4367-aa2c-7f6340da16f3	5ad12c3c-5a96-4a2b-89a4-566454a6869a	{"area": 301, "view": "street", "floor": 19, "rooms": 5, "compound": true, "bathrooms": 2, "finishing": "super_lux", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "shop", "building_age_years": 0, "maintenance_per_year": 42587}	\N	\N	\N	\N	\N	\N	\N	shop	super_lux	\N	\N	\N	ace48cdb-39c1-4f39-afff-3d12b9e884e8	8fe2e71f-4c47-48bb-92fd-d0d68e560aca	\N	\N	\N	\N	\N	\N	\N
20cb9126-6ae3-4d2f-b285-46af6357da17	f7fc3936-4bc1-4375-b8c2-c173126959ea	{"area": 508, "view": "garden", "floor": 10, "rooms": 4, "compound": false, "bathrooms": 2, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "twinhouse", "building_age_years": 1, "maintenance_per_year": 9747}	\N	\N	\N	\N	\N	\N	\N	twinhouse	semi_finished	\N	\N	\N	80a8e3b8-848e-44fd-b4a0-89b286d38f80	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
db2df50a-435d-483b-9396-4dbdfc08a7b1	c9e5c75d-ac07-4dcf-a123-fea99cca404b	{"area": 133, "view": "nile", "floor": 3, "rooms": 4, "compound": false, "bathrooms": 2, "finishing": "core_shell", "furnished": true, "offer_type": "rent", "delivery_date": "Ready to move", "property_type": "apartment", "building_age_years": 10, "maintenance_per_year": 45087}	\N	\N	\N	\N	\N	\N	\N	apartment	core_shell	\N	\N	\N	6097cee0-c9fb-4d27-941f-85c034ec789c	a75fb52b-8d59-4a19-aa8a-48bf80fceec9	\N	\N	\N	\N	\N	\N	\N
e7a885cc-e1c7-471c-bed1-878c451f925c	58002df9-b711-4713-8047-f828c50d6718	{"area": 299, "view": "sea", "floor": 17, "rooms": 1, "compound": false, "bathrooms": 1, "finishing": "finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "villa", "building_age_years": 8, "maintenance_per_year": 13202}	\N	\N	\N	\N	\N	\N	\N	villa	finished	\N	\N	\N	33ee14cb-bcc0-4daf-b93a-823bd29c5a22	6ee9e3e2-72e5-4837-b5a6-fd3bc88d1ad2	\N	\N	\N	\N	\N	\N	\N
62e2f811-b4a1-48ca-a37a-becdc5bdf834	20644d0f-152c-4e29-9092-c14238b4a261	{"area": 372, "view": "pool", "floor": 10, "rooms": 6, "compound": false, "bathrooms": 3, "finishing": "core_shell", "furnished": true, "offer_type": "rent", "delivery_date": "Ready to move", "property_type": "duplex", "building_age_years": 2, "maintenance_per_year": 45665}	\N	\N	\N	\N	\N	\N	\N	duplex	core_shell	\N	\N	\N	7326d47c-4060-48c9-ac48-12c790e78832	a75fb52b-8d59-4a19-aa8a-48bf80fceec9	\N	\N	\N	\N	\N	\N	\N
c174c3a3-9562-420e-b8fa-4152228b63d6	25a613fc-b24c-48c5-9dda-acf3c02a3542	{"area": 140, "view": "sea", "floor": 11, "rooms": 1, "compound": false, "bathrooms": 1, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "studio", "building_age_years": 12, "maintenance_per_year": 37220}	\N	\N	\N	\N	\N	\N	\N	studio	semi_finished	\N	\N	\N	133865ea-80c3-4043-9291-6bc7d55c0384	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
4815d0bd-4d1e-4bd1-99c9-e57d947cb5bc	fbc3778f-be9e-4548-b205-46f14e3b3faf	{"area": 341, "view": "pool", "floor": 16, "rooms": 4, "compound": false, "bathrooms": 2, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "penthouse", "building_age_years": 12, "maintenance_per_year": 37873}	\N	\N	\N	\N	\N	\N	\N	penthouse	semi_finished	\N	\N	\N	61d04884-0f14-427c-8f46-db591f317dc8	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
8b91fd40-58e5-415a-8008-40477dd88047	43911f51-805d-4b2c-add6-b328c2667a6e	{"area_sqm": 8001, "capacity": "1000 units/hr", "power_kw": 1070, "condition": "very_good", "infrastructure": "electricity_3phase", "industrial_type": "land", "available_licenses": false, "included_equipment": true, "year_of_manufacture": 2016}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	land	\N	\N	\N	\N	97ec9344-d608-462e-b088-050b678b251c	\N	34	imported	Turkey	container
8ec3e6a7-4275-481e-a2b6-1cacedb13564	240e7f63-766f-4fcc-b192-2df158c17999	{"area_sqm": 3309, "capacity": "10 tons/day", "industry": "food", "power_kw": 1932, "condition": "very_good", "infrastructure": "water", "industrial_type": "factory", "available_licenses": true, "included_equipment": false, "year_of_manufacture": 2022}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	factory	food	\N	\N	\N	d6911aa7-ba35-459f-b8e9-3f2dfe9ddf1d	3ef4bc92-f961-4388-9d0c-39ed16a9b37a	20	imported	Germany	air
c43f5d34-f1fc-4d4e-84ba-fd4f0264a17c	714ecac9-fd70-4822-8c2c-df9ae1be7994	{"area_sqm": 1747, "capacity": "10 tons/day", "power_kw": 2000, "condition": "good", "infrastructure": "all_utilities", "industrial_type": "warehouse", "available_licenses": false, "included_equipment": false, "year_of_manufacture": 2011}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	warehouse	\N	\N	\N	\N	b5128ea8-3618-45d2-97de-13840dd2c639	\N	27	imported	Germany	air
737f9073-5b68-40b1-b237-5c4b0739462f	000bdfd3-ef1f-43e1-b6bc-40e82258ad3e	{"area_sqm": 5670, "capacity": "500 units/hr", "power_kw": 1994, "condition": "very_good", "infrastructure": "gas", "industrial_type": "machine", "available_licenses": true, "included_equipment": true, "year_of_manufacture": 2021}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	machine	\N	\N	\N	\N	03f6d74b-53e5-45f7-bc42-82242ae88163	\N	7	local	Egypt	air
48fe3804-1733-4238-8343-7700376970b3	f543b945-c700-4357-97bb-2d5f5bb9d828	{"area_sqm": 1496, "capacity": "5000m²", "industry": "engineering", "power_kw": 823, "condition": "needs_maintenance", "infrastructure": "water", "industrial_type": "machine", "available_licenses": true, "included_equipment": false, "year_of_manufacture": 2022}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	machine	engineering	\N	\N	\N	03f6d74b-53e5-45f7-bc42-82242ae88163	23c701c7-83da-403b-9cdb-173b235fccab	17	imported	China	air
e62adb1a-82b8-456c-9118-4eb8fbad44f2	776e660f-a9f1-4129-b969-2fed1e1a6668	{"area_sqm": 3369, "capacity": "10 tons/day", "industry": "plastic", "power_kw": 1259, "condition": "good", "infrastructure": "gas", "industrial_type": "production_line", "available_licenses": false, "included_equipment": true, "year_of_manufacture": 2012}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	production_line	plastic	\N	\N	\N	6d2e541d-fcfc-4547-abf9-9f9dab6f5c18	1bc39352-fc2c-46b8-9209-f96b46794ab6	3	local	Egypt	bulk
653063c3-4ffc-47d7-94a0-36513ae0dfb8	d4ddac53-a22c-460b-96f2-481482d1bc95	{"area_sqm": 7454, "capacity": "10 tons/day", "power_kw": 1617, "condition": "excellent", "infrastructure": "water", "available_licenses": true, "included_equipment": true, "year_of_manufacture": 2023}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	34	imported	China	bulk
719c4d9f-0524-4e2f-93ac-6c8816206b29	ad7793eb-66af-4039-8267-c59488026824	{"year": 2020, "brand": "BMW", "color": "white", "model": "X5", "seats": 5, "mileage": 40190, "variant": "M-Sport", "condition": "used", "engine_cc": 3000, "fuel_type": "hybrid", "transmission": "automatic"}	021ed729-50a2-46b7-86d2-960eb2f84b38	da8105d9-48bc-4dfb-a32e-4b0ecdb8a413	028c92f2-1f14-4c92-a5d4-0eb1c2544015	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b71f7356-593c-4629-a7cb-fde99913cf68	afb9180b-6d35-4e8f-9858-897749ccb3d3	{"year": 2023, "brand": "Toyota", "color": "black", "model": "Fortuner", "seats": 5, "mileage": 14663, "variant": "VXR", "condition": "new", "engine_cc": 1600, "fuel_type": "hybrid", "transmission": "automatic"}	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	c19f3a78-62d4-4ad4-8004-19196ab8bb85	dd9465a9-020b-498e-b06d-6123bba759bd	hybrid	new	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
660bbde8-9f26-405f-aa7e-ea3bd6820a4b	30cc6cc4-25df-481a-87a6-f0a2e4e82618	{"year": 2023, "brand": "Ford", "color": "black", "model": "Mustang", "seats": 7, "mileage": 104792, "variant": "GT", "condition": "used", "engine_cc": 4000, "fuel_type": "hybrid", "transmission": "automatic"}	e6384217-6e92-41f6-885a-7a26fa24d51b	98170462-8262-4f5d-a32f-0057d2b93109	c719c747-8c5d-4a7a-8f48-5d3233b476eb	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
43329b55-7d1d-4d5c-a26d-a86eb02713c1	322f1d1d-f418-4a26-8e60-45d8c45858a9	{"year": 2018, "brand": "Lexus", "color": "silver", "model": "RX 350", "seats": 7, "mileage": 166574, "condition": "used", "engine_cc": 1600, "fuel_type": "hybrid", "transmission": "manual"}	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	f686c84b-896c-49f0-b188-fed009c3aee4	\N	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
34c2e5bc-5839-442b-a6f9-2117e5de3d7d	afdc4e90-2ad7-49e5-838c-3fbbee033f3d	{"year": 2024, "brand": "Mitsubishi", "color": "white", "model": "Eclipse Cross", "seats": 7, "mileage": 72847, "condition": "used", "engine_cc": 2500, "fuel_type": "hybrid", "transmission": "automatic"}	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	368fa5bc-5cef-4813-9418-25b4584aaa0d	\N	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6282e43d-6183-43de-9b99-9e3a6eaf6aaa	7adfddc0-5f2d-4e3a-823c-7ca55388ee69	{"area": 139, "view": "street", "floor": 19, "rooms": 2, "compound": true, "bathrooms": 1, "finishing": "finished", "furnished": true, "offer_type": "rent", "delivery_date": "Q4 2025", "property_type": "duplex", "building_age_years": 4, "maintenance_per_year": 11328}	\N	\N	\N	\N	\N	\N	\N	duplex	finished	\N	\N	\N	7326d47c-4060-48c9-ac48-12c790e78832	6ee9e3e2-72e5-4837-b5a6-fd3bc88d1ad2	\N	\N	\N	\N	\N	\N	\N
43c1da99-9088-4c21-9a11-029031de5e0c	8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	{"area": 359, "view": "nile", "floor": 10, "rooms": 2, "compound": true, "bathrooms": 1, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Q1 2026", "property_type": "apartment", "building_age_years": 13, "maintenance_per_year": 5176}	\N	\N	\N	\N	\N	\N	\N	apartment	semi_finished	\N	\N	\N	6097cee0-c9fb-4d27-941f-85c034ec789c	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
38943e93-b19f-40da-badb-e679fb4d1b76	9f249352-cd48-4c1d-b238-ca2a015a6f20	{"area": 510, "view": "street", "floor": 4, "rooms": 6, "compound": true, "bathrooms": 3, "finishing": "finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "chalet", "building_age_years": 12, "maintenance_per_year": 22073}	\N	\N	\N	\N	\N	\N	\N	chalet	finished	\N	\N	\N	130cafd9-09be-4b07-b74c-0352dc7de103	6ee9e3e2-72e5-4837-b5a6-fd3bc88d1ad2	\N	\N	\N	\N	\N	\N	\N
94fb45d1-1a17-4dd6-b113-35c9966b8e4d	906b9bd8-d0ca-4a6f-aec9-915686f8c48b	{"area": 269, "view": "nile", "floor": 9, "rooms": 5, "compound": false, "bathrooms": 2, "finishing": "core_shell", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "apartment", "building_age_years": 5, "maintenance_per_year": 12565}	\N	\N	\N	\N	\N	\N	\N	apartment	core_shell	\N	\N	\N	6097cee0-c9fb-4d27-941f-85c034ec789c	a75fb52b-8d59-4a19-aa8a-48bf80fceec9	\N	\N	\N	\N	\N	\N	\N
a11a3e0b-bc22-42e3-91d4-f62a97ef6f8d	35191d0c-d69e-4d03-93c6-fd48bfd5ab4f	{"area_sqm": 1990, "capacity": "10 tons/day", "industry": "textile", "power_kw": 732, "condition": "needs_maintenance", "infrastructure": "electricity_3phase", "industrial_type": "production_line", "available_licenses": true, "included_equipment": true, "year_of_manufacture": 2020}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	production_line	textile	\N	\N	\N	6d2e541d-fcfc-4547-abf9-9f9dab6f5c18	a0c78644-eddf-48df-9c76-e0166c4fb457	16	imported	United Arab Emirates	container
bef68b2b-82c8-4105-91d2-91ae2a74aad6	e10511a8-45c3-4da3-bc6e-2b192c15bd24	{"area_sqm": 8503, "capacity": "10 tons/day", "industry": "engineering", "power_kw": 556, "condition": "needs_maintenance", "infrastructure": "gas", "industrial_type": "factory", "available_licenses": false, "included_equipment": false, "year_of_manufacture": 2014}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	factory	engineering	\N	\N	\N	d6911aa7-ba35-459f-b8e9-3f2dfe9ddf1d	23c701c7-83da-403b-9cdb-173b235fccab	36	local	Egypt	container
66eaaead-635d-424b-a5aa-4999a8de90e2	6f8a18b3-7b7a-4eda-800c-f5ae5a5cd290	{"area_sqm": 4457, "capacity": "500 units/hr", "industry": "beverage", "power_kw": 901, "condition": "good", "infrastructure": "water", "industrial_type": "factory", "available_licenses": true, "included_equipment": false, "year_of_manufacture": 2023}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	factory	beverage	\N	\N	\N	d6911aa7-ba35-459f-b8e9-3f2dfe9ddf1d	f1ebee51-9bae-4382-8a13-d534b3b31295	29	imported	United Arab Emirates	container
beb8d16b-a0f1-4af7-95df-5c2ea9070ae0	188d6bfc-b83a-4299-8c55-d8d5505b9f4a	{"area_sqm": 8556, "capacity": "1000 units/hr", "industry": "pharmaceutical", "power_kw": 1048, "condition": "very_good", "infrastructure": "electricity_3phase", "industrial_type": "production_line", "available_licenses": true, "included_equipment": true, "year_of_manufacture": 2023}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	production_line	pharmaceutical	\N	\N	\N	6d2e541d-fcfc-4547-abf9-9f9dab6f5c18	d133db38-e6ca-40a2-bd99-5c97b492f05f	33	imported	China	air
b5c9482d-d0f5-4356-a11d-70322dc6ca90	4c1792ba-c514-454d-a4b3-39f3aad9fa71	{"area_sqm": 8826, "capacity": "500 units/hr", "power_kw": 377, "condition": "very_good", "infrastructure": "electricity_3phase", "industrial_type": "machine", "available_licenses": true, "included_equipment": false, "year_of_manufacture": 2012}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	machine	\N	\N	\N	\N	03f6d74b-53e5-45f7-bc42-82242ae88163	\N	39	imported	Turkey	air
3ea4531f-f06b-40c7-9c1d-30c6539f1d11	a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	{"industry": "plastic", "industrial_type": "raw_material"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	raw_material	plastic	\N	\N	\N	\N	\N	29	local	Egypt	air
6ff4191e-74eb-47eb-9e04-71e56ce6d6e4	ce85c9c5-65f2-4876-b98c-f11d7f183b25	{"industry": "plastic", "industrial_type": "raw_material"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	raw_material	plastic	\N	\N	\N	\N	\N	3	imported	United Arab Emirates	bulk
53e5ec85-deb1-49dd-83ea-e9e41a01b8f1	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	{"industry": "plastic", "industrial_type": "machine"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	machine	plastic	\N	\N	\N	\N	\N	38	local	Egypt	air
9c1fb657-6706-447e-937b-9ee256ca2353	a89eab67-0e52-408d-8887-03d24cd3886d	{"industry": "plastic", "industrial_type": "machine"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	machine	plastic	\N	\N	\N	\N	\N	31	local	Egypt	bulk
39966032-bf09-4d40-8783-7b9949671635	d6ab50a9-fc95-4d3b-9959-b66badab140f	{"industry": "plastic", "industrial_type": "production_line"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	production_line	plastic	\N	\N	\N	\N	\N	39	local	Egypt	air
f75575bf-8ac6-491d-8a8f-6ee41668931f	1e9b6e89-66ff-460b-a11f-bfa9d27e48d0	{"industry": "plastic", "industrial_type": "factory"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	factory	plastic	\N	\N	\N	\N	\N	31	local	Egypt	container
37437aa7-0b79-4f81-8dfe-d835897c152e	bf1b64b0-40db-494e-8b66-509316a30724	{"year": 2021, "brand": "Kia", "color": "silver", "model": "Sportage", "seats": 7, "mileage": 101292, "variant": "Luxury", "condition": "used", "engine_cc": 2500, "fuel_type": "petrol", "transmission": "manual"}	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	05de1c51-957d-483e-b96a-640249f3919d	afd59079-ad8d-4bdb-ae37-b09a2fdcd6c1	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3feaf83d-df35-4dc6-9b30-adf3bf0b1029	64d60de9-2649-48e8-8636-bb76c8a0192e	{"year": 2018, "brand": "Volkswagen", "color": "red", "model": "Tiguan", "seats": 7, "mileage": 108579, "condition": "used", "engine_cc": 3000, "fuel_type": "petrol", "transmission": "automatic"}	9436bf35-b78d-42b7-a0ae-443cb2ceec72	d59b1622-5ce6-4d12-b5d4-be8b02ec7e9c	\N	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
011b53ec-dbfd-48f9-92e5-bce45730405b	edf0deed-fa66-4c53-9ca3-5b87b10ec806	{"year": 2018, "brand": "Volkswagen", "color": "blue", "model": "Tiguan", "seats": 7, "mileage": 79149, "condition": "used", "engine_cc": 3000, "fuel_type": "hybrid", "transmission": "manual"}	9436bf35-b78d-42b7-a0ae-443cb2ceec72	d59b1622-5ce6-4d12-b5d4-be8b02ec7e9c	\N	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
141450f8-64cd-494f-9e7d-6365b0bc15d4	6531a87f-7a51-454d-8dea-9660c3aa3fa3	{"year": 2018, "brand": "Ford", "color": "white", "model": "Mustang", "seats": 7, "mileage": 176049, "variant": "GT", "condition": "used", "engine_cc": 3000, "fuel_type": "petrol", "transmission": "automatic"}	e6384217-6e92-41f6-885a-7a26fa24d51b	98170462-8262-4f5d-a32f-0057d2b93109	c719c747-8c5d-4a7a-8f48-5d3233b476eb	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
d64d0e26-f613-4fd2-961c-b3ed09b1b3d2	1535dacc-8620-475f-863c-f5048d3f271f	{"year": 2019, "brand": "Porsche", "color": "red", "model": "Cayenne", "seats": 5, "mileage": 179297, "condition": "used", "engine_cc": 3000, "fuel_type": "petrol", "transmission": "automatic"}	1dd5cb73-e65d-4884-97a4-c96ffc94fd83	fcdf28d8-f787-4278-a18e-1e776ed5af07	\N	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
620672b4-8f55-4b1c-bbe8-e6d01fcec34d	ff6d88fd-14e9-45f9-a2ea-552c61e61f14	{"year": 2018, "brand": "Land Rover", "color": "silver", "model": "Range Rover", "seats": 7, "mileage": 120290, "variant": "Vogue", "condition": "used", "engine_cc": 2500, "fuel_type": "hybrid", "transmission": "manual"}	7373ab06-3f4a-4058-8d7e-af7a21fa788d	bfb3c9d6-ed86-4d4e-a24d-72258b2820e9	db4bd753-5700-46ab-8059-552640d62621	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
120ee9a9-61e6-4c63-8743-f550f1201247	0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	{"year": 2021, "brand": "Nissan", "color": "blue", "model": "X-Trail", "seats": 7, "mileage": 119059, "condition": "used", "engine_cc": 4000, "fuel_type": "hybrid", "transmission": "manual"}	bf1f20e8-073b-4963-a44f-8f41a0126e96	be32c728-768a-471e-a522-9bbed28dd7e3	\N	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2a5b1749-1eab-4c7e-a38f-2db3acb425c3	0f2abacd-5388-4d16-88ba-19996ab07efc	{"year": 2022, "brand": "Honda", "color": "red", "model": "CR-V", "seats": 7, "mileage": 2395, "variant": "Touring", "condition": "new", "engine_cc": 2500, "fuel_type": "diesel", "transmission": "manual"}	3121b77a-cf02-4776-a3f6-8683a9a3e883	94499369-6cd2-4af5-8077-e8ea09eeec80	4d0da00e-01c1-495a-b130-b5c659dc3192	diesel	new	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8299aa5b-ded5-430f-97b8-133b5bf27d5a	228d2194-7cb3-4797-9cf6-9150f59e4b51	{"year": 2018, "brand": "Jeep", "color": "red", "model": "Grand Cherokee", "seats": 7, "mileage": 86975, "condition": "used", "engine_cc": 4000, "fuel_type": "hybrid", "transmission": "manual"}	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	c8939da5-7463-48b4-b452-feb46a50234a	\N	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
02d4b6cc-8e08-453c-ac1b-abadebe0dd12	f8828552-9e98-4c47-90ac-dfeafef6f259	{"year": 2022, "brand": "Lexus", "color": "black", "model": "RX 350", "seats": 7, "mileage": 82872, "condition": "used", "engine_cc": 3000, "fuel_type": "hybrid", "transmission": "automatic"}	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	f686c84b-896c-49f0-b188-fed009c3aee4	\N	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
a8c2fbee-3b19-4f43-b3c7-64587ea4b10c	34a62384-7311-43f7-9d85-75275232b454	{"year": 2019, "brand": "Porsche", "color": "red", "model": "Cayenne", "seats": 5, "mileage": 94658, "condition": "used", "engine_cc": 1600, "fuel_type": "diesel", "transmission": "automatic"}	1dd5cb73-e65d-4884-97a4-c96ffc94fd83	fcdf28d8-f787-4278-a18e-1e776ed5af07	\N	diesel	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1e3bd406-1c6c-4750-a992-f6d8d901424e	a0f30ae4-e397-4606-ae72-5a45a95a5c33	{"year": 2018, "brand": "Nissan", "color": "white", "model": "X-Trail", "seats": 5, "mileage": 46681, "condition": "used", "engine_cc": 3000, "fuel_type": "hybrid", "transmission": "manual"}	bf1f20e8-073b-4963-a44f-8f41a0126e96	be32c728-768a-471e-a522-9bbed28dd7e3	\N	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
536afbd6-fc16-44fa-b3ee-2680c43a960d	0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	{"year": 2022, "brand": "Honda", "color": "black", "model": "CR-V", "seats": 7, "mileage": 74040, "variant": "Touring", "condition": "used", "engine_cc": 2000, "fuel_type": "hybrid", "transmission": "automatic"}	3121b77a-cf02-4776-a3f6-8683a9a3e883	94499369-6cd2-4af5-8077-e8ea09eeec80	4d0da00e-01c1-495a-b130-b5c659dc3192	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b3c93f03-217c-4024-9ccf-bf1734bb699c	68870b9b-d774-47b3-862d-0c525aade4e0	{"year": 2020, "brand": "Audi", "color": "white", "model": "A4", "seats": 5, "mileage": 29340, "condition": "used", "engine_cc": 2500, "fuel_type": "petrol", "transmission": "automatic"}	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	d5980096-749a-4ef4-89f3-5e2fb56b570c	\N	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
0553c8aa-b931-46b9-9ed6-2c7a35efc7bd	8a1b4752-c8ad-4882-b9e1-40e845cdf053	{"year": 2023, "brand": "Lexus", "color": "white", "model": "RX 350", "seats": 7, "mileage": 4546, "condition": "new", "engine_cc": 2000, "fuel_type": "diesel", "transmission": "manual"}	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	f686c84b-896c-49f0-b188-fed009c3aee4	\N	diesel	new	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15f43ca8-b1ea-4aa0-bd2c-61b910153dde	cff450de-7e28-4ffa-afdc-d8a36a6aeadd	{"year": 2023, "brand": "Hyundai", "color": "white", "model": "Elantra", "seats": 5, "mileage": 150671, "condition": "used", "engine_cc": 2000, "fuel_type": "petrol", "transmission": "manual"}	c9bcc02d-87c4-4717-8ee9-5a7959104e52	1fd78677-c4f9-448f-96ea-2edbd3153ed7	\N	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
ef5383c2-b6b2-4c68-bc3b-29e52d73a07a	b91b906c-199e-4872-8bd7-aa305e61d456	{"year": 2023, "brand": "Kia", "color": "silver", "model": "Cerato", "seats": 5, "mileage": 85965, "variant": "EX", "condition": "used", "engine_cc": 4000, "fuel_type": "hybrid", "transmission": "manual"}	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	c33e502d-3a1d-4bad-8b3c-b00f9a4c73ac	ee71724e-9b6b-4948-9ae4-34d494c7ae35	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
32ef8219-2b6c-4da6-bbda-6c812f57e75e	35b7f9d3-1632-4549-9c32-e00d1ac6b862	{"year": 2022, "brand": "Chevrolet", "color": "black", "model": "Lanos", "seats": 5, "mileage": 132471, "condition": "used", "engine_cc": 2500, "fuel_type": "hybrid", "transmission": "automatic"}	0002d55a-beea-4ca9-9ab7-912f5d625dbe	74a2f759-e372-436d-b30c-14349b315970	\N	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
877b889b-9ba1-4890-bba0-48c287134e16	e069ac39-c738-4586-8629-31e0731e3f91	{"year": 2024, "brand": "Peugeot", "color": "black", "model": "208", "seats": 5, "mileage": 159661, "condition": "used", "engine_cc": 2000, "fuel_type": "petrol", "transmission": "manual"}	9a4722eb-e61a-46a5-8605-42defc479a6f	d772ed47-685a-4383-b965-d989b4e52ae5	\N	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
086a74c8-0d67-42bb-bee8-d3d052198847	f4c6f1bb-adb7-41f4-983a-64676c47e514	{"year": 2021, "brand": "Renault", "color": "silver", "model": "Duster", "seats": 7, "mileage": 13113, "condition": "new", "engine_cc": 2500, "fuel_type": "hybrid", "transmission": "automatic"}	4d28e82a-1aa0-4654-86ca-836324dddb7c	5d18451e-a2fd-4e45-9173-5c27bd3683a2	\N	hybrid	new	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
61e677a9-b764-4137-8e40-2a1a68709e0a	3094a424-7f3d-4719-8d95-9991b9680048	{"year": 2018, "brand": "Mitsubishi", "color": "red", "model": "Eclipse Cross", "seats": 7, "mileage": 143673, "condition": "used", "engine_cc": 2000, "fuel_type": "diesel", "transmission": "automatic"}	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	368fa5bc-5cef-4813-9418-25b4584aaa0d	\N	diesel	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
93a38da3-2a40-4281-b214-579b9ef69b1f	8c77c35d-3969-4fd0-933a-9558cc48fac5	{"year": 2021, "brand": "MG", "color": "silver", "model": "ZS", "seats": 5, "mileage": 42939, "variant": "Luxury", "condition": "used", "engine_cc": 2000, "fuel_type": "diesel", "transmission": "manual"}	01092beb-86ae-4ed5-81f2-efe9eb0fb717	cc9bb9e3-50ef-49d9-a295-686c186e959e	5eb702b3-68cf-4b4d-b8ef-37a23dd3106f	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
ffcd3395-3717-4bfd-93c8-61b6ed23e037	2c7e7e69-b413-4913-b965-00e13fa8f32d	{"year": 2020, "brand": "Mercedes-Benz", "color": "silver", "model": "GLE", "seats": 7, "mileage": 43420, "variant": "AMG", "condition": "used", "engine_cc": 2000, "fuel_type": "diesel", "transmission": "manual"}	ff874e82-8969-4196-aeef-2142b375a108	0ac20c8c-cfe0-4f22-881e-568fc9bd1126	e4ecce3a-7114-48c6-a916-fa75a2558646	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3b4a36e9-3b50-4a1f-a90b-61a7921ac1c7	f52e2c21-9f60-4a9d-9587-28c34be4313d	{"year": 2018, "brand": "Hyundai", "color": "white", "model": "Elantra", "seats": 7, "mileage": 95629, "condition": "used", "engine_cc": 4000, "fuel_type": "diesel", "transmission": "manual"}	c9bcc02d-87c4-4717-8ee9-5a7959104e52	1fd78677-c4f9-448f-96ea-2edbd3153ed7	\N	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
e6422be3-6ae6-4ec5-9b1c-69da548f0518	a702bac0-04c2-4ca6-8642-086500203e18	{"year": 2019, "brand": "BMW", "color": "blue", "model": "X5", "seats": 5, "mileage": 2443, "variant": "M-Sport", "condition": "new", "engine_cc": 2500, "fuel_type": "petrol", "transmission": "automatic"}	021ed729-50a2-46b7-86d2-960eb2f84b38	da8105d9-48bc-4dfb-a32e-4b0ecdb8a413	028c92f2-1f14-4c92-a5d4-0eb1c2544015	petrol	new	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
d6e3696d-ca37-4d84-9812-1648d62f3200	11e3e025-ac43-4186-99c4-e90fce734514	{"year": 2022, "brand": "Toyota", "color": "black", "model": "Fortuner", "seats": 5, "mileage": 60543, "variant": "VXR", "condition": "used", "engine_cc": 3000, "fuel_type": "diesel", "transmission": "manual"}	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	c19f3a78-62d4-4ad4-8004-19196ab8bb85	dd9465a9-020b-498e-b06d-6123bba759bd	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2b02fff3-216f-4ee3-b839-9f74ed7826be	7f5a475c-f641-4130-ad9d-316175ceddd8	{"year": 2024, "brand": "Hyundai", "color": "black", "model": "Tucson", "seats": 5, "mileage": 51833, "variant": "GLS", "condition": "used", "engine_cc": 1600, "fuel_type": "diesel", "transmission": "automatic"}	c9bcc02d-87c4-4717-8ee9-5a7959104e52	c684b989-28a1-41da-85a2-37c4ce13f550	b072c094-b9c4-4326-91c8-7d2500c5a2ed	diesel	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
fa156935-1ce6-4143-94d0-edc8c7819062	37103385-9490-4954-9687-50f8ee9e0a26	{"year": 2019, "brand": "Chevrolet", "color": "white", "model": "Camaro", "seats": 7, "mileage": 133344, "variant": "SS", "condition": "used", "engine_cc": 4000, "fuel_type": "petrol", "transmission": "manual"}	0002d55a-beea-4ca9-9ab7-912f5d625dbe	89f5460c-16d2-4744-9e13-c9af1b0458a1	63c8d26d-5a0c-45be-8cd2-1282047e9de3	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2714ea16-e1cd-4e4c-9ccf-46fd4efb0ec6	dd2a3f4a-84df-49f0-96bc-405d52e30e8b	{"year": 2023, "brand": "Kia", "color": "black", "model": "Cerato", "seats": 5, "mileage": 23824, "variant": "EX", "condition": "used", "engine_cc": 1600, "fuel_type": "hybrid", "transmission": "automatic"}	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	c33e502d-3a1d-4bad-8b3c-b00f9a4c73ac	ee71724e-9b6b-4948-9ae4-34d494c7ae35	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b2727cf0-18d4-47f5-bba8-e25691b85ec4	594f7353-9eeb-4f9d-a91e-402097aa1aa0	{"year": 2022, "brand": "Chevrolet", "color": "silver", "model": "Lanos", "seats": 5, "mileage": 53421, "condition": "used", "engine_cc": 2000, "fuel_type": "hybrid", "transmission": "automatic"}	0002d55a-beea-4ca9-9ab7-912f5d625dbe	74a2f759-e372-436d-b30c-14349b315970	\N	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
bfd243b4-bc01-475c-bb42-fa03ee6a5ac3	4e8d01e8-dddd-4ba0-b88b-b0068d47ac54	{"year": 2023, "brand": "Peugeot", "color": "white", "model": "208", "seats": 7, "mileage": 139256, "condition": "used", "engine_cc": 4000, "fuel_type": "hybrid", "transmission": "automatic"}	9a4722eb-e61a-46a5-8605-42defc479a6f	d772ed47-685a-4383-b965-d989b4e52ae5	\N	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
e0da4e7e-f3c6-45c9-ae9d-5c21a0b74552	adf38505-f2de-4fdd-a78e-4020df43ce5b	{"year": 2019, "brand": "Mitsubishi", "color": "silver", "model": "Eclipse Cross", "seats": 7, "mileage": 104126, "condition": "used", "engine_cc": 2000, "fuel_type": "hybrid", "transmission": "automatic"}	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	368fa5bc-5cef-4813-9418-25b4584aaa0d	\N	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
d28a6272-83ec-4dd1-b4ac-796552b51b71	8c7883b1-f456-4a6a-8f42-18c0316a9ef7	{"year": 2022, "brand": "MG", "color": "black", "model": "ZS", "seats": 5, "mileage": 36357, "variant": "Luxury", "condition": "used", "engine_cc": 4000, "fuel_type": "hybrid", "transmission": "manual"}	01092beb-86ae-4ed5-81f2-efe9eb0fb717	cc9bb9e3-50ef-49d9-a295-686c186e959e	5eb702b3-68cf-4b4d-b8ef-37a23dd3106f	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
cb76a674-ffa3-498f-b04f-43740059739f	5cba9a8c-3a15-4e7c-92ae-14de899b0403	{"year": 2022, "brand": "BMW", "color": "red", "model": "330i", "seats": 5, "mileage": 54888, "variant": "M Package", "condition": "used", "engine_cc": 1600, "fuel_type": "petrol", "transmission": "automatic"}	021ed729-50a2-46b7-86d2-960eb2f84b38	b454a2a0-40e5-4311-abb8-c3fb426b292e	6d56a6fc-187b-4763-ad71-e2e1e03b661b	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2bd3b1e0-5e05-4fce-a2f3-f37f447ec881	ba60c889-76e4-4635-9a59-0ed305f1043e	{"year": 2022, "brand": "Mercedes-Benz", "color": "red", "model": "GLE", "seats": 7, "mileage": 86812, "variant": "AMG", "condition": "used", "engine_cc": 2000, "fuel_type": "hybrid", "transmission": "manual"}	ff874e82-8969-4196-aeef-2142b375a108	0ac20c8c-cfe0-4f22-881e-568fc9bd1126	e4ecce3a-7114-48c6-a916-fa75a2558646	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
c8f76049-1015-437f-9fd9-6c01ff984740	320b6f96-0528-4430-9486-842cd3c10290	{"area": 528, "view": "street", "floor": 15, "rooms": 5, "compound": true, "bathrooms": 2, "finishing": "finished", "furnished": false, "offer_type": "sale", "delivery_date": "Q4 2027", "property_type": "apartment", "building_age_years": 9, "maintenance_per_year": 19300}	\N	\N	\N	\N	\N	\N	\N	apartment	finished	\N	\N	\N	6097cee0-c9fb-4d27-941f-85c034ec789c	6ee9e3e2-72e5-4837-b5a6-fd3bc88d1ad2	\N	\N	\N	\N	\N	\N	\N
cba0484a-54e1-47bf-a2f7-7096d1dfc4f2	83bd6cf4-667f-46a9-9136-42841beb0ddd	{"area": 318, "view": "pool", "floor": 4, "rooms": 1, "compound": true, "bathrooms": 1, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Q4 2027", "property_type": "villa", "building_age_years": 0, "maintenance_per_year": 49441}	\N	\N	\N	\N	\N	\N	\N	villa	semi_finished	\N	\N	\N	33ee14cb-bcc0-4daf-b93a-823bd29c5a22	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
d33d9909-7c5e-4827-9fd8-c214157fe339	956f7f0c-4c49-4849-8efc-1056cd1e46a7	{"area": 107, "view": "garden", "floor": 5, "rooms": 6, "compound": true, "bathrooms": 3, "finishing": "core_shell", "furnished": true, "offer_type": "rent", "delivery_date": "Q2 2027", "property_type": "penthouse", "building_age_years": 11, "maintenance_per_year": 26565}	\N	\N	\N	\N	\N	\N	\N	penthouse	core_shell	\N	\N	\N	61d04884-0f14-427c-8f46-db591f317dc8	a75fb52b-8d59-4a19-aa8a-48bf80fceec9	\N	\N	\N	\N	\N	\N	\N
5511ad45-3bca-45bf-a4b9-2f0faf0d9fbd	7e2e36ae-710b-4f01-b415-163004df50d5	{"area": 275, "view": "nile", "floor": 1, "rooms": 4, "compound": true, "bathrooms": 2, "finishing": "super_lux", "furnished": false, "offer_type": "sale", "delivery_date": "Q1 2027", "property_type": "studio", "building_age_years": 3, "maintenance_per_year": 44547}	\N	\N	\N	\N	\N	\N	\N	studio	super_lux	\N	\N	\N	133865ea-80c3-4043-9291-6bc7d55c0384	8fe2e71f-4c47-48bb-92fd-d0d68e560aca	\N	\N	\N	\N	\N	\N	\N
3ad4b45e-a8de-4800-8085-670d5b919f43	3f8579ca-1469-4fff-8dd0-867327549e2a	{"area": 538, "view": "street", "floor": 12, "rooms": 4, "compound": true, "bathrooms": 2, "finishing": "super_lux", "furnished": true, "offer_type": "rent", "delivery_date": "Ready to move", "property_type": "office", "building_age_years": 15, "maintenance_per_year": 47219}	\N	\N	\N	\N	\N	\N	\N	office	super_lux	\N	\N	\N	999b4b99-c31d-45b8-afba-290cf802d617	8fe2e71f-4c47-48bb-92fd-d0d68e560aca	\N	\N	\N	\N	\N	\N	\N
c05ec6ad-3af8-4d0b-abdc-e14360701a0b	5d5f76f9-8200-4cfb-b85f-eb3167ebe59c	{"area": 212, "view": "garden", "floor": 12, "rooms": 6, "compound": true, "bathrooms": 3, "finishing": "finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "shop", "building_age_years": 8, "maintenance_per_year": 49228}	\N	\N	\N	\N	\N	\N	\N	shop	finished	\N	\N	\N	ace48cdb-39c1-4f39-afff-3d12b9e884e8	6ee9e3e2-72e5-4837-b5a6-fd3bc88d1ad2	\N	\N	\N	\N	\N	\N	\N
514a9cd3-6d8f-4757-8949-ac6184edb87c	e104a255-93b8-4ce3-b2a2-16ed2dc22047	{"area": 538, "view": "nile", "floor": 1, "rooms": 3, "compound": false, "bathrooms": 1, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "twinhouse", "building_age_years": 8, "maintenance_per_year": 40611}	\N	\N	\N	\N	\N	\N	\N	twinhouse	semi_finished	\N	\N	\N	80a8e3b8-848e-44fd-b4a0-89b286d38f80	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
cde1eb1b-c234-4638-baec-229c3b51f4ec	1d10ee4e-0ea6-4334-bd44-cb11c2398322	{"year": 2024, "brand": "Ford", "color": "black", "model": "Mustang", "seats": 5, "mileage": 155123, "variant": "GT", "condition": "used", "engine_cc": 4000, "fuel_type": "petrol", "transmission": "automatic"}	e6384217-6e92-41f6-885a-7a26fa24d51b	98170462-8262-4f5d-a32f-0057d2b93109	c719c747-8c5d-4a7a-8f48-5d3233b476eb	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7b89003a-6be3-46ea-9446-c10979ad7e42	b38f66dc-3e8a-4e27-b878-87b9ff283a56	{"year": 2024, "brand": "Land Rover", "color": "white", "model": "Range Rover", "seats": 5, "mileage": 144679, "variant": "Vogue", "condition": "used", "engine_cc": 1600, "fuel_type": "petrol", "transmission": "manual"}	7373ab06-3f4a-4058-8d7e-af7a21fa788d	bfb3c9d6-ed86-4d4e-a24d-72258b2820e9	db4bd753-5700-46ab-8059-552640d62621	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
cc7f32ec-7cd4-497e-a2b0-e43fab18487a	bd1f899c-90a2-41d6-972f-a40762374777	{"year": 2023, "brand": "Toyota", "color": "silver", "model": "Corolla", "seats": 7, "mileage": 10532, "variant": "XLI", "condition": "new", "engine_cc": 3000, "fuel_type": "hybrid", "transmission": "automatic"}	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	c5e8c8af-9b5f-490b-af7d-5bdec92048f2	a09d6bbc-0c2b-42a9-a623-42f5b9908abc	hybrid	new	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
e1f32645-d458-425f-a2f2-c6089d492385	4c73b269-e275-4bd2-898f-39a018826814	{"year": 2018, "brand": "BMW", "color": "black", "model": "330i", "seats": 7, "mileage": 93528, "variant": "M Package", "condition": "used", "engine_cc": 1600, "fuel_type": "hybrid", "transmission": "manual"}	021ed729-50a2-46b7-86d2-960eb2f84b38	b454a2a0-40e5-4311-abb8-c3fb426b292e	6d56a6fc-187b-4763-ad71-e2e1e03b661b	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2346702f-d5fb-4657-89a5-f096e33f2b58	c3996838-428c-4cef-9199-176dd9d66848	{"year": 2021, "brand": "BMW", "color": "red", "model": "X5", "seats": 7, "mileage": 58261, "variant": "M-Sport", "condition": "used", "engine_cc": 1600, "fuel_type": "hybrid", "transmission": "automatic"}	021ed729-50a2-46b7-86d2-960eb2f84b38	da8105d9-48bc-4dfb-a32e-4b0ecdb8a413	028c92f2-1f14-4c92-a5d4-0eb1c2544015	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9439c42b-c786-442e-8543-6f7e8df8af03	02ca95ed-3f23-4485-86bb-e822d2d20b9d	{"area": 433, "view": "nile", "floor": 2, "rooms": 5, "compound": false, "bathrooms": 2, "finishing": "core_shell", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "villa", "building_age_years": 13, "maintenance_per_year": 22136}	\N	\N	\N	\N	\N	\N	\N	villa	core_shell	\N	\N	\N	33ee14cb-bcc0-4daf-b93a-823bd29c5a22	a75fb52b-8d59-4a19-aa8a-48bf80fceec9	\N	\N	\N	\N	\N	\N	\N
1b9ecfa7-15a2-4a83-9e26-be98f12b1361	af29f0a0-62b7-48c4-8995-ae58a192b39f	{"area": 497, "view": "pool", "floor": 6, "rooms": 2, "compound": false, "bathrooms": 1, "finishing": "finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "apartment", "building_age_years": 4, "maintenance_per_year": 23943}	\N	\N	\N	\N	\N	\N	\N	apartment	finished	\N	\N	\N	6097cee0-c9fb-4d27-941f-85c034ec789c	6ee9e3e2-72e5-4837-b5a6-fd3bc88d1ad2	\N	\N	\N	\N	\N	\N	\N
4323e9dd-4667-4e79-885c-129b5b34d0b8	9322a87e-6899-4b8a-8399-280801afaff0	{"area": 569, "view": "street", "floor": 16, "rooms": 3, "compound": false, "bathrooms": 1, "finishing": "core_shell", "furnished": true, "offer_type": "rent", "delivery_date": "Ready to move", "property_type": "duplex", "building_age_years": 14, "maintenance_per_year": 44510}	\N	\N	\N	\N	\N	\N	\N	duplex	core_shell	\N	\N	\N	7326d47c-4060-48c9-ac48-12c790e78832	a75fb52b-8d59-4a19-aa8a-48bf80fceec9	\N	\N	\N	\N	\N	\N	\N
9621fc61-665a-4c1c-8440-c0587da9d82f	37159531-b803-4b62-a764-209cae61eb8a	{"area": 292, "view": "sea", "floor": 12, "rooms": 2, "compound": false, "bathrooms": 1, "finishing": "super_lux", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "studio", "building_age_years": 8, "maintenance_per_year": 31848}	\N	\N	\N	\N	\N	\N	\N	studio	super_lux	\N	\N	\N	133865ea-80c3-4043-9291-6bc7d55c0384	8fe2e71f-4c47-48bb-92fd-d0d68e560aca	\N	\N	\N	\N	\N	\N	\N
83df516a-dc47-467f-87af-e616f019cee4	7263ec34-aa0e-46ee-9603-dc3c7e555089	{"area_sqm": 2183, "capacity": "2000 kg/hr", "power_kw": 1750, "condition": "good", "infrastructure": "all_utilities", "industrial_type": "land", "available_licenses": false, "included_equipment": true, "year_of_manufacture": 2020}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	land	\N	\N	\N	\N	97ec9344-d608-462e-b088-050b678b251c	\N	\N	\N	\N	\N
548505bb-f194-4214-a40c-fdcf497671c6	a0705f6e-b0e0-43fe-8352-90816e14fc59	{"area_sqm": 9975, "capacity": "10 tons/day", "industry": "food", "power_kw": 691, "condition": "very_good", "infrastructure": "water", "industrial_type": "factory", "available_licenses": true, "included_equipment": false, "year_of_manufacture": 2022}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	factory	food	\N	\N	\N	d6911aa7-ba35-459f-b8e9-3f2dfe9ddf1d	3ef4bc92-f961-4388-9d0c-39ed16a9b37a	\N	\N	\N	\N
250b3500-f1c5-48ea-9873-5f33a0b69049	ea279ba5-756f-456d-91d8-534388fb648a	{"area_sqm": 4720, "capacity": "2000 kg/hr", "industry": "textile", "power_kw": 1991, "condition": "good", "infrastructure": "water", "industrial_type": "production_line", "available_licenses": true, "included_equipment": true, "year_of_manufacture": 2011}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	production_line	textile	\N	\N	\N	6d2e541d-fcfc-4547-abf9-9f9dab6f5c18	a0c78644-eddf-48df-9c76-e0166c4fb457	\N	\N	\N	\N
d3b6bd89-507c-46aa-871f-82ee58743f1c	9150cc73-01b3-47fe-a15c-042af82ed4a3	{"area_sqm": 8575, "capacity": "10 tons/day", "power_kw": 880, "condition": "good", "infrastructure": "electricity_3phase", "industrial_type": "warehouse", "available_licenses": false, "included_equipment": false, "year_of_manufacture": 2016}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	warehouse	\N	\N	\N	\N	b5128ea8-3618-45d2-97de-13840dd2c639	\N	\N	\N	\N	\N
7cce77cc-f634-4f68-9368-e6f9edb9903f	af09ae88-c0da-4079-a0f4-7aa7407ac1fc	{"area_sqm": 3416, "capacity": "2000 kg/hr", "power_kw": 1274, "condition": "needs_maintenance", "infrastructure": "all_utilities", "industrial_type": "machine", "available_licenses": true, "included_equipment": true, "year_of_manufacture": 2018}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	machine	\N	\N	\N	\N	03f6d74b-53e5-45f7-bc42-82242ae88163	\N	\N	\N	\N	\N
b3992ec1-8dad-44ef-a462-8f148704ddd3	925a9409-46ca-4049-a382-97f840540c9d	{"area_sqm": 5889, "capacity": "500 units/hr", "industry": "engineering", "power_kw": 1016, "condition": "excellent", "infrastructure": "water", "industrial_type": "machine", "available_licenses": true, "included_equipment": false, "year_of_manufacture": 2022}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	machine	engineering	\N	\N	\N	03f6d74b-53e5-45f7-bc42-82242ae88163	23c701c7-83da-403b-9cdb-173b235fccab	\N	\N	\N	\N
80ed9f85-3965-42c5-84df-d4c899d59d27	8c21de11-dacc-42d7-b52b-2413d53bb5ae	{"area_sqm": 4101, "capacity": "500 units/hr", "industry": "beverage", "power_kw": 643, "condition": "needs_maintenance", "infrastructure": "all_utilities", "industrial_type": "factory", "available_licenses": true, "included_equipment": false, "year_of_manufacture": 2012}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	factory	beverage	\N	\N	\N	d6911aa7-ba35-459f-b8e9-3f2dfe9ddf1d	f1ebee51-9bae-4382-8a13-d534b3b31295	\N	\N	\N	\N
90387db7-a980-43e9-8cbf-9d4173852620	e50a3b9d-cb4f-49df-bb51-a7a0ae37a8da	{"area_sqm": 1928, "capacity": "1000 units/hr", "power_kw": 97, "condition": "needs_maintenance", "infrastructure": "all_utilities", "available_licenses": true, "included_equipment": true, "year_of_manufacture": 2014}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
53ca9290-848e-485e-aaea-4252b74c58e1	c5a76c3d-0b88-4859-b6d8-e557ebfaca65	{"area_sqm": 2796, "capacity": "2000 kg/hr", "industry": "engineering", "power_kw": 504, "condition": "very_good", "infrastructure": "all_utilities", "industrial_type": "factory", "available_licenses": false, "included_equipment": false, "year_of_manufacture": 2016}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	factory	engineering	\N	\N	\N	d6911aa7-ba35-459f-b8e9-3f2dfe9ddf1d	23c701c7-83da-403b-9cdb-173b235fccab	\N	\N	\N	\N
7a3f228a-00bc-48d7-9d17-ea33c9e8fea5	67ce4494-36b1-42c3-af3e-fe2e6b4872d3	{"area_sqm": 8603, "capacity": "500 units/hr", "industry": "pharmaceutical", "power_kw": 539, "condition": "needs_maintenance", "infrastructure": "electricity_3phase", "industrial_type": "production_line", "available_licenses": true, "included_equipment": true, "year_of_manufacture": 2012}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	production_line	pharmaceutical	\N	\N	\N	6d2e541d-fcfc-4547-abf9-9f9dab6f5c18	d133db38-e6ca-40a2-bd99-5c97b492f05f	\N	\N	\N	\N
d2bc148a-2777-4418-9d4c-36ba3d57288b	29113513-b741-470e-847a-57ff621f0f19	{"year": 2021, "brand": "Mercedes-Benz", "color": "black", "model": "C-Class", "seats": 5, "mileage": 51854, "variant": "C200", "condition": "used", "engine_cc": 2500, "fuel_type": "diesel", "transmission": "manual"}	ff874e82-8969-4196-aeef-2142b375a108	cce6d52c-efed-476c-adec-a830439434d0	4526f117-c0e7-4f51-95ea-8e765e31ddfb	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2a067380-d140-4ca4-940f-4b92add017c3	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	{"year": 2024, "brand": "Toyota", "color": "red", "model": "Fortuner", "seats": 7, "mileage": 78114, "variant": "VXR", "condition": "used", "engine_cc": 1600, "fuel_type": "hybrid", "transmission": "manual"}	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	c19f3a78-62d4-4ad4-8004-19196ab8bb85	dd9465a9-020b-498e-b06d-6123bba759bd	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2350a35b-c6c6-4d79-912f-5af49d502cfe	59f4e92b-92ff-461f-ae08-dc2be8fbff30	{"year": 2020, "brand": "Hyundai", "color": "red", "model": "Tucson", "seats": 5, "mileage": 37497, "variant": "GLS", "condition": "used", "engine_cc": 1600, "fuel_type": "hybrid", "transmission": "manual"}	c9bcc02d-87c4-4717-8ee9-5a7959104e52	c684b989-28a1-41da-85a2-37c4ce13f550	b072c094-b9c4-4326-91c8-7d2500c5a2ed	hybrid	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
fcaf4e9a-e45a-4bc4-b9fd-c7280a623f77	c56c0b52-50c2-4459-b4c5-19d2c401aaf0	{"year": 2019, "brand": "Kia", "color": "black", "model": "Sportage", "seats": 5, "mileage": 29414, "variant": "Luxury", "condition": "used", "engine_cc": 2000, "fuel_type": "petrol", "transmission": "automatic"}	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	05de1c51-957d-483e-b96a-640249f3919d	afd59079-ad8d-4bdb-ae37-b09a2fdcd6c1	petrol	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
81d31429-8a35-42f4-ac39-33a05f31c86a	80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	{"year": 2023, "brand": "Chevrolet", "color": "white", "model": "Camaro", "seats": 5, "mileage": 21312, "variant": "SS", "condition": "used", "engine_cc": 2500, "fuel_type": "diesel", "transmission": "manual"}	0002d55a-beea-4ca9-9ab7-912f5d625dbe	89f5460c-16d2-4744-9e13-c9af1b0458a1	63c8d26d-5a0c-45be-8cd2-1282047e9de3	diesel	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
281a4829-ef38-429f-a4fe-f362a5ea6a75	c5d495c4-7f15-4785-9ceb-444109eae4ca	{"year": 2022, "brand": "Audi", "color": "white", "model": "A4", "seats": 7, "mileage": 131683, "condition": "used", "engine_cc": 1600, "fuel_type": "diesel", "transmission": "automatic"}	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	d5980096-749a-4ef4-89f3-5e2fb56b570c	\N	diesel	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
00d4cb85-7be2-4c8b-8da5-d92008b1599d	bb9758f5-7491-4626-8264-f9b36e781015	{"year": 2023, "brand": "Toyota", "color": "silver", "model": "Corolla", "seats": 7, "mileage": 25884, "variant": "XLI", "condition": "used", "engine_cc": 2500, "fuel_type": "hybrid", "transmission": "automatic"}	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	c5e8c8af-9b5f-490b-af7d-5bdec92048f2	a09d6bbc-0c2b-42a9-a623-42f5b9908abc	hybrid	used	\N	automatic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
bf0657eb-8b43-4b58-84c3-3940c7874ef7	7ca26c99-aec3-4064-89c6-6acbf346ba9a	{"year": 2019, "brand": "Renault", "color": "red", "model": "Duster", "seats": 7, "mileage": 149678, "condition": "used", "engine_cc": 1600, "fuel_type": "petrol", "transmission": "manual"}	4d28e82a-1aa0-4654-86ca-836324dddb7c	5d18451e-a2fd-4e45-9173-5c27bd3683a2	\N	petrol	used	\N	manual	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
35908d26-456b-4ce1-926a-24bf638edcfb	24f1f647-642a-4a4f-b685-8f6cc62ca73a	{"area": 505, "view": "nile", "floor": 3, "rooms": 6, "compound": true, "bathrooms": 3, "finishing": "semi_finished", "furnished": true, "offer_type": "rent", "delivery_date": "Q2 2027", "property_type": "duplex", "building_age_years": 9, "maintenance_per_year": 20061}	\N	\N	\N	\N	\N	\N	\N	duplex	semi_finished	\N	\N	\N	7326d47c-4060-48c9-ac48-12c790e78832	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
4a1af56b-f085-4f9d-a463-29e193756853	eb1e5cc7-3431-4e72-9563-be6c520c561c	{"area": 530, "view": "sea", "floor": 18, "rooms": 2, "compound": true, "bathrooms": 1, "finishing": "semi_finished", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "chalet", "building_age_years": 3, "maintenance_per_year": 31868}	\N	\N	\N	\N	\N	\N	\N	chalet	semi_finished	\N	\N	\N	130cafd9-09be-4b07-b74c-0352dc7de103	eca44166-731d-49de-b6cc-d3b71b4116df	\N	\N	\N	\N	\N	\N	\N
1c9f402d-328c-4ee0-9a62-aa265c720d13	5531056b-c81d-4971-b026-fbdc40516ee8	{"area": 445, "view": "sea", "floor": 14, "rooms": 6, "compound": false, "bathrooms": 3, "finishing": "finished", "furnished": true, "offer_type": "rent", "delivery_date": "Ready to move", "property_type": "apartment", "building_age_years": 2, "maintenance_per_year": 15329}	\N	\N	\N	\N	\N	\N	\N	apartment	finished	\N	\N	\N	6097cee0-c9fb-4d27-941f-85c034ec789c	6ee9e3e2-72e5-4837-b5a6-fd3bc88d1ad2	\N	\N	\N	\N	\N	\N	\N
313143fd-d4a6-4718-9716-1ebeb8968730	ee9c255d-593a-404e-ba7c-54f76e5c537c	{"area": 98, "view": "street", "floor": 12, "rooms": 4, "compound": false, "bathrooms": 2, "finishing": "super_lux", "furnished": false, "offer_type": "sale", "delivery_date": "Ready to move", "property_type": "penthouse", "building_age_years": 0, "maintenance_per_year": 20298}	\N	\N	\N	\N	\N	\N	\N	penthouse	super_lux	\N	\N	\N	61d04884-0f14-427c-8f46-db591f317dc8	8fe2e71f-4c47-48bb-92fd-d0d68e560aca	\N	\N	\N	\N	\N	\N	\N
97a5e71a-8b8f-4360-bb0c-ceaaf643e9ed	40de3002-ada5-468e-b583-788cfbeb2a35	{"area_sqm": 9384, "capacity": "5000m²", "industry": "plastic", "power_kw": 545, "condition": "needs_maintenance", "infrastructure": "water", "industrial_type": "production_line", "available_licenses": false, "included_equipment": true, "year_of_manufacture": 2018}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	production_line	plastic	\N	\N	\N	6d2e541d-fcfc-4547-abf9-9f9dab6f5c18	1bc39352-fc2c-46b8-9209-f96b46794ab6	\N	\N	\N	\N
b4b1717f-c3f5-45c1-91e1-d3b66077a624	d625d165-7501-4c66-9601-fea4f5c5e94a	{"area_sqm": 8570, "capacity": "5000m²", "power_kw": 1457, "condition": "very_good", "infrastructure": "all_utilities", "industrial_type": "machine", "available_licenses": true, "included_equipment": false, "year_of_manufacture": 2017}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	machine	\N	\N	\N	\N	03f6d74b-53e5-45f7-bc42-82242ae88163	\N	\N	\N	\N	\N
\.


--
-- Data for Name: listing_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_comments (id, listing_id, author_id, parent_id, body, created_at) FROM stdin;
\.


--
-- Data for Name: listing_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_links (id, from_listing_id, to_listing_id, relation, created_at) FROM stdin;
ef3835e9-a0df-4c4b-818b-afe526c64a56	a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	feeds_into	2026-07-18 21:27:21.034611
799a4f4e-d931-44e4-ae62-8e3ee95629ae	ce85c9c5-65f2-4876-b98c-f11d7f183b25	a89eab67-0e52-408d-8887-03d24cd3886d	feeds_into	2026-07-18 21:27:21.037705
fe0c438f-4f48-4e86-95d8-bc5364a8aaeb	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	d6ab50a9-fc95-4d3b-9959-b66badab140f	part_of	2026-07-18 21:27:21.041166
0c47da7f-5d6c-4c36-9d2e-8470a5418cc4	a89eab67-0e52-408d-8887-03d24cd3886d	d6ab50a9-fc95-4d3b-9959-b66badab140f	part_of	2026-07-18 21:27:21.044307
334d4b29-2e75-463b-a677-49acd08e7e32	d6ab50a9-fc95-4d3b-9959-b66badab140f	1e9b6e89-66ff-460b-a11f-bfa9d27e48d0	part_of	2026-07-18 21:27:21.047891
ecb815bd-bb1c-4ffc-ba1b-3de60a332cb8	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	a89eab67-0e52-408d-8887-03d24cd3886d	compatible_with	2026-07-18 21:27:21.051161
\.


--
-- Data for Name: listing_media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_media (id, listing_id, type, url, thumbnail_url, is_thumbnail, sort_order) FROM stdin;
fcc826f1-0a6f-4e15-ab19-5c5d8a9e17df	ad7793eb-66af-4039-8267-c59488026824	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
d237bf35-6519-41bb-b549-7b1495cd013e	ad7793eb-66af-4039-8267-c59488026824	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
f2d5efa7-fdfa-46d3-a267-70b3f42c7c57	fc570df0-e974-4c5a-abbe-d2df329e8ae3	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
969ad032-fdb7-420e-b855-cb1ee4e10f5e	fc570df0-e974-4c5a-abbe-d2df329e8ae3	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	f	1
1c251785-aa5e-493d-a5c3-c985691f9b8c	afb9180b-6d35-4e8f-9858-897749ccb3d3	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
db6bafa2-287c-47df-8ef0-1f60eaf9ce96	afb9180b-6d35-4e8f-9858-897749ccb3d3	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
5d324692-4085-4bf2-9243-bf078d059e9f	5c396975-c3f2-4970-b281-f8db7cfca1bf	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
8bac5f82-68b2-4d6f-95be-86cba09fc1ab	5c396975-c3f2-4970-b281-f8db7cfca1bf	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
1fa4b969-d2b6-4fb3-8a61-e4bf12dca1b4	25130e61-f0ac-4a2f-ab46-91ce6f54649f	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
0827f950-6ebe-4b30-aeb8-eccf8b91dc0b	25130e61-f0ac-4a2f-ab46-91ce6f54649f	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
79731af3-abdd-4b11-bfc1-a658de933063	85c4c348-d4f0-44ed-b814-60c0a881559e	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	t	0
5f7015d8-fd79-4957-ba22-e534910c4b7d	85c4c348-d4f0-44ed-b814-60c0a881559e	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
baa87d3d-21a4-4a76-8074-f53c504b7eaf	f015cb68-23c1-45ac-8241-280405b54dcc	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
f5fa5203-0c1f-4c99-af09-07a4cc8038f2	f015cb68-23c1-45ac-8241-280405b54dcc	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
ae60918b-4f7c-42b0-a97a-0efa82510bbc	30cc6cc4-25df-481a-87a6-f0a2e4e82618	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
5c2b40d9-cbfb-4da9-8916-539f19d482f6	30cc6cc4-25df-481a-87a6-f0a2e4e82618	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
bb707234-2dcd-49e7-9a2a-4ee9632857a1	8ee87c30-45fd-451a-b437-c51e915da497	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
bb691c14-eac1-4367-87c8-c0c34eaa287d	8ee87c30-45fd-451a-b437-c51e915da497	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
cc25a919-2ebd-4321-aa1f-2e0e0b627375	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
170a6bdf-f63c-40a4-b097-4ec68b70699c	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
67d1c631-8027-4c8f-bfdd-861588810057	f4b561b7-113d-4938-8330-e527db01404c	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
1e582cb6-88f2-4c1e-9718-e850b1e020d8	f4b561b7-113d-4938-8330-e527db01404c	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
7134d040-c351-4c52-a514-634f92fcf4ba	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	t	0
dee7b685-b865-4b1c-8fd6-e3a02221c562	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
18f37af9-1ebc-47fc-b8da-a28272fc4fb7	38b5547f-3272-4752-adef-419278a5a379	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
829cc6bc-2701-4610-b146-241593e6ae69	38b5547f-3272-4752-adef-419278a5a379	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
b4d58078-896d-4295-8d88-20227fe8e2e2	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
b5f6943e-a1b3-4c94-a005-93c69da42a03	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
760979fb-021d-443a-96c4-db68d05d9e18	322f1d1d-f418-4a26-8e60-45d8c45858a9	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
45b60471-c700-469a-8509-28a3e5dc6f52	322f1d1d-f418-4a26-8e60-45d8c45858a9	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
77dbf16d-5f8f-467e-8eef-bf2a81e42668	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
73df70a3-68bc-4570-aa21-fa41353479a5	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
0f1878ba-4bec-42a7-91ba-eef40e23b14f	da4ea6a9-a539-457f-ab70-5e143be46366	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	t	0
13084620-5f04-49d6-80b7-f3af81e89551	da4ea6a9-a539-457f-ab70-5e143be46366	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
c85a1603-59ac-42d9-98f5-5df2f039576e	dfa4da74-d198-413d-828c-f629a7b50189	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	t	0
9210eff0-b365-4e83-91f2-c0eaa34a8547	dfa4da74-d198-413d-828c-f629a7b50189	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
59684b5c-7c75-45ae-8636-54e154d33ea5	ccc3c757-0782-4a1f-b2ac-31d59a9b307d	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
9b307c60-b28a-40be-b7f4-728479b5fdac	ccc3c757-0782-4a1f-b2ac-31d59a9b307d	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
5bceb92c-7d6f-4b0c-81bc-f217cca2c228	3086a988-b6a0-4e15-ab43-c09b98faafa7	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	t	0
a151ebe8-4d67-4b6b-b232-d5bde40ca39f	3086a988-b6a0-4e15-ab43-c09b98faafa7	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
b297a85e-5f58-4f7d-acda-6d8ceaeed6c2	9030afe9-63c8-4d9d-bac1-3dd49f4429e0	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
d6200edd-cc69-410c-9fe4-ea87197b1e28	9030afe9-63c8-4d9d-bac1-3dd49f4429e0	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
799cb385-05b4-4dc7-beef-2eede48789ec	afdc4e90-2ad7-49e5-838c-3fbbee033f3d	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
1025dbb9-4dee-499c-ad24-4d0c00349b54	afdc4e90-2ad7-49e5-838c-3fbbee033f3d	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	f	1
7d1b9d34-1c35-469e-975d-02d9efba0db0	09c8183b-d75c-4fad-ab84-55955aab44e2	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
1a972786-a332-4f50-bd34-be4523949d04	09c8183b-d75c-4fad-ab84-55955aab44e2	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
5e3035de-8b47-4fa8-b270-7e4ae8b66a9c	55850d32-1a17-48c5-9363-a58459046358	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
0f469131-ec98-4973-a667-0fec14a4d36c	55850d32-1a17-48c5-9363-a58459046358	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
246a8d49-8d32-42cb-b4f5-ebbde9ee2904	b8677ab7-9b44-4c7a-bc7c-1bd54ecaa5ca	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
1ee37861-2901-4b11-8206-3336c35652c3	b8677ab7-9b44-4c7a-bc7c-1bd54ecaa5ca	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
d867dd35-67e0-49e3-b250-45b805f52d7f	7adfddc0-5f2d-4e3a-823c-7ca55388ee69	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	t	0
9da388a8-15a4-416f-9094-b6530a47a124	7adfddc0-5f2d-4e3a-823c-7ca55388ee69	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	f	1
6e7ae537-8e7c-4d00-a0bf-b1c4b838c5e2	8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	t	0
e654b678-6c9e-4012-84b0-af0f1b188a4d	8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
90e63ebc-c03d-4f0d-b025-0b63844ffa86	bed7ae5c-ed17-42e2-8ba4-747f178c546c	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
2de335d9-16da-4308-99b8-7ee755d23f98	bed7ae5c-ed17-42e2-8ba4-747f178c546c	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	f	1
bd4d724b-d63f-42e7-ad85-2e92a43f4e58	7294796b-3884-4742-abee-d13b457c610b	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
127a6070-b968-4fb1-9cb9-9c371a65e898	7294796b-3884-4742-abee-d13b457c610b	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
0d259898-484a-48a4-8cd7-444edf5790a6	b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	t	0
0ddb037a-a9fc-4f3a-b18f-4d8b6bff4249	b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	f	1
7e1e8fa2-84df-410d-848b-836673dbe444	9f249352-cd48-4c1d-b238-ca2a015a6f20	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
8096a572-6de9-47f8-be7d-0a6d252d9c8c	9f249352-cd48-4c1d-b238-ca2a015a6f20	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	f	1
ac578c03-b168-4a9c-8304-29c1c7e74ef4	b7537c25-ddd0-4394-8e12-08015def429c	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	t	0
7a74919b-513b-414e-85f3-ed8e6e6ec103	b7537c25-ddd0-4394-8e12-08015def429c	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	f	1
4fffa856-9343-45f2-a46b-5f09592930aa	5ad12c3c-5a96-4a2b-89a4-566454a6869a	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	t	0
e497d9a6-d466-4513-9f64-f62fc3f3d920	5ad12c3c-5a96-4a2b-89a4-566454a6869a	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	f	1
99bc83bc-8051-41d9-bf97-5b2689fb4b3b	f7fc3936-4bc1-4375-b8c2-c173126959ea	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
5d5867df-c40f-47b9-8e15-b98e91bd4d4d	f7fc3936-4bc1-4375-b8c2-c173126959ea	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	f	1
a6842059-12cc-42e1-ba51-39bfbc62fe6f	c9e5c75d-ac07-4dcf-a123-fea99cca404b	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	t	0
5c088240-e1e1-435f-ad8a-cdbc93194889	c9e5c75d-ac07-4dcf-a123-fea99cca404b	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
8f96aee0-e07b-48ee-82e1-2cdd887e345c	58002df9-b711-4713-8047-f828c50d6718	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
3802ff86-a793-4956-8d83-ff5a79fc3bdb	58002df9-b711-4713-8047-f828c50d6718	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	f	1
060fdadd-069c-4461-bf5b-7f2a42155812	906b9bd8-d0ca-4a6f-aec9-915686f8c48b	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	t	0
42804213-d444-458c-b372-bc84d0b85a3d	906b9bd8-d0ca-4a6f-aec9-915686f8c48b	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	f	1
46f931fe-e221-4368-a99c-b546bbed2f1b	20644d0f-152c-4e29-9092-c14238b4a261	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
d85ce6e1-55a3-428c-9f89-8d1a67e8cc99	20644d0f-152c-4e29-9092-c14238b4a261	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	f	1
8d3dd841-826e-4284-8b96-64be3da237cd	25a613fc-b24c-48c5-9dda-acf3c02a3542	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	t	0
877c389f-bb4f-43eb-a5f3-522863ebd93d	25a613fc-b24c-48c5-9dda-acf3c02a3542	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	f	1
877d845b-f011-477a-9f11-ad2871501762	fbc3778f-be9e-4548-b205-46f14e3b3faf	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	t	0
5353a064-ca2f-475d-a546-f01dc2015c2a	fbc3778f-be9e-4548-b205-46f14e3b3faf	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
1033962d-2fe1-4e7f-864f-8e80a65fbc5d	43911f51-805d-4b2c-add6-b328c2667a6e	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
8227e79f-006f-423e-9c4b-46b21222aa0b	240e7f63-766f-4fcc-b192-2df158c17999	image	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	\N	t	0
42b27502-d712-4a57-af6f-aa91ca343a38	35191d0c-d69e-4d03-93c6-fd48bfd5ab4f	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
29811173-ce3e-466e-9481-058264941885	714ecac9-fd70-4822-8c2c-df9ae1be7994	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
303d2954-576d-4567-a569-acdd8ad558bb	000bdfd3-ef1f-43e1-b6bc-40e82258ad3e	image	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	\N	t	0
8fccfce3-2cf2-4444-a3c3-539b3f14f16b	f543b945-c700-4357-97bb-2d5f5bb9d828	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
4e81bc35-ae11-44bc-8cc2-019511fa51e4	776e660f-a9f1-4129-b969-2fed1e1a6668	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
203778d8-d7d3-4bd0-bc3d-907e39fe9661	6f8a18b3-7b7a-4eda-800c-f5ae5a5cd290	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
199d75ae-29e5-4d13-b8c2-081b1568fb3c	d4ddac53-a22c-460b-96f2-481482d1bc95	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
0ef4dea5-8ce2-4553-a946-718243e8b105	e10511a8-45c3-4da3-bc6e-2b192c15bd24	image	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	\N	t	0
4d99700b-3ef3-48d5-b47f-a47a65739725	188d6bfc-b83a-4299-8c55-d8d5505b9f4a	image	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	\N	t	0
a1cada67-5fb0-42aa-afaf-0652e5575a43	4c1792ba-c514-454d-a4b3-39f3aad9fa71	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
583d3d3e-1fdb-4d3d-a80e-b1d00b5a0343	a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
8701a323-870c-4a08-89a6-d395fb43a39c	ce85c9c5-65f2-4876-b98c-f11d7f183b25	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
8fe5d3ce-83fe-4353-87a0-f7b5c1d87905	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
ec6339fe-1513-4d26-9a94-0364892932c2	a89eab67-0e52-408d-8887-03d24cd3886d	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
40443205-e9b4-4e75-8bab-c47d114c19a9	d6ab50a9-fc95-4d3b-9959-b66badab140f	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
bcd2a823-3c2c-440e-8bbe-07998ca18f31	1e9b6e89-66ff-460b-a11f-bfa9d27e48d0	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
cbbc645c-e812-49e6-b938-452109f0cc90	a702bac0-04c2-4ca6-8642-086500203e18	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
94646815-19ff-4386-ba1d-b7dc4cbd5d4a	a702bac0-04c2-4ca6-8642-086500203e18	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
e65020a7-c6c5-4936-ab04-0fd2e59b829e	e986f0a2-b346-485e-8409-3ac93ab1d516	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
a3dda655-acb2-44ca-adda-d58026056dba	e986f0a2-b346-485e-8409-3ac93ab1d516	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
51890284-fe06-4394-8550-f21a1c6909b0	11e3e025-ac43-4186-99c4-e90fce734514	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	t	0
31a6efc6-9540-4ed1-95e4-301f7f0d1d9e	11e3e025-ac43-4186-99c4-e90fce734514	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
9b09c7a6-5b1f-4f8c-801e-376306318b0f	7f5a475c-f641-4130-ad9d-316175ceddd8	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
42a34092-c0ee-4d10-ad6e-ffe0eeac2e75	7f5a475c-f641-4130-ad9d-316175ceddd8	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
de9d9535-48e2-4fed-b78b-ebb2c0d84a56	bf1b64b0-40db-494e-8b66-509316a30724	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	t	0
369fd181-19f0-4d7c-a91f-cba3c8eb5bf9	bf1b64b0-40db-494e-8b66-509316a30724	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
2f031ea6-2f79-4c4b-b422-ecbb1e84aab9	64d60de9-2649-48e8-8636-bb76c8a0192e	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
fe4d0c3b-4c52-471e-83f7-aa6d9cb11e65	64d60de9-2649-48e8-8636-bb76c8a0192e	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
718de4fd-53d8-4208-b244-cc5139c92571	37103385-9490-4954-9687-50f8ee9e0a26	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
01e50481-fdf5-42e2-b5c3-c769aeb0fe64	37103385-9490-4954-9687-50f8ee9e0a26	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
0a77ed00-a2e3-4c03-870b-6c7022aecfe3	1d10ee4e-0ea6-4334-bd44-cb11c2398322	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
ae029f43-3078-4f4c-975d-6a56956ba64e	1d10ee4e-0ea6-4334-bd44-cb11c2398322	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
ce91a4b5-01b8-458e-b589-cd255d1f1ae1	34a62384-7311-43f7-9d85-75275232b454	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
2ed4999b-8813-4dd9-8711-f4b94868675c	34a62384-7311-43f7-9d85-75275232b454	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
81ebf129-4763-4fe7-8b2e-debb2fa392e6	b38f66dc-3e8a-4e27-b878-87b9ff283a56	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
d74abbb2-9683-4e46-9638-a756eff0a8b1	b38f66dc-3e8a-4e27-b878-87b9ff283a56	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
fb21d2fb-5bd6-45c4-ab95-e7bd164761c6	a0f30ae4-e397-4606-ae72-5a45a95a5c33	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
02496eda-c1ea-46b8-9528-d51b1e9749cb	a0f30ae4-e397-4606-ae72-5a45a95a5c33	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
efd89917-a3d8-4f91-a7b2-cd9aafcdbe47	0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
82d1545c-9816-4654-9c14-d0c93821dc3f	0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
a27351ea-b49c-497a-bfb5-f293dff81e12	68870b9b-d774-47b3-862d-0c525aade4e0	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
d29d9203-abef-48d6-911d-1007825ba814	68870b9b-d774-47b3-862d-0c525aade4e0	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	f	1
7c07a575-6ff8-4b40-b753-b7e060692920	8a1b4752-c8ad-4882-b9e1-40e845cdf053	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
3e8d8509-3ca4-40b6-ad4d-d017994b4f5d	8a1b4752-c8ad-4882-b9e1-40e845cdf053	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	f	1
c374aad6-c965-467e-a8ab-6258a0a8fce2	bd1f899c-90a2-41d6-972f-a40762374777	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
a7fdc483-0ef1-4610-ae05-3e1df9a7c240	bd1f899c-90a2-41d6-972f-a40762374777	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
9a021d97-360a-4fba-b7f4-7d37bd16fc81	cff450de-7e28-4ffa-afdc-d8a36a6aeadd	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	t	0
9c9429db-85e7-475a-95d5-53723444107a	cff450de-7e28-4ffa-afdc-d8a36a6aeadd	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	f	1
4534b098-abb3-49ec-bf9f-abd723a81933	b91b906c-199e-4872-8bd7-aa305e61d456	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	t	0
a977c989-db79-4296-9815-33fed3f17969	b91b906c-199e-4872-8bd7-aa305e61d456	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
7f21a3f0-f5af-4546-a71b-9b13e766cb4c	35b7f9d3-1632-4549-9c32-e00d1ac6b862	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
67c42b64-dade-44d0-83b9-28cc3a934fd0	35b7f9d3-1632-4549-9c32-e00d1ac6b862	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	f	1
e13b1fdc-10e6-4de9-9bfc-618dc2a3bb27	e069ac39-c738-4586-8629-31e0731e3f91	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
a12e3e8e-a2da-415d-8495-086485f25e0c	e069ac39-c738-4586-8629-31e0731e3f91	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
62a90f58-1e11-4f39-b8a3-a62126f8fa81	f4c6f1bb-adb7-41f4-983a-64676c47e514	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
4d87059e-d59d-4e65-9f26-67e6afd72786	f4c6f1bb-adb7-41f4-983a-64676c47e514	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
b47d1b98-9bac-497e-86ba-e885b6b822d5	3094a424-7f3d-4719-8d95-9991b9680048	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
8a362690-052b-4c59-9d6f-f6ef72e340c4	3094a424-7f3d-4719-8d95-9991b9680048	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	f	1
584d71af-125e-4e0b-ab22-5ad184a8b3de	8c77c35d-3969-4fd0-933a-9558cc48fac5	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
20d18b96-97f2-47d3-aa4b-639eaa149f67	8c77c35d-3969-4fd0-933a-9558cc48fac5	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
d9641079-fac5-4a87-8e49-5ff161d153e2	4c73b269-e275-4bd2-898f-39a018826814	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
3374c821-ebee-4438-a050-83412e277625	4c73b269-e275-4bd2-898f-39a018826814	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
15ea2775-0190-45e0-881c-a2fc77c39fb3	2c7e7e69-b413-4913-b965-00e13fa8f32d	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
515cfc1e-a6a0-4c8a-b15a-855b5733887b	2c7e7e69-b413-4913-b965-00e13fa8f32d	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
2e0c4d33-9e67-41cd-874c-69a7393b52f9	c3996838-428c-4cef-9199-176dd9d66848	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
2e1248d8-a7df-490a-b755-032e9a1bcc69	c3996838-428c-4cef-9199-176dd9d66848	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	f	1
0aef1732-432f-4e15-8e51-555855164efb	29113513-b741-470e-847a-57ff621f0f19	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	t	0
04d47724-af80-4294-a57a-a0c5d335d373	29113513-b741-470e-847a-57ff621f0f19	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
566ce078-46b8-43ef-972a-1fd80a9e8a41	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
21b19caf-1e8a-4723-b81b-ea1c33835b25	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	f	1
b20379ac-e5d7-44c0-9fd2-92ca6298b5e3	59f4e92b-92ff-461f-ae08-dc2be8fbff30	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
3c6dd560-3f85-4a8e-8c77-d5d1fd42184b	59f4e92b-92ff-461f-ae08-dc2be8fbff30	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
0a3ebf08-aa21-4998-929f-3a9b43cd7386	c56c0b52-50c2-4459-b4c5-19d2c401aaf0	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
64548409-e627-43b6-8f1d-6105883d253d	c56c0b52-50c2-4459-b4c5-19d2c401aaf0	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
d12ecdcc-c5f8-4aad-b0a8-9fc162b16120	edf0deed-fa66-4c53-9ca3-5b87b10ec806	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
be8fb901-72ea-4258-b00c-ad4b55bee437	edf0deed-fa66-4c53-9ca3-5b87b10ec806	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
78cfff7a-1884-438c-bda4-377988b70129	80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
4652ddd5-2ed8-4938-ab27-8d8a4057a29c	80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
8ee201a6-3693-4a75-a362-de189710de6e	6531a87f-7a51-454d-8dea-9660c3aa3fa3	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
a58b47dd-a6c0-47b0-9707-0eed2403d0a4	6531a87f-7a51-454d-8dea-9660c3aa3fa3	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
b5e4207b-bd82-445b-92ac-8c90472c04bd	1535dacc-8620-475f-863c-f5048d3f271f	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	t	0
ed20fe43-949d-4012-a70c-c57b50eb4d38	1535dacc-8620-475f-863c-f5048d3f271f	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	f	1
401ab791-1511-42a4-9d86-b52943c0d5d5	ff6d88fd-14e9-45f9-a2ea-552c61e61f14	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
6200f239-1069-4b55-90a0-d348b0de2410	ff6d88fd-14e9-45f9-a2ea-552c61e61f14	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
9bbe8fdd-041e-4820-b5a6-6b7b21aa88fa	0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
694bbf17-9db6-4872-9273-782ccd3c05b8	0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
c97c6bb4-1e11-4680-9a07-67b8d3a07f58	0f2abacd-5388-4d16-88ba-19996ab07efc	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
a7533275-885a-439f-94c8-a967b45168de	0f2abacd-5388-4d16-88ba-19996ab07efc	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
4c831410-2b5b-40ca-ac1b-1dceeaf00c3d	228d2194-7cb3-4797-9cf6-9150f59e4b51	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
b59fc852-dca2-482d-a785-c1cb70af3a7b	228d2194-7cb3-4797-9cf6-9150f59e4b51	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
bbbcbef6-aef4-4c85-a4fe-31bbc00761a8	c5d495c4-7f15-4785-9ceb-444109eae4ca	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
ab9006fc-26cf-4398-8b73-35c0ae5e99f4	c5d495c4-7f15-4785-9ceb-444109eae4ca	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
b13a42bb-77bf-4ce4-9aab-d8957c942137	f8828552-9e98-4c47-90ac-dfeafef6f259	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
2694bc46-13aa-4dc2-a27b-3e476423896f	f8828552-9e98-4c47-90ac-dfeafef6f259	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
a061ec7f-78a0-4c8e-b728-26e08e309ba3	bb9758f5-7491-4626-8264-f9b36e781015	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	t	0
64e77b70-c502-413a-b479-3aa9f23b3281	bb9758f5-7491-4626-8264-f9b36e781015	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
023bf7ed-6389-49c4-a347-ee6cc550cd52	f52e2c21-9f60-4a9d-9587-28c34be4313d	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	t	0
8f00e5dd-5bac-45a1-8553-a050782d7121	f52e2c21-9f60-4a9d-9587-28c34be4313d	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
50c4bdf9-dad5-4024-9013-c5a72ab52830	dd2a3f4a-84df-49f0-96bc-405d52e30e8b	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	t	0
ac797df8-010f-47a1-97a9-dc2a419599b1	dd2a3f4a-84df-49f0-96bc-405d52e30e8b	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	f	1
b4f73c17-fff4-4ef4-8f64-4caec1a158de	594f7353-9eeb-4f9d-a91e-402097aa1aa0	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
7eb2f784-becb-470d-99c9-23e4e906aab5	594f7353-9eeb-4f9d-a91e-402097aa1aa0	image	https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&q=80	\N	f	1
9d9fc5ab-aedf-4f89-b808-29e02310c3c1	4e8d01e8-dddd-4ba0-b88b-b0068d47ac54	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
b0fcbd57-8b07-4c37-a73f-f36265a4bccd	4e8d01e8-dddd-4ba0-b88b-b0068d47ac54	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
8ad00d4e-9b1f-4ade-93e7-97414846ae8f	7ca26c99-aec3-4064-89c6-6acbf346ba9a	image	https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80	\N	t	0
cc698bb9-581a-4a43-a04d-6dd16713fd02	7ca26c99-aec3-4064-89c6-6acbf346ba9a	image	https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&q=80	\N	f	1
3eef812d-528d-4125-8d95-37ed07cfce2e	adf38505-f2de-4fdd-a78e-4020df43ce5b	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
2a8c6513-75e3-42e9-93a3-368a46684980	adf38505-f2de-4fdd-a78e-4020df43ce5b	image	https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80	\N	f	1
2fc6be21-fb3e-4fe4-b68f-efcad93dcbbf	8c7883b1-f456-4a6a-8f42-18c0316a9ef7	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	t	0
e64f50ca-d9a5-46cf-abd7-a0dd80d75adc	8c7883b1-f456-4a6a-8f42-18c0316a9ef7	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	f	1
ebb1c9ba-b9b8-447c-a659-8d2b47ccccf6	5cba9a8c-3a15-4e7c-92ae-14de899b0403	image	https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80	\N	t	0
c6567c03-5c30-4cf6-ac16-964a0afe1e33	5cba9a8c-3a15-4e7c-92ae-14de899b0403	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
dd770f7b-4652-4295-b2dc-fdb9530c36b3	ba60c889-76e4-4635-9a59-0ed305f1043e	image	https://images.unsplash.com/photo-1638890443292-90b52d945c56?w=800&q=80	\N	t	0
a465ff3a-16f3-49e1-91e3-d26228a77038	ba60c889-76e4-4635-9a59-0ed305f1043e	image	https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&q=80	\N	f	1
8666b320-583a-4a1e-a049-a917f56fb666	24f1f647-642a-4a4f-b685-8f6cc62ca73a	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	t	0
5926eef1-a075-44a0-9cf0-2df24dd14837	24f1f647-642a-4a4f-b685-8f6cc62ca73a	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	f	1
52162193-5709-40b1-aa0c-9325da36e986	320b6f96-0528-4430-9486-842cd3c10290	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
90ad8a2d-05d5-4b0f-8130-5e2c7524b4e5	320b6f96-0528-4430-9486-842cd3c10290	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
21e9ae38-71ab-416b-ac2c-4d3ef40ac8ed	83bd6cf4-667f-46a9-9136-42841beb0ddd	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	t	0
53fb3d8b-0c20-414a-a9f0-29a5f1fc8506	83bd6cf4-667f-46a9-9136-42841beb0ddd	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	f	1
831f1880-89d1-442d-b9df-3e46473fc506	956f7f0c-4c49-4849-8efc-1056cd1e46a7	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	t	0
32e7f694-0e82-4628-8a95-2281aabedb5a	956f7f0c-4c49-4849-8efc-1056cd1e46a7	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	f	1
c4147d2f-3d56-4c4f-98a2-a45e6bbbac44	7e2e36ae-710b-4f01-b415-163004df50d5	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	t	0
221bbdf9-c160-4146-b95e-f52079a9ad49	7e2e36ae-710b-4f01-b415-163004df50d5	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
5f1de49b-d312-4256-ba3c-2d22e62c9059	eb1e5cc7-3431-4e72-9563-be6c520c561c	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	t	0
b0135583-bc79-42c4-93e1-ff953bf45dad	eb1e5cc7-3431-4e72-9563-be6c520c561c	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	f	1
07d2ebcd-2650-41e7-b192-4873f3833082	3f8579ca-1469-4fff-8dd0-867327549e2a	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	t	0
b695df87-883f-4985-b093-0211ccdb7929	3f8579ca-1469-4fff-8dd0-867327549e2a	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	f	1
d2b416f0-a0d1-41e9-a63b-7c6fe9f1fa8b	5d5f76f9-8200-4cfb-b85f-eb3167ebe59c	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	t	0
cb2f015c-de75-441f-9c0b-a70dbddc19c9	5d5f76f9-8200-4cfb-b85f-eb3167ebe59c	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	f	1
8f659508-469b-4917-bec9-1d635cbf673a	e104a255-93b8-4ce3-b2a2-16ed2dc22047	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
695fa97f-d6b5-4b1d-af58-baf1cb6d0f4a	e104a255-93b8-4ce3-b2a2-16ed2dc22047	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	f	1
7b86c8ff-1738-44a1-9b01-1ac3dc992416	5531056b-c81d-4971-b026-fbdc40516ee8	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	t	0
27113b07-659b-4d6e-8114-b80386702ac7	5531056b-c81d-4971-b026-fbdc40516ee8	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
5cb739a5-694d-472a-a0b9-6f4056462f65	02ca95ed-3f23-4485-86bb-e822d2d20b9d	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	t	0
22dc1214-f27a-4c28-b6ce-4fe5b74c9a44	02ca95ed-3f23-4485-86bb-e822d2d20b9d	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
8b6ffaea-651a-457d-85d2-8681e5010b04	af29f0a0-62b7-48c4-8995-ae58a192b39f	image	https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80	\N	t	0
834c49a6-bdfd-470b-9507-277fd54b1179	af29f0a0-62b7-48c4-8995-ae58a192b39f	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	f	1
3b3b83b6-321f-42f0-8f49-9fcbdbc8434f	9322a87e-6899-4b8a-8399-280801afaff0	image	https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80	\N	t	0
17b1f5af-67d5-4bbb-8209-b3e2cfc35b75	9322a87e-6899-4b8a-8399-280801afaff0	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
c9431552-2edc-4cfd-9010-64e9a5140b2d	37159531-b803-4b62-a764-209cae61eb8a	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	t	0
e0fff45d-6ecf-43c2-85bf-a0c61fa2c57c	37159531-b803-4b62-a764-209cae61eb8a	image	https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80	\N	f	1
13036bae-0b25-4b92-a657-6e244fd1785b	ee9c255d-593a-404e-ba7c-54f76e5c537c	image	https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80	\N	t	0
a80412bf-1e1c-40cf-862e-c6c52f3fb92d	ee9c255d-593a-404e-ba7c-54f76e5c537c	image	https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80	\N	f	1
387137fe-23e3-4ec2-baff-6f0fcf8403c7	7263ec34-aa0e-46ee-9603-dc3c7e555089	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
6afa4200-5929-43d8-a2a6-9d535993d1d0	a0705f6e-b0e0-43fe-8352-90816e14fc59	image	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	\N	t	0
1f54afcd-0c73-4047-a27e-7d9d2b35a258	ea279ba5-756f-456d-91d8-534388fb648a	image	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	\N	t	0
3ca6f9c2-6c6b-4adb-a480-2a62049902ea	9150cc73-01b3-47fe-a15c-042af82ed4a3	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
5aafda74-1f19-4fde-9e3b-17d21e414645	af09ae88-c0da-4079-a0f4-7aa7407ac1fc	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
f2caee2a-d67b-43c5-8918-db9f6b745e91	925a9409-46ca-4049-a382-97f840540c9d	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
321366ae-e7a9-41b8-8786-80ed4809dc89	40de3002-ada5-468e-b583-788cfbeb2a35	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
a747c3ec-7bf4-4918-bcc7-bf9125f55a75	8c21de11-dacc-42d7-b52b-2413d53bb5ae	image	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	\N	t	0
064f660e-d2d0-4da4-b17c-a3db8336792a	e50a3b9d-cb4f-49df-bb51-a7a0ae37a8da	image	https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80	\N	t	0
4653432d-e662-4168-9c18-c7d3c2ef3b8b	c5a76c3d-0b88-4859-b6d8-e557ebfaca65	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
f1894886-3b55-4e16-8389-1993890e69c6	67ce4494-36b1-42c3-af3e-fe2e6b4872d3	image	https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?w=800&q=80	\N	t	0
79d6c744-2462-4fef-afab-55f80f01cf3b	d625d165-7501-4c66-9601-fea4f5c5e94a	image	https://images.unsplash.com/photo-1565793298595-6a879b1d9492?w=800&q=80	\N	t	0
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listings (id, user_id, title, description, category, base_price_cash, location, location_id, latitude, longitude, status, trust_score, is_duplicate, duplicate_of_id, is_flagged, flag_reason, bumped_at, is_request, saves_count, created_at, updated_at) FROM stdin;
fc570df0-e974-4c5a-abbe-d2df329e8ae3	760eca0f-df82-4102-9263-2cc82898272b	Mercedes-Benz C200 2022 - 2019	Mercedes-Benz C200 2022، بحالة ممتازة، 146,143 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	9163483	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-05-30 21:27:21.272	2026-07-18 21:27:18.724547
afb9180b-6d35-4e8f-9858-897749ccb3d3	0f04b82a-797d-4bc6-afa3-b1857fca6608	Toyota Fortuner 2023 VXR - 2023	Toyota Fortuner 2023 VXR، بحالة ممتازة، 14,663 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	11846014	Hurghada	dc2df87b-e04a-4f2b-aa21-5accbfc66f30	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-05-21 21:27:21.272	2026-07-18 21:27:18.746696
5c396975-c3f2-4970-b281-f8db7cfca1bf	7a1f2488-111c-445b-9169-35e6b7eb37b4	Hyundai Tucson 2022 GLS - 2019	Hyundai Tucson 2022 GLS، بحالة ممتازة، 105,453 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	6864026	New Cairo	3cd4ad06-81bb-4033-b015-5344ceafd453	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-14 21:27:21.272	2026-07-18 21:27:18.763326
25130e61-f0ac-4a2f-ab46-91ce6f54649f	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Kia Sportage 2023 Luxury - 2022	Kia Sportage 2023 Luxury، بحالة ممتازة، 161,166 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	3002394	Sheikh Zayed	578d0bc4-3fec-44fa-b1b0-5d8be9c9edd0	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-05-31 21:27:21.272	2026-07-18 21:27:18.789358
85c4c348-d4f0-44ed-b814-60c0a881559e	267d8854-2d0d-4988-89b2-bca9de35e789	Volkswagen Tiguan 2022 - 2023	Volkswagen Tiguan 2022، بحالة ممتازة، 116,678 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	9420636	Dokki	7f557079-993f-4712-84d5-2d4d0e4f4cc1	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-06-07 21:27:21.272	2026-07-18 21:27:18.807469
f015cb68-23c1-45ac-8241-280405b54dcc	00ba65f0-e746-4c79-8026-09723e0a59f0	Chevrolet Camaro 2021 SS - 2024	Chevrolet Camaro 2021 SS، بحالة ممتازة، 167,417 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	4648671	Heliopolis	90a6ac27-2ae9-4390-ae51-0f6fb62c8f54	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-05-31 21:27:21.272	2026-07-18 21:27:18.824983
30cc6cc4-25df-481a-87a6-f0a2e4e82618	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Ford Mustang 2022 GT - 2023	Ford Mustang 2022 GT، بحالة ممتازة، 104,792 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	10672717	New Cairo	3cd4ad06-81bb-4033-b015-5344ceafd453	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-14 21:27:21.272	2026-07-18 21:27:18.847526
8ee87c30-45fd-451a-b437-c51e915da497	760eca0f-df82-4102-9263-2cc82898272b	Porsche Cayenne 2022 - 2022	Porsche Cayenne 2022، بحالة ممتازة، 85,065 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1657569	North Coast	3530af51-8979-4e9d-adc0-5e547c16706d	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-06-08 21:27:21.272	2026-07-18 21:27:18.868233
f4b561b7-113d-4938-8330-e527db01404c	7a1f2488-111c-445b-9169-35e6b7eb37b4	Nissan X-Trail 2022 - 2021	Nissan X-Trail 2022، بحالة ممتازة، 109,066 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	970713	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-05-25 21:27:21.272	2026-07-18 21:27:18.919255
1da570ab-f9ec-45f3-b77a-c8c1b08d284a	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Honda CR-V 2022 Touring - 2018	Honda CR-V 2022 Touring، بحالة ممتازة، 17,990 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2135053	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-05-26 21:27:21.272	2026-07-18 21:27:18.94105
38b5547f-3272-4752-adef-419278a5a379	267d8854-2d0d-4988-89b2-bca9de35e789	Jeep Grand Cherokee 2022 - 2021	Jeep Grand Cherokee 2022، بحالة ممتازة، 127,205 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2167290	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-07-13 21:27:21.272	2026-07-18 21:27:18.962747
4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	00ba65f0-e746-4c79-8026-09723e0a59f0	Audi A4 2023 - 2019	Audi A4 2023، بحالة ممتازة، 138,496 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1703993	Ain Sokhna	5a9d628a-08ad-43b6-9d1a-60dacd881fd4	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-07-13 21:27:21.272	2026-07-18 21:27:18.989134
322f1d1d-f418-4a26-8e60-45d8c45858a9	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Lexus RX 350 2022 - 2018	Lexus RX 350 2022، بحالة ممتازة، 166,574 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	705007	North Coast	3530af51-8979-4e9d-adc0-5e547c16706d	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-11 21:27:21.272	2026-07-18 21:27:19.011809
6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	760eca0f-df82-4102-9263-2cc82898272b	Toyota Corolla 2023 XLI - 2022	Toyota Corolla 2023 XLI، بحالة ممتازة، 155,938 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2196660	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-14 21:27:21.272	2026-07-18 21:27:19.043258
da4ea6a9-a539-457f-ab70-5e143be46366	0f04b82a-797d-4bc6-afa3-b1857fca6608	Hyundai Elantra 2022 - 2018	Hyundai Elantra 2022، بحالة ممتازة، 59,081 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1875197	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-05 21:27:21.272	2026-07-18 21:27:19.069901
dfa4da74-d198-413d-828c-f629a7b50189	7a1f2488-111c-445b-9169-35e6b7eb37b4	Kia Cerato 2023 EX - 2020	Kia Cerato 2023 EX، بحالة ممتازة، 106,271 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2194909	Heliopolis	90a6ac27-2ae9-4390-ae51-0f6fb62c8f54	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-07 21:27:21.272	2026-07-18 21:27:19.10179
ccc3c757-0782-4a1f-b2ac-31d59a9b307d	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Chevrolet Lanos 2019 - 2024	Chevrolet Lanos 2019، بحالة ممتازة، 134,094 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1557931	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-07 21:27:21.272	2026-07-18 21:27:19.122694
3086a988-b6a0-4e15-ab43-c09b98faafa7	267d8854-2d0d-4988-89b2-bca9de35e789	Peugeot 208 2022 - 2018	Peugeot 208 2022، بحالة ممتازة، 134,932 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2013430	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-06-20 21:27:21.272	2026-07-18 21:27:19.145904
9030afe9-63c8-4d9d-bac1-3dd49f4429e0	00ba65f0-e746-4c79-8026-09723e0a59f0	Renault Duster 2023 - 2022	Renault Duster 2023، بحالة ممتازة، 97,852 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1085052	El Rehab City	00e3ae20-5fda-4c86-8e76-cb907c6c6b6e	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-06-30 21:27:21.272	2026-07-18 21:27:19.240679
afdc4e90-2ad7-49e5-838c-3fbbee033f3d	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Mitsubishi Eclipse Cross 2022 - 2024	Mitsubishi Eclipse Cross 2022، بحالة ممتازة، 72,847 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	357437	North Coast	3530af51-8979-4e9d-adc0-5e547c16706d	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-16 21:27:21.272	2026-07-18 21:27:19.25433
09c8183b-d75c-4fad-ab84-55955aab44e2	760eca0f-df82-4102-9263-2cc82898272b	MG ZS 2023 Luxury - 2018	MG ZS 2023 Luxury، بحالة ممتازة، 9,656 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2429416	Dokki	7f557079-993f-4712-84d5-2d4d0e4f4cc1	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-24 21:27:21.272	2026-07-18 21:27:19.267087
55850d32-1a17-48c5-9363-a58459046358	0f04b82a-797d-4bc6-afa3-b1857fca6608	BMW 330i 2022 M Package - 2019	BMW 330i 2022 M Package، بحالة ممتازة، 156,126 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1038976	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-05 21:27:21.272	2026-07-18 21:27:19.280273
7adfddc0-5f2d-4e3a-823c-7ca55388ee69	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Luxury Duplex - New Cairo - Palm Hills	Luxury Duplex - New Cairo - Palm Hills. مساحة 139 متر. 2 غرف. طابق 19. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	86108	Sheikh Zayed	578d0bc4-3fec-44fa-b1b0-5d8be9c9edd0	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-06 21:27:21.272	2026-07-18 21:27:19.3124
8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	760eca0f-df82-4102-9263-2cc82898272b	Apartment 200m² - Zamalek Nile View	Apartment 200m² - Zamalek Nile View. مساحة 359 متر. 2 غرف. طابق 10. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	16174399	Heliopolis	90a6ac27-2ae9-4390-ae51-0f6fb62c8f54	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-05-28 21:27:21.272	2026-07-18 21:27:19.326987
bed7ae5c-ed17-42e2-8ba4-747f178c546c	0f04b82a-797d-4bc6-afa3-b1857fca6608	Villa 600m² - Sheikh Zayed Compound	Villa 600m² - Sheikh Zayed Compound. مساحة 131 متر. 3 غرف. طابق 8. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	19827807	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-04 21:27:21.272	2026-07-18 21:27:19.346029
7294796b-3884-4742-abee-d13b457c610b	7a1f2488-111c-445b-9169-35e6b7eb37b4	Penthouse - Heliopolis City Stars	Penthouse - Heliopolis City Stars. مساحة 493 متر. 5 غرف. طابق 17. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	33149	New Cairo	3cd4ad06-81bb-4033-b015-5344ceafd453	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-06 21:27:21.272	2026-07-18 21:27:19.362579
b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Studio - Maadi Sarayat	Studio - Maadi Sarayat. مساحة 348 متر. 2 غرف. طابق 8. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	16613294	Luxor	4183024b-fe14-497d-879f-7d521ddcd093	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-05-30 21:27:21.272	2026-07-18 21:27:19.494193
9f249352-cd48-4c1d-b238-ca2a015a6f20	267d8854-2d0d-4988-89b2-bca9de35e789	Chalet - North Coast Marina	Chalet - North Coast Marina. مساحة 510 متر. 6 غرف. طابق 4. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	1904413	Sheikh Zayed	578d0bc4-3fec-44fa-b1b0-5d8be9c9edd0	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-06-12 21:27:21.272	2026-07-18 21:27:19.513064
5ad12c3c-5a96-4a2b-89a4-566454a6869a	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Shop - City Centre Almaza	Shop - City Centre Almaza. مساحة 301 متر. 5 غرف. طابق 19. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	1205610	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-02 21:27:21.272	2026-07-18 21:27:19.557072
f7fc3936-4bc1-4375-b8c2-c173126959ea	760eca0f-df82-4102-9263-2cc82898272b	Twin House - El Rehab City	Twin House - El Rehab City. مساحة 508 متر. 4 غرف. طابق 10. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	2456737	Hurghada	dc2df87b-e04a-4f2b-aa21-5accbfc66f30	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-06 21:27:21.272	2026-07-18 21:27:19.575497
c9e5c75d-ac07-4dcf-a123-fea99cca404b	0f04b82a-797d-4bc6-afa3-b1857fca6608	Apartment 150m² - 6th October Dreamland	Apartment 150m² - 6th October Dreamland. مساحة 133 متر. 4 غرف. طابق 3. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	20807	North Coast	3530af51-8979-4e9d-adc0-5e547c16706d	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-17 21:27:21.272	2026-07-18 21:27:19.595102
58002df9-b711-4713-8047-f828c50d6718	7a1f2488-111c-445b-9169-35e6b7eb37b4	Standalone Villa - Hyde Park New Cairo	Standalone Villa - Hyde Park New Cairo. مساحة 299 متر. 1 غرف. طابق 17. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	1468182	Luxor	4183024b-fe14-497d-879f-7d521ddcd093	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-01 21:27:21.272	2026-07-18 21:27:19.609824
906b9bd8-d0ca-4a6f-aec9-915686f8c48b	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Apartment 180m² - Zahraa Maadi	Apartment 180m² - Zahraa Maadi. مساحة 269 متر. 5 غرف. طابق 9. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	3574107	New Cairo	3cd4ad06-81bb-4033-b015-5344ceafd453	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-25 21:27:21.272	2026-07-18 21:27:19.632638
20644d0f-152c-4e29-9092-c14238b4a261	267d8854-2d0d-4988-89b2-bca9de35e789	Duplex 350m² - Katameya Heights	Duplex 350m² - Katameya Heights. مساحة 372 متر. 6 غرف. طابق 10. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	28768	Zamalek	aa6cfc96-5289-46e0-89bb-5aaff82d2ac3	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-06-20 21:27:21.272	2026-07-18 21:27:19.652317
25a613fc-b24c-48c5-9dda-acf3c02a3542	00ba65f0-e746-4c79-8026-09723e0a59f0	Studio - New Administrative Capital	Studio - New Administrative Capital. مساحة 140 متر. 1 غرف. طابق 11. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	4181004	Hurghada	dc2df87b-e04a-4f2b-aa21-5accbfc66f30	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-06-20 21:27:21.272	2026-07-18 21:27:19.668498
fbc3778f-be9e-4548-b205-46f14e3b3faf	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Penthouse - El-Gouna Hurghada Sea View	Penthouse - El-Gouna Hurghada Sea View. مساحة 341 متر. 4 غرف. طابق 16. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	2735905	New Cairo	3cd4ad06-81bb-4033-b015-5344ceafd453	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-01 21:27:21.272	2026-07-18 21:27:19.683593
43911f51-805d-4b2c-add6-b328c2667a6e	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Industrial Land 5000m² - 10th of Ramadan City	Industrial Land 5000m² - 10th of Ramadan City. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	882795	Badr City	ff130cef-1d12-42c3-93f3-6a419ab1558a	\N	\N	active	62	f	\N	f	\N	\N	f	0	2026-06-01 21:27:21.272	2026-07-18 21:27:19.697479
240e7f63-766f-4fcc-b192-2df158c17999	760eca0f-df82-4102-9263-2cc82898272b	Food Processing Factory - Alexandria Port	Food Processing Factory - Alexandria Port. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	13251401	Borg El Arab	2f60e0b9-5425-4f06-85f2-ffe8f43b2556	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-06 21:27:21.272	2026-07-18 21:27:19.71511
35191d0c-d69e-4d03-93c6-fd48bfd5ab4f	0f04b82a-797d-4bc6-afa3-b1857fca6608	Textile Production Line - Mahalla El-Kubra	Textile Production Line - Mahalla El-Kubra. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	6536401	Alexandria Industrial Zone	c3de9601-f89a-46ef-8a10-9356d7165eb5	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-16 21:27:21.272	2026-07-18 21:27:19.735019
714ecac9-fd70-4822-8c2c-df9ae1be7994	7a1f2488-111c-445b-9169-35e6b7eb37b4	Cold Storage Warehouse - Obour City	Cold Storage Warehouse - Obour City. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	8087574	Borg El Arab	2f60e0b9-5425-4f06-85f2-ffe8f43b2556	\N	\N	active	87	f	\N	f	\N	\N	f	0	2026-06-08 21:27:21.272	2026-07-18 21:27:19.757504
000bdfd3-ef1f-43e1-b6bc-40e82258ad3e	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Printing Machine KOMORI - Full Setup	Printing Machine KOMORI - Full Setup. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	10854965	Badr City	ff130cef-1d12-42c3-93f3-6a419ab1558a	\N	\N	active	87	f	\N	f	\N	\N	f	0	2026-05-26 21:27:21.272	2026-07-18 21:27:19.779766
f543b945-c700-4357-97bb-2d5f5bb9d828	267d8854-2d0d-4988-89b2-bca9de35e789	CNC Machining Center - German Made	CNC Machining Center - German Made. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	6912421	Borg El Arab	2f60e0b9-5425-4f06-85f2-ffe8f43b2556	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-06-16 21:27:21.272	2026-07-18 21:27:19.796716
776e660f-a9f1-4129-b969-2fed1e1a6668	00ba65f0-e746-4c79-8026-09723e0a59f0	Plastic Injection Moulding Line	Plastic Injection Moulding Line. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	5945828	Obour City	6153f31d-2c13-4faf-b201-1109aa7a57ae	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-05-29 21:27:21.272	2026-07-18 21:27:19.814779
d4ddac53-a22c-460b-96f2-481482d1bc95	760eca0f-df82-4102-9263-2cc82898272b	Solar Panel Manufacturing Unit	Solar Panel Manufacturing Unit. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	17202138	10th of Ramadan City	0faa24e8-facf-440a-989a-1067b28bb5cb	\N	\N	active	67	f	\N	f	\N	\N	f	0	2026-06-22 21:27:21.272	2026-07-18 21:27:19.855594
e10511a8-45c3-4da3-bc6e-2b192c15bd24	0f04b82a-797d-4bc6-afa3-b1857fca6608	Marble Cutting Factory - Shaq El Thoaban	Marble Cutting Factory - Shaq El Thoaban. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	16318563	10th of Ramadan City	0faa24e8-facf-440a-989a-1067b28bb5cb	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-11 21:27:21.272	2026-07-18 21:27:19.876064
7ce2d80c-5ea0-4739-aae0-b29c26a55acb	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Toyota Fortuner 2023 VXR - 2024	Toyota Fortuner 2023 VXR، بحالة ممتازة، 78,114 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	8703858	El Rehab City	00e3ae20-5fda-4c86-8e76-cb907c6c6b6e	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.348709	2026-07-19 13:56:01.348709
7f5a475c-f641-4130-ad9d-316175ceddd8	760eca0f-df82-4102-9263-2cc82898272b	Hyundai Tucson 2022 GLS - 2024	Hyundai Tucson 2022 GLS، بحالة ممتازة، 51,833 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	7514417	Hurghada	dc2df87b-e04a-4f2b-aa21-5accbfc66f30	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.711777	2026-07-18 22:00:17.711777
bf1b64b0-40db-494e-8b66-509316a30724	0f04b82a-797d-4bc6-afa3-b1857fca6608	Kia Sportage 2023 Luxury - 2021	Kia Sportage 2023 Luxury، بحالة ممتازة، 101,292 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	3779768	Sheikh Zayed	578d0bc4-3fec-44fa-b1b0-5d8be9c9edd0	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.792314	2026-07-18 22:00:17.792314
64d60de9-2649-48e8-8636-bb76c8a0192e	7a1f2488-111c-445b-9169-35e6b7eb37b4	Volkswagen Tiguan 2022 - 2018	Volkswagen Tiguan 2022، بحالة ممتازة، 108,579 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	10548457	Mansoura	75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.813226	2026-07-18 22:00:17.813226
37103385-9490-4954-9687-50f8ee9e0a26	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Chevrolet Camaro 2021 SS - 2019	Chevrolet Camaro 2021 SS، بحالة ممتازة، 133,344 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	10254604	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.83305	2026-07-18 22:00:17.83305
ad7793eb-66af-4039-8267-c59488026824	1b06f035-4e8a-4dd7-86e3-95299957f2b8	BMW X5 2023 M-Sport - 2020	BMW X5 2023 M-Sport، بحالة ممتازة، 40,190 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	7249971	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-09 21:27:21.272	2026-07-18 21:27:18.672619
860a0fe8-c854-4af8-a524-fa1e53a8ed6d	0f04b82a-797d-4bc6-afa3-b1857fca6608	Land Rover Range Rover 2021 Vogue - 2019	Land Rover Range Rover 2021 Vogue، بحالة ممتازة، 47,441 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1216749	North Coast	3530af51-8979-4e9d-adc0-5e547c16706d	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-06-30 21:27:21.272	2026-07-18 21:27:18.902436
b8677ab7-9b44-4c7a-bc7c-1bd54ecaa5ca	7a1f2488-111c-445b-9169-35e6b7eb37b4	Mercedes GLE 2022 AMG - 2018	Mercedes GLE 2022 AMG، بحالة ممتازة، 5,133 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1370210	Mansoura	75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-14 21:27:21.272	2026-07-18 21:27:19.297288
b7537c25-ddd0-4394-8e12-08015def429c	00ba65f0-e746-4c79-8026-09723e0a59f0	Office Space 500m² - Downtown Cairo	Office Space 500m² - Downtown Cairo. مساحة 97 متر. 2 غرف. طابق 16. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	75830	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-14 21:27:21.272	2026-07-18 21:27:19.542587
6f8a18b3-7b7a-4eda-800c-f5ae5a5cd290	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Bottling Plant 10,000 bottles/hr	Bottling Plant 10,000 bottles/hr. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	23917256	Badr City	ff130cef-1d12-42c3-93f3-6a419ab1558a	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-05 21:27:21.272	2026-07-18 21:27:19.834405
188d6bfc-b83a-4299-8c55-d8d5505b9f4a	7a1f2488-111c-445b-9169-35e6b7eb37b4	Pharmaceutical Manufacturing Line	Pharmaceutical Manufacturing Line. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	11030422	Badr City	ff130cef-1d12-42c3-93f3-6a419ab1558a	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-11 21:27:21.272	2026-07-18 21:27:19.895162
4c1792ba-c514-454d-a4b3-39f3aad9fa71	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Auto Workshop Equipment Full Set	Auto Workshop Equipment Full Set. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	9155796	Obour City	6153f31d-2c13-4faf-b201-1109aa7a57ae	\N	\N	active	87	f	\N	f	\N	\N	f	0	2026-07-03 21:27:21.272	2026-07-18 21:27:19.913998
a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	0f04b82a-797d-4bc6-afa3-b1857fca6608	بوليمر بولي إيثيلين خام HDPE	مواد خام بلاستيك عالية النقاء، مناسبة لماكينات الحقن والنفخ. تسليم فوري.	industrial	1883400	10th of Ramadan City	\N	\N	\N	active	0	f	\N	f	\N	\N	f	0	2026-06-27 21:27:21.272	2026-07-18 21:27:20.922888
ce85c9c5-65f2-4876-b98c-f11d7f183b25	0f04b82a-797d-4bc6-afa3-b1857fca6608	حبيبات بلاستيك PVC نقية	خامات PVC للصناعات البلاستيكية، جودة تصدير، متوفرة بكميات كبيرة.	industrial	1218478	10th of Ramadan City	\N	\N	\N	active	0	f	\N	f	\N	\N	f	0	2026-06-28 21:27:21.272	2026-07-18 21:27:20.941028
5b43e47b-9ac6-4c33-ae58-75829f6bfe00	0f04b82a-797d-4bc6-afa3-b1857fca6608	ماكينة حقن بلاستيك 250 طن	ماكينة حقن بلاستيك أوتوماتيكية بالكامل، حالة ممتازة، تشمل القوالب الأساسية.	industrial	3415836	10th of Ramadan City	\N	\N	\N	active	0	f	\N	f	\N	\N	f	0	2026-07-02 21:27:21.272	2026-07-18 21:27:20.960826
a89eab67-0e52-408d-8887-03d24cd3886d	1b06f035-4e8a-4dd7-86e3-95299957f2b8	ماكينة نفخ بلاستيك أوتوماتيك	ماكينة نفخ زجاجات PET، إنتاجية عالية، صيانة دورية موثقة.	industrial	3981137	10th of Ramadan City	\N	\N	\N	active	0	f	\N	f	\N	\N	f	0	2026-06-29 21:27:21.272	2026-07-18 21:27:20.980944
d6ab50a9-fc95-4d3b-9959-b66badab140f	0f04b82a-797d-4bc6-afa3-b1857fca6608	خط إنتاج زجاجات PET كامل	خط إنتاج متكامل لزجاجات PET من الخامة حتى التعبئة، جاهز للتشغيل.	industrial	17912557	10th of Ramadan City	\N	\N	\N	active	0	f	\N	f	\N	\N	f	0	2026-07-12 21:27:21.272	2026-07-18 21:27:21.000071
1e9b6e89-66ff-460b-a11f-bfa9d27e48d0	0f04b82a-797d-4bc6-afa3-b1857fca6608	مصنع بلاستيك متكامل - العاشر من رمضان	مصنع بلاستيك متكامل على مساحة 5000م²، يشمل خطوط إنتاج ومرافق وتراخيص.	industrial	66164678	10th of Ramadan City	\N	\N	\N	active	0	f	\N	f	\N	\N	f	0	2026-07-04 21:27:21.272	2026-07-18 21:27:21.017186
1d10ee4e-0ea6-4334-bd44-cb11c2398322	267d8854-2d0d-4988-89b2-bca9de35e789	Ford Mustang 2022 GT - 2024	Ford Mustang 2022 GT، بحالة ممتازة، 155,123 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	4649488	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.861771	2026-07-18 22:00:17.861771
34a62384-7311-43f7-9d85-75275232b454	00ba65f0-e746-4c79-8026-09723e0a59f0	Porsche Cayenne 2022 - 2019	Porsche Cayenne 2022، بحالة ممتازة، 94,658 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2309140	Ain Sokhna	5a9d628a-08ad-43b6-9d1a-60dacd881fd4	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.883954	2026-07-18 22:00:17.883954
b38f66dc-3e8a-4e27-b878-87b9ff283a56	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Land Rover Range Rover 2021 Vogue - 2024	Land Rover Range Rover 2021 Vogue، بحالة ممتازة، 144,679 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1293551	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.903871	2026-07-18 22:00:17.903871
a0f30ae4-e397-4606-ae72-5a45a95a5c33	760eca0f-df82-4102-9263-2cc82898272b	Nissan X-Trail 2022 - 2018	Nissan X-Trail 2022، بحالة ممتازة، 46,681 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2149685	Sheikh Zayed	578d0bc4-3fec-44fa-b1b0-5d8be9c9edd0	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.931934	2026-07-18 22:00:17.931934
0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	0f04b82a-797d-4bc6-afa3-b1857fca6608	Honda CR-V 2022 Touring - 2022	Honda CR-V 2022 Touring، بحالة ممتازة، 74,040 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2325461	Luxor	4183024b-fe14-497d-879f-7d521ddcd093	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.952562	2026-07-18 22:00:17.952562
edf0deed-fa66-4c53-9ca3-5b87b10ec806	7a1f2488-111c-445b-9169-35e6b7eb37b4	Volkswagen Tiguan 2022 - 2018	Volkswagen Tiguan 2022، بحالة ممتازة، 79,149 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	11740204	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.461546	2026-07-19 13:56:01.461546
80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Chevrolet Camaro 2021 SS - 2023	Chevrolet Camaro 2021 SS، بحالة ممتازة، 21,312 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	5668054	Dokki	7f557079-993f-4712-84d5-2d4d0e4f4cc1	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.49399	2026-07-19 13:56:01.49399
6531a87f-7a51-454d-8dea-9660c3aa3fa3	267d8854-2d0d-4988-89b2-bca9de35e789	Ford Mustang 2022 GT - 2018	Ford Mustang 2022 GT، بحالة ممتازة، 176,049 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	3045183	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.529826	2026-07-19 13:56:01.529826
1535dacc-8620-475f-863c-f5048d3f271f	00ba65f0-e746-4c79-8026-09723e0a59f0	Porsche Cayenne 2022 - 2019	Porsche Cayenne 2022، بحالة ممتازة، 179,297 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1385534	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.562589	2026-07-19 13:56:01.562589
ff6d88fd-14e9-45f9-a2ea-552c61e61f14	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Land Rover Range Rover 2021 Vogue - 2018	Land Rover Range Rover 2021 Vogue، بحالة ممتازة، 120,290 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2402499	Mansoura	75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.597941	2026-07-19 13:56:01.597941
0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	760eca0f-df82-4102-9263-2cc82898272b	Nissan X-Trail 2022 - 2021	Nissan X-Trail 2022، بحالة ممتازة، 119,059 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2753728	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.632846	2026-07-19 13:56:01.632846
0f2abacd-5388-4d16-88ba-19996ab07efc	0f04b82a-797d-4bc6-afa3-b1857fca6608	Honda CR-V 2022 Touring - 2022	Honda CR-V 2022 Touring، بحالة ممتازة، 2,395 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2465522	Hurghada	dc2df87b-e04a-4f2b-aa21-5accbfc66f30	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.665867	2026-07-19 13:56:01.665867
228d2194-7cb3-4797-9cf6-9150f59e4b51	7a1f2488-111c-445b-9169-35e6b7eb37b4	Jeep Grand Cherokee 2022 - 2018	Jeep Grand Cherokee 2022، بحالة ممتازة، 86,975 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2387914	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.699582	2026-07-19 13:56:01.699582
c5d495c4-7f15-4785-9ceb-444109eae4ca	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Audi A4 2023 - 2022	Audi A4 2023، بحالة ممتازة، 131,683 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1776473	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.734745	2026-07-19 13:56:01.734745
f8828552-9e98-4c47-90ac-dfeafef6f259	267d8854-2d0d-4988-89b2-bca9de35e789	Lexus RX 350 2022 - 2022	Lexus RX 350 2022، بحالة ممتازة، 82,872 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2730255	Ain Sokhna	5a9d628a-08ad-43b6-9d1a-60dacd881fd4	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.824127	2026-07-19 13:56:01.824127
bb9758f5-7491-4626-8264-f9b36e781015	00ba65f0-e746-4c79-8026-09723e0a59f0	Toyota Corolla 2023 XLI - 2023	Toyota Corolla 2023 XLI، بحالة ممتازة، 25,884 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2224993	Ain Sokhna	5a9d628a-08ad-43b6-9d1a-60dacd881fd4	\N	\N	active	42	t	bd1f899c-90a2-41d6-972f-a40762374777	f	\N	\N	f	0	2026-07-19 13:56:01.866771	2026-07-19 13:56:01.866771
f52e2c21-9f60-4a9d-9587-28c34be4313d	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Hyundai Elantra 2022 - 2018	Hyundai Elantra 2022، بحالة ممتازة، 95,629 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1547428	North Coast	3530af51-8979-4e9d-adc0-5e547c16706d	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.90047	2026-07-19 13:56:01.90047
8a1b4752-c8ad-4882-b9e1-40e845cdf053	267d8854-2d0d-4988-89b2-bca9de35e789	Lexus RX 350 2022 - 2023	Lexus RX 350 2022، بحالة ممتازة، 4,546 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	604955	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.016057	2026-07-18 22:00:18.016057
bd1f899c-90a2-41d6-972f-a40762374777	00ba65f0-e746-4c79-8026-09723e0a59f0	Toyota Corolla 2023 XLI - 2023	Toyota Corolla 2023 XLI، بحالة ممتازة، 10,532 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2221323	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.033013	2026-07-18 22:00:18.033013
b91b906c-199e-4872-8bd7-aa305e61d456	760eca0f-df82-4102-9263-2cc82898272b	Kia Cerato 2023 EX - 2023	Kia Cerato 2023 EX، بحالة ممتازة، 85,965 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2480566	Mansoura	75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.089923	2026-07-18 22:00:18.089923
35b7f9d3-1632-4549-9c32-e00d1ac6b862	0f04b82a-797d-4bc6-afa3-b1857fca6608	Chevrolet Lanos 2019 - 2022	Chevrolet Lanos 2019، بحالة ممتازة، 132,471 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2712598	Hurghada	dc2df87b-e04a-4f2b-aa21-5accbfc66f30	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.111941	2026-07-18 22:00:18.111941
e069ac39-c738-4586-8629-31e0731e3f91	7a1f2488-111c-445b-9169-35e6b7eb37b4	Peugeot 208 2022 - 2024	Peugeot 208 2022، بحالة ممتازة، 159,661 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1225456	Hurghada	dc2df87b-e04a-4f2b-aa21-5accbfc66f30	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.127599	2026-07-18 22:00:18.127599
f4c6f1bb-adb7-41f4-983a-64676c47e514	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Renault Duster 2023 - 2021	Renault Duster 2023، بحالة ممتازة، 13,113 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	744624	Heliopolis	90a6ac27-2ae9-4390-ae51-0f6fb62c8f54	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.140928	2026-07-18 22:00:18.140928
3094a424-7f3d-4719-8d95-9991b9680048	267d8854-2d0d-4988-89b2-bca9de35e789	Mitsubishi Eclipse Cross 2022 - 2018	Mitsubishi Eclipse Cross 2022، بحالة ممتازة، 143,673 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1528508	New Cairo	3cd4ad06-81bb-4033-b015-5344ceafd453	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.157066	2026-07-18 22:00:18.157066
8c77c35d-3969-4fd0-933a-9558cc48fac5	00ba65f0-e746-4c79-8026-09723e0a59f0	MG ZS 2023 Luxury - 2021	MG ZS 2023 Luxury، بحالة ممتازة، 42,939 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	565727	Mansoura	75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.171696	2026-07-18 22:00:18.171696
4c73b269-e275-4bd2-898f-39a018826814	1b06f035-4e8a-4dd7-86e3-95299957f2b8	BMW 330i 2022 M Package - 2018	BMW 330i 2022 M Package، بحالة ممتازة، 93,528 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2664703	Mansoura	75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.186452	2026-07-18 22:00:18.186452
2c7e7e69-b413-4913-b965-00e13fa8f32d	760eca0f-df82-4102-9263-2cc82898272b	Mercedes GLE 2022 AMG - 2020	Mercedes GLE 2022 AMG، بحالة ممتازة، 43,420 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2548203	Zamalek	aa6cfc96-5289-46e0-89bb-5aaff82d2ac3	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.20237	2026-07-18 22:00:18.20237
a702bac0-04c2-4ca6-8642-086500203e18	267d8854-2d0d-4988-89b2-bca9de35e789	BMW X5 2023 M-Sport - 2019	BMW X5 2023 M-Sport، بحالة ممتازة، 2,443 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	11821057	North Coast	3530af51-8979-4e9d-adc0-5e547c16706d	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.618356	2026-07-18 22:00:17.618356
e986f0a2-b346-485e-8409-3ac93ab1d516	00ba65f0-e746-4c79-8026-09723e0a59f0	Mercedes-Benz C200 2022 - 2024	Mercedes-Benz C200 2022، بحالة ممتازة، 89,788 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	3508795	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.648035	2026-07-18 22:00:17.648035
11e3e025-ac43-4186-99c4-e90fce734514	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Toyota Fortuner 2023 VXR - 2022	Toyota Fortuner 2023 VXR، بحالة ممتازة، 60,543 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	6874065	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.681843	2026-07-18 22:00:17.681843
68870b9b-d774-47b3-862d-0c525aade4e0	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Audi A4 2023 - 2020	Audi A4 2023، بحالة ممتازة، 29,340 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	849627	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-18 22:00:17.996523	2026-07-18 22:00:17.996523
cff450de-7e28-4ffa-afdc-d8a36a6aeadd	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Hyundai Elantra 2022 - 2023	Hyundai Elantra 2022، بحالة ممتازة، 150,671 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1723940	Hurghada	dc2df87b-e04a-4f2b-aa21-5accbfc66f30	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-18 22:00:18.0557	2026-07-18 22:00:18.0557
594f7353-9eeb-4f9d-a91e-402097aa1aa0	0f04b82a-797d-4bc6-afa3-b1857fca6608	Chevrolet Lanos 2019 - 2022	Chevrolet Lanos 2019، بحالة ممتازة، 53,421 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2280814	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.969215	2026-07-19 13:56:01.969215
4e8d01e8-dddd-4ba0-b88b-b0068d47ac54	7a1f2488-111c-445b-9169-35e6b7eb37b4	Peugeot 208 2022 - 2023	Peugeot 208 2022، بحالة ممتازة، 139,256 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2550294	Luxor	4183024b-fe14-497d-879f-7d521ddcd093	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.996258	2026-07-19 13:56:01.996258
7ca26c99-aec3-4064-89c6-6acbf346ba9a	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Renault Duster 2023 - 2019	Renault Duster 2023، بحالة ممتازة، 149,678 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2436991	Sheikh Zayed	578d0bc4-3fec-44fa-b1b0-5d8be9c9edd0	\N	\N	active	90	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.032143	2026-07-19 13:56:02.032143
adf38505-f2de-4fdd-a78e-4020df43ce5b	267d8854-2d0d-4988-89b2-bca9de35e789	Mitsubishi Eclipse Cross 2022 - 2019	Mitsubishi Eclipse Cross 2022، بحالة ممتازة، 104,126 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1222990	Luxor	4183024b-fe14-497d-879f-7d521ddcd093	\N	\N	active	70	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.059238	2026-07-19 13:56:02.059238
8c7883b1-f456-4a6a-8f42-18c0316a9ef7	00ba65f0-e746-4c79-8026-09723e0a59f0	MG ZS 2023 Luxury - 2022	MG ZS 2023 Luxury، بحالة ممتازة، 36,357 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1394521	Dokki	7f557079-993f-4712-84d5-2d4d0e4f4cc1	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.086692	2026-07-19 13:56:02.086692
5cba9a8c-3a15-4e7c-92ae-14de899b0403	1b06f035-4e8a-4dd7-86e3-95299957f2b8	BMW 330i 2022 M Package - 2022	BMW 330i 2022 M Package، بحالة ممتازة، 54,888 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1060708	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.11359	2026-07-19 13:56:02.11359
ba60c889-76e4-4635-9a59-0ed305f1043e	760eca0f-df82-4102-9263-2cc82898272b	Mercedes GLE 2022 AMG - 2022	Mercedes GLE 2022 AMG، بحالة ممتازة، 86,812 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	1087285	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.142184	2026-07-19 13:56:02.142184
24f1f647-642a-4a4f-b685-8f6cc62ca73a	267d8854-2d0d-4988-89b2-bca9de35e789	Luxury Duplex - New Cairo - Palm Hills	Luxury Duplex - New Cairo - Palm Hills. مساحة 505 متر. 6 غرف. طابق 3. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	64834	Zamalek	aa6cfc96-5289-46e0-89bb-5aaff82d2ac3	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.175396	2026-07-19 13:56:02.175396
320b6f96-0528-4430-9486-842cd3c10290	00ba65f0-e746-4c79-8026-09723e0a59f0	Apartment 200m² - Zamalek Nile View	Apartment 200m² - Zamalek Nile View. مساحة 528 متر. 5 غرف. طابق 15. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	35270392	Sheikh Zayed	578d0bc4-3fec-44fa-b1b0-5d8be9c9edd0	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.202487	2026-07-19 13:56:02.202487
83bd6cf4-667f-46a9-9136-42841beb0ddd	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Villa 600m² - Sheikh Zayed Compound	Villa 600m² - Sheikh Zayed Compound. مساحة 318 متر. 1 غرف. طابق 4. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	13230978	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.236862	2026-07-19 13:56:02.236862
956f7f0c-4c49-4849-8efc-1056cd1e46a7	760eca0f-df82-4102-9263-2cc82898272b	Penthouse - Heliopolis City Stars	Penthouse - Heliopolis City Stars. مساحة 107 متر. 6 غرف. طابق 5. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	12708	Luxor	4183024b-fe14-497d-879f-7d521ddcd093	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.272209	2026-07-19 13:56:02.272209
7e2e36ae-710b-4f01-b415-163004df50d5	0f04b82a-797d-4bc6-afa3-b1857fca6608	Studio - Maadi Sarayat	Studio - Maadi Sarayat. مساحة 275 متر. 4 غرف. طابق 1. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	17334615	Zamalek	aa6cfc96-5289-46e0-89bb-5aaff82d2ac3	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.299203	2026-07-19 13:56:02.299203
eb1e5cc7-3431-4e72-9563-be6c520c561c	7a1f2488-111c-445b-9169-35e6b7eb37b4	Chalet - North Coast Marina	Chalet - North Coast Marina. مساحة 530 متر. 2 غرف. طابق 18. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	2506366	New Cairo	3cd4ad06-81bb-4033-b015-5344ceafd453	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.411731	2026-07-19 13:56:02.411731
5d5f76f9-8200-4cfb-b85f-eb3167ebe59c	267d8854-2d0d-4988-89b2-bca9de35e789	Shop - City Centre Almaza	Shop - City Centre Almaza. مساحة 212 متر. 6 غرف. طابق 12. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	4933304	Mansoura	75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.47438	2026-07-19 13:56:02.47438
e104a255-93b8-4ce3-b2a2-16ed2dc22047	00ba65f0-e746-4c79-8026-09723e0a59f0	Twin House - El Rehab City	Twin House - El Rehab City. مساحة 538 متر. 3 غرف. طابق 1. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	4146928	New Cairo	3cd4ad06-81bb-4033-b015-5344ceafd453	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.509337	2026-07-19 13:56:02.509337
5531056b-c81d-4971-b026-fbdc40516ee8	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Apartment 150m² - 6th October Dreamland	Apartment 150m² - 6th October Dreamland. مساحة 445 متر. 6 غرف. طابق 14. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	30055	Dokki	7f557079-993f-4712-84d5-2d4d0e4f4cc1	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.545367	2026-07-19 13:56:02.545367
02ca95ed-3f23-4485-86bb-e822d2d20b9d	760eca0f-df82-4102-9263-2cc82898272b	Standalone Villa - Hyde Park New Cairo	Standalone Villa - Hyde Park New Cairo. مساحة 433 متر. 5 غرف. طابق 2. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	7275665	Ain Sokhna	5a9d628a-08ad-43b6-9d1a-60dacd881fd4	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.572998	2026-07-19 13:56:02.572998
af29f0a0-62b7-48c4-8995-ae58a192b39f	0f04b82a-797d-4bc6-afa3-b1857fca6608	Apartment 180m² - Zahraa Maadi	Apartment 180m² - Zahraa Maadi. مساحة 497 متر. 2 غرف. طابق 6. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	3590840	Mansoura	75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.607255	2026-07-19 13:56:02.607255
9322a87e-6899-4b8a-8399-280801afaff0	7a1f2488-111c-445b-9169-35e6b7eb37b4	Duplex 350m² - Katameya Heights	Duplex 350m² - Katameya Heights. مساحة 569 متر. 3 غرف. طابق 16. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	11783	Zamalek	aa6cfc96-5289-46e0-89bb-5aaff82d2ac3	\N	\N	active	92	f	\N	f	\N	\N	f	1	2026-07-19 13:56:02.641393	2026-07-19 13:56:02.641393
c3996838-428c-4cef-9199-176dd9d66848	267d8854-2d0d-4988-89b2-bca9de35e789	BMW X5 2023 M-Sport - 2021	BMW X5 2023 M-Sport، بحالة ممتازة، 58,261 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	5382358	6th of October City	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.22426	2026-07-19 13:56:01.22426
29113513-b741-470e-847a-57ff621f0f19	00ba65f0-e746-4c79-8026-09723e0a59f0	Mercedes-Benz C200 2022 - 2021	Mercedes-Benz C200 2022، بحالة ممتازة، 51,854 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	10962551	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.314952	2026-07-19 13:56:01.314952
59f4e92b-92ff-461f-ae08-dc2be8fbff30	760eca0f-df82-4102-9263-2cc82898272b	Hyundai Tucson 2022 GLS - 2020	Hyundai Tucson 2022 GLS، بحالة ممتازة، 37,497 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	11102784	Maadi	f2326b32-8c0a-452e-9404-8a5d0a394b3a	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.387038	2026-07-19 13:56:01.387038
c56c0b52-50c2-4459-b4c5-19d2c401aaf0	0f04b82a-797d-4bc6-afa3-b1857fca6608	Kia Sportage 2023 Luxury - 2019	Kia Sportage 2023 Luxury، بحالة ممتازة، 29,414 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	5860983	Zamalek	aa6cfc96-5289-46e0-89bb-5aaff82d2ac3	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.423667	2026-07-19 13:56:01.423667
dd2a3f4a-84df-49f0-96bc-405d52e30e8b	760eca0f-df82-4102-9263-2cc82898272b	Kia Cerato 2023 EX - 2023	Kia Cerato 2023 EX، بحالة ممتازة، 23,824 كيلومتر. لون خارجي أبيض / داخلي أسود. سيرفس كامل. الأوراق سليمة.	car	2263890	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:01.934807	2026-07-19 13:56:01.934807
3f8579ca-1469-4fff-8dd0-867327549e2a	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Office Space 500m² - Downtown Cairo	Office Space 500m² - Downtown Cairo. مساحة 538 متر. 4 غرف. طابق 12. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	60968	Giza	f4008afe-cc53-4e84-9467-be1bcd30519f	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.445415	2026-07-19 13:56:02.445415
37159531-b803-4b62-a764-209cae61eb8a	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Studio - New Administrative Capital	Studio - New Administrative Capital. مساحة 292 متر. 2 غرف. طابق 12. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	3482519	Zamalek	aa6cfc96-5289-46e0-89bb-5aaff82d2ac3	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.668091	2026-07-19 13:56:02.668091
ee9c255d-593a-404e-ba7c-54f76e5c537c	267d8854-2d0d-4988-89b2-bca9de35e789	Penthouse - El-Gouna Hurghada Sea View	Penthouse - El-Gouna Hurghada Sea View. مساحة 98 متر. 4 غرف. طابق 12. إطلالة رائعة. تشطيب سوبر لوكس.	real_estate	4221766	Alexandria	7e3abd0b-8acf-486e-8dca-d135bc54dd01	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.695772	2026-07-19 13:56:02.695772
7263ec34-aa0e-46ee-9603-dc3c7e555089	267d8854-2d0d-4988-89b2-bca9de35e789	Industrial Land 5000m² - 10th of Ramadan City	Industrial Land 5000m² - 10th of Ramadan City. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	5753506	Alexandria Industrial Zone	c3de9601-f89a-46ef-8a10-9356d7165eb5	\N	\N	active	67	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.722809	2026-07-19 13:56:02.722809
a0705f6e-b0e0-43fe-8352-90816e14fc59	00ba65f0-e746-4c79-8026-09723e0a59f0	Food Processing Factory - Alexandria Port	Food Processing Factory - Alexandria Port. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	7064072	Alexandria Industrial Zone	c3de9601-f89a-46ef-8a10-9356d7165eb5	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.759207	2026-07-19 13:56:02.759207
ea279ba5-756f-456d-91d8-534388fb648a	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Textile Production Line - Mahalla El-Kubra	Textile Production Line - Mahalla El-Kubra. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	17897143	Borg El Arab	2f60e0b9-5425-4f06-85f2-ffe8f43b2556	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.793204	2026-07-19 13:56:02.793204
9150cc73-01b3-47fe-a15c-042af82ed4a3	760eca0f-df82-4102-9263-2cc82898272b	Cold Storage Warehouse - Obour City	Cold Storage Warehouse - Obour City. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	21204112	10th of Ramadan City	0faa24e8-facf-440a-989a-1067b28bb5cb	\N	\N	active	87	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.82575	2026-07-19 13:56:02.82575
af09ae88-c0da-4079-a0f4-7aa7407ac1fc	0f04b82a-797d-4bc6-afa3-b1857fca6608	Printing Machine KOMORI - Full Setup	Printing Machine KOMORI - Full Setup. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	2761065	Alexandria Industrial Zone	c3de9601-f89a-46ef-8a10-9356d7165eb5	\N	\N	active	87	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.866184	2026-07-19 13:56:02.866184
925a9409-46ca-4049-a382-97f840540c9d	7a1f2488-111c-445b-9169-35e6b7eb37b4	CNC Machining Center - German Made	CNC Machining Center - German Made. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	5115428	Alexandria Industrial Zone	c3de9601-f89a-46ef-8a10-9356d7165eb5	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.903808	2026-07-19 13:56:02.903808
40de3002-ada5-468e-b583-788cfbeb2a35	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	Plastic Injection Moulding Line	Plastic Injection Moulding Line. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	14753861	Sadat City	6dba2603-dc8e-4b5e-9be0-994a84a08e49	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.936346	2026-07-19 13:56:02.936346
8c21de11-dacc-42d7-b52b-2413d53bb5ae	267d8854-2d0d-4988-89b2-bca9de35e789	Bottling Plant 10,000 bottles/hr	Bottling Plant 10,000 bottles/hr. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	17221757	Borg El Arab	2f60e0b9-5425-4f06-85f2-ffe8f43b2556	\N	\N	active	72	f	\N	f	\N	\N	f	0	2026-07-19 13:56:02.975471	2026-07-19 13:56:02.975471
e50a3b9d-cb4f-49df-bb51-a7a0ae37a8da	00ba65f0-e746-4c79-8026-09723e0a59f0	Solar Panel Manufacturing Unit	Solar Panel Manufacturing Unit. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	16390661	Obour City	6153f31d-2c13-4faf-b201-1109aa7a57ae	\N	\N	active	47	f	\N	f	\N	\N	f	0	2026-07-19 13:56:03.013766	2026-07-19 13:56:03.013766
c5a76c3d-0b88-4859-b6d8-e557ebfaca65	1b06f035-4e8a-4dd7-86e3-95299957f2b8	Marble Cutting Factory - Shaq El Thoaban	Marble Cutting Factory - Shaq El Thoaban. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	13378782	Sadat City	6dba2603-dc8e-4b5e-9be0-994a84a08e49	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:03.054151	2026-07-19 13:56:03.054151
67ce4494-36b1-42c3-af3e-fe2e6b4872d3	760eca0f-df82-4102-9263-2cc82898272b	Pharmaceutical Manufacturing Line	Pharmaceutical Manufacturing Line. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	22593980	Alexandria Industrial Zone	c3de9601-f89a-46ef-8a10-9356d7165eb5	\N	\N	active	92	f	\N	f	\N	\N	f	0	2026-07-19 13:56:03.088628	2026-07-19 13:56:03.088628
d625d165-7501-4c66-9601-fea4f5c5e94a	0f04b82a-797d-4bc6-afa3-b1857fca6608	Auto Workshop Equipment Full Set	Auto Workshop Equipment Full Set. حالة ممتازة. جاهز للتشغيل الفوري. يشمل جميع المعدات والتراخيص.	industrial	11692194	10th of Ramadan City	0faa24e8-facf-440a-989a-1067b28bb5cb	\N	\N	active	87	f	\N	f	\N	\N	f	0	2026-07-19 13:56:03.121239	2026-07-19 13:56:03.121239
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.locations (id, city, area, slug, zone_type, latitude, longitude, created_at) FROM stdin;
3cd4ad06-81bb-4033-b015-5344ceafd453	Cairo	New Cairo	new-cairo	new_city	30.0300000	31.4913000	2026-07-18 21:27:18.171678
f4008afe-cc53-4e84-9467-be1bcd30519f	Giza	6th of October City	6th-of-october-city	new_city	29.9660000	30.9230000	2026-07-18 21:27:18.179273
aa6cfc96-5289-46e0-89bb-5aaff82d2ac3	Cairo	Zamalek	zamalek	urban	30.0618000	31.2194000	2026-07-18 21:27:18.183866
f2326b32-8c0a-452e-9404-8a5d0a394b3a	Cairo	Maadi	maadi	urban	29.9603000	31.2569000	2026-07-18 21:27:18.299627
90a6ac27-2ae9-4390-ae51-0f6fb62c8f54	Cairo	Heliopolis	heliopolis	urban	30.0911000	31.3425000	2026-07-18 21:27:18.307033
7f557079-993f-4712-84d5-2d4d0e4f4cc1	Giza	Dokki	dokki	urban	30.0388000	31.2110000	2026-07-18 21:27:18.311126
b8828543-5104-45b2-b475-ea2849ae28d7	Giza	Giza	giza	urban	30.0131000	31.2089000	2026-07-18 21:27:18.315179
578d0bc4-3fec-44fa-b1b0-5d8be9c9edd0	Giza	Sheikh Zayed	sheikh-zayed	suburb	30.0444000	30.9760000	2026-07-18 21:27:18.320486
00e3ae20-5fda-4c86-8e76-cb907c6c6b6e	Cairo	El Rehab City	el-rehab-city	new_city	30.0586000	31.4913000	2026-07-18 21:27:18.324497
5a9d628a-08ad-43b6-9d1a-60dacd881fd4	Suez	Ain Sokhna	ain-sokhna	coastal	29.6004000	32.3160000	2026-07-18 21:27:18.329938
3530af51-8979-4e9d-adc0-5e547c16706d	Matrouh	North Coast	north-coast	coastal	31.0339000	28.5000000	2026-07-18 21:27:18.337671
75eea696-433d-4bfa-b8b3-bdf3bec3d3c9	Dakahlia	Mansoura	mansoura	urban	31.0409000	31.3785000	2026-07-18 21:27:18.344479
7e3abd0b-8acf-486e-8dca-d135bc54dd01	Alexandria	Alexandria	alexandria	coastal	31.2001000	29.9187000	2026-07-18 21:27:18.348615
dc2df87b-e04a-4f2b-aa21-5accbfc66f30	Red Sea	Hurghada	hurghada	coastal	27.2579000	33.8116000	2026-07-18 21:27:18.351875
4183024b-fe14-497d-879f-7d521ddcd093	Luxor	Luxor	luxor	urban	25.6872000	32.6396000	2026-07-18 21:27:18.356045
0faa24e8-facf-440a-989a-1067b28bb5cb	Sharqia	10th of Ramadan City	10th-of-ramadan-city	industrial	30.2960000	31.7420000	2026-07-18 21:27:18.359694
6153f31d-2c13-4faf-b201-1109aa7a57ae	Qalyubia	Obour City	obour-city	industrial	30.2280000	31.4710000	2026-07-18 21:27:18.366892
c3de9601-f89a-46ef-8a10-9356d7165eb5	Alexandria	Alexandria Industrial Zone	alexandria-industrial-zone	industrial	31.1500000	29.8800000	2026-07-18 21:27:18.373802
2f60e0b9-5425-4f06-85f2-ffe8f43b2556	Alexandria	Borg El Arab	borg-el-arab	industrial	30.8550000	29.5680000	2026-07-18 21:27:18.377526
6dba2603-dc8e-4b5e-9be0-994a84a08e49	Monufia	Sadat City	sadat-city	industrial	30.3650000	30.5230000	2026-07-18 21:27:18.381441
ff130cef-1d12-42c3-93f3-6a419ab1558a	Cairo	Badr City	badr-city	new_city	30.1300000	31.7200000	2026-07-18 21:27:18.386483
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, conversation_id, sender_id, body, media_url, media_kind, reactions, reply_to_id, listing_ref_id, read_at, created_at) FROM stdin;
fe56bc7b-b114-439f-89df-be1d0a452acb	1387a42e-f4b5-48c7-91d8-e4269bf13ebd	f787718d-27d8-4877-82fd-b4ff2a25bdee	رطرطز	\N	\N	\N	\N	\N	\N	2026-07-21 13:34:30.010217
63067023-b384-4ff0-9b09-f68034c75826	1387a42e-f4b5-48c7-91d8-e4269bf13ebd	f787718d-27d8-4877-82fd-b4ff2a25bdee	رير	\N	\N	\N	\N	\N	\N	2026-07-21 13:34:31.788509
090c01c8-a8e6-41d7-9598-305c65dfb122	1387a42e-f4b5-48c7-91d8-e4269bf13ebd	f787718d-27d8-4877-82fd-b4ff2a25bdee	تيا	\N	\N	\N	\N	\N	\N	2026-07-21 13:34:42.007125
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.models (id, brand_id, name, slug, body_type, year_start, year_end, created_at) FROM stdin;
b454a2a0-40e5-4311-abb8-c3fb426b292e	021ed729-50a2-46b7-86d2-960eb2f84b38	330i	bmw-330i	\N	\N	\N	2026-07-18 21:27:17.377612
74a2f759-e372-436d-b30c-14349b315970	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Lanos	chevrolet-lanos	\N	\N	\N	2026-07-18 21:27:17.690533
fcdf28d8-f787-4278-a18e-1e776ed5af07	1dd5cb73-e65d-4884-97a4-c96ffc94fd83	Cayenne	porsche-cayenne	\N	\N	\N	2026-07-18 21:27:17.735296
bfb3c9d6-ed86-4d4e-a24d-72258b2820e9	7373ab06-3f4a-4058-8d7e-af7a21fa788d	Range Rover	land-rover-range-rover	\N	\N	\N	2026-07-18 21:27:17.773214
f686c84b-896c-49f0-b188-fed009c3aee4	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	RX 350	lexus-rx-350	\N	\N	\N	2026-07-18 21:27:18.152947
c5e8c8af-9b5f-490b-af7d-5bdec92048f2	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Corolla	toyota-corolla	sedan	\N	\N	2026-07-18 21:27:17.483765
c0f9b8fc-5715-486b-8370-ff89650c3a2e	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Camry	toyota-camry	sedan	\N	\N	2026-07-19 13:56:41.111692
f595fad5-a39f-48a9-9615-54aa8ea2fa81	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Yaris	toyota-yaris	hatchback	\N	\N	2026-07-19 13:56:41.120585
22e8250b-62d0-457d-a7f9-8bc92a64e846	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Belta	toyota-belta	sedan	\N	\N	2026-07-19 13:56:41.128649
0a3669e8-64af-4474-9c30-41f8eae65b30	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Corolla Cross	toyota-corolla-cross	crossover	\N	\N	2026-07-19 13:56:41.136232
4b998f92-c193-4799-b7f6-78dae3fe98d7	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	RAV4	toyota-rav4	suv	\N	\N	2026-07-19 13:56:41.145188
291ddb7a-c712-44f4-a330-e72a350b4091	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	C-HR	toyota-c-hr	crossover	\N	\N	2026-07-19 13:56:41.152589
b325c876-4a08-4e12-b7b6-fe39d16684da	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Raize	toyota-raize	suv	\N	\N	2026-07-19 13:56:41.160274
4f0e36ff-8bc5-4396-b9aa-89dc208e316f	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Rush	toyota-rush	suv	\N	\N	2026-07-19 13:56:41.167182
c19f3a78-62d4-4ad4-8004-19196ab8bb85	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Fortuner	toyota-fortuner	suv	\N	\N	2026-07-18 21:27:17.504856
38b7901e-14af-4294-ad0a-45472a756aff	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Land Cruiser	toyota-land-cruiser	suv	\N	\N	2026-07-19 13:56:41.181292
b9a45b4d-891e-4a77-9df0-adafd226ea04	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Land Cruiser Prado	toyota-land-cruiser-prado	suv	\N	\N	2026-07-19 13:56:41.189357
6f8a300d-614b-45a0-9d64-b0e87a9b2217	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Highlander	toyota-highlander	suv	\N	\N	2026-07-19 13:56:41.196049
080d8aef-c1a7-453c-a9c8-90d1ffa6bc3f	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Hilux	toyota-hilux	pickup	\N	\N	2026-07-19 13:56:41.203031
b7cfba67-dd92-45a8-80ee-2ff29f9df50b	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Avanza	toyota-avanza	minivan	\N	\N	2026-07-19 13:56:41.210729
0928b489-b2b1-4149-b939-04f156d79939	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Innova	toyota-innova	minivan	\N	\N	2026-07-19 13:56:41.217752
e639aacd-ffcb-4260-8db6-595aba1bb980	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Hiace	toyota-hiace	van	\N	\N	2026-07-19 13:56:41.224171
5c86ee5b-b167-4181-8a6f-88e109da3271	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Coaster	toyota-coaster	van	\N	\N	2026-07-19 13:56:41.23107
aa883f59-ed1a-4f67-be9a-edb3bb45ca9b	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Prius	toyota-prius	hatchback	\N	\N	2026-07-19 13:56:41.237497
8a1da6b7-2d94-4a9c-a2c7-af52ce896b75	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	GR86	toyota-gr86	coupe	\N	\N	2026-07-19 13:56:41.24448
9ee22f8b-fea1-4adf-8d1d-54f90d5dfc4a	fb14e662-681c-4cc1-bcdb-e60479fe8ad1	Supra	toyota-supra	coupe	\N	\N	2026-07-19 13:56:41.251454
7fa21bac-c0f1-4857-abd6-98d6c984eca0	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	ES	lexus-es	sedan	\N	\N	2026-07-19 13:56:41.260473
e5caf0dd-0aeb-418d-b6ac-438f9b2cfde6	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	IS	lexus-is	sedan	\N	\N	2026-07-19 13:56:41.268675
54ba5437-5828-4fd8-b48d-abc438544853	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	LS	lexus-ls	sedan	\N	\N	2026-07-19 13:56:41.275827
9d010889-8b77-47ef-b6af-d7acb590acbe	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	UX	lexus-ux	crossover	\N	\N	2026-07-19 13:56:41.285616
fade1fc2-e366-4a48-8166-13dc75c4fb44	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	NX	lexus-nx	suv	\N	\N	2026-07-19 13:56:41.293458
c7bc5c26-52f9-45e9-9d6f-2f38a287855c	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	RX	lexus-rx	suv	\N	\N	2026-07-19 13:56:41.300139
4687ff44-2d01-4f77-af4c-22299c412ec7	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	GX	lexus-gx	suv	\N	\N	2026-07-19 13:56:41.307536
674a4ce0-f365-4170-8c4c-592dad6712b8	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	LX	lexus-lx	suv	\N	\N	2026-07-19 13:56:41.314093
4bdf7f18-b883-4ded-b17a-719c436ddd6f	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	RC	lexus-rc	coupe	\N	\N	2026-07-19 13:56:41.320891
f86ab34c-f5ff-44a5-898f-18a1a7fda59e	d8357d5e-3e5f-4d49-82c2-80f2db20fccc	LC	lexus-lc	coupe	\N	\N	2026-07-19 13:56:41.327151
24533ac8-637b-4654-a61a-c66e26a0f3d4	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Accent	hyundai-accent	sedan	\N	\N	2026-07-19 13:56:41.334482
1fd78677-c4f9-448f-96ea-2edbd3153ed7	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Elantra	hyundai-elantra	sedan	\N	\N	2026-07-18 21:27:17.552134
7a48ce0c-1da6-4bd0-be47-6ba406cd9ada	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Sonata	hyundai-sonata	sedan	\N	\N	2026-07-19 13:56:41.347633
34e6315b-9479-41b9-a32d-64f33d22c3ba	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Azera	hyundai-azera	sedan	\N	\N	2026-07-19 13:56:41.354145
bda159af-f50f-444a-9f51-d90bc7187587	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Verna	hyundai-verna	sedan	\N	\N	2026-07-19 13:56:41.361156
b21628c6-d513-40b3-b7b7-99f86f690558	c9bcc02d-87c4-4717-8ee9-5a7959104e52	i10	hyundai-i10	hatchback	\N	\N	2026-07-19 13:56:41.367717
8d26f972-81e5-49f9-990d-159db72e6d1d	c9bcc02d-87c4-4717-8ee9-5a7959104e52	i20	hyundai-i20	hatchback	\N	\N	2026-07-19 13:56:41.37471
353d07e6-2149-405f-8d43-ed88c5ed55e5	c9bcc02d-87c4-4717-8ee9-5a7959104e52	i30	hyundai-i30	hatchback	\N	\N	2026-07-19 13:56:41.380884
f7cf1573-7465-4b0d-8095-fccbf1e90d27	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Bayon	hyundai-bayon	crossover	\N	\N	2026-07-19 13:56:41.388533
6c92cff5-4696-4a98-87ed-d92a26f80e04	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Venue	hyundai-venue	suv	\N	\N	2026-07-19 13:56:41.395099
e9d75968-0d51-4a1e-bcae-a2c3f6f480aa	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Creta	hyundai-creta	suv	\N	\N	2026-07-19 13:56:41.40202
4180f016-3234-477b-b2af-11ba8f83f9b8	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Kona	hyundai-kona	crossover	\N	\N	2026-07-19 13:56:41.408571
c684b989-28a1-41da-85a2-37c4ce13f550	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Tucson	hyundai-tucson	suv	\N	\N	2026-07-18 21:27:17.534087
8d62b2c2-9c0f-4882-bb19-d94a119696c4	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Santa Fe	hyundai-santa-fe	suv	\N	\N	2026-07-19 13:56:41.422914
ec86f95b-6c0e-4776-81a6-56b12beab4a1	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Palisade	hyundai-palisade	suv	\N	\N	2026-07-19 13:56:41.429848
9781994a-df71-4813-8229-eec1e3ee5230	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Staria	hyundai-staria	van	\N	\N	2026-07-19 13:56:41.436078
ac446c33-a97d-4dab-98ab-969763712c2d	c9bcc02d-87c4-4717-8ee9-5a7959104e52	H1	hyundai-h1	van	\N	\N	2026-07-19 13:56:41.443134
48e667c6-e2ac-40cc-8310-43d2d0c1a6a7	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Ioniq 5	hyundai-ioniq-5	crossover	\N	\N	2026-07-19 13:56:41.449567
8d8b79ad-5d83-48f2-9a3f-98cec40849e2	c9bcc02d-87c4-4717-8ee9-5a7959104e52	Ioniq 6	hyundai-ioniq-6	sedan	\N	\N	2026-07-19 13:56:41.456485
968c8535-3a2a-4098-b68e-c92ee3577dff	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Pegas	kia-pegas	sedan	\N	\N	2026-07-19 13:56:41.46361
243f7789-986e-4f38-9cff-d30279237957	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Rio	kia-rio	sedan	\N	\N	2026-07-19 13:56:41.470864
c33e502d-3a1d-4bad-8b3c-b00f9a4c73ac	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Cerato	kia-cerato	sedan	\N	\N	2026-07-18 21:27:17.608745
1487f603-2ccd-4bba-bdcb-ded547b3a5d8	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	K5	kia-k5	sedan	\N	\N	2026-07-19 13:56:41.48488
e9414731-95e2-49e8-a8bc-aad3a476a880	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Optima	kia-optima	sedan	\N	\N	2026-07-19 13:56:41.492359
23653ee4-8251-430f-ab60-29b8030c9f1d	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Stinger	kia-stinger	sedan	\N	\N	2026-07-19 13:56:41.509191
2db6915c-fd25-4160-b67f-31321a4c9e87	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Picanto	kia-picanto	hatchback	\N	\N	2026-07-19 13:56:41.515825
7a8644eb-1284-4e20-9dff-f8381cbc3276	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Soul	kia-soul	crossover	\N	\N	2026-07-19 13:56:41.522856
22ed6f07-74c8-4d0d-a15a-39917284fa08	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Sonet	kia-sonet	suv	\N	\N	2026-07-19 13:56:41.529252
ec2a7e44-2552-4c66-854b-3b7cb943610a	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Seltos	kia-seltos	suv	\N	\N	2026-07-19 13:56:41.536172
05de1c51-957d-483e-b96a-640249f3919d	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Sportage	kia-sportage	suv	\N	\N	2026-07-18 21:27:17.589915
caf47ac5-6e83-48db-be36-60b25bb3bf66	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Sorento	kia-sorento	suv	\N	\N	2026-07-19 13:56:41.549677
b03d9060-7610-4cd9-8df7-164f75189402	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Telluride	kia-telluride	suv	\N	\N	2026-07-19 13:56:41.556104
839cd64c-01c2-4317-95a2-6992786b949c	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Carnival	kia-carnival	minivan	\N	\N	2026-07-19 13:56:41.562848
42b5b671-6542-4027-874a-9621bc274894	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Carens	kia-carens	minivan	\N	\N	2026-07-19 13:56:41.571062
20a0a37b-7f44-4567-a613-db2f711b98e4	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	EV6	kia-ev6	crossover	\N	\N	2026-07-19 13:56:41.577802
4f9ae54d-f312-42fb-bc5b-fffb1e315a3d	ecf8f40a-b9f8-4ef2-9844-5a6640d120bd	Niro	kia-niro	crossover	\N	\N	2026-07-19 13:56:41.584237
be32c728-768a-471e-a522-9bbed28dd7e3	bf1f20e8-073b-4963-a44f-8f41a0126e96	X-Trail	nissan-x-trail	suv	\N	\N	2026-07-18 21:27:17.834098
368fa5bc-5cef-4813-9418-25b4584aaa0d	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Eclipse Cross	mitsubishi-eclipse-cross	suv	\N	\N	2026-07-18 21:27:18.112201
94499369-6cd2-4af5-8077-e8ea09eeec80	3121b77a-cf02-4776-a3f6-8683a9a3e883	CR-V	honda-cr-v	suv	\N	\N	2026-07-18 21:27:17.871195
cce6d52c-efed-476c-adec-a830439434d0	ff874e82-8969-4196-aeef-2142b375a108	C-Class	mercedes-benz-c-class	sedan	\N	\N	2026-07-18 21:27:17.402645
0ac20c8c-cfe0-4f22-881e-568fc9bd1126	ff874e82-8969-4196-aeef-2142b375a108	GLE	mercedes-benz-gle	suv	\N	\N	2026-07-18 21:27:17.424448
da8105d9-48bc-4dfb-a32e-4b0ecdb8a413	021ed729-50a2-46b7-86d2-960eb2f84b38	X5	bmw-x5	suv	\N	\N	2026-07-18 21:27:17.348834
d5980096-749a-4ef4-89f3-5e2fb56b570c	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	A4	audi-a4	sedan	\N	\N	2026-07-18 21:27:17.453288
d59b1622-5ce6-4d12-b5d4-be8b02ec7e9c	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Tiguan	volkswagen-tiguan	suv	\N	\N	2026-07-18 21:27:17.646775
c8939da5-7463-48b4-b452-feb46a50234a	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Grand Cherokee	jeep-grand-cherokee	suv	\N	\N	2026-07-18 21:27:17.906308
5d18451e-a2fd-4e45-9173-5c27bd3683a2	4d28e82a-1aa0-4654-86ca-836324dddb7c	Duster	renault-duster	suv	\N	\N	2026-07-18 21:27:18.077011
d772ed47-685a-4383-b965-d989b4e52ae5	9a4722eb-e61a-46a5-8605-42defc479a6f	208	peugeot-208	hatchback	\N	\N	2026-07-18 21:27:17.975011
cc9bb9e3-50ef-49d9-a295-686c186e959e	01092beb-86ae-4ed5-81f2-efe9eb0fb717	ZS	mg-zs	suv	\N	\N	2026-07-18 21:27:18.131767
b901f25e-f064-4c9c-9a95-adb0f51a5971	bf1f20e8-073b-4963-a44f-8f41a0126e96	Sunny	nissan-sunny	sedan	\N	\N	2026-07-19 13:56:41.592158
fd86d0d7-ae5a-42ea-aed1-4055beb60720	bf1f20e8-073b-4963-a44f-8f41a0126e96	Sentra	nissan-sentra	sedan	\N	\N	2026-07-19 13:56:41.60149
6b08ffe5-01bb-4424-9b22-656a25edaf1e	bf1f20e8-073b-4963-a44f-8f41a0126e96	Sylphy	nissan-sylphy	sedan	\N	\N	2026-07-19 13:56:41.609549
189d7837-971f-4406-aba6-1eec3cfcac39	bf1f20e8-073b-4963-a44f-8f41a0126e96	Altima	nissan-altima	sedan	\N	\N	2026-07-19 13:56:41.618194
e112a313-fb32-422c-988f-9ad2c2a5c59b	bf1f20e8-073b-4963-a44f-8f41a0126e96	Maxima	nissan-maxima	sedan	\N	\N	2026-07-19 13:56:41.624928
4399aee3-2e8f-4b16-b741-1f89b1f53de9	bf1f20e8-073b-4963-a44f-8f41a0126e96	Micra	nissan-micra	hatchback	\N	\N	2026-07-19 13:56:41.632327
e2ee995d-ff7c-4898-a320-7cafc40598f6	bf1f20e8-073b-4963-a44f-8f41a0126e96	Kicks	nissan-kicks	crossover	\N	\N	2026-07-19 13:56:41.638919
6a5e1c16-b524-40a4-83b8-f720ac814603	bf1f20e8-073b-4963-a44f-8f41a0126e96	Juke	nissan-juke	crossover	\N	\N	2026-07-19 13:56:41.645716
fa508493-eca1-4974-a6d9-e977c2b95b33	bf1f20e8-073b-4963-a44f-8f41a0126e96	Qashqai	nissan-qashqai	crossover	\N	\N	2026-07-19 13:56:41.651938
6eb001cb-38e0-4246-9bbf-fabf344e376a	bf1f20e8-073b-4963-a44f-8f41a0126e96	Terrano	nissan-terrano	suv	\N	\N	2026-07-19 13:56:41.665303
c4bace7d-535b-43b9-9738-b0fe413adcd6	bf1f20e8-073b-4963-a44f-8f41a0126e96	Murano	nissan-murano	suv	\N	\N	2026-07-19 13:56:41.672108
da0b274b-1cc7-4956-a92c-5db0ce36c6c1	bf1f20e8-073b-4963-a44f-8f41a0126e96	Pathfinder	nissan-pathfinder	suv	\N	\N	2026-07-19 13:56:41.678581
d960d6ad-f721-4db7-accf-a8a2234fd4e8	bf1f20e8-073b-4963-a44f-8f41a0126e96	Patrol	nissan-patrol	suv	\N	\N	2026-07-19 13:56:41.685405
c5984719-5576-48fd-b6f5-209b5990d11e	bf1f20e8-073b-4963-a44f-8f41a0126e96	Armada	nissan-armada	suv	\N	\N	2026-07-19 13:56:41.691719
66687ef9-da4f-48b9-960f-e334f1114c27	bf1f20e8-073b-4963-a44f-8f41a0126e96	Navara	nissan-navara	pickup	\N	\N	2026-07-19 13:56:41.698951
cce80758-db6d-4c67-94e7-1f6782744ed3	bf1f20e8-073b-4963-a44f-8f41a0126e96	Urvan	nissan-urvan	van	\N	\N	2026-07-19 13:56:41.705156
d3dc86ed-80e1-4689-b0d1-b34b0a737ffa	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Aveo	chevrolet-aveo	sedan	\N	\N	2026-07-19 13:56:41.712677
cf25e51a-1689-4e25-b91a-28caa0480371	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Optra	chevrolet-optra	sedan	\N	\N	2026-07-19 13:56:41.719152
4fee74c1-e45a-40eb-b72d-b6550b8c7cbf	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Cruze	chevrolet-cruze	sedan	\N	\N	2026-07-19 13:56:41.726111
e0b028f5-ffd2-4c35-b5aa-af83a3386360	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Malibu	chevrolet-malibu	sedan	\N	\N	2026-07-19 13:56:41.732674
d74d9197-f549-4cdf-ba3c-44eb9c1bfca3	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Spark	chevrolet-spark	hatchback	\N	\N	2026-07-19 13:56:41.739677
8dd29cc1-abc8-4c91-bccf-4c0e7325b4c9	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Groove	chevrolet-groove	crossover	\N	\N	2026-07-19 13:56:41.745949
3b3036c6-d846-4893-8c08-9cb60faed720	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Captiva	chevrolet-captiva	suv	\N	\N	2026-07-19 13:56:41.752793
db746455-c837-467c-819b-93694c2df4ac	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Equinox	chevrolet-equinox	suv	\N	\N	2026-07-19 13:56:41.759027
df6564e7-5bda-47f4-bd46-58fa1488b44f	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Trailblazer	chevrolet-trailblazer	suv	\N	\N	2026-07-19 13:56:41.765606
d4c92511-ca9c-41a9-a35f-6af207ed8ead	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Blazer	chevrolet-blazer	suv	\N	\N	2026-07-19 13:56:41.772087
8b1c6f79-544b-4407-b2ad-37f414f225c2	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Traverse	chevrolet-traverse	suv	\N	\N	2026-07-19 13:56:41.779879
d7a507b4-eed3-4988-b63b-1cd0f9914c4a	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Tahoe	chevrolet-tahoe	suv	\N	\N	2026-07-19 13:56:41.786476
2f180fbf-2051-468c-a2e4-80042117260d	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Suburban	chevrolet-suburban	suv	\N	\N	2026-07-19 13:56:41.793355
89f5460c-16d2-4744-9e13-c9af1b0458a1	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Camaro	chevrolet-camaro	coupe	\N	\N	2026-07-18 21:27:17.667385
4c36bced-0834-4dca-ac94-66823636ca64	0002d55a-beea-4ca9-9ab7-912f5d625dbe	Silverado	chevrolet-silverado	pickup	\N	\N	2026-07-19 13:56:41.806757
2ada8396-7df7-4a79-900e-0e25a15b0b1c	0002d55a-beea-4ca9-9ab7-912f5d625dbe	N300	chevrolet-n300	van	\N	\N	2026-07-19 13:56:41.81306
7be4662c-35a4-4c23-b599-ed365ea56034	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Attrage	mitsubishi-attrage	sedan	\N	\N	2026-07-19 13:56:41.821184
accf15ba-2c9a-402c-a231-34b1e1d2005a	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Lancer	mitsubishi-lancer	sedan	\N	\N	2026-07-19 13:56:41.827873
c243798a-a8c1-4650-87b9-386585d2916d	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Mirage	mitsubishi-mirage	hatchback	\N	\N	2026-07-19 13:56:41.834998
b2b8c8d6-05ec-495c-b3a4-271bc054f271	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Xpander	mitsubishi-xpander	minivan	\N	\N	2026-07-19 13:56:41.841429
1abde998-1c46-40b7-a837-9a2e2f0c6545	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	ASX	mitsubishi-asx	suv	\N	\N	2026-07-19 13:56:41.848291
0f9a001a-cd6b-47ea-b68f-1e187b389380	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Outlander	mitsubishi-outlander	suv	\N	\N	2026-07-19 13:56:41.861585
3d4e3d27-1c9a-46d9-b97f-a70ac73abd59	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Montero Sport	mitsubishi-montero-sport	suv	\N	\N	2026-07-19 13:56:41.867758
74ad04b8-598f-406a-a8f0-de0db31efad5	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Pajero	mitsubishi-pajero	suv	\N	\N	2026-07-19 13:56:41.875825
73772401-ec20-447a-9807-f1420c8d3504	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	L200	mitsubishi-l200	pickup	\N	\N	2026-07-19 13:56:41.882446
277dc118-aef2-49d7-9c52-db4e4f754638	efa6ea67-c81b-4ca7-a3fd-3ccb9166dba4	Canter	mitsubishi-canter	van	\N	\N	2026-07-19 13:56:41.889429
b9d0f78d-b07e-48fd-a8db-897995bd6d42	3121b77a-cf02-4776-a3f6-8683a9a3e883	City	honda-city	sedan	\N	\N	2026-07-19 13:56:41.896462
c748449e-2bd3-48fd-9b0d-f1ccdd40aa5f	3121b77a-cf02-4776-a3f6-8683a9a3e883	Civic	honda-civic	sedan	\N	\N	2026-07-19 13:56:41.903266
1a0e70c6-fd27-4966-82a6-3bbc88c9ed90	3121b77a-cf02-4776-a3f6-8683a9a3e883	Accord	honda-accord	sedan	\N	\N	2026-07-19 13:56:41.909539
4a1841b4-d746-42ef-8f5c-d077809a630b	3121b77a-cf02-4776-a3f6-8683a9a3e883	Jazz	honda-jazz	hatchback	\N	\N	2026-07-19 13:56:41.9167
4d7359b5-7344-4c00-89d3-2fe1054412f5	3121b77a-cf02-4776-a3f6-8683a9a3e883	HR-V	honda-hr-v	crossover	\N	\N	2026-07-19 13:56:41.923295
9039201b-59b4-40f9-ae2a-0f01c5b07dba	3121b77a-cf02-4776-a3f6-8683a9a3e883	ZR-V	honda-zr-v	suv	\N	\N	2026-07-19 13:56:41.930174
113dcc78-47af-45d9-8beb-43b95d169e14	3121b77a-cf02-4776-a3f6-8683a9a3e883	Pilot	honda-pilot	suv	\N	\N	2026-07-19 13:56:41.943381
09f51a37-c0d4-46c3-907b-fb5d70b1e474	3121b77a-cf02-4776-a3f6-8683a9a3e883	BR-V	honda-br-v	minivan	\N	\N	2026-07-19 13:56:41.950041
406fbd48-9a80-4590-b7b6-eff3a6c254ad	3121b77a-cf02-4776-a3f6-8683a9a3e883	Odyssey	honda-odyssey	minivan	\N	\N	2026-07-19 13:56:41.956885
51c9769b-2f48-474a-ae59-b8c7692c3dab	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	Mazda 2	mazda-mazda-2	hatchback	\N	\N	2026-07-19 13:56:41.964014
59ca43b2-9a7c-414a-8e4c-25088051bd90	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	Mazda 3	mazda-mazda-3	sedan	\N	\N	2026-07-19 13:56:41.97084
bc4ab69a-b12a-4218-bc64-9a3034dc08e8	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	Mazda 6	mazda-mazda-6	sedan	\N	\N	2026-07-19 13:56:41.977286
c02bf949-68e7-4d7f-ad5c-19fe84cd49cd	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	CX-3	mazda-cx-3	crossover	\N	\N	2026-07-19 13:56:41.983912
3f95a231-1369-4e2d-a8ef-2b398464365a	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	CX-30	mazda-cx-30	crossover	\N	\N	2026-07-19 13:56:41.990067
f720b72f-31a7-4c2f-b5d6-11b7f55edadc	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	CX-5	mazda-cx-5	suv	\N	\N	2026-07-19 13:56:41.996791
bda653b6-8c01-4cff-9866-77d2469a6298	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	CX-60	mazda-cx-60	suv	\N	\N	2026-07-19 13:56:42.002957
bfd715de-024b-463f-a453-e98d2b21047e	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	CX-9	mazda-cx-9	suv	\N	\N	2026-07-19 13:56:42.013152
5d397900-7aec-4fb7-b02a-4e050e8745f8	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	CX-90	mazda-cx-90	suv	\N	\N	2026-07-19 13:56:42.020739
5be10e46-9d33-4868-96ad-19ad6d7c3161	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	MX-5	mazda-mx-5	convertible	\N	\N	2026-07-19 13:56:42.027796
cf001bf1-b38d-496a-947e-d514c3f944b6	ac9aa9b0-5671-488a-9bd9-3df82d0992fe	BT-50	mazda-bt-50	pickup	\N	\N	2026-07-19 13:56:42.034156
faa16f2f-5ebd-4326-a692-60e6d94298cf	ff874e82-8969-4196-aeef-2142b375a108	A-Class	mercedes-benz-a-class	hatchback	\N	\N	2026-07-19 13:56:42.041743
7c78838c-c941-405b-a5f7-47daf671ee2d	ff874e82-8969-4196-aeef-2142b375a108	E-Class	mercedes-benz-e-class	sedan	\N	\N	2026-07-19 13:56:42.054763
a5e03e85-7876-4e0b-a0ae-1af8db18476c	ff874e82-8969-4196-aeef-2142b375a108	S-Class	mercedes-benz-s-class	sedan	\N	\N	2026-07-19 13:56:42.061282
5f83a8c8-697b-4083-a30d-96012c5cbaad	ff874e82-8969-4196-aeef-2142b375a108	CLA	mercedes-benz-cla	sedan	\N	\N	2026-07-19 13:56:42.068346
dd1bed70-6478-4d94-b9ef-bbbe218c9e5a	ff874e82-8969-4196-aeef-2142b375a108	CLS	mercedes-benz-cls	coupe	\N	\N	2026-07-19 13:56:42.075015
4c5899f8-c707-4e8d-aa81-0c84866632e2	ff874e82-8969-4196-aeef-2142b375a108	GLA	mercedes-benz-gla	suv	\N	\N	2026-07-19 13:56:42.081818
c3032aa3-35b3-4695-be08-9143cce6652f	ff874e82-8969-4196-aeef-2142b375a108	GLB	mercedes-benz-glb	suv	\N	\N	2026-07-19 13:56:42.088185
a21f09a2-cbff-4fbb-abc1-805618b63dfa	ff874e82-8969-4196-aeef-2142b375a108	GLC	mercedes-benz-glc	suv	\N	\N	2026-07-19 13:56:42.095164
aa35a02a-180f-4de9-8bd0-9ee6d5c34968	ff874e82-8969-4196-aeef-2142b375a108	GLS	mercedes-benz-gls	suv	\N	\N	2026-07-19 13:56:42.108153
0b43ef3e-7097-430d-bd44-fd3a88643ee4	ff874e82-8969-4196-aeef-2142b375a108	G-Class	mercedes-benz-g-class	suv	\N	\N	2026-07-19 13:56:42.114776
af508da0-e2e4-46d7-b668-a9f5eecabf16	ff874e82-8969-4196-aeef-2142b375a108	V-Class	mercedes-benz-v-class	van	\N	\N	2026-07-19 13:56:42.121534
9a1eb15f-b622-43bd-b454-f21c38afb7ad	ff874e82-8969-4196-aeef-2142b375a108	Vito	mercedes-benz-vito	van	\N	\N	2026-07-19 13:56:42.127819
c10de8a0-2459-4f92-b8b0-00e34c823687	ff874e82-8969-4196-aeef-2142b375a108	Sprinter	mercedes-benz-sprinter	van	\N	\N	2026-07-19 13:56:42.134589
bce0131e-9c65-4be9-a3a2-b811c8d4aac1	ff874e82-8969-4196-aeef-2142b375a108	AMG GT	mercedes-benz-amg-gt	coupe	\N	\N	2026-07-19 13:56:42.140732
313baf77-4fd9-49a2-9163-7a10bb0f8141	ff874e82-8969-4196-aeef-2142b375a108	EQS	mercedes-benz-eqs	sedan	\N	\N	2026-07-19 13:56:42.147615
fe09c10d-e27c-4906-9105-f8d61c73aacc	ff874e82-8969-4196-aeef-2142b375a108	EQE	mercedes-benz-eqe	sedan	\N	\N	2026-07-19 13:56:42.154526
14fa0ac1-77da-4f13-a275-c04865ecba66	ff874e82-8969-4196-aeef-2142b375a108	EQB	mercedes-benz-eqb	suv	\N	\N	2026-07-19 13:56:42.161348
50fd8ce2-cc45-4b30-b2d3-ffae5e0e0451	021ed729-50a2-46b7-86d2-960eb2f84b38	1 Series	bmw-1-series	hatchback	\N	\N	2026-07-19 13:56:42.168426
d50cd595-b84f-426b-981d-9b6eb6233b2f	021ed729-50a2-46b7-86d2-960eb2f84b38	2 Series	bmw-2-series	coupe	\N	\N	2026-07-19 13:56:42.175142
0e1e98d0-bf2b-4458-8251-707668052399	021ed729-50a2-46b7-86d2-960eb2f84b38	3 Series	bmw-3-series	sedan	\N	\N	2026-07-19 13:56:42.18153
790f3c5c-a9f2-4cfd-93e5-0406b6285ef6	021ed729-50a2-46b7-86d2-960eb2f84b38	4 Series	bmw-4-series	coupe	\N	\N	2026-07-19 13:56:42.188219
2a69d71a-db12-4346-aee9-f0fb087068fc	021ed729-50a2-46b7-86d2-960eb2f84b38	5 Series	bmw-5-series	sedan	\N	\N	2026-07-19 13:56:42.194492
5ca35132-6017-4e51-94b3-9cdedd12bbf2	021ed729-50a2-46b7-86d2-960eb2f84b38	7 Series	bmw-7-series	sedan	\N	\N	2026-07-19 13:56:42.201656
24fec6c3-fa4e-4f99-9851-b088cc114cfe	021ed729-50a2-46b7-86d2-960eb2f84b38	8 Series	bmw-8-series	coupe	\N	\N	2026-07-19 13:56:42.20783
96135c0a-cdff-4c98-ab21-cc8e999a5b9b	021ed729-50a2-46b7-86d2-960eb2f84b38	X1	bmw-x1	suv	\N	\N	2026-07-19 13:56:42.215129
cd42ecf8-3115-467f-87e2-2b63f5cbd351	021ed729-50a2-46b7-86d2-960eb2f84b38	X3	bmw-x3	suv	\N	\N	2026-07-19 13:56:42.221233
8429f1ef-ece6-468c-a681-84b90fecc45b	021ed729-50a2-46b7-86d2-960eb2f84b38	X4	bmw-x4	suv	\N	\N	2026-07-19 13:56:42.227829
2284f5af-8784-431b-95fe-9e20fd050501	021ed729-50a2-46b7-86d2-960eb2f84b38	X6	bmw-x6	suv	\N	\N	2026-07-19 13:56:42.241419
9fa5c3b2-838b-4ccf-93b7-82ea6bb59275	021ed729-50a2-46b7-86d2-960eb2f84b38	X7	bmw-x7	suv	\N	\N	2026-07-19 13:56:42.24793
3c0abbf8-5f3e-4b5d-824f-fb3f20525da8	021ed729-50a2-46b7-86d2-960eb2f84b38	Z4	bmw-z4	convertible	\N	\N	2026-07-19 13:56:42.255183
417c4099-af58-45d7-aa20-dceb75ce8fa0	021ed729-50a2-46b7-86d2-960eb2f84b38	i4	bmw-i4	sedan	\N	\N	2026-07-19 13:56:42.261604
abc87971-5049-4f5f-a210-a914c83de597	021ed729-50a2-46b7-86d2-960eb2f84b38	iX	bmw-ix	suv	\N	\N	2026-07-19 13:56:42.268666
f7b3c262-a9c0-44af-8d36-3199a5f7ef46	021ed729-50a2-46b7-86d2-960eb2f84b38	i7	bmw-i7	sedan	\N	\N	2026-07-19 13:56:42.275037
41938e0d-0fce-477d-ad44-28914831d713	021ed729-50a2-46b7-86d2-960eb2f84b38	M3	bmw-m3	sedan	\N	\N	2026-07-19 13:56:42.282069
1805c6ee-e9da-4df3-ae23-5474db169149	021ed729-50a2-46b7-86d2-960eb2f84b38	M4	bmw-m4	coupe	\N	\N	2026-07-19 13:56:42.288544
ee3ce7d8-6067-4bdf-9aa8-f770f290fd6c	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	A3	audi-a3	sedan	\N	\N	2026-07-19 13:56:42.295791
c300d864-ea14-4cf4-9306-bf4a26adc357	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	A6	audi-a6	sedan	\N	\N	2026-07-19 13:56:42.309808
141aadb8-e723-455c-8c31-9d5493987b6a	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	A8	audi-a8	sedan	\N	\N	2026-07-19 13:56:42.316665
131dc8ff-6e5a-47fc-b849-ac833ab97485	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	Q2	audi-q2	suv	\N	\N	2026-07-19 13:56:42.323338
a3cfe5b8-9302-4fb0-8fb3-393fa0324750	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	Q3	audi-q3	suv	\N	\N	2026-07-19 13:56:42.329665
80b85590-cb02-476e-873f-c5c366ad80f6	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	Q5	audi-q5	suv	\N	\N	2026-07-19 13:56:42.336825
91beef11-c434-461e-a868-6f50eb46e139	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	Q7	audi-q7	suv	\N	\N	2026-07-19 13:56:42.343344
71288856-5880-4033-b37f-1e8fa4627a15	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	Q8	audi-q8	suv	\N	\N	2026-07-19 13:56:42.352755
0c404a05-a501-4c7f-9b93-7583d30c2dcf	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	A5	audi-a5	coupe	\N	\N	2026-07-19 13:56:42.359872
b44422b9-4d50-46c7-a8d9-9c2393293ab5	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	A7	audi-a7	coupe	\N	\N	2026-07-19 13:56:42.366873
3333eb6b-2ea4-4f1b-8e01-44eda2cc0412	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	TT	audi-tt	coupe	\N	\N	2026-07-19 13:56:42.373231
5399a127-9515-44fd-8b43-c9f2937adc05	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	e-tron	audi-e-tron	suv	\N	\N	2026-07-19 13:56:42.379907
0428e654-a8e2-4d0d-88c1-1c2cc656784b	efd772c5-ce5b-4b45-8ca8-fdcf7689c098	Q4 e-tron	audi-q4-e-tron	suv	\N	\N	2026-07-19 13:56:42.387691
32b9cc98-4837-4aaa-ada6-31ec178e8873	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Polo	volkswagen-polo	hatchback	\N	\N	2026-07-19 13:56:42.395219
fb577e1c-7ed8-47fc-a9d3-eabea748799a	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Golf	volkswagen-golf	hatchback	\N	\N	2026-07-19 13:56:42.401708
d04a9293-7a38-40b2-8f13-40a3e147c9ed	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Jetta	volkswagen-jetta	sedan	\N	\N	2026-07-19 13:56:42.408638
4f7f3177-9b97-4eab-8719-7665176e0548	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Passat	volkswagen-passat	sedan	\N	\N	2026-07-19 13:56:42.414962
24fb8c41-b4d4-4b12-bcfb-cf62bc446588	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Arteon	volkswagen-arteon	sedan	\N	\N	2026-07-19 13:56:42.422315
2e429dba-d1ec-44d1-a373-53aa68feb5e3	9436bf35-b78d-42b7-a0ae-443cb2ceec72	T-Roc	volkswagen-t-roc	crossover	\N	\N	2026-07-19 13:56:42.428812
10b540a2-3909-4411-b231-efa0b4c39f5c	9436bf35-b78d-42b7-a0ae-443cb2ceec72	T-Cross	volkswagen-t-cross	crossover	\N	\N	2026-07-19 13:56:42.435635
3c65b2e1-65e2-48ac-8eeb-4ff44029ffa2	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Touareg	volkswagen-touareg	suv	\N	\N	2026-07-19 13:56:42.4486
e20b4609-c6e7-4fd8-8d3c-e137fe649137	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Teramont	volkswagen-teramont	suv	\N	\N	2026-07-19 13:56:42.455299
10b7861d-aabf-4398-88f5-5164cf95763c	9436bf35-b78d-42b7-a0ae-443cb2ceec72	ID.4	volkswagen-id-4	suv	\N	\N	2026-07-19 13:56:42.462134
7a73559f-ad53-4711-835c-b30f576c2705	9436bf35-b78d-42b7-a0ae-443cb2ceec72	ID.6	volkswagen-id-6	suv	\N	\N	2026-07-19 13:56:42.46856
88ff4d7d-adad-43aa-8260-6ecd524ceb81	9436bf35-b78d-42b7-a0ae-443cb2ceec72	Caddy	volkswagen-caddy	van	\N	\N	2026-07-19 13:56:42.475474
d78009a6-63f1-4a90-b6c7-7beb1e1de80f	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Renegade	jeep-renegade	suv	\N	\N	2026-07-19 13:56:42.485924
d56fbab3-9288-4b7e-8052-d515835a9552	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Compass	jeep-compass	suv	\N	\N	2026-07-19 13:56:42.496316
0516073b-afdd-4ee3-a7e7-8e1b64428686	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Cherokee	jeep-cherokee	suv	\N	\N	2026-07-19 13:56:42.505853
d680cfbe-4d68-48be-aa30-493b786a2e8f	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Wrangler	jeep-wrangler	suv	\N	\N	2026-07-19 13:56:42.519279
3f062250-0f9d-420a-bf85-bb2fd51d6721	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Gladiator	jeep-gladiator	pickup	\N	\N	2026-07-19 13:56:42.526664
ed5fc8de-c750-48b3-a3a3-e7afa9f3fb77	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Wagoneer	jeep-wagoneer	suv	\N	\N	2026-07-19 13:56:42.533739
67122301-79d7-4c1d-8172-74c43725f496	111fe2b5-cb8b-4dc8-ab07-e77500b0ae29	Grand Wagoneer	jeep-grand-wagoneer	suv	\N	\N	2026-07-19 13:56:42.540956
01953f9a-bd1f-42e8-ab05-ea63bfe1ec08	4d28e82a-1aa0-4654-86ca-836324dddb7c	Logan	renault-logan	sedan	\N	\N	2026-07-19 13:56:42.547899
9df6e9d9-300c-423e-ba5f-774bc59edb98	4d28e82a-1aa0-4654-86ca-836324dddb7c	Sandero	renault-sandero	hatchback	\N	\N	2026-07-19 13:56:42.554905
69b949fd-175e-4fe2-9c61-288994410093	4d28e82a-1aa0-4654-86ca-836324dddb7c	Megane	renault-megane	sedan	\N	\N	2026-07-19 13:56:42.561472
213b30e7-95d8-4b84-82fc-3bfd0a6dc240	4d28e82a-1aa0-4654-86ca-836324dddb7c	Fluence	renault-fluence	sedan	\N	\N	2026-07-19 13:56:42.571294
2050234b-a1bf-45ba-b5c4-9297669d9aa2	4d28e82a-1aa0-4654-86ca-836324dddb7c	Clio	renault-clio	hatchback	\N	\N	2026-07-19 13:56:42.577917
1db2a09f-744c-4f04-a9b1-88b3f7ff3679	4d28e82a-1aa0-4654-86ca-836324dddb7c	Kwid	renault-kwid	hatchback	\N	\N	2026-07-19 13:56:42.588229
d1030274-bce6-47a3-be71-8f3bc55da0ae	4d28e82a-1aa0-4654-86ca-836324dddb7c	Captur	renault-captur	crossover	\N	\N	2026-07-19 13:56:42.601906
f5b8f6f4-262b-4674-a8da-49b3e214f9b1	4d28e82a-1aa0-4654-86ca-836324dddb7c	Kadjar	renault-kadjar	suv	\N	\N	2026-07-19 13:56:42.608445
a712af4c-9002-4e45-856b-997c3831b62b	4d28e82a-1aa0-4654-86ca-836324dddb7c	Koleos	renault-koleos	suv	\N	\N	2026-07-19 13:56:42.615254
e869aee7-71e8-43df-bdc3-9038fff83fed	4d28e82a-1aa0-4654-86ca-836324dddb7c	Austral	renault-austral	suv	\N	\N	2026-07-19 13:56:42.621545
78eaeb70-cc0a-4d08-993c-ebff6831182d	4d28e82a-1aa0-4654-86ca-836324dddb7c	Talisman	renault-talisman	sedan	\N	\N	2026-07-19 13:56:42.62844
f866563a-3d1c-4162-91b4-8bb3775b52ee	9a4722eb-e61a-46a5-8605-42defc479a6f	301	peugeot-301	sedan	\N	\N	2026-07-19 13:56:42.64542
1b92598c-c799-495e-87aa-9bed7e68f98c	9a4722eb-e61a-46a5-8605-42defc479a6f	308	peugeot-308	hatchback	\N	\N	2026-07-19 13:56:42.654328
4c59b461-6aa5-49c7-a363-419d942f36cb	9a4722eb-e61a-46a5-8605-42defc479a6f	508	peugeot-508	sedan	\N	\N	2026-07-19 13:56:42.662377
b6c44f15-5738-47f5-b839-063c0cdb8281	9a4722eb-e61a-46a5-8605-42defc479a6f	2008	peugeot-2008	crossover	\N	\N	2026-07-19 13:56:42.668741
403e188d-8431-4b97-acbd-144575176212	9a4722eb-e61a-46a5-8605-42defc479a6f	3008	peugeot-3008	suv	\N	\N	2026-07-19 13:56:42.675841
0591bfc2-a147-421e-9bb7-a2fb5b1992e0	9a4722eb-e61a-46a5-8605-42defc479a6f	5008	peugeot-5008	suv	\N	\N	2026-07-19 13:56:42.682204
3c947efd-1558-497f-8862-7acb493eda47	9a4722eb-e61a-46a5-8605-42defc479a6f	Partner	peugeot-partner	van	\N	\N	2026-07-19 13:56:42.689219
5ce11b05-ecd3-4375-be0a-f8fb960f7508	9a4722eb-e61a-46a5-8605-42defc479a6f	Rifter	peugeot-rifter	minivan	\N	\N	2026-07-19 13:56:42.695624
8797461f-e39c-420b-a8aa-4d81b525eac1	9a4722eb-e61a-46a5-8605-42defc479a6f	Landtrek	peugeot-landtrek	pickup	\N	\N	2026-07-19 13:56:42.703124
cdab8254-b470-40ca-a6c4-bb404a2de88d	01092beb-86ae-4ed5-81f2-efe9eb0fb717	MG3	mg-mg3	hatchback	\N	\N	2026-07-19 13:56:42.710372
595c37c9-f6a3-4ed8-a572-a468f688a678	01092beb-86ae-4ed5-81f2-efe9eb0fb717	MG4	mg-mg4	hatchback	\N	\N	2026-07-19 13:56:42.717374
4af97ecf-9c0e-41db-85e9-8cddf088fa7c	01092beb-86ae-4ed5-81f2-efe9eb0fb717	MG5	mg-mg5	sedan	\N	\N	2026-07-19 13:56:42.723874
11b668c2-84c3-4b9b-b4ef-067a7e796492	01092beb-86ae-4ed5-81f2-efe9eb0fb717	MG6	mg-mg6	sedan	\N	\N	2026-07-19 13:56:42.73101
204c7543-1025-4cef-9f8c-bdb99385fdc5	01092beb-86ae-4ed5-81f2-efe9eb0fb717	MG7	mg-mg7	sedan	\N	\N	2026-07-19 13:56:42.737637
03f08f31-df6b-4885-91c9-0f4deb829abe	01092beb-86ae-4ed5-81f2-efe9eb0fb717	GT	mg-gt	sedan	\N	\N	2026-07-19 13:56:42.744887
11fc66b1-843a-46d1-9a05-103057e8305c	01092beb-86ae-4ed5-81f2-efe9eb0fb717	HS	mg-hs	suv	\N	\N	2026-07-19 13:56:42.75985
e1dd9fa3-4d81-451e-8f88-7256edb5cfae	01092beb-86ae-4ed5-81f2-efe9eb0fb717	RX5	mg-rx5	suv	\N	\N	2026-07-19 13:56:42.766555
1b8f84c5-2381-4925-8624-9abe65bc8a2a	01092beb-86ae-4ed5-81f2-efe9eb0fb717	RX8	mg-rx8	suv	\N	\N	2026-07-19 13:56:42.773753
f317e076-f40c-4ffa-9356-a83340ba7ff3	01092beb-86ae-4ed5-81f2-efe9eb0fb717	One	mg-one	suv	\N	\N	2026-07-19 13:56:42.780045
45939a81-fb1a-4b1b-bc35-05ce6265ac2e	01092beb-86ae-4ed5-81f2-efe9eb0fb717	Marvel R	mg-marvel-r	suv	\N	\N	2026-07-19 13:56:42.787616
e41d3a90-b894-4033-b8a1-9f21c33ea045	9de73407-dd78-4d29-8a65-2def29e5ee56	Arrizo 5	chery-arrizo-5	sedan	\N	\N	2026-07-19 13:56:42.794994
2fea0e95-ba57-4f25-aa12-b4b2dc8394d9	9de73407-dd78-4d29-8a65-2def29e5ee56	Arrizo 6	chery-arrizo-6	sedan	\N	\N	2026-07-19 13:56:42.805142
481fad8b-6595-4c8f-9596-10cc23c85c73	9de73407-dd78-4d29-8a65-2def29e5ee56	Arrizo 8	chery-arrizo-8	sedan	\N	\N	2026-07-19 13:56:42.811481
1af3f6ae-0056-4f8a-ab98-69fdc369b97c	9de73407-dd78-4d29-8a65-2def29e5ee56	Tiggo 2	chery-tiggo-2	suv	\N	\N	2026-07-19 13:56:42.818353
23546fab-a68b-4f4a-8bb8-5b39612f80cc	9de73407-dd78-4d29-8a65-2def29e5ee56	Tiggo 3	chery-tiggo-3	suv	\N	\N	2026-07-19 13:56:42.825317
cfcee182-ea8c-4d7b-a5a3-3bd45d5cfcc9	9de73407-dd78-4d29-8a65-2def29e5ee56	Tiggo 4	chery-tiggo-4	suv	\N	\N	2026-07-19 13:56:42.836203
b1127f1f-0df2-4f98-b255-7cf29dc759d1	9de73407-dd78-4d29-8a65-2def29e5ee56	Tiggo 7	chery-tiggo-7	suv	\N	\N	2026-07-19 13:56:42.842766
68cb1c9b-ec3d-461e-97cf-47288fe0c908	9de73407-dd78-4d29-8a65-2def29e5ee56	Tiggo 7 Pro	chery-tiggo-7-pro	suv	\N	\N	2026-07-19 13:56:42.849844
afb8237f-1f73-4311-8331-20c74d101bd1	9de73407-dd78-4d29-8a65-2def29e5ee56	Tiggo 8	chery-tiggo-8	suv	\N	\N	2026-07-19 13:56:42.856351
99c2a6b5-0cf3-4f74-ada2-5ff5c34e9603	9de73407-dd78-4d29-8a65-2def29e5ee56	Tiggo 8 Pro	chery-tiggo-8-pro	suv	\N	\N	2026-07-19 13:56:42.863279
e71d7ee9-fa93-4b26-aac5-d2b823e83b86	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Seagull	byd-seagull	hatchback	\N	\N	2026-07-19 13:56:42.870963
352d449a-a82c-45bc-a46e-5bbf2291191a	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Dolphin	byd-dolphin	hatchback	\N	\N	2026-07-19 13:56:42.878272
1d2476f1-e461-43ca-b167-bbbc9680daf5	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Atto 3	byd-atto-3	suv	\N	\N	2026-07-19 13:56:42.884705
c515cff7-dfb5-45e4-a6a8-0a4ab6fe62b3	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Yuan Plus	byd-yuan-plus	suv	\N	\N	2026-07-19 13:56:42.891588
3a2787e7-366e-4b97-9313-431808a41e17	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Song	byd-song	suv	\N	\N	2026-07-19 13:56:42.898175
5a5f2e27-8f8e-4661-aded-c7baf6fddfec	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Tang	byd-tang	suv	\N	\N	2026-07-19 13:56:43.021548
1af55b77-ede9-4088-b114-ee5fdbfe6c88	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Qin	byd-qin	sedan	\N	\N	2026-07-19 13:56:43.029807
05b3b952-a5c6-42cd-a1db-596f787ee093	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Han	byd-han	sedan	\N	\N	2026-07-19 13:56:43.037406
418883c0-d588-4b75-bc5d-eb1f84734027	65400ac9-ebc7-46cf-bdda-ea0d807f2401	Seal	byd-seal	sedan	\N	\N	2026-07-19 13:56:43.044068
b92ab1c0-8634-4c98-93c0-3121910baf5e	65400ac9-ebc7-46cf-bdda-ea0d807f2401	F3	byd-f3	sedan	\N	\N	2026-07-19 13:56:43.051196
f3557158-3c03-4465-b4b3-87bb38247716	ec5e2fe8-0d74-446c-b31d-868d58560867	Alto	suzuki-alto	hatchback	\N	\N	2026-07-19 13:56:43.058784
c3e70797-c7da-45e4-9518-7dd8b461037d	ec5e2fe8-0d74-446c-b31d-868d58560867	Celerio	suzuki-celerio	hatchback	\N	\N	2026-07-19 13:56:43.065893
09641d9c-1eb9-4ace-9e9a-fc1e2cef386c	ec5e2fe8-0d74-446c-b31d-868d58560867	Swift	suzuki-swift	hatchback	\N	\N	2026-07-19 13:56:43.072782
82d878c5-e650-4101-9177-1f924ee6e993	ec5e2fe8-0d74-446c-b31d-868d58560867	Baleno	suzuki-baleno	hatchback	\N	\N	2026-07-19 13:56:43.079885
ffad0488-121b-4051-ac10-cdb393c8cf3b	ec5e2fe8-0d74-446c-b31d-868d58560867	S-Presso	suzuki-s-presso	hatchback	\N	\N	2026-07-19 13:56:43.086267
256b8d43-691d-460f-a657-fcfe8ecef305	ec5e2fe8-0d74-446c-b31d-868d58560867	Dzire	suzuki-dzire	sedan	\N	\N	2026-07-19 13:56:43.094028
5c67d1de-3756-469a-aaf1-976e74ac9ed3	ec5e2fe8-0d74-446c-b31d-868d58560867	Ciaz	suzuki-ciaz	sedan	\N	\N	2026-07-19 13:56:43.100498
3fae4f12-1c88-4078-bec1-0cab9eb362b8	ec5e2fe8-0d74-446c-b31d-868d58560867	Fronx	suzuki-fronx	crossover	\N	\N	2026-07-19 13:56:43.107533
5efe75f4-e56e-4a26-a20a-5d45ce9356e2	ec5e2fe8-0d74-446c-b31d-868d58560867	Vitara	suzuki-vitara	suv	\N	\N	2026-07-19 13:56:43.11402
70973345-a27a-46a9-b756-8ff112ec32ae	ec5e2fe8-0d74-446c-b31d-868d58560867	Grand Vitara	suzuki-grand-vitara	suv	\N	\N	2026-07-19 13:56:43.121329
b61fcc34-dac6-4a54-9052-2d90f8e9163e	ec5e2fe8-0d74-446c-b31d-868d58560867	Jimny	suzuki-jimny	suv	\N	\N	2026-07-19 13:56:43.127787
4d48035f-7a1e-4dcc-ba20-b3196acf43b9	ec5e2fe8-0d74-446c-b31d-868d58560867	Ertiga	suzuki-ertiga	minivan	\N	\N	2026-07-19 13:56:43.136198
ded6cae2-ef84-4aea-a38c-af6c59a31995	ec5e2fe8-0d74-446c-b31d-868d58560867	XL7	suzuki-xl7	suv	\N	\N	2026-07-19 13:56:43.143269
fd8848b5-b866-4256-bf7e-5ec521285ad2	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Fabia	skoda-fabia	hatchback	\N	\N	2026-07-19 13:56:43.151157
d7b79dac-8176-47dc-8d4d-1f95a8f3b155	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Scala	skoda-scala	hatchback	\N	\N	2026-07-19 13:56:43.157746
6d39f47e-2c51-4307-b803-7476208ac02c	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Rapid	skoda-rapid	sedan	\N	\N	2026-07-19 13:56:43.165192
287f5454-8b7f-4d73-8da4-7a288443f622	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Octavia	skoda-octavia	sedan	\N	\N	2026-07-19 13:56:43.17169
4ce87c95-6a33-4e80-9de6-e4c0f328ee9e	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Superb	skoda-superb	sedan	\N	\N	2026-07-19 13:56:43.179959
672620e2-10f2-442c-8e57-afc4181f9ba4	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Kamiq	skoda-kamiq	crossover	\N	\N	2026-07-19 13:56:43.186424
b7bf3e6d-823a-41d8-8bc8-a2eea0755b99	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Karoq	skoda-karoq	suv	\N	\N	2026-07-19 13:56:43.194586
218cd8c0-4e1c-474b-b8d4-e890414e17f4	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Kodiaq	skoda-kodiaq	suv	\N	\N	2026-07-19 13:56:43.201129
10292e6a-db27-4e5c-814a-1d86c53489b6	9a5680ec-d6bb-458d-a845-7e3af9ed512a	Enyaq	skoda-enyaq	suv	\N	\N	2026-07-19 13:56:43.20839
7623e103-7f44-43a2-8317-0cb866636651	7c9ab19c-c70f-4792-b3d2-1303530dd83a	Emgrand	geely-emgrand	sedan	\N	\N	2026-07-19 13:56:43.215452
b41159f8-5160-4e80-8d7f-0e843ce18991	7c9ab19c-c70f-4792-b3d2-1303530dd83a	Preface	geely-preface	sedan	\N	\N	2026-07-19 13:56:43.225009
7423d815-66b2-48bb-9bbc-57bdcfa43668	7c9ab19c-c70f-4792-b3d2-1303530dd83a	Coolray	geely-coolray	suv	\N	\N	2026-07-19 13:56:43.232184
1021e3bf-8601-4dea-aa46-4acf4a117607	7c9ab19c-c70f-4792-b3d2-1303530dd83a	Azkarra	geely-azkarra	suv	\N	\N	2026-07-19 13:56:43.239724
657f4097-5d67-4044-a3c8-139e6ac622f3	7c9ab19c-c70f-4792-b3d2-1303530dd83a	Tugella	geely-tugella	suv	\N	\N	2026-07-19 13:56:43.24671
5d5bb421-4ce5-4137-ae1f-273b3e72fb7b	7c9ab19c-c70f-4792-b3d2-1303530dd83a	Okavango	geely-okavango	suv	\N	\N	2026-07-19 13:56:43.254199
6e0965a7-4e9f-4fe6-b083-d4071bdf1eb4	7c9ab19c-c70f-4792-b3d2-1303530dd83a	Monjaro	geely-monjaro	suv	\N	\N	2026-07-19 13:56:43.260774
454796f0-f8f5-4b34-8fd0-981563c7c183	7c9ab19c-c70f-4792-b3d2-1303530dd83a	Starray	geely-starray	suv	\N	\N	2026-07-19 13:56:43.268785
91e628f4-a85a-4e03-8a02-43fa27db0ca3	7c9ab19c-c70f-4792-b3d2-1303530dd83a	GX3 Pro	geely-gx3-pro	suv	\N	\N	2026-07-19 13:56:43.275335
bb664474-2fee-4641-81a8-84b5f95cd958	be87cc45-47d1-49db-bc9e-43296357d41a	Jolion	haval-jolion	suv	\N	\N	2026-07-19 13:56:43.282996
6d7fca3c-5781-489c-9c8c-471fd0357415	be87cc45-47d1-49db-bc9e-43296357d41a	H6	haval-h6	suv	\N	\N	2026-07-19 13:56:43.289558
da3c6c7c-4d68-4887-b31e-e6f8ab81bef2	be87cc45-47d1-49db-bc9e-43296357d41a	H9	haval-h9	suv	\N	\N	2026-07-19 13:56:43.296752
7f6ba73e-e6c0-453d-aaa5-54367f3a3c3b	be87cc45-47d1-49db-bc9e-43296357d41a	Dargo	haval-dargo	suv	\N	\N	2026-07-19 13:56:43.303823
cdd4401e-e752-4241-a1f1-1b1ece8499bd	be87cc45-47d1-49db-bc9e-43296357d41a	H2	haval-h2	suv	\N	\N	2026-07-19 13:56:43.31118
b8819112-8b68-4ec4-bf10-aa3bfb98795c	be87cc45-47d1-49db-bc9e-43296357d41a	F7	haval-f7	suv	\N	\N	2026-07-19 13:56:43.317669
9256a23e-7c2e-4dcd-875c-378a81bf5f33	be87cc45-47d1-49db-bc9e-43296357d41a	M6	haval-m6	suv	\N	\N	2026-07-19 13:56:43.324535
d604e29d-7bf1-4716-b8d5-d0fe24ad91bf	e6384217-6e92-41f6-885a-7a26fa24d51b	Figo	ford-figo	hatchback	\N	\N	2026-07-19 13:56:43.332212
5e17d6e4-56a7-4a55-b144-566c330561bf	e6384217-6e92-41f6-885a-7a26fa24d51b	Fiesta	ford-fiesta	hatchback	\N	\N	2026-07-19 13:56:43.339479
155e668e-5a76-4900-9710-4ce931b48286	e6384217-6e92-41f6-885a-7a26fa24d51b	Focus	ford-focus	sedan	\N	\N	2026-07-19 13:56:43.34611
ffd6d8fb-035b-402b-9b7b-69ec89dc3915	e6384217-6e92-41f6-885a-7a26fa24d51b	Fusion	ford-fusion	sedan	\N	\N	2026-07-19 13:56:43.35333
bc4fcbba-4ead-489b-9479-10288ba05705	e6384217-6e92-41f6-885a-7a26fa24d51b	Taurus	ford-taurus	sedan	\N	\N	2026-07-19 13:56:43.361275
8a13fa9e-14be-45d8-b3d1-45f499276940	e6384217-6e92-41f6-885a-7a26fa24d51b	EcoSport	ford-ecosport	suv	\N	\N	2026-07-19 13:56:43.368314
a7b7bfd2-c794-4950-9e1c-cbb6b1351fd0	e6384217-6e92-41f6-885a-7a26fa24d51b	Territory	ford-territory	suv	\N	\N	2026-07-19 13:56:43.374929
b3234918-a678-4877-af4a-e98bcf283f8e	e6384217-6e92-41f6-885a-7a26fa24d51b	Kuga	ford-kuga	suv	\N	\N	2026-07-19 13:56:43.382074
e1d4392c-1c38-48f8-ae10-caf8589ea814	e6384217-6e92-41f6-885a-7a26fa24d51b	Edge	ford-edge	suv	\N	\N	2026-07-19 13:56:43.388666
5e3f023a-1563-4aa8-b6ac-672f9fddcacc	e6384217-6e92-41f6-885a-7a26fa24d51b	Explorer	ford-explorer	suv	\N	\N	2026-07-19 13:56:43.396354
635a7028-dbae-4494-a110-0180b8dcddab	e6384217-6e92-41f6-885a-7a26fa24d51b	Everest	ford-everest	suv	\N	\N	2026-07-19 13:56:43.403112
f1cc5c1a-36c7-4252-b32d-5dfafeca0c77	e6384217-6e92-41f6-885a-7a26fa24d51b	Bronco	ford-bronco	suv	\N	\N	2026-07-19 13:56:43.410765
531c2acd-2491-4ac7-a26e-240f6bc5580b	e6384217-6e92-41f6-885a-7a26fa24d51b	Ranger	ford-ranger	pickup	\N	\N	2026-07-19 13:56:43.41723
cc023ba8-e915-4fff-a341-8e737d5ac744	e6384217-6e92-41f6-885a-7a26fa24d51b	F-150	ford-f-150	pickup	\N	\N	2026-07-19 13:56:43.424454
98170462-8262-4f5d-a32f-0057d2b93109	e6384217-6e92-41f6-885a-7a26fa24d51b	Mustang	ford-mustang	coupe	\N	\N	2026-07-18 21:27:17.70685
8e5864fa-2b46-41c2-86be-fef676134b4a	e6384217-6e92-41f6-885a-7a26fa24d51b	Transit	ford-transit	van	\N	\N	2026-07-19 13:56:43.438728
3e4afe46-796a-4786-990d-e9da187d8dd1	3c3f05b7-bc1c-4dc8-b4ba-7d5627bac975	Corsa	opel-corsa	hatchback	\N	\N	2026-07-19 13:56:43.446147
f788cb7b-c7e0-4157-8d5d-b913debd482a	3c3f05b7-bc1c-4dc8-b4ba-7d5627bac975	Astra	opel-astra	hatchback	\N	\N	2026-07-19 13:56:43.453445
575fdc75-9503-4d5b-8408-8e9d39f66d9a	3c3f05b7-bc1c-4dc8-b4ba-7d5627bac975	Insignia	opel-insignia	sedan	\N	\N	2026-07-19 13:56:43.46046
f2014ab5-37cb-4897-a731-3c5457fa886a	3c3f05b7-bc1c-4dc8-b4ba-7d5627bac975	Crossland	opel-crossland	crossover	\N	\N	2026-07-19 13:56:43.46775
4e2a7b95-eb50-465b-9b9a-7e9665a02a78	3c3f05b7-bc1c-4dc8-b4ba-7d5627bac975	Mokka	opel-mokka	crossover	\N	\N	2026-07-19 13:56:43.474926
5fa51526-6983-4595-8f34-6150ac417435	3c3f05b7-bc1c-4dc8-b4ba-7d5627bac975	Grandland	opel-grandland	suv	\N	\N	2026-07-19 13:56:43.48278
e0f16bb9-76cb-444f-9f3b-d45cefcd438a	3c3f05b7-bc1c-4dc8-b4ba-7d5627bac975	Combo	opel-combo	van	\N	\N	2026-07-19 13:56:43.490145
b22bd64f-e651-4231-8d56-6c3497e5c58b	92334d9b-b7c7-439e-b661-57d5df4f34a1	500	fiat-500	hatchback	\N	\N	2026-07-19 13:56:43.498402
9650a1d0-4c06-4284-bf0e-cd12babdc0c3	92334d9b-b7c7-439e-b661-57d5df4f34a1	Panda	fiat-panda	hatchback	\N	\N	2026-07-19 13:56:43.505262
7eb30bd8-49fb-4e1f-a7ac-846416a81cfd	92334d9b-b7c7-439e-b661-57d5df4f34a1	Punto	fiat-punto	hatchback	\N	\N	2026-07-19 13:56:43.512958
36a687c6-2502-4763-a674-355c027d9602	92334d9b-b7c7-439e-b661-57d5df4f34a1	Tipo	fiat-tipo	sedan	\N	\N	2026-07-19 13:56:43.52014
f0b2785a-a27d-4534-94eb-a7211995c1bf	92334d9b-b7c7-439e-b661-57d5df4f34a1	500X	fiat-500x	crossover	\N	\N	2026-07-19 13:56:43.527342
6fc37dae-1d84-427c-9e7b-929ece5b38b2	92334d9b-b7c7-439e-b661-57d5df4f34a1	Doblo	fiat-doblo	van	\N	\N	2026-07-19 13:56:43.533827
ce2b0426-29d2-4bc2-bfaf-23edb1280a86	92334d9b-b7c7-439e-b661-57d5df4f34a1	Fiorino	fiat-fiorino	van	\N	\N	2026-07-19 13:56:43.54119
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_preferences (id, user_id, type, in_app, email, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, type, title, body, data, read_at, created_at) FROM stdin;
d3cac85b-61af-480e-a70a-b5387586423a	7a1f2488-111c-445b-9169-35e6b7eb37b4	payment_success	تم الدفع بنجاح · Payment successful	تم تسجيل رسوم مهتم بمبلغ 30.00 ج.م. · Lead charge of 30.00 EGP recorded.	{"kind": "lead_charge", "amount": "30.00", "plan_name": null, "balance_after": "9970.00", "invoice_number": "INV-20260721-F3C15DE517C5", "transaction_id": "f3c15de5-17c5-4e59-9dae-b0db2ca8386b"}	\N	2026-07-21 13:33:10.241081
1a22227c-ac15-418b-a83c-cc8f482a84b6	7a1f2488-111c-445b-9169-35e6b7eb37b4	system	إعجاب جديد بإعلانك · New like on your listing	شخص حفظ «Duplex 350m² - Katameya Heights» · Someone saved "Duplex 350m² - Katameya Heights"	{"listing_id": "9322a87e-6899-4b8a-8399-280801afaff0"}	\N	2026-07-21 13:33:19.226177
8ad9d013-d2b6-47b7-8ecd-4cf1c2cefdea	7a1f2488-111c-445b-9169-35e6b7eb37b4	lead	عميل مهتم جديد · New lead	اهتمام (طلب تمويل · Finance request) بإعلان «Duplex 350m² - Katameya Heights» · New interest on your listing	{"lead_id": "11294434-f541-484a-9ea1-9c771610bf39", "listing_id": "9322a87e-6899-4b8a-8399-280801afaff0"}	\N	2026-07-21 13:33:10.241794
22cf3231-2004-498f-9d94-ec2bdf5b7fdb	760eca0f-df82-4102-9263-2cc82898272b	lead	عميل مهتم جديد · New lead	اهتمام (محادثة · Chat) بإعلان «Kia Cerato 2023 EX - 2023» · New interest on your listing	{"lead_id": "5824c17b-4eb4-4462-ad5a-383aca96c077", "listing_id": "b91b906c-199e-4872-8bd7-aa305e61d456"}	\N	2026-07-21 13:34:27.088637
3b8036c5-9190-4b44-8a42-e5dfea9e3ace	760eca0f-df82-4102-9263-2cc82898272b	payment_success	تم الدفع بنجاح · Payment successful	تم تسجيل رسوم مهتم بمبلغ 10.00 ج.م. · Lead charge of 10.00 EGP recorded.	{"kind": "lead_charge", "amount": "10.00", "plan_name": null, "balance_after": "9990.00", "invoice_number": "INV-20260721-D9EB4B3D4080", "transaction_id": "d9eb4b3d-4080-4834-9802-d039fd0d9ff1"}	\N	2026-07-21 13:34:27.09219
9e1aa582-bc1f-4c7d-ab07-574986204119	760eca0f-df82-4102-9263-2cc82898272b	message	BANCO User	رطرطز	{"listing_id": "b91b906c-199e-4872-8bd7-aa305e61d456", "conversation_id": "1387a42e-f4b5-48c7-91d8-e4269bf13ebd"}	\N	2026-07-21 13:34:30.02031
8279da88-f8f4-4818-93e7-8618fe8784e4	760eca0f-df82-4102-9263-2cc82898272b	message	BANCO User	رير	{"listing_id": "b91b906c-199e-4872-8bd7-aa305e61d456", "conversation_id": "1387a42e-f4b5-48c7-91d8-e4269bf13ebd"}	\N	2026-07-21 13:34:31.795802
326c6f7e-f1c2-4d20-9e0d-fe612fcc6755	760eca0f-df82-4102-9263-2cc82898272b	message	BANCO User	تيا	{"listing_id": "b91b906c-199e-4872-8bd7-aa305e61d456", "conversation_id": "1387a42e-f4b5-48c7-91d8-e4269bf13ebd"}	\N	2026-07-21 13:34:42.015591
\.


--
-- Data for Name: ownership_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ownership_types (id, slug, name, name_ar, sort_order, created_at) FROM stdin;
901a51ce-a749-4aa2-b396-b6cdb0c65fef	resale	Resale	إعادة بيع	0	2026-07-18 21:27:18.467459
b2e6376d-08af-45d9-bccf-fff6199f45de	primary	Primary	أولى	1	2026-07-18 21:27:18.471568
37b16bbe-b26d-4d54-b5fa-068c69c11f35	installment_ready	Installment Ready	جاهز للتقسيط	2	2026-07-18 21:27:18.47742
\.


--
-- Data for Name: payment_intents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_intents (id, user_id, amount, method, purpose, status, provider_ref, plan_id, completed_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: payment_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_options (id, listing_id, mode, down_payment, monthly_payment, duration_months, is_islamic_compliant, provider, provider_name, annual_rate_pct, profit_rate_pct) FROM stdin;
1e8592f7-8976-4f34-b6b9-2860249b081f	ad7793eb-66af-4039-8267-c59488026824	cash	\N	\N	\N	f	seller	\N	\N	\N
9ad4c8bc-c426-45d0-8d4a-ad53efdbebab	ad7793eb-66af-4039-8267-c59488026824	seller_installment	1449994	161110	36	f	seller	\N	\N	\N
44287f10-97dd-4637-9bc1-01c7b0668689	ad7793eb-66af-4039-8267-c59488026824	bank_finance	1812493	113281	48	f	bank	CIB Auto Finance	18.5	\N
697b17cf-d630-4210-894b-b9135340e471	ad7793eb-66af-4039-8267-c59488026824	bank_finance	2174991	171985	36	t	dealer	Faisal Islamic Murabaha	\N	22
f4b0586d-bea7-4911-8180-95e927600d3a	fc570df0-e974-4c5a-abbe-d2df329e8ae3	cash	\N	\N	\N	f	seller	\N	\N	\N
75458b3a-03be-44cb-8b36-373b11089c2a	fc570df0-e974-4c5a-abbe-d2df329e8ae3	seller_installment	1832697	122180	60	f	seller	\N	\N	\N
d856767a-4fa7-4d3d-8ed3-c1fb044c6270	fc570df0-e974-4c5a-abbe-d2df329e8ae3	bank_finance	2290871	143179	48	f	bank	CIB Auto Finance	18.5	\N
ca7ce60a-28d7-4d77-9574-abbcfaed9cb1	afb9180b-6d35-4e8f-9858-897749ccb3d3	cash	\N	\N	\N	f	seller	\N	\N	\N
eb7d839b-e7a0-4bf5-bfb5-b776c867b786	afb9180b-6d35-4e8f-9858-897749ccb3d3	seller_installment	2369203	394867	24	f	seller	\N	\N	\N
b3012d40-c910-4274-8b99-be156cb00ea5	afb9180b-6d35-4e8f-9858-897749ccb3d3	bank_finance	2961504	185094	48	f	bank	CIB Auto Finance	18.5	\N
b809aac9-901d-4a74-8bff-23d0d7d43ad7	afb9180b-6d35-4e8f-9858-897749ccb3d3	bank_finance	3553804	209033	48	t	dealer	ADIB Egypt Islamic	\N	21
3fe3d352-44b2-45d9-a3a3-93fb9c422e3d	5c396975-c3f2-4970-b281-f8db7cfca1bf	cash	\N	\N	\N	f	seller	\N	\N	\N
b40b776b-6edf-496d-9582-344815360875	5c396975-c3f2-4970-b281-f8db7cfca1bf	seller_installment	1372805	114400	48	f	seller	\N	\N	\N
5c015e5d-0011-4359-8ec4-a99e40f20f37	5c396975-c3f2-4970-b281-f8db7cfca1bf	bank_finance	1716007	71500	72	f	bank	QNB Alahli Auto	19.25	\N
2520dc03-2859-4915-99f4-27f6077594c7	25130e61-f0ac-4a2f-ab46-91ce6f54649f	cash	\N	\N	\N	f	seller	\N	\N	\N
a253621b-e77a-40c5-bbab-d8969cf4a995	25130e61-f0ac-4a2f-ab46-91ce6f54649f	seller_installment	600479	66720	36	f	seller	\N	\N	\N
8b17a95f-7aa8-44db-8501-5e6323a8a1b7	25130e61-f0ac-4a2f-ab46-91ce6f54649f	bank_finance	750599	37530	60	f	bank	NBE Wheels	18	\N
64514e7f-ab09-494d-9336-1c90cdd66061	25130e61-f0ac-4a2f-ab46-91ce6f54649f	bank_finance	900718	71223	36	t	dealer	Faisal Islamic Murabaha	\N	22
d295e6c8-f0f3-4000-8c4c-f44207ead499	85c4c348-d4f0-44ed-b814-60c0a881559e	cash	\N	\N	\N	f	seller	\N	\N	\N
ae5016cd-5664-4573-8886-bb5540176033	85c4c348-d4f0-44ed-b814-60c0a881559e	seller_installment	1884127	125608	60	f	seller	\N	\N	\N
11273ae4-d92f-4722-8a81-37116590e6a6	85c4c348-d4f0-44ed-b814-60c0a881559e	bank_finance	2355159	98132	72	f	bank	QNB Alahli Auto	19.25	\N
af5bee2e-c85d-4ccd-bbc6-f3b810eb62ca	f015cb68-23c1-45ac-8241-280405b54dcc	cash	\N	\N	\N	f	seller	\N	\N	\N
dc1c3f7a-d1c4-4f15-a4f5-11ddc7a85677	f015cb68-23c1-45ac-8241-280405b54dcc	seller_installment	929734	154956	24	f	seller	\N	\N	\N
3b1ef3cd-5add-4fb2-83b3-77065ba20b9e	f015cb68-23c1-45ac-8241-280405b54dcc	bank_finance	1162168	48424	72	f	bank	Banque Misr Drive	17.75	\N
c66a4939-a31b-4833-9e93-32ff04e61e92	f015cb68-23c1-45ac-8241-280405b54dcc	bank_finance	1394601	82030	48	t	dealer	ADIB Egypt Islamic	\N	21
1001b02e-0a91-423f-a16f-841ca79c512f	30cc6cc4-25df-481a-87a6-f0a2e4e82618	cash	\N	\N	\N	f	seller	\N	\N	\N
80b31f41-fee9-47bc-bd6e-dbdbbb0b92eb	30cc6cc4-25df-481a-87a6-f0a2e4e82618	seller_installment	2134543	142303	60	f	seller	\N	\N	\N
a0fa62b8-8cf0-4a07-aa04-9938e8e6566c	30cc6cc4-25df-481a-87a6-f0a2e4e82618	bank_finance	2668179	133409	60	f	bank	Banque Misr Drive	17.75	\N
90e0c819-88ad-4cb5-9915-95afd904e816	8ee87c30-45fd-451a-b437-c51e915da497	cash	\N	\N	\N	f	seller	\N	\N	\N
35f1b37c-de0b-4901-bcd2-bc5c4f59b552	8ee87c30-45fd-451a-b437-c51e915da497	seller_installment	331514	55252	24	f	seller	\N	\N	\N
697d3583-affe-4f6d-a7af-f06baab26ac6	8ee87c30-45fd-451a-b437-c51e915da497	bank_finance	414392	17266	72	f	bank	QNB Alahli Auto	19.25	\N
ee4ba0ca-13a2-46fb-994f-946415dccddd	8ee87c30-45fd-451a-b437-c51e915da497	bank_finance	497271	58982	24	t	dealer	Faisal Islamic Murabaha	\N	22
bf880279-caa3-4c7e-a118-e6a3a66f4d88	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	cash	\N	\N	\N	f	seller	\N	\N	\N
1957047e-e2ba-422a-aaba-d34ff3a35384	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	seller_installment	243350	40558	24	f	seller	\N	\N	\N
b33b3016-8226-4918-a2d0-3c2b6f714fda	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	bank_finance	304187	19012	48	f	bank	Banque Misr Drive	17.75	\N
a46b827d-9139-4ddf-919c-45be096443e9	f4b561b7-113d-4938-8330-e527db01404c	cash	\N	\N	\N	f	seller	\N	\N	\N
1d4fb361-403e-48b1-a58e-7d4d388d5a43	f4b561b7-113d-4938-8330-e527db01404c	seller_installment	194143	12943	60	f	seller	\N	\N	\N
6d91a3a4-571e-4386-9c23-4a9ce9819db8	f4b561b7-113d-4938-8330-e527db01404c	bank_finance	242678	15167	48	f	bank	QNB Alahli Auto	19.25	\N
17f23a1c-3558-4f81-9dc3-4801c125d9e4	f4b561b7-113d-4938-8330-e527db01404c	bank_finance	291214	17271	48	t	dealer	Faisal Islamic Murabaha	\N	22
338272e2-2bd1-4e9d-b566-7c6da1bed92e	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	cash	\N	\N	\N	f	seller	\N	\N	\N
beb3f031-6fa1-4c20-bf16-c4b3c58e9085	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	seller_installment	427011	71168	24	f	seller	\N	\N	\N
affc30d3-0a0d-4204-a1a6-7231c9efb41b	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	bank_finance	533763	26688	60	f	bank	CIB Auto Finance	18.5	\N
0cad6214-1484-49bb-b8f6-4c49107bb8b7	38b5547f-3272-4752-adef-419278a5a379	cash	\N	\N	\N	f	seller	\N	\N	\N
15328c3e-002b-46e2-b9c2-584def6ebee5	38b5547f-3272-4752-adef-419278a5a379	seller_installment	433458	36122	48	f	seller	\N	\N	\N
c1ed1a37-5edf-438d-8658-9ac5c28d3c91	38b5547f-3272-4752-adef-419278a5a379	bank_finance	541823	33864	48	f	bank	Banque Misr Drive	17.75	\N
d2971622-89eb-480e-9693-346d8f4b58ea	38b5547f-3272-4752-adef-419278a5a379	bank_finance	650187	38244	48	t	dealer	ADIB Egypt Islamic	\N	21
1189647c-094d-4a33-b463-b052a2636f03	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	cash	\N	\N	\N	f	seller	\N	\N	\N
9bbbcce2-49a0-4526-9368-7d289ea8a0a4	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	seller_installment	340799	37867	36	f	seller	\N	\N	\N
85b4290f-3680-472c-95bf-52676ec0a2e1	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	bank_finance	425998	17750	72	f	bank	QNB Alahli Auto	19.25	\N
b2532ad6-2f72-418a-b846-e121c54aa177	322f1d1d-f418-4a26-8e60-45d8c45858a9	cash	\N	\N	\N	f	seller	\N	\N	\N
8cb1baf4-82ff-40ce-abc0-8ff4f597e8da	322f1d1d-f418-4a26-8e60-45d8c45858a9	seller_installment	141001	9400	60	f	seller	\N	\N	\N
edba5529-70ea-44fb-8576-9c4608c0568b	322f1d1d-f418-4a26-8e60-45d8c45858a9	bank_finance	176252	8813	60	f	bank	QNB Alahli Auto	19.25	\N
2c0805e8-a3a3-4f11-8b83-b06b4d21be70	322f1d1d-f418-4a26-8e60-45d8c45858a9	bank_finance	211502	25498	24	t	dealer	Al Baraka Murabaha	\N	24
7e6affa7-83b8-4e8c-905f-91d8c0393942	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	cash	\N	\N	\N	f	seller	\N	\N	\N
ac68bafc-adb4-47a4-aa4d-2a1335a220bd	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	seller_installment	439332	73222	24	f	seller	\N	\N	\N
cac5f1fe-2818-4f7a-a4ee-5cbefec9b05e	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	bank_finance	549165	34323	48	f	bank	CIB Auto Finance	18.5	\N
0e9fa37d-d20e-4312-97cc-ca63944d6ca7	da4ea6a9-a539-457f-ab70-5e143be46366	cash	\N	\N	\N	f	seller	\N	\N	\N
843fcb75-94c7-4e98-b8ae-22c0d34d0aad	da4ea6a9-a539-457f-ab70-5e143be46366	seller_installment	375039	41671	36	f	seller	\N	\N	\N
08d757b1-4e79-4618-bdc2-dd893a3e45dc	da4ea6a9-a539-457f-ab70-5e143be46366	bank_finance	468799	29300	48	f	bank	CIB Auto Finance	18.5	\N
0aea5e85-e66e-4171-b9e3-ab3335be9d3e	da4ea6a9-a539-457f-ab70-5e143be46366	bank_finance	562559	44484	36	t	dealer	Faisal Islamic Murabaha	\N	22
04a6f030-ded8-4b9b-a4d1-cd63378c8a8e	dfa4da74-d198-413d-828c-f629a7b50189	cash	\N	\N	\N	f	seller	\N	\N	\N
f79ae9e6-17d7-48b1-b0b4-44bbe44c1ccd	dfa4da74-d198-413d-828c-f629a7b50189	seller_installment	438982	48776	36	f	seller	\N	\N	\N
297aa08e-942a-40aa-905b-648378777f0f	dfa4da74-d198-413d-828c-f629a7b50189	bank_finance	548727	22864	72	f	bank	CIB Auto Finance	18.5	\N
c2bb766e-c112-4e6d-8b3c-1f43b39d6905	8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	cash	\N	\N	\N	f	seller	\N	\N	\N
989dc55c-5777-4718-a637-8aa504433c5d	8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	seller_installment	2426160	381896	36	f	seller	\N	\N	\N
ca92ce27-c13a-4024-a919-edb10a202671	bed7ae5c-ed17-42e2-8ba4-747f178c546c	cash	\N	\N	\N	f	seller	\N	\N	\N
9f6cd1b9-1acf-432c-9fff-cb98ab279583	bed7ae5c-ed17-42e2-8ba4-747f178c546c	seller_installment	2974171	140447	120	t	seller	\N	\N	\N
5e20c702-fff8-460c-9ec8-bb75fb5b3154	b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	cash	\N	\N	\N	f	seller	\N	\N	\N
8d79da4e-d8fc-4655-a537-dbddb17f05b0	b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	seller_installment	2491994	235355	60	t	seller	\N	\N	\N
5068820d-be88-4932-a736-d2b58770e868	9f249352-cd48-4c1d-b238-ca2a015a6f20	cash	\N	\N	\N	f	seller	\N	\N	\N
c6913c05-a671-49b5-823d-9bd21be72643	9f249352-cd48-4c1d-b238-ca2a015a6f20	seller_installment	285662	19271	84	f	seller	\N	\N	\N
e2c6b107-f0e0-44c1-b80d-6a07f77b021f	5ad12c3c-5a96-4a2b-89a4-566454a6869a	cash	\N	\N	\N	f	seller	\N	\N	\N
ac4d5ff0-29a6-4efc-a704-25e6daabd727	5ad12c3c-5a96-4a2b-89a4-566454a6869a	seller_installment	180842	17079	60	f	seller	\N	\N	\N
fc410c38-8625-44cd-9fca-e3d7bd90c5e7	f7fc3936-4bc1-4375-b8c2-c173126959ea	cash	\N	\N	\N	f	seller	\N	\N	\N
a2c65ec6-98d1-4b5b-91ba-c607d443380f	f7fc3936-4bc1-4375-b8c2-c173126959ea	seller_installment	368511	24860	84	t	seller	\N	\N	\N
4e2e81ff-6167-4768-858b-13603ef28ad0	58002df9-b711-4713-8047-f828c50d6718	cash	\N	\N	\N	f	seller	\N	\N	\N
7ca97420-3324-472b-8101-6c48851ae027	58002df9-b711-4713-8047-f828c50d6718	seller_installment	220227	10400	120	t	seller	\N	\N	\N
16c78e01-a74d-4cb6-b0c1-9ef5bb4250af	906b9bd8-d0ca-4a6f-aec9-915686f8c48b	cash	\N	\N	\N	f	seller	\N	\N	\N
a0812017-a9cd-4978-8855-ced9774ab494	906b9bd8-d0ca-4a6f-aec9-915686f8c48b	seller_installment	536116	36167	84	f	seller	\N	\N	\N
d78baebe-c1bb-4ea7-a65c-5b696695f0ef	43911f51-805d-4b2c-add6-b328c2667a6e	cash	\N	\N	\N	f	seller	\N	\N	\N
e541ad2a-3f31-4c42-ba51-3bf95ea8d32a	240e7f63-766f-4fcc-b192-2df158c17999	cash	\N	\N	\N	f	seller	\N	\N	\N
c2830e71-3805-4a9c-b6ea-f32fdbbb4089	35191d0c-d69e-4d03-93c6-fd48bfd5ab4f	cash	\N	\N	\N	f	seller	\N	\N	\N
a64d3941-2cca-4093-b066-60d6e48ede4f	714ecac9-fd70-4822-8c2c-df9ae1be7994	cash	\N	\N	\N	f	seller	\N	\N	\N
07309df6-a0bd-42bd-b4d3-1cf093b3a301	000bdfd3-ef1f-43e1-b6bc-40e82258ad3e	cash	\N	\N	\N	f	seller	\N	\N	\N
908eebef-fa78-453b-99dd-b28b34f6df0d	f543b945-c700-4357-97bb-2d5f5bb9d828	cash	\N	\N	\N	f	seller	\N	\N	\N
a0fa790f-c677-43b5-8e58-280525b51937	776e660f-a9f1-4129-b969-2fed1e1a6668	cash	\N	\N	\N	f	seller	\N	\N	\N
3143070e-1868-41dc-8e88-ef575222a26d	6f8a18b3-7b7a-4eda-800c-f5ae5a5cd290	cash	\N	\N	\N	f	seller	\N	\N	\N
e6d10d1f-fb5e-4a55-9690-d916dfd6d17b	d4ddac53-a22c-460b-96f2-481482d1bc95	cash	\N	\N	\N	f	seller	\N	\N	\N
2bb1163d-5a0a-4b83-a741-a336feef165e	e10511a8-45c3-4da3-bc6e-2b192c15bd24	cash	\N	\N	\N	f	seller	\N	\N	\N
a46a7b83-31a8-4d29-b9ca-e284d0860d8a	188d6bfc-b83a-4299-8c55-d8d5505b9f4a	cash	\N	\N	\N	f	seller	\N	\N	\N
44ea71cf-ebc5-43bf-ac44-9c1450ba32db	4c1792ba-c514-454d-a4b3-39f3aad9fa71	cash	\N	\N	\N	f	seller	\N	\N	\N
d70f08ce-425a-4502-b75b-7ae995886667	a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	cash	\N	\N	\N	f	seller	\N	\N	\N
07b1f9a8-d6b1-4eda-9336-b2b0c35bd480	ce85c9c5-65f2-4876-b98c-f11d7f183b25	cash	\N	\N	\N	f	seller	\N	\N	\N
f4cda4c0-2ef5-4077-910d-3adb85b04361	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	cash	\N	\N	\N	f	seller	\N	\N	\N
e6047838-b342-478c-baa7-ce1de732be61	a89eab67-0e52-408d-8887-03d24cd3886d	cash	\N	\N	\N	f	seller	\N	\N	\N
694f3a8e-de99-402e-976f-8c2be8098f1a	d6ab50a9-fc95-4d3b-9959-b66badab140f	cash	\N	\N	\N	f	seller	\N	\N	\N
02f87759-95ae-4174-8a9f-5ebc36fa13db	1e9b6e89-66ff-460b-a11f-bfa9d27e48d0	cash	\N	\N	\N	f	seller	\N	\N	\N
5f8362ac-53ca-4d11-95b0-70976f4edca8	a702bac0-04c2-4ca6-8642-086500203e18	cash	\N	\N	\N	f	seller	\N	\N	\N
29f64947-08fe-4dcb-a165-e1d27f25d377	a702bac0-04c2-4ca6-8642-086500203e18	seller_installment	2364211	197018	48	f	seller	\N	\N	\N
838228ed-b01d-46c4-8a36-958520de1ef7	a702bac0-04c2-4ca6-8642-086500203e18	bank_finance	2955264	147763	60	f	bank	NBE Wheels	18	\N
14ecf67b-0a46-47b7-ae6b-7ae6c93ccbe9	a702bac0-04c2-4ca6-8642-086500203e18	bank_finance	3546317	427528	24	t	dealer	Al Baraka Murabaha	\N	24
b25f3101-3969-4e93-93ae-22f784109474	e986f0a2-b346-485e-8409-3ac93ab1d516	cash	\N	\N	\N	f	seller	\N	\N	\N
43c69a78-7282-4819-b298-843e8cd26003	e986f0a2-b346-485e-8409-3ac93ab1d516	seller_installment	701759	77973	36	f	seller	\N	\N	\N
31d8b0d8-9d5f-4801-b349-44d54d46641f	e986f0a2-b346-485e-8409-3ac93ab1d516	bank_finance	877199	43860	60	f	bank	Banque Misr Drive	17.75	\N
ce02a8af-8b63-45af-8ef3-a7f12ce7aded	11e3e025-ac43-4186-99c4-e90fce734514	cash	\N	\N	\N	f	seller	\N	\N	\N
4c6b8adc-bdba-4ba2-81d8-040c2527cd79	11e3e025-ac43-4186-99c4-e90fce734514	seller_installment	1374813	114568	48	f	seller	\N	\N	\N
51e99fff-89d7-4b88-bd2a-33ebc1467ec6	11e3e025-ac43-4186-99c4-e90fce734514	bank_finance	1718516	71605	72	f	bank	CIB Auto Finance	18.5	\N
69a11a09-0723-4870-9878-f6fde97e950f	11e3e025-ac43-4186-99c4-e90fce734514	bank_finance	2062220	124306	48	t	dealer	Al Baraka Murabaha	\N	24
3e3ea7a3-658a-4c81-8407-b35f12eaeb80	7f5a475c-f641-4130-ad9d-316175ceddd8	cash	\N	\N	\N	f	seller	\N	\N	\N
a23e38c9-569a-4022-87fc-cba91d1b5ad3	7f5a475c-f641-4130-ad9d-316175ceddd8	seller_installment	1502883	166987	36	f	seller	\N	\N	\N
c50253e9-c1c7-4dae-a512-401c56d65009	7f5a475c-f641-4130-ad9d-316175ceddd8	bank_finance	1878604	117413	48	f	bank	QNB Alahli Auto	19.25	\N
08d6bcdb-1fd0-4b2d-9146-f481f465abe7	bf1b64b0-40db-494e-8b66-509316a30724	cash	\N	\N	\N	f	seller	\N	\N	\N
e33c2a5d-2846-49e4-9c93-18733f4aba40	bf1b64b0-40db-494e-8b66-509316a30724	seller_installment	755954	50397	60	f	seller	\N	\N	\N
00fd12d6-7c32-499b-9f3d-812c411c6358	bf1b64b0-40db-494e-8b66-509316a30724	bank_finance	944942	47247	60	f	bank	QNB Alahli Auto	19.25	\N
0a6d07a6-ac20-4ee9-a4f8-e9268f2a4537	bf1b64b0-40db-494e-8b66-509316a30724	bank_finance	1133930	136702	24	t	dealer	Al Baraka Murabaha	\N	24
f966e2e3-94fb-4ce6-924f-a730dcbe63c0	64d60de9-2649-48e8-8636-bb76c8a0192e	cash	\N	\N	\N	f	seller	\N	\N	\N
1f9dcef5-ce18-463a-b938-93758ec0ab1c	64d60de9-2649-48e8-8636-bb76c8a0192e	seller_installment	2109691	351615	24	f	seller	\N	\N	\N
45e2a716-3f87-4138-8921-dc93085c8edf	64d60de9-2649-48e8-8636-bb76c8a0192e	bank_finance	2637114	109880	72	f	bank	CIB Auto Finance	18.5	\N
aefd5f48-a3b6-4350-b5ad-c428785f0e1d	37103385-9490-4954-9687-50f8ee9e0a26	cash	\N	\N	\N	f	seller	\N	\N	\N
1469f13e-8728-43aa-8ed7-b0d9f903482d	37103385-9490-4954-9687-50f8ee9e0a26	seller_installment	2050921	136728	60	f	seller	\N	\N	\N
07fe75a9-e194-49d5-b9ec-bd51619ed565	37103385-9490-4954-9687-50f8ee9e0a26	bank_finance	2563651	106819	72	f	bank	QNB Alahli Auto	19.25	\N
18ef2ea7-8d31-46eb-83b4-847c04203e53	37103385-9490-4954-9687-50f8ee9e0a26	bank_finance	3076381	247250	36	t	dealer	Al Baraka Murabaha	\N	24
31141845-98b2-4d1c-99fd-6035b8b5db60	1d10ee4e-0ea6-4334-bd44-cb11c2398322	cash	\N	\N	\N	f	seller	\N	\N	\N
545a330c-f95c-410c-b991-0ab801f00f2c	1d10ee4e-0ea6-4334-bd44-cb11c2398322	seller_installment	929898	77491	48	f	seller	\N	\N	\N
6c949248-6f52-4fc6-b81d-7cddbc0ec887	1d10ee4e-0ea6-4334-bd44-cb11c2398322	bank_finance	1162372	48432	72	f	bank	NBE Wheels	18	\N
a2ffa219-fc26-4a12-8f87-1d2adfc1ae8f	34a62384-7311-43f7-9d85-75275232b454	cash	\N	\N	\N	f	seller	\N	\N	\N
62b2eebd-af74-49eb-8a22-b1aa56302814	34a62384-7311-43f7-9d85-75275232b454	seller_installment	461828	76971	24	f	seller	\N	\N	\N
d8a6c79a-e643-4c50-9d7d-6d771f6664f0	34a62384-7311-43f7-9d85-75275232b454	bank_finance	577285	24054	72	f	bank	QNB Alahli Auto	19.25	\N
2ed73027-4d9e-489d-8fa4-91fa5d8f24b9	34a62384-7311-43f7-9d85-75275232b454	bank_finance	692742	55676	36	t	dealer	Al Baraka Murabaha	\N	24
1aa3cdb2-b221-4da2-8a3c-3589ec5baeac	b38f66dc-3e8a-4e27-b878-87b9ff283a56	cash	\N	\N	\N	f	seller	\N	\N	\N
420ce24a-f835-45d3-aeab-cd47b44d0852	b38f66dc-3e8a-4e27-b878-87b9ff283a56	seller_installment	258710	28746	36	f	seller	\N	\N	\N
6664cfad-5dfe-4390-b267-ddb5b93d5ead	b38f66dc-3e8a-4e27-b878-87b9ff283a56	bank_finance	323388	13474	72	f	bank	Banque Misr Drive	17.75	\N
dcc234ea-4fbb-4f19-b97f-f2d2c436f5d9	a0f30ae4-e397-4606-ae72-5a45a95a5c33	cash	\N	\N	\N	f	seller	\N	\N	\N
b05f1082-2753-4c9f-86a0-411e5bb6c1eb	a0f30ae4-e397-4606-ae72-5a45a95a5c33	seller_installment	429937	35828	48	f	seller	\N	\N	\N
d7b3518d-602a-456f-96aa-298ebb366675	a0f30ae4-e397-4606-ae72-5a45a95a5c33	bank_finance	537421	26871	60	f	bank	QNB Alahli Auto	19.25	\N
b0d80c42-375d-4524-a80b-7dc4392ac52b	a0f30ae4-e397-4606-ae72-5a45a95a5c33	bank_finance	644906	37933	48	t	dealer	ADIB Egypt Islamic	\N	21
1d45f4b7-5326-46ef-92a1-f0fa467837dd	0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	cash	\N	\N	\N	f	seller	\N	\N	\N
9f765b9d-c149-4a33-894e-83ca6c7dcd17	0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	seller_installment	465092	77515	24	f	seller	\N	\N	\N
7fd21fc2-11e7-4b15-9dc1-8fc7850be401	0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	bank_finance	581365	29068	60	f	bank	NBE Wheels	18	\N
d049c8e7-5c49-4a70-8d2b-8e9d865b599e	68870b9b-d774-47b3-862d-0c525aade4e0	cash	\N	\N	\N	f	seller	\N	\N	\N
0796eab8-cb5d-4403-ba00-dc75a60c3f45	68870b9b-d774-47b3-862d-0c525aade4e0	seller_installment	169925	18881	36	f	seller	\N	\N	\N
ca3dc69f-7885-4910-8e27-684e4cd49be0	68870b9b-d774-47b3-862d-0c525aade4e0	bank_finance	212407	10620	60	f	bank	CIB Auto Finance	18.5	\N
359fa508-c0e3-4438-ab3e-bf7271529ccc	8a1b4752-c8ad-4882-b9e1-40e845cdf053	cash	\N	\N	\N	f	seller	\N	\N	\N
e0ff978f-1ec4-4b5f-824a-7a0d85f73873	8a1b4752-c8ad-4882-b9e1-40e845cdf053	seller_installment	120991	8066	60	f	seller	\N	\N	\N
ee7f8755-c9fb-426b-89c0-a14027e34c06	8a1b4752-c8ad-4882-b9e1-40e845cdf053	bank_finance	151239	9452	48	f	bank	CIB Auto Finance	18.5	\N
2bd2b81c-289e-47b8-9310-2410f0b871fa	8a1b4752-c8ad-4882-b9e1-40e845cdf053	bank_finance	181487	10940	48	t	dealer	Al Baraka Murabaha	\N	24
efe1426a-41d7-4689-9a2b-a5e605b374f0	bd1f899c-90a2-41d6-972f-a40762374777	cash	\N	\N	\N	f	seller	\N	\N	\N
e4b00830-5b95-4f30-92f5-c093f0f696e5	bd1f899c-90a2-41d6-972f-a40762374777	seller_installment	444265	74044	24	f	seller	\N	\N	\N
d7831a02-a10b-4dfa-82c7-c2f182d0924d	bd1f899c-90a2-41d6-972f-a40762374777	bank_finance	555331	27767	60	f	bank	QNB Alahli Auto	19.25	\N
8620c5be-93ea-4429-9a2e-0347e9a8b81c	cff450de-7e28-4ffa-afdc-d8a36a6aeadd	cash	\N	\N	\N	f	seller	\N	\N	\N
c857984b-0251-40df-b782-620bec76a4c3	cff450de-7e28-4ffa-afdc-d8a36a6aeadd	seller_installment	344788	57465	24	f	seller	\N	\N	\N
c1677aa7-f631-497a-9bba-6174fb886f4a	cff450de-7e28-4ffa-afdc-d8a36a6aeadd	bank_finance	430985	26937	48	f	bank	Banque Misr Drive	17.75	\N
3d69143b-838f-4650-9304-6502abf65e4c	cff450de-7e28-4ffa-afdc-d8a36a6aeadd	bank_finance	517182	30672	48	t	dealer	Faisal Islamic Murabaha	\N	22
cd774bf1-2f3c-4734-9ed6-aba5426f63d0	b91b906c-199e-4872-8bd7-aa305e61d456	cash	\N	\N	\N	f	seller	\N	\N	\N
484d00d1-102c-46c9-8f89-456d45a2d535	b91b906c-199e-4872-8bd7-aa305e61d456	seller_installment	496113	82686	24	f	seller	\N	\N	\N
aba900a5-4548-4a30-b5f9-d421d62b51d5	b91b906c-199e-4872-8bd7-aa305e61d456	bank_finance	620142	25839	72	f	bank	CIB Auto Finance	18.5	\N
905cde55-d3e4-4ff3-9c31-e1824604590b	c3996838-428c-4cef-9199-176dd9d66848	cash	\N	\N	\N	f	seller	\N	\N	\N
25e8a038-00ed-4c59-a43a-6d2ec8a4d077	c3996838-428c-4cef-9199-176dd9d66848	seller_installment	1076472	119608	36	f	seller	\N	\N	\N
f1cfd3f2-14e7-4000-91ad-10f8ab7465a8	c3996838-428c-4cef-9199-176dd9d66848	bank_finance	1345590	67279	60	f	bank	NBE Wheels	18	\N
8871228f-7035-41ae-8f05-618656a8c923	c3996838-428c-4cef-9199-176dd9d66848	bank_finance	1614707	191522	24	t	dealer	Faisal Islamic Murabaha	\N	22
4373f332-6f84-47ad-81bb-6cd496726717	29113513-b741-470e-847a-57ff621f0f19	cash	\N	\N	\N	f	seller	\N	\N	\N
e0433ed2-ceb1-4f45-827f-62900cf902d9	29113513-b741-470e-847a-57ff621f0f19	seller_installment	2192510	146167	60	f	seller	\N	\N	\N
7f6fd282-5ac2-459f-a25d-0dbc79eadcc8	29113513-b741-470e-847a-57ff621f0f19	bank_finance	2740638	114193	72	f	bank	CIB Auto Finance	18.5	\N
a0b3dd46-9cca-4e29-b6a7-3f58c28238b6	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	cash	\N	\N	\N	f	seller	\N	\N	\N
eae31f64-69d2-4e4b-94d6-225992334c8e	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	seller_installment	1740772	193419	36	f	seller	\N	\N	\N
d561cadc-b915-48ae-8365-8c1559bd5f7a	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	bank_finance	2175965	90665	72	f	bank	NBE Wheels	18	\N
f9c5abc2-be38-4c6a-bc73-55d2210a8e8b	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	bank_finance	2611157	157395	48	t	dealer	Al Baraka Murabaha	\N	24
77ddb0c7-bd74-4566-b939-f26bc1b28601	59f4e92b-92ff-461f-ae08-dc2be8fbff30	cash	\N	\N	\N	f	seller	\N	\N	\N
e1eb4753-fe81-4988-8cb1-f25880713c42	59f4e92b-92ff-461f-ae08-dc2be8fbff30	seller_installment	2220557	370093	24	f	seller	\N	\N	\N
25d685b7-117b-4970-abc6-adafa9704d3f	59f4e92b-92ff-461f-ae08-dc2be8fbff30	bank_finance	2775696	173481	48	f	bank	Banque Misr Drive	17.75	\N
47715d79-5398-46ee-b501-22b58f219dfa	c56c0b52-50c2-4459-b4c5-19d2c401aaf0	cash	\N	\N	\N	f	seller	\N	\N	\N
f5493928-ebe3-43f6-b5bf-47c8d7fc0283	c56c0b52-50c2-4459-b4c5-19d2c401aaf0	seller_installment	1172197	97683	48	f	seller	\N	\N	\N
481f3947-8abc-4670-b392-03f4e74bca6d	c56c0b52-50c2-4459-b4c5-19d2c401aaf0	bank_finance	1465246	61052	72	f	bank	Banque Misr Drive	17.75	\N
0650f490-a919-48d4-8894-526222f61555	c56c0b52-50c2-4459-b4c5-19d2c401aaf0	bank_finance	1758295	139036	36	t	dealer	Faisal Islamic Murabaha	\N	22
83fb3aa1-053a-4aab-b10c-8c12e52d0f48	edf0deed-fa66-4c53-9ca3-5b87b10ec806	cash	\N	\N	\N	f	seller	\N	\N	\N
9c932b37-3402-4c53-8564-8e229fac5405	edf0deed-fa66-4c53-9ca3-5b87b10ec806	seller_installment	2348041	260893	36	f	seller	\N	\N	\N
beddc57d-2859-4bc1-bdb0-e1d8841f9e5a	edf0deed-fa66-4c53-9ca3-5b87b10ec806	bank_finance	2935051	122294	72	f	bank	NBE Wheels	18	\N
e3b852fe-bcf5-40b3-ae4d-3646ff892931	80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	cash	\N	\N	\N	f	seller	\N	\N	\N
2d37b296-9695-4b0b-8b80-82ff4db73ced	80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	seller_installment	1133611	125957	36	f	seller	\N	\N	\N
882c7df2-3e44-4548-808d-11bdefdd93dd	80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	bank_finance	1417014	88563	48	f	bank	Banque Misr Drive	17.75	\N
106f2b38-dda0-45ea-901a-0e06b44788fd	80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	bank_finance	1700416	102497	48	t	dealer	Al Baraka Murabaha	\N	24
6ce99e44-5e38-49c5-b7f9-f00d27cb01e6	6531a87f-7a51-454d-8dea-9660c3aa3fa3	cash	\N	\N	\N	f	seller	\N	\N	\N
059136b6-a534-41af-80c9-34b2ac80395b	6531a87f-7a51-454d-8dea-9660c3aa3fa3	seller_installment	609037	40602	60	f	seller	\N	\N	\N
529177fe-01ef-430e-94ce-7764dfb67291	6531a87f-7a51-454d-8dea-9660c3aa3fa3	bank_finance	761296	31721	72	f	bank	CIB Auto Finance	18.5	\N
fbb9f4d9-9ef7-4763-94e7-2d117e1b2972	1535dacc-8620-475f-863c-f5048d3f271f	cash	\N	\N	\N	f	seller	\N	\N	\N
65582a67-7a5b-4c10-a679-c0ddb35ca78e	1535dacc-8620-475f-863c-f5048d3f271f	seller_installment	277107	46184	24	f	seller	\N	\N	\N
3f165e06-fed8-48f3-a813-d7eb1f067219	1535dacc-8620-475f-863c-f5048d3f271f	bank_finance	346384	17319	60	f	bank	NBE Wheels	18	\N
0a7c7a45-bd2b-4bb8-9c4f-8a28e37710f5	1535dacc-8620-475f-863c-f5048d3f271f	bank_finance	415660	48898	24	t	dealer	ADIB Egypt Islamic	\N	21
dea2df11-9993-4cd7-a54d-fa81e56fe810	ff6d88fd-14e9-45f9-a2ea-552c61e61f14	cash	\N	\N	\N	f	seller	\N	\N	\N
3fea212c-747d-4946-9e01-dcd590e163a5	ff6d88fd-14e9-45f9-a2ea-552c61e61f14	seller_installment	480500	40042	48	f	seller	\N	\N	\N
73ee3860-b5b8-4ab6-b741-e0a77e64cf11	ff6d88fd-14e9-45f9-a2ea-552c61e61f14	bank_finance	600625	30031	60	f	bank	CIB Auto Finance	18.5	\N
fee5b1b8-0646-4e60-8ce9-806725a4dd52	0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	cash	\N	\N	\N	f	seller	\N	\N	\N
a0a11923-d0c5-4bc1-b6f7-3ecad3f9631a	0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	seller_installment	550746	36716	60	f	seller	\N	\N	\N
e37235c7-294c-4089-a62e-f2d7f9417b0c	0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	bank_finance	688432	28685	72	f	bank	QNB Alahli Auto	19.25	\N
23a9e8bd-caa7-4184-9628-6a0fdc3bff59	0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	bank_finance	826118	97184	24	t	dealer	ADIB Egypt Islamic	\N	21
1efbf8f8-68ba-47b5-87f3-bb193ca44469	0f2abacd-5388-4d16-88ba-19996ab07efc	cash	\N	\N	\N	f	seller	\N	\N	\N
4fa65145-676b-44ca-ab6d-c6f335eb7aa0	0f2abacd-5388-4d16-88ba-19996ab07efc	seller_installment	493104	41092	48	f	seller	\N	\N	\N
b41bba9f-ed02-4591-9dc3-9295639c8f73	0f2abacd-5388-4d16-88ba-19996ab07efc	bank_finance	616381	25683	72	f	bank	Banque Misr Drive	17.75	\N
651f5791-728a-4d4b-832a-d5d75b8778a6	228d2194-7cb3-4797-9cf6-9150f59e4b51	cash	\N	\N	\N	f	seller	\N	\N	\N
c23c56ae-d433-49ee-a643-77349210154d	228d2194-7cb3-4797-9cf6-9150f59e4b51	seller_installment	477583	79597	24	f	seller	\N	\N	\N
bd0febea-c73e-4b80-8b36-a3a78a6ed27d	228d2194-7cb3-4797-9cf6-9150f59e4b51	bank_finance	596979	24874	72	f	bank	CIB Auto Finance	18.5	\N
74008557-dac2-4af9-b5ae-2f7d8670a6c1	228d2194-7cb3-4797-9cf6-9150f59e4b51	bank_finance	716374	56182	36	t	dealer	ADIB Egypt Islamic	\N	21
b17772e4-9eb0-430f-825a-da8942fc05a9	c5d495c4-7f15-4785-9ceb-444109eae4ca	cash	\N	\N	\N	f	seller	\N	\N	\N
d20ac006-7659-4f52-bb92-b0b09eb88043	c5d495c4-7f15-4785-9ceb-444109eae4ca	seller_installment	355295	59216	24	f	seller	\N	\N	\N
33a1e3b9-0c70-40bf-8acc-b1c1407c84c5	c5d495c4-7f15-4785-9ceb-444109eae4ca	bank_finance	444118	18505	72	f	bank	CIB Auto Finance	18.5	\N
d280d4e3-6c61-4bfa-85ce-dde6281860ac	f8828552-9e98-4c47-90ac-dfeafef6f259	cash	\N	\N	\N	f	seller	\N	\N	\N
214f4b54-6df0-43eb-aa8a-884b42b0b895	f8828552-9e98-4c47-90ac-dfeafef6f259	seller_installment	546051	45504	48	f	seller	\N	\N	\N
1f28b820-804c-45a1-b093-bba7e9203f64	f8828552-9e98-4c47-90ac-dfeafef6f259	bank_finance	682564	42660	48	f	bank	CIB Auto Finance	18.5	\N
dcd39435-d805-4219-baa3-8406b59db02b	f8828552-9e98-4c47-90ac-dfeafef6f259	bank_finance	819077	97152	24	t	dealer	Faisal Islamic Murabaha	\N	22
47fcd919-9512-42ac-90a6-b07b4cf6361c	bb9758f5-7491-4626-8264-f9b36e781015	cash	\N	\N	\N	f	seller	\N	\N	\N
63e4320c-0d02-4ac5-8050-70fcb6c7b476	bb9758f5-7491-4626-8264-f9b36e781015	seller_installment	444999	49444	36	f	seller	\N	\N	\N
8ac4a6a1-8b52-43df-85e1-5d29339a4b80	bb9758f5-7491-4626-8264-f9b36e781015	bank_finance	556248	34766	48	f	bank	QNB Alahli Auto	19.25	\N
8a81824b-2f88-41ee-ad44-de08b3c8ff4b	f52e2c21-9f60-4a9d-9587-28c34be4313d	cash	\N	\N	\N	f	seller	\N	\N	\N
edb24401-9d8d-4e9b-bcd3-3f198ddf5e77	f52e2c21-9f60-4a9d-9587-28c34be4313d	seller_installment	309486	25790	48	f	seller	\N	\N	\N
a0d3698d-3980-4e06-9a33-2469fc26669d	f52e2c21-9f60-4a9d-9587-28c34be4313d	bank_finance	386857	19343	60	f	bank	NBE Wheels	18	\N
4e303ee9-ef41-425c-9f78-45d97709ae7f	f52e2c21-9f60-4a9d-9587-28c34be4313d	bank_finance	464228	27306	48	t	dealer	ADIB Egypt Islamic	\N	21
7ab4f174-ba0d-4c78-94db-ae07c78fd208	dd2a3f4a-84df-49f0-96bc-405d52e30e8b	cash	\N	\N	\N	f	seller	\N	\N	\N
160f70a7-87f1-4c3a-ad31-1d8a3776d675	dd2a3f4a-84df-49f0-96bc-405d52e30e8b	seller_installment	452778	75463	24	f	seller	\N	\N	\N
3b6d3d4a-f836-402b-8c7c-c8d4af7d2bca	dd2a3f4a-84df-49f0-96bc-405d52e30e8b	bank_finance	565973	35373	48	f	bank	CIB Auto Finance	18.5	\N
4f317d4c-d8a0-4d3d-afdd-0dbcff269333	320b6f96-0528-4430-9486-842cd3c10290	cash	\N	\N	\N	f	seller	\N	\N	\N
ae346855-8ad4-491b-b9ef-420a7296cf92	320b6f96-0528-4430-9486-842cd3c10290	seller_installment	5290559	356903	84	f	seller	\N	\N	\N
4efa7df9-0c76-4043-8df6-a2089e0cf6ca	83bd6cf4-667f-46a9-9136-42841beb0ddd	cash	\N	\N	\N	f	seller	\N	\N	\N
53403fb9-66d0-40f8-b120-15265f3c1bb7	83bd6cf4-667f-46a9-9136-42841beb0ddd	seller_installment	1984647	312398	36	t	seller	\N	\N	\N
4c864525-92e0-46ea-96ff-8b5fd7ebaef8	7e2e36ae-710b-4f01-b415-163004df50d5	cash	\N	\N	\N	f	seller	\N	\N	\N
09a06d89-3226-4ad6-9197-b7086cdfa110	7e2e36ae-710b-4f01-b415-163004df50d5	seller_installment	2600192	122787	120	t	seller	\N	\N	\N
e9256d88-2abc-4973-a59c-373d9c851b99	eb1e5cc7-3431-4e72-9563-be6c520c561c	cash	\N	\N	\N	f	seller	\N	\N	\N
05f7809b-ff47-442c-bc9f-ee5fb394c30e	eb1e5cc7-3431-4e72-9563-be6c520c561c	seller_installment	375955	59178	36	f	seller	\N	\N	\N
a00fe60b-fc6c-477f-985b-9e62c17258ec	5d5f76f9-8200-4cfb-b85f-eb3167ebe59c	cash	\N	\N	\N	f	seller	\N	\N	\N
6a2ce74d-a43e-4274-82b3-70a00e1354f5	5d5f76f9-8200-4cfb-b85f-eb3167ebe59c	seller_installment	739996	69888	60	f	seller	\N	\N	\N
55ea022e-9525-4847-9b59-b3310cc5a9e4	e104a255-93b8-4ce3-b2a2-16ed2dc22047	cash	\N	\N	\N	f	seller	\N	\N	\N
1d3656d4-4acb-42c9-8293-ce8065ceab4a	e104a255-93b8-4ce3-b2a2-16ed2dc22047	seller_installment	622039	97914	36	t	seller	\N	\N	\N
5841af6a-bbe3-43a5-a5e0-676df95dd7d1	02ca95ed-3f23-4485-86bb-e822d2d20b9d	cash	\N	\N	\N	f	seller	\N	\N	\N
47cd4ef8-5ff8-4f91-b0cd-1fa3bc2a04be	02ca95ed-3f23-4485-86bb-e822d2d20b9d	seller_installment	1091350	73623	84	t	seller	\N	\N	\N
4bf72ae2-a729-486d-918c-8dcfe2a1df09	af29f0a0-62b7-48c4-8995-ae58a192b39f	cash	\N	\N	\N	f	seller	\N	\N	\N
ece38377-3d2c-4739-a46d-c92556b9c6a0	af29f0a0-62b7-48c4-8995-ae58a192b39f	seller_installment	538626	84784	36	f	seller	\N	\N	\N
ae976d31-d65f-4e0f-8448-3ead1f26a17c	7263ec34-aa0e-46ee-9603-dc3c7e555089	cash	\N	\N	\N	f	seller	\N	\N	\N
b36b6478-c14d-410f-abe3-7d1648341759	a0705f6e-b0e0-43fe-8352-90816e14fc59	cash	\N	\N	\N	f	seller	\N	\N	\N
74ee676d-600f-41dd-93f8-49d42de07931	ea279ba5-756f-456d-91d8-534388fb648a	cash	\N	\N	\N	f	seller	\N	\N	\N
47ebaffc-880e-4074-b08c-d60fcf2fc522	9150cc73-01b3-47fe-a15c-042af82ed4a3	cash	\N	\N	\N	f	seller	\N	\N	\N
82b11a39-9bce-414f-b585-9681f603e2e3	af09ae88-c0da-4079-a0f4-7aa7407ac1fc	cash	\N	\N	\N	f	seller	\N	\N	\N
67ab44eb-8878-44fd-8785-b2dbc3d98842	925a9409-46ca-4049-a382-97f840540c9d	cash	\N	\N	\N	f	seller	\N	\N	\N
c873e27b-c3f7-49e5-8d8d-94db1845ca9d	40de3002-ada5-468e-b583-788cfbeb2a35	cash	\N	\N	\N	f	seller	\N	\N	\N
cc42da63-1a44-471d-bea0-c9e9e7555f66	8c21de11-dacc-42d7-b52b-2413d53bb5ae	cash	\N	\N	\N	f	seller	\N	\N	\N
1ea8f794-e8b8-43dd-b3ec-43485c91af0f	e50a3b9d-cb4f-49df-bb51-a7a0ae37a8da	cash	\N	\N	\N	f	seller	\N	\N	\N
16a0790b-251b-42eb-990d-5c3062d53397	c5a76c3d-0b88-4859-b6d8-e557ebfaca65	cash	\N	\N	\N	f	seller	\N	\N	\N
35a0e9d9-3f56-4b35-b36a-d97c0ac64a4a	67ce4494-36b1-42c3-af3e-fe2e6b4872d3	cash	\N	\N	\N	f	seller	\N	\N	\N
5f351a87-c167-4cbb-afa6-78351cb8a7bb	d625d165-7501-4c66-9601-fea4f5c5e94a	cash	\N	\N	\N	f	seller	\N	\N	\N
\.


--
-- Data for Name: payment_provider_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_provider_config (provider, enabled, mode, public_key, integration_ids, api_base, enc_secret_key, enc_hmac_secret, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pending_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pending_locations (id, raw_name, normalized, iso_country_code, suggested_parent_id, suggested_type, occurrence_count, confidence_score, source, status, merged_into_id, first_seen_at, last_seen_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plans (id, slug, name, name_ar, audience, is_baseline, monthly_price, listing_quota, active_listing_cap, boost_price, cpl_whatsapp, cpl_call, cpl_chat, cpl_finance_request, ranking_weight, features, is_active, sort_order, created_at) FROM stdin;
97c4ac13-06f5-4df6-8658-682a175dff7d	individual_free	Individual	فردي	individual	t	0	50	50	100	0	0	0	0	1	{}	t	0	2026-07-18 21:27:18.549675
506ca60e-73df-4a5d-828a-eb0426ceb169	dealer_free	Dealer Starter	تاجر مبتدئ	dealer	t	0	50	50	150	20	15	10	30	1	{}	t	1	2026-07-18 21:27:18.555662
f17aef70-a475-4fb8-8c6c-9ee7b6f91d43	dealer_basic	Basic	أساسي	dealer	f	999	50	100	120	15	12	8	25	1.2	{"analytics": true}	t	2	2026-07-18 21:27:18.55951
45e0537f-b65f-4e0b-aad5-4fa6f02e852a	dealer_pro	Pro	احترافي	dealer	f	2999	200	400	90	12	10	6	20	1.5	{"analytics": true, "bulk_import": true, "priority_support": true}	t	3	2026-07-18 21:27:18.56733
f4111751-083b-4445-a51f-6c669b4d6bbe	dealer_enterprise	Enterprise	مؤسسي	enterprise	f	7999	\N	\N	60	8	6	4	15	2	{"analytics": true, "bulk_import": true, "priority_support": true, "dedicated_manager": true}	t	4	2026-07-18 21:27:18.571556
6189b2cd-b375-4e36-8f55-7fba456aa189	bank_featured	Bank Featured	تمييز البنوك	company	f	14999	\N	\N	0	0	0	0	0	3	{"analytics": true, "finance_partner": true, "featured_placement": true}	t	5	2026-07-18 21:27:18.575273
\.


--
-- Data for Name: price_observations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_observations (id, listing_id, category, segment_key, location_key, price, currency, attributes, source, observed_at, created_at) FROM stdin;
f2056290-5f42-4a96-8c73-f7cc1b7ea825	e986f0a2-b346-485e-8409-3ac93ab1d516	car	car|alexandria|mercedes-benz|c-class|2022-2024	alexandria	3508795.00	EGP	{"year": "2024", "brand": "Mercedes-Benz", "model": "C-Class", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-18 22:00:17.648	2026-07-19 13:57:38.72574
8ab79d34-e22b-4889-91f3-b5cde1d48a5d	fc570df0-e974-4c5a-abbe-d2df329e8ae3	car	car|alexandria|mercedes-benz|c-class|2019-2021	alexandria	9163483.00	EGP	{"year": "2019", "brand": "Mercedes-Benz", "model": "C-Class", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-05-30 21:27:21.272	2026-07-19 13:57:38.755059
5fa34ef8-ca8f-47b6-a42b-18a98e388799	5c396975-c3f2-4970-b281-f8db7cfca1bf	car	car|new-cairo|hyundai|tucson|2019-2021	new-cairo	6864026.00	EGP	{"year": "2019", "brand": "Hyundai", "model": "Tucson", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-06-14 21:27:21.272	2026-07-19 13:57:38.764832
92d3fd33-3463-4f8d-9612-9c4736a60144	25130e61-f0ac-4a2f-ab46-91ce6f54649f	car	car|sheikh-zayed|kia|sportage|2022-2024	sheikh-zayed	3002394.00	EGP	{"year": "2022", "brand": "Kia", "model": "Sportage", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-05-31 21:27:21.272	2026-07-19 13:57:38.775131
a3d6b355-d1e9-49f8-bd19-2092948811ff	85c4c348-d4f0-44ed-b814-60c0a881559e	car	car|dokki|volkswagen|tiguan|2022-2024	dokki	9420636.00	EGP	{"year": "2023", "brand": "Volkswagen", "model": "Tiguan", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-06-07 21:27:21.272	2026-07-19 13:57:38.785689
18782959-4e94-4eb4-af91-bbf865cb09e7	f015cb68-23c1-45ac-8241-280405b54dcc	car	car|heliopolis|chevrolet|camaro|2022-2024	heliopolis	4648671.00	EGP	{"year": "2024", "brand": "Chevrolet", "model": "Camaro", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-05-31 21:27:21.272	2026-07-19 13:57:38.795298
df160c62-a196-45fe-89e9-e04bbdfba045	8ee87c30-45fd-451a-b437-c51e915da497	car	car|north-coast|porsche|cayenne|2022-2024	north-coast	1657569.00	EGP	{"year": "2022", "brand": "Porsche", "model": "Cayenne", "condition": "used", "fuel_type": "diesel", "transmission": "automatic"}	backfill	2026-06-08 21:27:21.272	2026-07-19 13:57:38.804885
9156b132-54ca-4d06-b0b3-46f47a75f771	860a0fe8-c854-4af8-a524-fa1e53a8ed6d	car	car|north-coast|land-rover|range-rover|2019-2021	north-coast	1216749.00	EGP	{"year": "2019", "brand": "Land Rover", "model": "Range Rover", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-06-30 21:27:21.272	2026-07-19 13:57:38.81589
4131823c-d257-4bd5-b93e-d81b59ef6559	f4b561b7-113d-4938-8330-e527db01404c	car	car|giza|nissan|x-trail|2019-2021	giza	970713.00	EGP	{"year": "2021", "brand": "Nissan", "model": "X-Trail", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-05-25 21:27:21.272	2026-07-19 13:57:38.830132
052eff89-445f-4676-a944-22b8699fe312	1da570ab-f9ec-45f3-b77a-c8c1b08d284a	car	car|6th-of-october-city|honda|cr-v|2016-2018	6th-of-october-city	2135053.00	EGP	{"year": "2018", "brand": "Honda", "model": "CR-V", "condition": "new", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-05-26 21:27:21.272	2026-07-19 13:57:38.842453
425eb536-9ac0-47df-8f2d-a6a669683016	38b5547f-3272-4752-adef-419278a5a379	car	car|maadi|jeep|grand-cherokee|2019-2021	maadi	2167290.00	EGP	{"year": "2021", "brand": "Jeep", "model": "Grand Cherokee", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-13 21:27:21.272	2026-07-19 13:57:38.853189
f940f195-520a-4137-be9e-8a2d87014bd2	4c19e21c-8c00-4c51-8e9f-b0d92c78cf78	car	car|ain-sokhna|audi|a4|2019-2021	ain-sokhna	1703993.00	EGP	{"year": "2019", "brand": "Audi", "model": "A4", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-13 21:27:21.272	2026-07-19 13:57:38.861744
6aa124c2-11a5-4aed-9e09-a77c507771ab	6a9f1680-e6b9-4713-bbc9-5ddc2deae0a5	car	car|giza|toyota|corolla|2022-2024	giza	2196660.00	EGP	{"year": "2022", "brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "diesel", "transmission": "automatic"}	backfill	2026-07-14 21:27:21.272	2026-07-19 13:57:38.873474
d21fc37b-f0a8-490f-820c-25908b2417c9	da4ea6a9-a539-457f-ab70-5e143be46366	car	car|maadi|hyundai|elantra|2016-2018	maadi	1875197.00	EGP	{"year": "2018", "brand": "Hyundai", "model": "Elantra", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-05 21:27:21.272	2026-07-19 13:57:38.880952
45ad4bac-d67d-4144-823d-695ecf4ccb3d	dfa4da74-d198-413d-828c-f629a7b50189	car	car|heliopolis|kia|cerato|2019-2021	heliopolis	2194909.00	EGP	{"year": "2020", "brand": "Kia", "model": "Cerato", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-07 21:27:21.272	2026-07-19 13:57:38.896106
fe41f344-0ee8-4797-82a3-d67b7815c3c8	ccc3c757-0782-4a1f-b2ac-31d59a9b307d	car	car|maadi|chevrolet|lanos|2022-2024	maadi	1557931.00	EGP	{"year": "2024", "brand": "Chevrolet", "model": "Lanos", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-07-07 21:27:21.272	2026-07-19 13:57:38.9033
a288826b-5c1f-479a-9e49-cf8f10415d5d	3086a988-b6a0-4e15-ab43-c09b98faafa7	car	car|giza|peugeot|208|2016-2018	giza	2013430.00	EGP	{"year": "2018", "brand": "Peugeot", "model": "208", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-06-20 21:27:21.272	2026-07-19 13:57:38.911558
7c60a1da-1a4d-485d-b207-a522ebbc2dd3	9030afe9-63c8-4d9d-bac1-3dd49f4429e0	car	car|el-rehab-city|renault|duster|2022-2024	el-rehab-city	1085052.00	EGP	{"year": "2022", "brand": "Renault", "model": "Duster", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-06-30 21:27:21.272	2026-07-19 13:57:38.918978
0ecee1c1-a4d7-4bdd-a7d8-9b88f50ef627	09c8183b-d75c-4fad-ab84-55955aab44e2	car	car|dokki|mg|zs|2016-2018	dokki	2429416.00	EGP	{"year": "2018", "brand": "MG", "model": "ZS", "condition": "new", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-06-24 21:27:21.272	2026-07-19 13:57:38.92916
1fa35576-69a4-415e-9a3e-750b7bb6b0f5	55850d32-1a17-48c5-9363-a58459046358	car	car|maadi|bmw|330i|2019-2021	maadi	1038976.00	EGP	{"year": "2019", "brand": "BMW", "model": "330i", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-07-05 21:27:21.272	2026-07-19 13:57:38.961525
ed3abd3a-5400-4770-a16f-625c58c75890	b8677ab7-9b44-4c7a-bc7c-1bd54ecaa5ca	car	car|mansoura|mercedes-benz|gle|2016-2018	mansoura	1370210.00	EGP	{"year": "2018", "brand": "Mercedes-Benz", "model": "GLE", "condition": "new", "fuel_type": "diesel", "transmission": "automatic"}	backfill	2026-07-14 21:27:21.272	2026-07-19 13:57:38.97097
a2c21087-eab1-490f-8957-7731c293b0e1	bed7ae5c-ed17-42e2-8ba4-747f178c546c	real_estate	real_estate|6th-of-october-city|villa	6th-of-october-city	19827807.00	EGP	{"area": "131", "rooms": "3", "finishing": "semi_finished", "offer_type": "sale", "property_type": "villa"}	backfill	2026-06-04 21:27:21.272	2026-07-19 13:57:38.979465
55ab6ff3-b079-4988-8582-3787f62995e4	7294796b-3884-4742-abee-d13b457c610b	real_estate	real_estate|new-cairo|penthouse	new-cairo	33149.00	EGP	{"area": "493", "rooms": "5", "finishing": "core_shell", "offer_type": "rent", "property_type": "penthouse"}	backfill	2026-06-06 21:27:21.272	2026-07-19 13:57:38.986678
d1960d80-9e48-43c1-90d2-73ed32f5a352	b7cc2f8f-2721-4b1a-9c5b-15ef279aaf23	real_estate	real_estate|luxor|studio	luxor	16613294.00	EGP	{"area": "348", "rooms": "2", "finishing": "semi_finished", "offer_type": "sale", "property_type": "studio"}	backfill	2026-05-30 21:27:21.272	2026-07-19 13:57:38.994286
e4f5f52a-56d4-46d9-8f4f-3177c0ceb22b	b7537c25-ddd0-4394-8e12-08015def429c	real_estate	real_estate|maadi|office	maadi	75830.00	EGP	{"area": "97", "rooms": "2", "finishing": "core_shell", "offer_type": "rent", "property_type": "office"}	backfill	2026-07-14 21:27:21.272	2026-07-19 13:57:39.001962
91a3b272-f35f-4487-99e5-ffdb72823374	5ad12c3c-5a96-4a2b-89a4-566454a6869a	real_estate	real_estate|maadi|shop	maadi	1205610.00	EGP	{"area": "301", "rooms": "5", "finishing": "super_lux", "offer_type": "sale", "property_type": "shop"}	backfill	2026-07-02 21:27:21.272	2026-07-19 13:57:39.010215
6cfad18f-a029-46ed-aaec-dad37ed3fa8c	f7fc3936-4bc1-4375-b8c2-c173126959ea	real_estate	real_estate|hurghada|twinhouse	hurghada	2456737.00	EGP	{"area": "508", "rooms": "4", "finishing": "semi_finished", "offer_type": "sale", "property_type": "twinhouse"}	backfill	2026-07-06 21:27:21.272	2026-07-19 13:57:39.021756
50ae72f5-ef80-434e-bcac-c704c63ae7df	c9e5c75d-ac07-4dcf-a123-fea99cca404b	real_estate	real_estate|north-coast|apartment	north-coast	20807.00	EGP	{"area": "133", "rooms": "4", "finishing": "core_shell", "offer_type": "rent", "property_type": "apartment"}	backfill	2026-07-17 21:27:21.272	2026-07-19 13:57:39.028464
46f345df-416d-4a23-8cb0-7f115716fc1a	58002df9-b711-4713-8047-f828c50d6718	real_estate	real_estate|luxor|villa	luxor	1468182.00	EGP	{"area": "299", "rooms": "1", "finishing": "finished", "offer_type": "sale", "property_type": "villa"}	backfill	2026-07-01 21:27:21.272	2026-07-19 13:57:39.05783
a83429d8-36a3-4bfa-a9cf-96e94bdc48d7	20644d0f-152c-4e29-9092-c14238b4a261	real_estate	real_estate|zamalek|duplex	zamalek	28768.00	EGP	{"area": "372", "rooms": "6", "finishing": "core_shell", "offer_type": "rent", "property_type": "duplex"}	backfill	2026-06-20 21:27:21.272	2026-07-19 13:57:39.069868
eee32d0c-1594-477c-abdf-26f1c6418515	25a613fc-b24c-48c5-9dda-acf3c02a3542	real_estate	real_estate|hurghada|studio	hurghada	4181004.00	EGP	{"area": "140", "rooms": "1", "finishing": "semi_finished", "offer_type": "sale", "property_type": "studio"}	backfill	2026-06-20 21:27:21.272	2026-07-19 13:57:39.159934
e4f6bde2-2c94-40d1-8589-f7d3fa220a19	fbc3778f-be9e-4548-b205-46f14e3b3faf	real_estate	real_estate|new-cairo|penthouse	new-cairo	2735905.00	EGP	{"area": "341", "rooms": "4", "finishing": "semi_finished", "offer_type": "sale", "property_type": "penthouse"}	backfill	2026-07-01 21:27:21.272	2026-07-19 13:57:39.167194
225086be-2f2c-489e-96de-f99c1e30a010	43911f51-805d-4b2c-add6-b328c2667a6e	industrial	industrial|badr-city|land	badr-city	882795.00	EGP	{"industrial_type": "land"}	backfill	2026-06-01 21:27:21.272	2026-07-19 13:57:39.176299
01e06bb5-378c-43f6-90ae-2f735c71189e	240e7f63-766f-4fcc-b192-2df158c17999	industrial	industrial|borg-el-arab|factory	borg-el-arab	13251401.00	EGP	{"industry": "food", "industrial_type": "factory"}	backfill	2026-06-06 21:27:21.272	2026-07-19 13:57:39.193754
005baa4a-a974-4072-a17b-8b2be5745d3b	714ecac9-fd70-4822-8c2c-df9ae1be7994	industrial	industrial|borg-el-arab|warehouse	borg-el-arab	8087574.00	EGP	{"industrial_type": "warehouse"}	backfill	2026-06-08 21:27:21.272	2026-07-19 13:57:39.201042
7f774f0c-248a-4b2e-b207-820dfb8aedbc	000bdfd3-ef1f-43e1-b6bc-40e82258ad3e	industrial	industrial|badr-city|machine	badr-city	10854965.00	EGP	{"industrial_type": "machine"}	backfill	2026-05-26 21:27:21.272	2026-07-19 13:57:39.208372
ce9bad57-abe4-4b2d-923c-687d2289cdc1	f543b945-c700-4357-97bb-2d5f5bb9d828	industrial	industrial|borg-el-arab|machine	borg-el-arab	6912421.00	EGP	{"industry": "engineering", "industrial_type": "machine"}	backfill	2026-06-16 21:27:21.272	2026-07-19 13:57:39.219859
45d4d290-88c8-4268-97e4-343e658e72fe	776e660f-a9f1-4129-b969-2fed1e1a6668	industrial	industrial|obour-city|production_line	obour-city	5945828.00	EGP	{"industry": "plastic", "industrial_type": "production_line"}	backfill	2026-05-29 21:27:21.272	2026-07-19 13:57:39.229579
194fe4aa-56ef-4f4e-b575-a7d161739406	d4ddac53-a22c-460b-96f2-481482d1bc95	industrial	industrial|10th-of-ramadan-city	10th-of-ramadan-city	17202138.00	EGP	{}	backfill	2026-06-22 21:27:21.272	2026-07-19 13:57:39.237598
487e92b7-6dd4-406d-b99d-d351207a5dc5	ad7793eb-66af-4039-8267-c59488026824	car	car|6th-of-october-city|bmw|x5|2019-2021	6th-of-october-city	7249971.00	EGP	{"year": "2020", "brand": "BMW", "model": "X5", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-09 21:27:21.272	2026-07-19 13:57:39.244175
729eda39-c3ee-4999-a380-4ac0e2602c50	afb9180b-6d35-4e8f-9858-897749ccb3d3	car	car|hurghada|toyota|fortuner|2022-2024	hurghada	11846014.00	EGP	{"year": "2023", "brand": "Toyota", "model": "Fortuner", "condition": "new", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-05-21 21:27:21.272	2026-07-19 13:57:39.256759
98cecc50-ca46-44aa-b0fe-cf318d43f179	30cc6cc4-25df-481a-87a6-f0a2e4e82618	car	car|new-cairo|ford|mustang|2022-2024	new-cairo	10672717.00	EGP	{"year": "2023", "brand": "Ford", "model": "Mustang", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-06-14 21:27:21.272	2026-07-19 13:57:39.268105
ee401f65-715b-4a69-82dd-aa0ba8cabb85	322f1d1d-f418-4a26-8e60-45d8c45858a9	car	car|north-coast|lexus|rx-350|2016-2018	north-coast	705007.00	EGP	{"year": "2018", "brand": "Lexus", "model": "RX 350", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-11 21:27:21.272	2026-07-19 13:57:39.276908
6d5e3d82-36c9-457e-a091-99e7e6fcd1dd	afdc4e90-2ad7-49e5-838c-3fbbee033f3d	car	car|north-coast|mitsubishi|eclipse-cross|2022-2024	north-coast	357437.00	EGP	{"year": "2024", "brand": "Mitsubishi", "model": "Eclipse Cross", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-16 21:27:21.272	2026-07-19 13:57:39.28702
f379e0d1-3164-4602-81c8-bbcdb14423dc	7adfddc0-5f2d-4e3a-823c-7ca55388ee69	real_estate	real_estate|sheikh-zayed|duplex	sheikh-zayed	86108.00	EGP	{"area": "139", "rooms": "2", "finishing": "finished", "offer_type": "rent", "property_type": "duplex"}	backfill	2026-06-06 21:27:21.272	2026-07-19 13:57:39.293621
9c6dc243-8466-4f13-b7a5-4b3fa443ead1	8d1b2ff0-40aa-4c68-9992-31ca6bd61b1b	real_estate	real_estate|heliopolis|apartment	heliopolis	16174399.00	EGP	{"area": "359", "rooms": "2", "finishing": "semi_finished", "offer_type": "sale", "property_type": "apartment"}	backfill	2026-05-28 21:27:21.272	2026-07-19 13:57:39.30172
37a2f1bc-7bad-4830-a9ab-4cd70f8a6a0b	9f249352-cd48-4c1d-b238-ca2a015a6f20	real_estate	real_estate|sheikh-zayed|chalet	sheikh-zayed	1904413.00	EGP	{"area": "510", "rooms": "6", "finishing": "finished", "offer_type": "sale", "property_type": "chalet"}	backfill	2026-06-12 21:27:21.272	2026-07-19 13:57:39.313625
eab63404-e1d5-4c9e-adef-1a3d2f956c81	906b9bd8-d0ca-4a6f-aec9-915686f8c48b	real_estate	real_estate|new-cairo|apartment	new-cairo	3574107.00	EGP	{"area": "269", "rooms": "5", "finishing": "core_shell", "offer_type": "sale", "property_type": "apartment"}	backfill	2026-06-25 21:27:21.272	2026-07-19 13:57:39.320657
fe4e0153-ed91-49ef-bf81-51cd80b53328	35191d0c-d69e-4d03-93c6-fd48bfd5ab4f	industrial	industrial|alexandria-industrial-zone|production_line	alexandria-industrial-zone	6536401.00	EGP	{"industry": "textile", "industrial_type": "production_line"}	backfill	2026-06-16 21:27:21.272	2026-07-19 13:57:39.327636
969abbb2-0c82-42ff-abfe-837b49bb4824	e10511a8-45c3-4da3-bc6e-2b192c15bd24	industrial	industrial|10th-of-ramadan-city|factory	10th-of-ramadan-city	16318563.00	EGP	{"industry": "engineering", "industrial_type": "factory"}	backfill	2026-07-11 21:27:21.272	2026-07-19 13:57:39.334179
2b5b9b3f-b0d3-4e7a-b91d-6e2b40eb9f8f	6f8a18b3-7b7a-4eda-800c-f5ae5a5cd290	industrial	industrial|badr-city|factory	badr-city	23917256.00	EGP	{"industry": "beverage", "industrial_type": "factory"}	backfill	2026-07-05 21:27:21.272	2026-07-19 13:57:39.34273
c217cebb-02b1-4427-aeca-df2b4426520e	188d6bfc-b83a-4299-8c55-d8d5505b9f4a	industrial	industrial|badr-city|production_line	badr-city	11030422.00	EGP	{"industry": "pharmaceutical", "industrial_type": "production_line"}	backfill	2026-07-11 21:27:21.272	2026-07-19 13:57:39.354129
7ff44747-b890-4615-add0-568fd805ab48	4c1792ba-c514-454d-a4b3-39f3aad9fa71	industrial	industrial|obour-city|machine	obour-city	9155796.00	EGP	{"industrial_type": "machine"}	backfill	2026-07-03 21:27:21.272	2026-07-19 13:57:39.362287
ec85014a-33ae-4b1d-b8b6-61fb54fbe5d6	a8b788a2-eeb2-41e0-a1b0-0114aa7891d3	industrial	industrial|10th-of-ramadan-city|raw_material	10th-of-ramadan-city	1883400.00	EGP	{"industry": "plastic", "industrial_type": "raw_material"}	backfill	2026-06-27 21:27:21.272	2026-07-19 13:57:39.370211
c67c5c9c-89dd-494c-8aea-5fc6be1f7fa0	ce85c9c5-65f2-4876-b98c-f11d7f183b25	industrial	industrial|10th-of-ramadan-city|raw_material	10th-of-ramadan-city	1218478.00	EGP	{"industry": "plastic", "industrial_type": "raw_material"}	backfill	2026-06-28 21:27:21.272	2026-07-19 13:57:39.38471
6c7f0689-a82e-407d-a6a9-1f711bda6df1	5b43e47b-9ac6-4c33-ae58-75829f6bfe00	industrial	industrial|10th-of-ramadan-city|machine	10th-of-ramadan-city	3415836.00	EGP	{"industry": "plastic", "industrial_type": "machine"}	backfill	2026-07-02 21:27:21.272	2026-07-19 13:57:39.404613
313ac632-e5c3-4c3f-a4fd-23de40e8ce59	a89eab67-0e52-408d-8887-03d24cd3886d	industrial	industrial|10th-of-ramadan-city|machine	10th-of-ramadan-city	3981137.00	EGP	{"industry": "plastic", "industrial_type": "machine"}	backfill	2026-06-29 21:27:21.272	2026-07-19 13:57:39.413309
dfb76626-8951-4b05-ad3f-5b94c26f674f	d6ab50a9-fc95-4d3b-9959-b66badab140f	industrial	industrial|10th-of-ramadan-city|production_line	10th-of-ramadan-city	17912557.00	EGP	{"industry": "plastic", "industrial_type": "production_line"}	backfill	2026-07-12 21:27:21.272	2026-07-19 13:57:39.425178
cb396701-544d-4704-af75-3e4fee9477e0	1e9b6e89-66ff-460b-a11f-bfa9d27e48d0	industrial	industrial|10th-of-ramadan-city|factory	10th-of-ramadan-city	66164678.00	EGP	{"industry": "plastic", "industrial_type": "factory"}	backfill	2026-07-04 21:27:21.272	2026-07-19 13:57:39.43703
b5e9cff2-44ab-4a7e-a3a1-c015c1b07086	bf1b64b0-40db-494e-8b66-509316a30724	car	car|sheikh-zayed|kia|sportage|2019-2021	sheikh-zayed	3779768.00	EGP	{"year": "2021", "brand": "Kia", "model": "Sportage", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-07-18 22:00:17.792	2026-07-19 13:57:39.449801
061f8615-d0c4-4553-9430-d4c65677f594	64d60de9-2649-48e8-8636-bb76c8a0192e	car	car|mansoura|volkswagen|tiguan|2016-2018	mansoura	10548457.00	EGP	{"year": "2018", "brand": "Volkswagen", "model": "Tiguan", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-18 22:00:17.813	2026-07-19 13:57:39.459089
b069c333-1d4e-432f-836a-5735a77838a7	edf0deed-fa66-4c53-9ca3-5b87b10ec806	car	car|6th-of-october-city|volkswagen|tiguan|2016-2018	6th-of-october-city	11740204.00	EGP	{"year": "2018", "brand": "Volkswagen", "model": "Tiguan", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-19 13:56:01.461	2026-07-19 13:57:39.466972
61415a13-df71-42ff-a322-2826e1a3e3b4	6531a87f-7a51-454d-8dea-9660c3aa3fa3	car	car|6th-of-october-city|ford|mustang|2016-2018	6th-of-october-city	3045183.00	EGP	{"year": "2018", "brand": "Ford", "model": "Mustang", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.529	2026-07-19 13:57:39.477064
53d8f514-9b22-4563-b799-cb28cd8a08fc	1535dacc-8620-475f-863c-f5048d3f271f	car	car|maadi|porsche|cayenne|2019-2021	maadi	1385534.00	EGP	{"year": "2019", "brand": "Porsche", "model": "Cayenne", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.562	2026-07-19 13:57:39.488447
5e918717-0d34-4811-a4ea-22cd08f24536	ff6d88fd-14e9-45f9-a2ea-552c61e61f14	car	car|mansoura|land-rover|range-rover|2016-2018	mansoura	2402499.00	EGP	{"year": "2018", "brand": "Land Rover", "model": "Range Rover", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-19 13:56:01.597	2026-07-19 13:57:39.499273
fd98fa86-c974-485f-8286-6b1dbd1c25dc	0b4ec5fc-85e7-4b56-8460-5c965ddff8c4	car	car|6th-of-october-city|nissan|x-trail|2019-2021	6th-of-october-city	2753728.00	EGP	{"year": "2021", "brand": "Nissan", "model": "X-Trail", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-19 13:56:01.632	2026-07-19 13:57:39.511301
461c341e-56ae-4f56-95dc-d118085b8390	0f2abacd-5388-4d16-88ba-19996ab07efc	car	car|hurghada|honda|cr-v|2022-2024	hurghada	2465522.00	EGP	{"year": "2022", "brand": "Honda", "model": "CR-V", "condition": "new", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-19 13:56:01.665	2026-07-19 13:57:39.517913
d820747e-8c9d-4987-b9f8-b26cf6d0a677	228d2194-7cb3-4797-9cf6-9150f59e4b51	car	car|6th-of-october-city|jeep|grand-cherokee|2016-2018	6th-of-october-city	2387914.00	EGP	{"year": "2018", "brand": "Jeep", "model": "Grand Cherokee", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-19 13:56:01.699	2026-07-19 13:57:39.526035
75d4ddd6-bf4a-4fd2-81b1-81e0dfabd9be	f8828552-9e98-4c47-90ac-dfeafef6f259	car	car|ain-sokhna|lexus|rx-350|2022-2024	ain-sokhna	2730255.00	EGP	{"year": "2022", "brand": "Lexus", "model": "RX 350", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.824	2026-07-19 13:57:39.535708
cd78f464-cc78-48c8-b335-a9a8b3e350a8	34a62384-7311-43f7-9d85-75275232b454	car	car|ain-sokhna|porsche|cayenne|2019-2021	ain-sokhna	2309140.00	EGP	{"year": "2019", "brand": "Porsche", "model": "Cayenne", "condition": "used", "fuel_type": "diesel", "transmission": "automatic"}	backfill	2026-07-18 22:00:17.883	2026-07-19 13:57:39.544852
86aa245d-9153-4fc5-a366-c7e16bfdf374	a0f30ae4-e397-4606-ae72-5a45a95a5c33	car	car|sheikh-zayed|nissan|x-trail|2016-2018	sheikh-zayed	2149685.00	EGP	{"year": "2018", "brand": "Nissan", "model": "X-Trail", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-18 22:00:17.931	2026-07-19 13:57:39.552651
fa3faf15-c9c0-4ebe-b158-fba16d7ff775	0fb08ca8-6683-4a0b-b50c-00b79c9e3bfe	car	car|luxor|honda|cr-v|2022-2024	luxor	2325461.00	EGP	{"year": "2022", "brand": "Honda", "model": "CR-V", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-18 22:00:17.952	2026-07-19 13:57:39.561972
4760472c-f815-4bf9-bb51-91fc18c832ff	68870b9b-d774-47b3-862d-0c525aade4e0	car	car|giza|audi|a4|2019-2021	giza	849627.00	EGP	{"year": "2020", "brand": "Audi", "model": "A4", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-18 22:00:17.996	2026-07-19 13:57:39.572711
ccd74880-08e7-4588-b157-57a65b59b597	8a1b4752-c8ad-4882-b9e1-40e845cdf053	car	car|alexandria|lexus|rx-350|2022-2024	alexandria	604955.00	EGP	{"year": "2023", "brand": "Lexus", "model": "RX 350", "condition": "new", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-18 22:00:18.016	2026-07-19 13:57:39.58149
e27108a9-fa2b-4ffc-a0f9-07ff75b74141	cff450de-7e28-4ffa-afdc-d8a36a6aeadd	car	car|hurghada|hyundai|elantra|2022-2024	hurghada	1723940.00	EGP	{"year": "2023", "brand": "Hyundai", "model": "Elantra", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-07-18 22:00:18.055	2026-07-19 13:57:39.588963
85770ac2-1d84-47a8-9577-f88fd5b8d85d	b91b906c-199e-4872-8bd7-aa305e61d456	car	car|mansoura|kia|cerato|2022-2024	mansoura	2480566.00	EGP	{"year": "2023", "brand": "Kia", "model": "Cerato", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-18 22:00:18.089	2026-07-19 13:57:39.595986
facb9173-e9d7-4bff-b235-5a3223665f51	35b7f9d3-1632-4549-9c32-e00d1ac6b862	car	car|hurghada|chevrolet|lanos|2022-2024	hurghada	2712598.00	EGP	{"year": "2022", "brand": "Chevrolet", "model": "Lanos", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-18 22:00:18.111	2026-07-19 13:57:39.604108
76948bf3-c168-44ab-b4e0-0ba523933db0	e069ac39-c738-4586-8629-31e0731e3f91	car	car|hurghada|peugeot|208|2022-2024	hurghada	1225456.00	EGP	{"year": "2024", "brand": "Peugeot", "model": "208", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-07-18 22:00:18.127	2026-07-19 13:57:39.612329
1de8ad62-362a-4e4c-8e00-a531c6e52a5b	f4c6f1bb-adb7-41f4-983a-64676c47e514	car	car|heliopolis|renault|duster|2019-2021	heliopolis	744624.00	EGP	{"year": "2021", "brand": "Renault", "model": "Duster", "condition": "new", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-18 22:00:18.14	2026-07-19 13:57:39.619716
88e4ff76-728a-4059-9652-c232dd368722	3094a424-7f3d-4719-8d95-9991b9680048	car	car|new-cairo|mitsubishi|eclipse-cross|2016-2018	new-cairo	1528508.00	EGP	{"year": "2018", "brand": "Mitsubishi", "model": "Eclipse Cross", "condition": "used", "fuel_type": "diesel", "transmission": "automatic"}	backfill	2026-07-18 22:00:18.157	2026-07-19 13:57:39.627732
6f4398ea-c414-4da6-8583-f439ba473bea	8c77c35d-3969-4fd0-933a-9558cc48fac5	car	car|mansoura|mg|zs|2019-2021	mansoura	565727.00	EGP	{"year": "2021", "brand": "MG", "model": "ZS", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-18 22:00:18.171	2026-07-19 13:57:39.638731
95425c1d-8893-41b3-912f-dd276a79d69f	2c7e7e69-b413-4913-b965-00e13fa8f32d	car	car|zamalek|mercedes-benz|gle|2019-2021	zamalek	2548203.00	EGP	{"year": "2020", "brand": "Mercedes-Benz", "model": "GLE", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-18 22:00:18.202	2026-07-19 13:57:39.650152
a4073025-5dcc-4168-94e1-ab905f91544d	f52e2c21-9f60-4a9d-9587-28c34be4313d	car	car|north-coast|hyundai|elantra|2016-2018	north-coast	1547428.00	EGP	{"year": "2018", "brand": "Hyundai", "model": "Elantra", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-19 13:56:01.9	2026-07-19 13:57:39.659243
d490df5b-14d0-4e75-b73c-e4e383d3f326	a702bac0-04c2-4ca6-8642-086500203e18	car	car|north-coast|bmw|x5|2019-2021	north-coast	11821057.00	EGP	{"year": "2019", "brand": "BMW", "model": "X5", "condition": "new", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-18 22:00:17.618	2026-07-19 13:57:39.666266
df80cdcf-90c1-4c4e-bec6-b2f69d2cab61	11e3e025-ac43-4186-99c4-e90fce734514	car	car|alexandria|toyota|fortuner|2022-2024	alexandria	6874065.00	EGP	{"year": "2022", "brand": "Toyota", "model": "Fortuner", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-18 22:00:17.681	2026-07-19 13:57:39.674041
5df2bbe2-011d-41f1-94cb-5aa3d5ce2c10	7f5a475c-f641-4130-ad9d-316175ceddd8	car	car|hurghada|hyundai|tucson|2022-2024	hurghada	7514417.00	EGP	{"year": "2024", "brand": "Hyundai", "model": "Tucson", "condition": "used", "fuel_type": "diesel", "transmission": "automatic"}	backfill	2026-07-18 22:00:17.711	2026-07-19 13:57:39.683893
b909c0a4-8fec-42d8-8565-9c51df087f7e	37103385-9490-4954-9687-50f8ee9e0a26	car	car|6th-of-october-city|chevrolet|camaro|2019-2021	6th-of-october-city	10254604.00	EGP	{"year": "2019", "brand": "Chevrolet", "model": "Camaro", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-07-18 22:00:17.833	2026-07-19 13:57:39.693816
a6c7a36b-326a-4bae-8d15-00c0df9f7646	dd2a3f4a-84df-49f0-96bc-405d52e30e8b	car	car|alexandria|kia|cerato|2022-2024	alexandria	2263890.00	EGP	{"year": "2023", "brand": "Kia", "model": "Cerato", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.934	2026-07-19 13:57:39.703458
151a88a8-c49c-4cdd-b268-e403fcc5ce11	594f7353-9eeb-4f9d-a91e-402097aa1aa0	car	car|alexandria|chevrolet|lanos|2022-2024	alexandria	2280814.00	EGP	{"year": "2022", "brand": "Chevrolet", "model": "Lanos", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.969	2026-07-19 13:57:39.718717
ed160015-a7d2-41c4-b1b3-be261b4e0b91	4e8d01e8-dddd-4ba0-b88b-b0068d47ac54	car	car|luxor|peugeot|208|2022-2024	luxor	2550294.00	EGP	{"year": "2023", "brand": "Peugeot", "model": "208", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.996	2026-07-19 13:57:39.728064
c16ee560-5093-433e-931f-3f963581895d	adf38505-f2de-4fdd-a78e-4020df43ce5b	car	car|luxor|mitsubishi|eclipse-cross|2019-2021	luxor	1222990.00	EGP	{"year": "2019", "brand": "Mitsubishi", "model": "Eclipse Cross", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-19 13:56:02.059	2026-07-19 13:57:39.735796
d92d8673-12d8-4308-a455-d87b3df43d47	8c7883b1-f456-4a6a-8f42-18c0316a9ef7	car	car|dokki|mg|zs|2022-2024	dokki	1394521.00	EGP	{"year": "2022", "brand": "MG", "model": "ZS", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-19 13:56:02.086	2026-07-19 13:57:39.747324
cc4ee410-414a-4a3a-bde5-7c8efd82c061	5cba9a8c-3a15-4e7c-92ae-14de899b0403	car	car|giza|bmw|330i|2022-2024	giza	1060708.00	EGP	{"year": "2022", "brand": "BMW", "model": "330i", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-19 13:56:02.113	2026-07-19 13:57:39.762524
247fe099-a685-4347-8462-9255870e08be	ba60c889-76e4-4635-9a59-0ed305f1043e	car	car|maadi|mercedes-benz|gle|2022-2024	maadi	1087285.00	EGP	{"year": "2022", "brand": "Mercedes-Benz", "model": "GLE", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-19 13:56:02.142	2026-07-19 13:57:39.780689
5aae6313-dadd-4f08-96ff-d6feffb40554	320b6f96-0528-4430-9486-842cd3c10290	real_estate	real_estate|sheikh-zayed|apartment	sheikh-zayed	35270392.00	EGP	{"area": "528", "rooms": "5", "finishing": "finished", "offer_type": "sale", "property_type": "apartment"}	backfill	2026-07-19 13:56:02.202	2026-07-19 13:57:39.790692
227fa127-65e5-4375-9ec5-04de179627d7	83bd6cf4-667f-46a9-9136-42841beb0ddd	real_estate	real_estate|6th-of-october-city|villa	6th-of-october-city	13230978.00	EGP	{"area": "318", "rooms": "1", "finishing": "semi_finished", "offer_type": "sale", "property_type": "villa"}	backfill	2026-07-19 13:56:02.236	2026-07-19 13:57:39.801913
b3b67b2f-62ae-4e7b-b79f-497d8d98eaa0	956f7f0c-4c49-4849-8efc-1056cd1e46a7	real_estate	real_estate|luxor|penthouse	luxor	12708.00	EGP	{"area": "107", "rooms": "6", "finishing": "core_shell", "offer_type": "rent", "property_type": "penthouse"}	backfill	2026-07-19 13:56:02.272	2026-07-19 13:57:39.80971
7b682b7b-97cd-4280-9070-29ffbec1a636	7e2e36ae-710b-4f01-b415-163004df50d5	real_estate	real_estate|zamalek|studio	zamalek	17334615.00	EGP	{"area": "275", "rooms": "4", "finishing": "super_lux", "offer_type": "sale", "property_type": "studio"}	backfill	2026-07-19 13:56:02.299	2026-07-19 13:57:39.821498
30557d22-21b1-4c87-94a9-2caf711f801f	3f8579ca-1469-4fff-8dd0-867327549e2a	real_estate	real_estate|giza|office	giza	60968.00	EGP	{"area": "538", "rooms": "4", "finishing": "super_lux", "offer_type": "rent", "property_type": "office"}	backfill	2026-07-19 13:56:02.445	2026-07-19 13:57:39.831549
42034337-5f52-47c6-b003-e61bb2cc59de	5d5f76f9-8200-4cfb-b85f-eb3167ebe59c	real_estate	real_estate|mansoura|shop	mansoura	4933304.00	EGP	{"area": "212", "rooms": "6", "finishing": "finished", "offer_type": "sale", "property_type": "shop"}	backfill	2026-07-19 13:56:02.474	2026-07-19 13:57:39.845117
39bc6622-f235-4192-8de9-9af3d4096760	e104a255-93b8-4ce3-b2a2-16ed2dc22047	real_estate	real_estate|new-cairo|twinhouse	new-cairo	4146928.00	EGP	{"area": "538", "rooms": "3", "finishing": "semi_finished", "offer_type": "sale", "property_type": "twinhouse"}	backfill	2026-07-19 13:56:02.509	2026-07-19 13:57:39.86162
8ad45b94-5035-48e5-9381-71a5802f0942	1d10ee4e-0ea6-4334-bd44-cb11c2398322	car	car|giza|ford|mustang|2022-2024	giza	4649488.00	EGP	{"year": "2024", "brand": "Ford", "model": "Mustang", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-18 22:00:17.861	2026-07-19 13:57:39.868607
0e8cd7f5-8ea3-433e-8400-b62359017b1b	b38f66dc-3e8a-4e27-b878-87b9ff283a56	car	car|giza|land-rover|range-rover|2022-2024	giza	1293551.00	EGP	{"year": "2024", "brand": "Land Rover", "model": "Range Rover", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-07-18 22:00:17.903	2026-07-19 13:57:39.877953
625b27be-2a88-4de2-9c49-e6606119d193	bd1f899c-90a2-41d6-972f-a40762374777	car	car|alexandria|toyota|corolla|2022-2024	alexandria	2221323.00	EGP	{"year": "2023", "brand": "Toyota", "model": "Corolla", "condition": "new", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-18 22:00:18.033	2026-07-19 13:57:39.885308
3c8cb784-0b04-41fa-908d-ea592f2a2cba	4c73b269-e275-4bd2-898f-39a018826814	car	car|mansoura|bmw|330i|2016-2018	mansoura	2664703.00	EGP	{"year": "2018", "brand": "BMW", "model": "330i", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-18 22:00:18.186	2026-07-19 13:57:39.894289
c0ea5076-57e5-42f0-b1f2-b1ca394387f6	c3996838-428c-4cef-9199-176dd9d66848	car	car|6th-of-october-city|bmw|x5|2019-2021	6th-of-october-city	5382358.00	EGP	{"year": "2021", "brand": "BMW", "model": "X5", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.224	2026-07-19 13:57:39.901168
507252c4-890d-470a-86ad-c1a7659dbe9b	02ca95ed-3f23-4485-86bb-e822d2d20b9d	real_estate	real_estate|ain-sokhna|villa	ain-sokhna	7275665.00	EGP	{"area": "433", "rooms": "5", "finishing": "core_shell", "offer_type": "sale", "property_type": "villa"}	backfill	2026-07-19 13:56:02.572	2026-07-19 13:57:39.912377
e014cc84-82cc-46f6-8e55-1916558505c6	af29f0a0-62b7-48c4-8995-ae58a192b39f	real_estate	real_estate|mansoura|apartment	mansoura	3590840.00	EGP	{"area": "497", "rooms": "2", "finishing": "finished", "offer_type": "sale", "property_type": "apartment"}	backfill	2026-07-19 13:56:02.607	2026-07-19 13:57:39.919153
4bb97588-8ef9-4287-b496-38a8d4f8b6fd	9322a87e-6899-4b8a-8399-280801afaff0	real_estate	real_estate|zamalek|duplex	zamalek	11783.00	EGP	{"area": "569", "rooms": "3", "finishing": "core_shell", "offer_type": "rent", "property_type": "duplex"}	backfill	2026-07-19 13:56:02.641	2026-07-19 13:57:39.926335
becb9543-8656-4aa5-8187-5be3985d655e	37159531-b803-4b62-a764-209cae61eb8a	real_estate	real_estate|zamalek|studio	zamalek	3482519.00	EGP	{"area": "292", "rooms": "2", "finishing": "super_lux", "offer_type": "sale", "property_type": "studio"}	backfill	2026-07-19 13:56:02.668	2026-07-19 13:57:39.933788
64b241bf-921b-49aa-872b-eeb7aa6a42f4	7263ec34-aa0e-46ee-9603-dc3c7e555089	industrial	industrial|alexandria-industrial-zone|land	alexandria-industrial-zone	5753506.00	EGP	{"industrial_type": "land"}	backfill	2026-07-19 13:56:02.722	2026-07-19 13:57:39.941256
35e18ab4-7cec-4dd8-9f5c-27f17c3f577f	a0705f6e-b0e0-43fe-8352-90816e14fc59	industrial	industrial|alexandria-industrial-zone|factory	alexandria-industrial-zone	7064072.00	EGP	{"industry": "food", "industrial_type": "factory"}	backfill	2026-07-19 13:56:02.759	2026-07-19 13:57:39.94792
94505f10-4d66-4c28-bd81-399dadda373c	ea279ba5-756f-456d-91d8-534388fb648a	industrial	industrial|borg-el-arab|production_line	borg-el-arab	17897143.00	EGP	{"industry": "textile", "industrial_type": "production_line"}	backfill	2026-07-19 13:56:02.793	2026-07-19 13:57:39.954659
73082332-aefe-45f8-8335-e2889d7f577e	9150cc73-01b3-47fe-a15c-042af82ed4a3	industrial	industrial|10th-of-ramadan-city|warehouse	10th-of-ramadan-city	21204112.00	EGP	{"industrial_type": "warehouse"}	backfill	2026-07-19 13:56:02.825	2026-07-19 13:57:39.961511
562e60fe-80cf-46fd-86ad-99b8c0ddd351	af09ae88-c0da-4079-a0f4-7aa7407ac1fc	industrial	industrial|alexandria-industrial-zone|machine	alexandria-industrial-zone	2761065.00	EGP	{"industrial_type": "machine"}	backfill	2026-07-19 13:56:02.866	2026-07-19 13:57:39.968241
e24597d1-0aa3-4e71-89aa-5768ca69e5dc	925a9409-46ca-4049-a382-97f840540c9d	industrial	industrial|alexandria-industrial-zone|machine	alexandria-industrial-zone	5115428.00	EGP	{"industry": "engineering", "industrial_type": "machine"}	backfill	2026-07-19 13:56:02.903	2026-07-19 13:57:39.975583
e2a77036-1f8a-4e71-845d-58668d3f353e	8c21de11-dacc-42d7-b52b-2413d53bb5ae	industrial	industrial|borg-el-arab|factory	borg-el-arab	17221757.00	EGP	{"industry": "beverage", "industrial_type": "factory"}	backfill	2026-07-19 13:56:02.975	2026-07-19 13:57:39.982542
c241daf0-9951-417c-870a-dcfe8389fd66	e50a3b9d-cb4f-49df-bb51-a7a0ae37a8da	industrial	industrial|obour-city	obour-city	16390661.00	EGP	{}	backfill	2026-07-19 13:56:03.013	2026-07-19 13:57:39.989568
a2cf57cc-4ba3-478b-9a46-b40e55615338	c5a76c3d-0b88-4859-b6d8-e557ebfaca65	industrial	industrial|sadat-city|factory	sadat-city	13378782.00	EGP	{"industry": "engineering", "industrial_type": "factory"}	backfill	2026-07-19 13:56:03.054	2026-07-19 13:57:39.996632
fbf29d8b-4540-496f-bd35-4825eb5f147c	67ce4494-36b1-42c3-af3e-fe2e6b4872d3	industrial	industrial|alexandria-industrial-zone|production_line	alexandria-industrial-zone	22593980.00	EGP	{"industry": "pharmaceutical", "industrial_type": "production_line"}	backfill	2026-07-19 13:56:03.088	2026-07-19 13:57:40.003012
e252ce48-9b39-4037-9c07-b327a93db83e	29113513-b741-470e-847a-57ff621f0f19	car	car|alexandria|mercedes-benz|c-class|2019-2021	alexandria	10962551.00	EGP	{"year": "2021", "brand": "Mercedes-Benz", "model": "C-Class", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-19 13:56:01.314	2026-07-19 13:57:40.009817
82fa3766-cd49-4a67-958a-dc5dff5ebcfd	7ce2d80c-5ea0-4739-aae0-b29c26a55acb	car	car|el-rehab-city|toyota|fortuner|2022-2024	el-rehab-city	8703858.00	EGP	{"year": "2024", "brand": "Toyota", "model": "Fortuner", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-19 13:56:01.348	2026-07-19 13:57:40.016522
609bf6f7-da96-47a7-ba4a-6387c7b2af0c	59f4e92b-92ff-461f-ae08-dc2be8fbff30	car	car|maadi|hyundai|tucson|2019-2021	maadi	11102784.00	EGP	{"year": "2020", "brand": "Hyundai", "model": "Tucson", "condition": "used", "fuel_type": "hybrid", "transmission": "manual"}	backfill	2026-07-19 13:56:01.387	2026-07-19 13:57:40.117928
1789a9bf-87a4-493c-9756-b8a9dc750d30	c56c0b52-50c2-4459-b4c5-19d2c401aaf0	car	car|zamalek|kia|sportage|2019-2021	zamalek	5860983.00	EGP	{"year": "2019", "brand": "Kia", "model": "Sportage", "condition": "used", "fuel_type": "petrol", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.423	2026-07-19 13:57:40.124777
6dd04a89-fee1-4a0b-bf1d-6589f67d88c2	80e0f0fc-3bd8-4e71-9ffc-348b8fd7a655	car	car|dokki|chevrolet|camaro|2022-2024	dokki	5668054.00	EGP	{"year": "2023", "brand": "Chevrolet", "model": "Camaro", "condition": "used", "fuel_type": "diesel", "transmission": "manual"}	backfill	2026-07-19 13:56:01.493	2026-07-19 13:57:40.13221
f244d6dc-cd93-4ee3-b4dc-8ae3a9990975	c5d495c4-7f15-4785-9ceb-444109eae4ca	car	car|giza|audi|a4|2022-2024	giza	1776473.00	EGP	{"year": "2022", "brand": "Audi", "model": "A4", "condition": "used", "fuel_type": "diesel", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.734	2026-07-19 13:57:40.140905
2fa3a3c7-bd83-4b1c-82d6-124f24ed7770	bb9758f5-7491-4626-8264-f9b36e781015	car	car|ain-sokhna|toyota|corolla|2022-2024	ain-sokhna	2224993.00	EGP	{"year": "2023", "brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "hybrid", "transmission": "automatic"}	backfill	2026-07-19 13:56:01.866	2026-07-19 13:57:40.148121
59fadf32-5ea1-4df8-8a63-2b4ceb65485a	7ca26c99-aec3-4064-89c6-6acbf346ba9a	car	car|sheikh-zayed|renault|duster|2019-2021	sheikh-zayed	2436991.00	EGP	{"year": "2019", "brand": "Renault", "model": "Duster", "condition": "used", "fuel_type": "petrol", "transmission": "manual"}	backfill	2026-07-19 13:56:02.032	2026-07-19 13:57:40.155786
151b94a2-237f-424b-a3b3-9ca524223606	24f1f647-642a-4a4f-b685-8f6cc62ca73a	real_estate	real_estate|zamalek|duplex	zamalek	64834.00	EGP	{"area": "505", "rooms": "6", "finishing": "semi_finished", "offer_type": "rent", "property_type": "duplex"}	backfill	2026-07-19 13:56:02.175	2026-07-19 13:57:40.164426
8f483ff8-41a2-418f-87bf-9447239c4771	eb1e5cc7-3431-4e72-9563-be6c520c561c	real_estate	real_estate|new-cairo|chalet	new-cairo	2506366.00	EGP	{"area": "530", "rooms": "2", "finishing": "semi_finished", "offer_type": "sale", "property_type": "chalet"}	backfill	2026-07-19 13:56:02.411	2026-07-19 13:57:40.171049
2a0e3f75-d2ce-467b-9f2a-35d1afbfca25	5531056b-c81d-4971-b026-fbdc40516ee8	real_estate	real_estate|dokki|apartment	dokki	30055.00	EGP	{"area": "445", "rooms": "6", "finishing": "finished", "offer_type": "rent", "property_type": "apartment"}	backfill	2026-07-19 13:56:02.545	2026-07-19 13:57:40.178076
5f68d4e9-bc84-4680-a353-bfba7c706ce6	ee9c255d-593a-404e-ba7c-54f76e5c537c	real_estate	real_estate|alexandria|penthouse	alexandria	4221766.00	EGP	{"area": "98", "rooms": "4", "finishing": "super_lux", "offer_type": "sale", "property_type": "penthouse"}	backfill	2026-07-19 13:56:02.695	2026-07-19 13:57:40.193349
d1cf62e1-65c2-4d5f-8027-5b681e7acfad	40de3002-ada5-468e-b583-788cfbeb2a35	industrial	industrial|sadat-city|production_line	sadat-city	14753861.00	EGP	{"industry": "plastic", "industrial_type": "production_line"}	backfill	2026-07-19 13:56:02.936	2026-07-19 13:57:40.201927
58bda8c3-5478-4343-b14e-3ac7493ef903	d625d165-7501-4c66-9601-fea4f5c5e94a	industrial	industrial|10th-of-ramadan-city|machine	10th-of-ramadan-city	11692194.00	EGP	{"industrial_type": "machine"}	backfill	2026-07-19 13:56:03.121	2026-07-19 13:57:40.209573
3833c64c-554b-4d4d-8328-631451ff0677	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 14:01:01.06116	2026-07-19 14:01:01.06116
2a45f05e-aee9-4440-8153-9f8cc8f964e6	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:02:33.118159	2026-07-20 00:02:33.118159
da2a3f74-9f38-4a68-8ef7-ce32a9e0c5f7	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:02:33.186868	2026-07-20 00:02:33.186868
8a1fa669-0b2d-4226-b91e-238142bfe6b7	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:38:27.140733	2026-07-20 12:38:27.140733
9aa830fe-f4a2-4336-aac7-b9f6df0b83a2	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:02:42.92369	2026-07-20 00:02:42.92369
3444e7c8-a926-4d87-88d2-07e37f74699a	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:51:33.368635	2026-07-20 12:51:33.368635
5e03a751-3b77-4da7-9ca2-9add590df125	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:02:47.042052	2026-07-20 00:02:47.042052
4f6b3f92-6cc7-4172-9668-f7708867f1c4	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 01:00:10.429848	2026-07-20 01:00:10.429848
ed6abc38-b035-41fe-958d-2328ef392b62	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:28:17.944527	2026-07-20 00:28:17.944527
4dcc04bf-60fe-4b81-a268-7e0ecdbdec2a	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:28:17.846094	2026-07-20 00:28:17.846094
4f7c4218-c177-4276-8139-c65b5d55b637	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 00:28:23.067772	2026-07-20 00:28:23.067772
a2461bba-b03a-4fb7-a0be-3618c817efe7	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:28:26.733197	2026-07-20 00:28:26.733197
ee7a7e7a-3d13-4023-bd3f-850494e6ea74	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-19 14:01:14.776124	2026-07-19 14:01:14.776124
9bed8c72-b28e-461d-b322-a23fae8a8e3e	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 14:01:16.096685	2026-07-19 14:01:16.096685
0ab9c930-ba58-4bbd-9eba-821697e9a082	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 14:01:16.478719	2026-07-19 14:01:16.478719
48385fd8-4144-47fd-8a84-0a72eb085054	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 14:01:16.348986	2026-07-19 14:01:16.348986
33128d22-b6a0-49aa-880c-98b6730ee030	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-19 14:01:16.41899	2026-07-19 14:01:16.41899
15000f1e-1037-4459-b75f-a0c303fffac1	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 14:01:16.282727	2026-07-19 14:01:16.282727
7bdc432c-b374-4a6a-915c-ab133213473a	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 14:01:26.179228	2026-07-19 14:01:26.179228
2cc0015c-9677-46b0-813c-4553a7aeb82c	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 14:01:26.261134	2026-07-19 14:01:26.261134
9f2953fe-37bd-42f0-8e36-70ae3bb444d7	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 18:58:36.237066	2026-07-19 18:58:36.237066
ffe1b4a5-404b-401a-8a98-ef4cf3539dd0	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 18:58:36.350568	2026-07-19 18:58:36.350568
54f12e40-bcd6-4e2b-bc46-6e73792a0dab	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 18:58:36.163252	2026-07-19 18:58:36.163252
aa785761-0ba8-4263-9d1c-ae668c44b8f7	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 18:58:36.278724	2026-07-19 18:58:36.278724
c3899155-0aa1-4c49-8e90-855ec6d77790	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-19 18:58:36.317563	2026-07-19 18:58:36.317563
ca8ff69d-7e0e-49f0-a81e-0e96ba9d26f0	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-19 18:58:37.658048	2026-07-19 18:58:37.658048
0d8268ee-cc8f-436a-b5c8-24675f030d58	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 18:58:44.625667	2026-07-19 18:58:44.625667
d9f43eb6-c759-4987-a5e4-dc16e2f45197	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 01:00:10.499477	2026-07-20 01:00:10.499477
a9b39769-6786-45b8-9f3e-9da54b05e570	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 01:00:10.546824	2026-07-20 01:00:10.546824
4e74caf9-1e0d-4bf9-b74e-89cd7fbeb028	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:02:33.334091	2026-07-20 00:02:33.334091
d95f3108-36ee-4e2c-ac6b-ecdd5e1286ed	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:02:33.226207	2026-07-20 00:02:33.226207
c3545630-2126-4c99-8110-257188b2c79c	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 00:02:33.303501	2026-07-20 00:02:33.303501
c1286ec4-6b1a-4d9a-911c-6487ce38a955	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 18:58:51.152633	2026-07-19 18:58:51.152633
da39f14e-9aa0-44dc-ab65-fab88baa8439	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 01:00:10.590196	2026-07-20 01:00:10.590196
69455ec9-82ac-4f29-8936-4b6b14fa7f7d	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 18:58:51.208521	2026-07-19 18:58:51.208521
2d011272-0f28-4f1a-8781-db522471ec6a	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 00:02:38.742947	2026-07-20 00:02:38.742947
e94d4903-5b80-43d1-b723-1faf1010f30a	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 01:00:10.637227	2026-07-20 01:00:10.637227
eefc3907-1a5b-42d1-9efd-85afe7be1a67	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:02:46.988317	2026-07-20 00:02:46.988317
d2b79c64-eccc-493c-8556-43111971e0bf	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:38:33.205116	2026-07-20 12:38:33.205116
10b99936-34b3-4e37-b486-15787a352e74	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 01:00:13.785437	2026-07-20 01:00:13.785437
c0eefd13-a52c-42f2-98a1-3fe213ebd025	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 19:16:50.599667	2026-07-19 19:16:50.599667
f0b09df2-b2fb-4d8e-9b50-ec4495bf798f	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 19:16:50.712281	2026-07-19 19:16:50.712281
a7a23909-1f29-4ff3-9f5d-8cdae5cbba34	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 19:16:50.539756	2026-07-19 19:16:50.539756
c4db6c8b-dfbb-44d4-869c-4c2995ba6ea3	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 19:16:50.631785	2026-07-19 19:16:50.631785
249f4cea-d41d-4a83-88bd-d2863e9cd293	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-19 19:16:50.675607	2026-07-19 19:16:50.675607
84871b0a-da49-4293-a0e0-3f3b6972f637	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:38:37.272347	2026-07-20 12:38:37.272347
a50f51c0-bd7b-4b27-8aa0-8c4d5acabcea	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-19 19:16:52.784782	2026-07-19 19:16:52.784782
e1bd502c-9c36-491b-9964-94b38b44b9b7	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 01:00:17.178468	2026-07-20 01:00:17.178468
b49c2b7d-8216-4bbd-b12f-5ead9aaf4a4d	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 19:16:58.849893	2026-07-19 19:16:58.849893
1d14307c-a70b-4e8c-b075-37a36323f817	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:55:45.321432	2026-07-20 12:55:45.321432
31d09516-5de4-4f4a-9f7f-cad0e7568c44	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 19:17:00.406657	2026-07-19 19:17:00.406657
bd1f59dd-142b-45b1-8159-faac2aa94594	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 01:00:20.989877	2026-07-20 01:00:20.989877
365910bd-ecac-442a-a32c-c0d5d976c586	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-19 19:17:00.451531	2026-07-19 19:17:00.451531
4dec49b9-5534-4ee7-87b2-f73949abb6b3	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:48:39.601136	2026-07-20 12:48:39.601136
9e850e6e-6882-4113-b8e9-6c6d1b18a49f	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 01:00:21.039543	2026-07-20 01:00:21.039543
acf7f4cd-2e5e-4d3d-80f7-88f1be8bde38	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:48:41.471537	2026-07-20 12:48:41.471537
3e92c41f-6836-4281-b95f-e09e7f3a6d3e	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:48:41.424834	2026-07-20 12:48:41.424834
a0e43b70-2982-4648-8c75-802e4d6e251b	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:48:51.844029	2026-07-20 12:48:51.844029
27ca55da-a47d-4a39-95dd-d50029a1e390	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:28:18.044635	2026-07-20 00:28:18.044635
13b49e73-1036-44f0-9dc4-ce29db636f2a	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:28:17.910373	2026-07-20 00:28:17.910373
a5a2bfb7-9fb1-4d2e-a4b8-2d73f187ffb9	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 00:28:17.990017	2026-07-20 00:28:17.990017
048f6390-ec88-493d-b841-3109e086a765	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:28:25.695562	2026-07-20 00:28:25.695562
b269b6f6-9422-4e21-9534-0c880682ff35	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:28:26.786348	2026-07-20 00:28:26.786348
488d5215-48ae-46f0-9d69-3e15a446b9f8	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:57:35.150246	2026-07-20 00:57:35.150246
491f803b-bfea-4bf9-b30c-bd3c8dd00ab4	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:57:35.21826	2026-07-20 00:57:35.21826
84969e5c-3080-499f-97b9-7a1341bdbb7b	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:57:35.254293	2026-07-20 00:57:35.254293
705ccacf-0d18-4d59-ad7c-1f368f1d7e94	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 00:57:35.299333	2026-07-20 00:57:35.299333
4abc134d-1bf7-4a1b-b56b-a93f38ec3bb8	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:57:35.330733	2026-07-20 00:57:35.330733
da37d0f2-ca24-4e24-bbd0-e16a58efe752	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 00:57:39.491189	2026-07-20 00:57:39.491189
e930f87c-87f9-413d-a2e9-fa5e449184dc	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:57:40.573409	2026-07-20 00:57:40.573409
d2b25d6a-5d70-4178-96a0-b042f9a8c092	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:57:45.916137	2026-07-20 00:57:45.916137
e4753fc9-0acc-4fc8-bebe-0cd6f50c329e	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 00:57:45.968005	2026-07-20 00:57:45.968005
4e13c102-deeb-4725-b929-f8bdff516749	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:38:37.215971	2026-07-20 12:38:37.215971
df24ad5f-fe65-4569-bbc7-3586c5c10af0	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:51:33.529083	2026-07-20 12:51:33.529083
ef8c8985-d728-4fe8-820a-0b837e2fd74f	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:51:41.21228	2026-07-20 12:51:41.21228
2fe34c7c-ef64-41f8-826e-f62e87401edd	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:55:45.377084	2026-07-20 12:55:45.377084
065f4fb4-e484-4f22-87fe-d2c3858e7849	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:55:45.425232	2026-07-20 12:55:45.425232
980ffcd7-5a3c-4928-bf9e-f4dd96675866	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:56:01.052435	2026-07-20 12:56:01.052435
3ac7ebcc-62ae-431d-a1be-6478d4d3fa02	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:01.125562	2026-07-20 12:56:01.125562
462f3798-306e-4003-ab3a-1ab28c6d9b59	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:00.910065	2026-07-20 12:56:00.910065
70ce5930-5e5c-4c91-899c-1c68adcc8861	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:18:26.463496	2026-07-20 12:18:26.463496
e52fff5e-3416-425f-a7ca-9fa8167ad55b	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:18:26.61436	2026-07-20 12:18:26.61436
82b80c45-44f4-49f3-9c49-ddbec2d0e7e9	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:18:26.712605	2026-07-20 12:18:26.712605
d511cce2-1b54-41cd-8266-966de7de94f8	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:18:26.816001	2026-07-20 12:18:26.816001
2e6ba910-ebca-43cd-a889-289029f5ad99	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:18:26.914873	2026-07-20 12:18:26.914873
e2765229-c2ca-4f15-8c79-9f32679fa0c7	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:18:31.812733	2026-07-20 12:18:31.812733
d02b7f55-a393-4220-b10a-4b7ce78696ec	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:22.943343	2026-07-20 12:56:22.943343
a1590e19-0152-4358-854d-1f301a5a7115	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:18:35.679578	2026-07-20 12:18:35.679578
75a2ed43-ac06-4283-953a-232d6c8847dd	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:18:37.838854	2026-07-20 12:18:37.838854
93d9205c-6bbf-4463-8eff-37bc3060a758	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:36.077103	2026-07-20 12:56:36.077103
8e98e8ad-0253-4b86-b713-c600cc64a5d6	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:18:37.940655	2026-07-20 12:18:37.940655
6e45e5c2-b65f-47f7-86bc-e99ccbfead95	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:48:41.590618	2026-07-20 12:48:41.590618
41643f16-39a7-462d-bbf6-0a1005182d24	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:48:41.53328	2026-07-20 12:48:41.53328
3c200b79-2356-4822-b4a1-3f138848cd21	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:48:41.350601	2026-07-20 12:48:41.350601
aa281e86-6dee-4bf7-91f5-71c42899cc62	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:48:47.17532	2026-07-20 12:48:47.17532
ff49f378-9d27-474e-a0cb-2a8d6c0df421	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:48:51.90977	2026-07-20 12:48:51.90977
270922de-663d-447a-8d4b-2c1ce1cccbc0	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:34:40.949363	2026-07-20 12:34:40.949363
89fca270-142e-4a60-90a3-915759b0cb62	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:34:40.772966	2026-07-20 12:34:40.772966
b1ffbdf5-018c-478d-b6d4-5aca07110c1f	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:34:40.823513	2026-07-20 12:34:40.823513
37d05b1f-33fa-4740-8f74-c210fd3fe45b	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:34:40.733179	2026-07-20 12:34:40.733179
8e56bd11-e789-49d7-bdcd-7bc6232cf609	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:34:40.578213	2026-07-20 12:34:40.578213
9eac7c80-57f2-4ac5-a311-e41d39843ac8	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:34:55.511964	2026-07-20 12:34:55.511964
6b7c48dc-8032-442d-bb6c-10e68ded9ee7	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:34:56.711372	2026-07-20 12:34:56.711372
afd590c3-25f2-4cf3-b8c1-7bc7b2d021c4	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:34:56.782617	2026-07-20 12:34:56.782617
fbedc015-2b7e-45b2-81b6-489e62eeeee1	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:34:59.572904	2026-07-20 12:34:59.572904
7eacff76-9984-46e5-878c-e6efa2b77e77	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:38:17.988736	2026-07-20 12:38:17.988736
18d8b055-9896-4f7d-b8f7-f0113d464722	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:38:18.036618	2026-07-20 12:38:18.036618
35cc9407-5a72-4e70-9ede-9fb028baa698	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:38:17.879726	2026-07-20 12:38:17.879726
167d6e39-ed16-4ad1-8793-4ee8919b157b	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:38:18.071201	2026-07-20 12:38:18.071201
4920d195-72fd-41bf-936f-c04a51efd992	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:38:17.95019	2026-07-20 12:38:17.95019
4dacddbc-0d01-4bd4-9d8c-49a98813ed29	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:51:33.298405	2026-07-20 12:51:33.298405
8947e434-a130-4dc7-88e5-2db3578ba7b9	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:51:33.417123	2026-07-20 12:51:33.417123
4602a756-37fa-4a0d-9211-80465c55f110	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:51:33.465819	2026-07-20 12:51:33.465819
4702c63d-75e3-4eaf-8588-e24eb7a23952	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:55:45.198683	2026-07-20 12:55:45.198683
97c2ef46-7b10-4771-b179-b6a06c105ec6	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:51:49.344764	2026-07-20 12:51:49.344764
966f5046-2b0e-4370-9438-0146a2c57855	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:55:45.278102	2026-07-20 12:55:45.278102
74682881-7088-4a99-ac84-af0e7a35a5cf	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:00.953957	2026-07-20 12:56:00.953957
b414e589-4e6e-4618-9a4f-5b5adccf8479	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:23.104065	2026-07-20 12:56:23.104065
5a85e057-c0ca-4441-b241-598b752ff877	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:56:23.054042	2026-07-20 12:56:23.054042
d40e3345-493d-47d6-8b37-7537f2761707	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:52:45.599898	2026-07-20 12:52:45.599898
b861d5ea-229e-4151-8aab-3e64f5903c5f	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:52:45.659919	2026-07-20 12:52:45.659919
9b505b97-5826-4d52-a063-93ea4c3dcef0	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:52:45.501338	2026-07-20 12:52:45.501338
cccd7599-8478-4cc5-9763-4121ba1a2d20	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:49:28.646899	2026-07-20 12:49:28.646899
1c684715-d99a-48e3-b190-1368283e3313	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:49:28.527912	2026-07-20 12:49:28.527912
863c4aad-4235-430a-98ba-78100d4524d3	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:49:28.59311	2026-07-20 12:49:28.59311
38b13da9-bdbb-4956-ad1e-839fddf00ec1	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:49:28.379528	2026-07-20 12:49:28.379528
c48a1b78-165a-4a09-804f-3e48c99bc624	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:49:28.479325	2026-07-20 12:49:28.479325
0d469dec-fc04-4774-8405-5b756e16ea65	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:52:54.731536	2026-07-20 12:52:54.731536
bee0d5b4-dbc8-4481-9f6a-87b2174ab128	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:49:39.602586	2026-07-20 12:49:39.602586
e854cbf4-01c8-4c5d-873a-e3d582b16e41	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:40.3484	2026-07-20 12:56:40.3484
02e847d0-ab1a-46f2-966d-4dc2bded2d11	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:49:49.723683	2026-07-20 12:49:49.723683
44b446d1-15cd-47c6-a62a-230e108c6669	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:52:57.461124	2026-07-20 12:52:57.461124
872e8b09-f399-420e-9e26-b91211d06f9f	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:49:52.429407	2026-07-20 12:49:52.429407
48bf45db-71b1-4a6c-a408-4e1934fcd22d	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:49:52.498035	2026-07-20 12:49:52.498035
9293c2bf-0899-409b-8985-869abb1cf3c9	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:53:53.483381	2026-07-20 12:53:53.483381
532c09d0-6ce8-4de7-981d-52127acc4805	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:53:53.604562	2026-07-20 12:53:53.604562
8d392343-c757-424b-ae12-0451e150efd8	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:53:53.655369	2026-07-20 12:53:53.655369
57d3778b-99c1-46a5-a164-06c2bcd1132c	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:53:53.705847	2026-07-20 12:53:53.705847
55ca7484-94b0-4455-9180-05b52e1c121b	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:54:03.220665	2026-07-20 12:54:03.220665
d4b2c994-f976-4bb4-9422-6d36730fc897	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:54:07.348623	2026-07-20 12:54:07.348623
d52c8951-10d6-4cb8-9354-d46161909ccb	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:54:46.254806	2026-07-20 12:54:46.254806
4e2b2878-5d39-4d5a-9b8f-b3ae983fdfcd	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:54:46.458169	2026-07-20 12:54:46.458169
06c5b811-4e47-4d88-9192-be85e73cf378	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:54:46.366261	2026-07-20 12:54:46.366261
76ae0e3c-2f0d-4db7-a149-f99eb069ef4c	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:54:46.410462	2026-07-20 12:54:46.410462
7b95383b-ae79-4f18-bccf-74eaff7eed5e	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:55:03.528926	2026-07-20 12:55:03.528926
9de5daa5-f676-4355-b01d-ec26a01a41cd	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:55:05.495385	2026-07-20 12:55:05.495385
0bcbbed8-de0b-4509-878a-e80f8eff820e	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:51:39.929106	2026-07-20 12:51:39.929106
e3445747-1ebf-48b8-a9ad-06eb7ea3da0d	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:00.824926	2026-07-20 12:56:00.824926
c3ddf122-ff08-4559-ab97-2d957e29ce7c	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:51:49.414083	2026-07-20 12:51:49.414083
38a3cf9a-2950-4f6f-9b70-be1a5893e883	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:50:37.182781	2026-07-20 12:50:37.182781
ede5d211-6eaa-4fe8-a05b-ec152223530a	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:50:37.283527	2026-07-20 12:50:37.283527
a2bd44ed-15f7-47f3-a725-1f4224259c1d	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:50:37.441774	2026-07-20 12:50:37.441774
7015ee73-0504-4722-8d97-f79423089336	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:50:37.329599	2026-07-20 12:50:37.329599
f535d671-5514-4a4f-8883-86115c4e9ca5	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 12:50:37.381871	2026-07-20 12:50:37.381871
b5426a57-d97f-4af4-87aa-c6ed17ea4ab3	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:52:45.539117	2026-07-20 12:52:45.539117
482607c2-ddf8-44da-b629-cacb08da7caa	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:50:40.97662	2026-07-20 12:50:40.97662
30cee9b9-3b6d-4d35-bdb6-12a2b6345c1b	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:52:45.427505	2026-07-20 12:52:45.427505
d2aabb0d-8ed7-4052-bf18-3aae62de5275	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:50:45.452643	2026-07-20 12:50:45.452643
2fb0c81c-3c6c-44e9-ba2a-545c635c3081	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:22.852382	2026-07-20 12:56:22.852382
6d51897d-4166-423d-af35-a2934d4b604b	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:50:49.189797	2026-07-20 12:50:49.189797
47d6c075-c281-4fec-9f79-d0ef3813a44e	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:52:51.279597	2026-07-20 12:52:51.279597
7ce7daba-5054-4e36-b28d-a4d6c233b3fd	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:50:49.249648	2026-07-20 12:50:49.249648
51c7d876-b14e-4ace-b83c-76e339060976	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:23.004591	2026-07-20 12:56:23.004591
c7f34f9b-94fc-4470-881b-16ac856e84fe	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:52:54.790994	2026-07-20 12:52:54.790994
6388ced9-e037-4d1b-892f-6f4b1032b976	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:56:32.479505	2026-07-20 12:56:32.479505
7d3c0f7d-0a63-40eb-bf92-5636fd0e0434	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:56:40.403516	2026-07-20 12:56:40.403516
af791a87-4a5f-45c6-a40b-9ba87546eeff	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 13:33:23.628404	2026-07-20 13:33:23.628404
9c6a53c8-5fdb-4cb7-bc12-ea6ecb97b4af	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 13:33:25.13131	2026-07-20 13:33:25.13131
034ac0d0-9356-4563-83bc-6e14d0d82176	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 13:33:25.256575	2026-07-20 13:33:25.256575
68061b11-23e8-4d29-ac21-baa51b92df27	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 13:33:25.059214	2026-07-20 13:33:25.059214
86b5f348-4df2-49d0-a85e-69bb946ecc6e	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 13:33:25.172017	2026-07-20 13:33:25.172017
cad2a195-d45d-47e9-a5f3-de15356cae42	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 13:33:25.220687	2026-07-20 13:33:25.220687
bbee6439-15a3-4a2a-acb6-8eb04c92fa92	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 13:33:32.806258	2026-07-20 13:33:32.806258
c85a7cd9-9d24-4157-a923-b257e78fbaf8	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 13:33:35.680414	2026-07-20 13:33:35.680414
ba5a98e8-f39c-45a9-9d0c-9b97f58835f7	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:53:53.560928	2026-07-20 12:53:53.560928
d3ae57cd-50f9-4c5a-85e7-2b6ec1e3f6bb	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:53:59.544305	2026-07-20 12:53:59.544305
a8ec86ca-52ef-4cfb-b4db-a55e6db74a62	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 13:33:35.746463	2026-07-20 13:33:35.746463
4348f7a8-a15d-456c-8848-4ff428871eee	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:54:07.289397	2026-07-20 12:54:07.289397
02933141-13d3-410b-9c23-873cfc95bb29	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:54:46.324319	2026-07-20 12:54:46.324319
920ff4c6-6cb7-49e0-a881-8afc21ff188e	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 12:54:57.580361	2026-07-20 12:54:57.580361
9c148960-cd04-4778-ad99-85aee2a19346	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 12:55:05.425452	2026-07-20 12:55:05.425452
ce5aca81-3bf5-4b3c-8005-0058808e2eed	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 18:22:23.228513	2026-07-20 18:22:23.228513
b7ba25e7-c894-4fb0-8715-4acf1c1c95fc	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 18:22:23.276687	2026-07-20 18:22:23.276687
31c67ab9-3730-4846-89ab-48eab8696b35	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	290000.00	EGP	{"condition": "used"}	listing_sold	2026-07-20 18:22:23.327941	2026-07-20 18:22:23.327941
2e2a7699-8100-47d0-b146-f58ed20298dd	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 18:22:23.155344	2026-07-20 18:22:23.155344
17c8f8dd-5971-47c3-9386-2f69261484b6	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 18:22:23.363528	2026-07-20 18:22:23.363528
d8089c0d-af02-4f7a-be38-c4ff9b0031be	\N	car	car|new-cairo،-cairo|toyota|corolla	new-cairo،-cairo	850000.00	EGP	{"brand": "Toyota", "model": "Corolla", "condition": "used", "fuel_type": "petrol"}	listing_publish	2026-07-20 18:22:28.312938	2026-07-20 18:22:28.312938
d6ca9d9c-ad1e-43c8-9a44-e17b128c752c	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	350000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 18:22:35.184647	2026-07-20 18:22:35.184647
f8d57e67-150b-462c-b16b-93aa231b43ab	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 18:22:36.353317	2026-07-20 18:22:36.353317
34bfa609-4c5f-4afc-b1d2-9aaf61a396b2	\N	car	car|new-cairo،-cairo	new-cairo،-cairo	300000.00	EGP	{"condition": "used"}	listing_publish	2026-07-20 18:22:36.42423	2026-07-20 18:22:36.42423
\.


--
-- Data for Name: promo_ad_campaign_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promo_ad_campaign_config (id, enabled, verified_monthly_amount, unverified_monthly_amount, duration_months, campaign_version, starts_at, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: promo_ad_grants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promo_ad_grants (id, user_id, campaign_version, month_index, amount, created_at) FROM stdin;
\.


--
-- Data for Name: promo_ad_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promo_ad_transactions (id, user_id, type, amount, balance_after, campaign_version, reference_type, reference_id, description, idempotency_key, created_at) FROM stdin;
\.


--
-- Data for Name: property_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.property_types (id, slug, name, name_ar, sort_order, created_at) FROM stdin;
6097cee0-c9fb-4d27-941f-85c034ec789c	apartment	Apartment	شقة	0	2026-07-18 21:27:18.393569
33ee14cb-bcc0-4daf-b93a-823bd29c5a22	villa	Villa	فيلا	1	2026-07-18 21:27:18.397642
c7b1111a-7f06-4f60-b8e4-a848d3de8d04	townhouse	Townhouse	تاون هاوس	2	2026-07-18 21:27:18.404827
80a8e3b8-848e-44fd-b4a0-89b286d38f80	twinhouse	Twinhouse	توين هاوس	3	2026-07-18 21:27:18.411181
61d04884-0f14-427c-8f46-db591f317dc8	penthouse	Penthouse	بنتهاوس	4	2026-07-18 21:27:18.414901
7326d47c-4060-48c9-ac48-12c790e78832	duplex	Duplex	دوبلكس	5	2026-07-18 21:27:18.419459
133865ea-80c3-4043-9291-6bc7d55c0384	studio	Studio	استوديو	6	2026-07-18 21:27:18.424318
130cafd9-09be-4b07-b74c-0352dc7de103	chalet	Chalet	شاليه	7	2026-07-18 21:27:18.431567
999b4b99-c31d-45b8-afba-290cf802d617	office	Office	مكتب	8	2026-07-18 21:27:18.434611
1be3d0fa-abb9-4b8e-9f9e-f361d5b79ceb	clinic	Clinic	عيادة	9	2026-07-18 21:27:18.438168
ace48cdb-39c1-4f39-afff-3d12b9e884e8	shop	Shop	محل	10	2026-07-18 21:27:18.441899
e2e83517-2086-48ee-a09f-ddad9011b1b5	land	Land	أرض	11	2026-07-18 21:27:18.445432
\.


--
-- Data for Name: push_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_tokens (id, user_id, token, platform, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rate_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rate_events (id, counter_name, bucket_key, event_at) FROM stdin;
b08d486a-6b35-4657-ae51-bc4526300fad	lead_rate	f787718d-27d8-4877-82fd-b4ff2a25bdee	2026-07-21 13:33:10.152634
4d55dd1e-ba98-4dc7-a827-f5f298f2b970	listing_lead_rate	9322a87e-6899-4b8a-8399-280801afaff0	2026-07-21 13:33:10.160092
68879b1e-4db8-4c7a-8524-8ecbdf262e62	ip_clicks	127.0.0.1	2026-07-21 13:33:10.163506
e6b3bffa-c0c6-4de2-9386-935d6dbc42bb	lead_repeat	f787718d-27d8-4877-82fd-b4ff2a25bdee:9322a87e-6899-4b8a-8399-280801afaff0	2026-07-21 13:33:10.176598
bf142c52-bc17-4a00-bdc3-2f5f16d37ee9	conversation_rate	f787718d-27d8-4877-82fd-b4ff2a25bdee	2026-07-21 13:34:27.052717
1e4facda-a5cc-4dff-beff-981cdae15cd6	lead_rate	f787718d-27d8-4877-82fd-b4ff2a25bdee	2026-07-21 13:34:27.054585
451bd114-0108-4b0c-a520-9ad34b834c55	listing_lead_rate	b91b906c-199e-4872-8bd7-aa305e61d456	2026-07-21 13:34:27.059516
ea695447-e2e7-4a39-b15b-09de375c30ec	ip_clicks	127.0.0.1	2026-07-21 13:34:27.063688
94459081-9215-4053-b312-380e950abd0f	lead_repeat	f787718d-27d8-4877-82fd-b4ff2a25bdee:b91b906c-199e-4872-8bd7-aa305e61d456	2026-07-21 13:34:27.070667
1f45e318-a5f3-47e2-804f-560d487d68ee	message_rate	f787718d-27d8-4877-82fd-b4ff2a25bdee	2026-07-21 13:34:30.002813
4622ca3e-6269-4545-8e5c-c39383dc1480	message_rate	f787718d-27d8-4877-82fd-b4ff2a25bdee	2026-07-21 13:34:31.782583
c87ca846-395c-44e8-a3c4-570407d3b1b1	message_rate	f787718d-27d8-4877-82fd-b4ff2a25bdee	2026-07-21 13:34:42.000153
\.


--
-- Data for Name: reference_developers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reference_developers (id, slug, name_en, name_ar, local_name, iso_country_code, aliases, search_keywords, search_blob, popularity, status, created_at, updated_at) FROM stdin;
8867ee3e-c70a-4584-b464-0febbbd4047a	talaat-moustafa-group	Talaat Moustafa Group	مجموعة طلعت مصطفى	\N	EG	[]	["TMG", "طلعت مصطفى", "تي ام جي", "talaat"]	talaat moustafa group مجموعة طلعت مصطفى tmg طلعت مصطفى تي ام جي talaat talaat-moustafa-group	0	active	2026-07-18 21:27:23.549885	2026-07-19 13:56:32.948
417247e3-ace9-4828-981e-df5d1d312263	emaar-misr	Emaar Misr	إعمار مصر	\N	EG	[]	["Emaar", "إعمار", "امار"]	emaar misr إعمار مصر emaar إعمار امار emaar-misr	0	active	2026-07-18 21:27:23.630017	2026-07-19 13:56:33.059
936bb484-ddf1-4bfa-b4fb-d45519af4142	palm-hills	Palm Hills Developments	بالم هيلز	\N	EG	[]	["Palm Hills", "بالم هيلز", "PHD"]	palm hills developments بالم هيلز palm hills phd palm-hills	0	active	2026-07-18 21:27:23.743863	2026-07-19 13:56:33.072
e4630408-0674-4f8b-bf20-2964bdd8b104	mountain-view	Mountain View	ماونتن فيو	\N	EG	[]	["Mountain View", "ماونتن فيو", "MV", "DMG"]	mountain view ماونتن فيو mv dmg mountain-view	0	active	2026-07-18 21:27:23.748385	2026-07-19 13:56:33.085
1b5acfcf-fc19-4960-bfb4-2b9ea3faa5b4	misr-italia	Misr Italia Properties	مصر إيطاليا	\N	EG	[]	["Misr Italia", "مصر ايطاليا", "مصر إيطاليا"]	misr italia properties مصر إيطاليا misr italia مصر ايطاليا misr-italia	0	active	2026-07-18 21:27:23.7529	2026-07-19 13:56:33.093
be1d5045-4201-4c31-a5d6-24103db7f8d9	sodic	SODIC	سوديك	\N	EG	[]	["SODIC", "سوديك", "سو ديك"]	sodic سوديك سو ديك	0	active	2026-07-18 21:27:23.757539	2026-07-19 13:56:33.109
7f947c27-fd9d-4157-bd01-d9155fdf94f0	ora-developers	Ora Developers	أورا للتطوير	\N	EG	[]	["Ora", "أورا", "اورا", "ساويرس"]	ora developers أورا للتطوير ora أورا اورا ساويرس ora-developers	0	active	2026-07-18 21:27:23.760935	2026-07-19 13:56:33.127
8664519e-c755-4d73-a86e-e3995b281427	hyde-park	Hyde Park Developments	هايد بارك	\N	EG	[]	["Hyde Park", "هايد بارك"]	hyde park developments هايد بارك hyde park hyde-park	0	active	2026-07-18 21:27:23.766777	2026-07-19 13:56:33.145
0df74c3a-8139-4cd4-b2f3-ecf83016cd78	al-ahly-sabbour	Al Ahly Sabbour	الأهلي صبور	\N	EG	[]	["Sabbour", "صبور", "الاهلي صبور"]	al ahly sabbour الأهلي صبور sabbour صبور الاهلي صبور al-ahly-sabbour	0	active	2026-07-18 21:27:23.771229	2026-07-19 13:56:33.155
d80fa520-2473-44a4-9d7b-d912f04b76e9	hassan-allam	Hassan Allam Properties	حسن علام	\N	EG	[]	["Hassan Allam", "حسن علام"]	hassan allam properties حسن علام hassan allam hassan-allam	0	active	2026-07-18 21:27:23.775584	2026-07-19 13:56:33.176
97b1750e-4dc8-4437-9d8a-905b83dc601c	city-edge	City Edge Developments	سيتي إيدج	\N	EG	[]	["City Edge", "سيتي ايدج", "سيتي إيدج"]	city edge developments سيتي إيدج city edge سيتي ايدج city-edge	0	active	2026-07-18 21:27:23.781427	2026-07-19 13:56:33.184
0f9e8dd8-eb8d-40f5-904c-1a77c4675d89	lmd	LMD	إل إم دي	\N	EG	[]	["LMD", "ال ام دي"]	lmd إل إم دي ال ام دي	0	active	2026-07-18 21:27:23.785364	2026-07-19 13:56:33.192
94c09d1c-c8d5-42f1-8a57-cd0418c26a38	tatweer-misr	Tatweer Misr	تطوير مصر	\N	EG	[]	["Tatweer Misr", "تطوير مصر"]	tatweer misr تطوير مصر tatweer-misr	0	active	2026-07-18 21:27:23.788834	2026-07-19 13:56:33.203
e4d3ab7c-0238-4806-99f8-a5aa8ad0a773	cred	CRED	كريد	\N	EG	[]	["CRED", "كريد"]	cred كريد	0	active	2026-07-18 21:27:23.793411	2026-07-19 13:56:33.213
824b28cf-ea9e-494a-af71-dae840f905b9	la-vista	La Vista Developments	لافيستا	\N	EG	[]	["La Vista", "لافيستا", "لا فيستا"]	la vista developments لافيستا la vista لا فيستا la-vista	0	active	2026-07-18 21:27:23.796614	2026-07-19 13:56:33.22
d6805422-9168-4fd1-b54b-d6578ab6621b	emaar-properties	Emaar Properties	إعمار العقارية	\N	EG	[]	["Emaar", "إعمار"]	emaar properties إعمار العقارية emaar إعمار emaar-properties	0	active	2026-07-18 21:27:23.800381	2026-07-19 13:56:33.229
e6982af0-9e96-4f0e-aaaa-eb34fd9d33dd	damac	DAMAC Properties	داماك	\N	EG	[]	["Damac", "داماك"]	damac properties داماك damac	0	active	2026-07-18 21:27:23.804525	2026-07-19 13:56:33.239
76047228-37c9-4005-aa68-21f7ee34e9b2	nakheel	Nakheel	نخيل	\N	EG	[]	["Nakheel", "نخيل"]	nakheel نخيل	0	active	2026-07-18 21:27:23.808371	2026-07-19 13:56:33.247
74c35641-b212-4dc1-a0ba-32a727d5c160	meraas	Meraas	ميراس	\N	EG	[]	["Meraas", "ميراس"]	meraas ميراس	0	active	2026-07-18 21:27:23.811696	2026-07-19 13:56:33.254
4a127859-a3fe-468c-aa6b-ba1039f9dd43	dubai-properties	Dubai Properties	دبي العقارية	\N	EG	[]	["Dubai Properties"]	dubai properties دبي العقارية dubai-properties	0	active	2026-07-18 21:27:23.815561	2026-07-19 13:56:33.264
4f90e87e-45eb-4111-847f-0ecacf662bcb	sobha-realty	Sobha Realty	صوبها	\N	EG	[]	["Sobha", "صوبها"]	sobha realty صوبها sobha sobha-realty	0	active	2026-07-18 21:27:23.819074	2026-07-19 13:56:33.377
5756f4f7-1f30-4d82-bb95-b4ad9b2d1276	aldar	Aldar Properties	الدار العقارية	\N	EG	[]	["Aldar", "الدار"]	aldar properties الدار العقارية aldar الدار	0	active	2026-07-18 21:27:23.82346	2026-07-19 13:56:33.386
0dee2ff8-a26a-4e7c-b278-692076f42ecc	majid-al-futtaim	Majid Al Futtaim	ماجد الفطيم	\N	EG	[]	["Majid Al Futtaim", "الفطيم"]	majid al futtaim ماجد الفطيم الفطيم majid-al-futtaim	0	active	2026-07-18 21:27:23.82698	2026-07-19 13:56:33.393
5eb4415f-2181-4bee-b88c-fa443a6ecd3f	roshn	ROSHN	روشن	\N	EG	[]	["Roshn", "روشن"]	roshn روشن	0	active	2026-07-18 21:27:23.831142	2026-07-19 13:56:33.4
726f6bbf-1d60-4d90-ac1d-bd9a4d30b38a	qatari-diar	Qatari Diar	الديار القطرية	\N	EG	[]	["Qatari Diar", "الديار"]	qatari diar الديار القطرية الديار qatari-diar	0	active	2026-07-18 21:27:23.835114	2026-07-19 13:56:33.408
2e54f11d-15c8-485e-bfdc-34eaa433cae9	united-development	United Development Company	الشركة المتحدة للتنمية	\N	EG	[]	["UDC", "The Pearl"]	united development company الشركة المتحدة للتنمية udc the pearl united-development	0	active	2026-07-18 21:27:23.842073	2026-07-19 13:56:33.416
b1853876-bea8-4f21-a8d6-1aa8d9530b58	diyar-al-muharraq	Diyar Al Muharraq	ديار المحرق	\N	EG	[]	["Diyar Al Muharraq", "ديار المحرق"]	diyar al muharraq ديار المحرق diyar-al-muharraq	0	active	2026-07-18 21:27:23.84785	2026-07-19 13:56:33.423
\.


--
-- Data for Name: reference_places; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reference_places (id, global_id, parent_id, place_type, iso_country_code, name_en, name_ar, local_name, slug, aliases, search_keywords, search_blob, developer_id, latitude, longitude, geohash, postal_code, timezone, currency, language, popularity, verified, source, source_url, confidence_score, status, created_at, updated_at) FROM stdin;
e6d7db7a-1e47-4800-957e-ce6c0987bc31	egypt.new-cairo.first-settlement	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	community	EG	First Settlement	التجمع الأول	\N	first-settlement	[]	["First Settlement", "التجمع الأول", "التجمع الاول"]	first settlement التجمع الأول التجمع الاول	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.860668	2026-07-19 13:56:33.474
66ebaaf4-64da-40e7-b32d-8c4a16f523df	egypt.new-cairo.third-settlement	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	community	EG	Third Settlement	التجمع الثالث	\N	third-settlement	[]	["Third Settlement", "التجمع الثالث"]	third settlement التجمع الثالث	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.87636	2026-07-19 13:56:33.481
6b0bfca0-dc58-4346-b852-3bc5b43c95af	egypt.new-cairo.fifth-settlement	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	community	EG	Fifth Settlement	التجمع الخامس	\N	fifth-settlement	[]	["Fifth Settlement", "التجمع الخامس", "Fifth", "خامس", "New Cairo"]	fifth settlement التجمع الخامس fifth خامس new cairo	\N	\N	\N	\N	\N	\N	\N	\N	95	t	curated	\N	\N	active	2026-07-18 21:27:23.882655	2026-07-19 13:56:33.506
e350a633-c67d-4b74-ab13-9470408a1f2e	egypt.new-cairo.fifth-settlement.hyde-park-new-cairo	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Hyde Park	هايد بارك	\N	hyde-park-new-cairo	[]	["Hyde Park", "هايد بارك"]	hyde park هايد بارك hyde park new cairo	8664519e-c755-4d73-a86e-e3995b281427	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.895804	2026-07-19 13:56:33.519
da505f77-8bf2-4f86-87ce-cad15b2bbcf5	egypt.new-cairo.fifth-settlement.mountain-view-icity-nc	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Mountain View iCity	ماونتن فيو آي سيتي	\N	mountain-view-icity-nc	[]	["iCity", "اي سيتي", "ماونتن فيو"]	mountain view icity ماونتن فيو آي سيتي icity اي سيتي ماونتن فيو mountain view icity nc	e4630408-0674-4f8b-bf20-2964bdd8b104	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.900773	2026-07-19 13:56:33.528
bceb8c67-40f9-48a2-92e3-79f5b8afcc99	egypt.new-cairo.fifth-settlement.palm-hills-new-cairo	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Palm Hills New Cairo	بالم هيلز نيو كايرو	\N	palm-hills-new-cairo	[]	["PHNC", "بالم هيلز"]	palm hills new cairo بالم هيلز نيو كايرو phnc بالم هيلز	936bb484-ddf1-4bfa-b4fb-d45519af4142	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.905124	2026-07-19 13:56:33.547
51b77397-ae33-434c-8ff4-694363f68f37	egypt.new-cairo.fifth-settlement.mivida	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Mivida	ميفيدا	\N	mivida	[]	["Mivida", "ميفيدا", "mivida"]	mivida ميفيدا	417247e3-ace9-4828-981e-df5d1d312263	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.90922	2026-07-19 13:56:33.555
a133b270-962e-4f8a-99a8-1389ae3e7a1f	egypt.new-cairo.fifth-settlement.taj-city	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Taj City	تاج سيتي	\N	taj-city	[]	["Taj City", "تاج سيتي"]	taj city تاج سيتي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.912765	2026-07-19 13:56:33.565
bea7eb16-bdaa-4f0f-9198-9c4748e9c000	egypt.new-cairo.fifth-settlement.stone-residence	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Stone Residence	ستون ريزيدنس	\N	stone-residence	[]	["Stone Residence", "ستون"]	stone residence ستون ريزيدنس ستون	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.916633	2026-07-19 13:56:33.577
fe9f1021-9daa-4952-bbde-b083ab6a629d	egypt.new-cairo.fifth-settlement.villette	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Villette	فيليت	\N	villette	[]	["Villette", "فيليت"]	villette فيليت	be1d5045-4201-4c31-a5d6-24103db7f8d9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.922142	2026-07-19 13:56:33.585
0c59c30b-23e6-4cf6-936e-bb4b56b1d224	egypt.new-cairo.fifth-settlement.zed-east	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Zed East	زيد إيست	\N	zed-east	[]	["Zed East", "زيد ايست", "زد"]	zed east زيد إيست زيد ايست زد	7f947c27-fd9d-4157-bd01-d9155fdf94f0	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.92537	2026-07-19 13:56:33.597
4c94c6be-a321-499f-ba8e-b34e1bbec996	egypt.new-cairo.fifth-settlement.the-waterway	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	The Waterway	ووتر واي	\N	the-waterway	[]	["Waterway", "ووتر واي"]	the waterway ووتر واي waterway	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.929313	2026-07-19 13:56:33.604
88aa1517-0371-4319-97ac-14647973efea	egypt.new-cairo.fifth-settlement.district-5	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	District 5	ديستريكت 5	\N	district-5	[]	["District 5", "ديستريكت 5", "district five"]	district 5 ديستريكت 5 district five	0f9e8dd8-eb8d-40f5-904c-1a77c4675d89	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.933115	2026-07-19 13:56:33.613
f0dd65cc-d555-4637-a60f-df7e2e4e64e9	egypt.new-cairo.fifth-settlement.lake-view	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Lake View	ليك فيو	\N	lake-view	[]	["Lake View", "ليك فيو"]	lake view ليك فيو	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.937076	2026-07-19 13:56:33.621
565cb120-1140-4701-a92b-6d861d6607dd	egypt.new-cairo.fifth-settlement.fifth-square	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Fifth Square	فيفث سكوير	\N	fifth-square	[]	["Fifth Square", "فيفث سكوير"]	fifth square فيفث سكوير	0df74c3a-8139-4cd4-b2f3-ecf83016cd78	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.940786	2026-07-19 13:56:33.629
7f8e3266-fc39-4341-9ebb-2a2d9ecd1edf	egypt.new-cairo.fifth-settlement.trio-gardens	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Trio Gardens	تريو جاردنز	\N	trio-gardens	[]	["Trio Gardens", "تريو"]	trio gardens تريو جاردنز تريو	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.943916	2026-07-19 13:56:33.639
46e2bf63-87e3-4628-8d57-64c8b7f3f86b	egypt.new-cairo.fifth-settlement.eastown	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Eastown	إيستاون	\N	eastown	[]	["Eastown", "ايستاون"]	eastown إيستاون ايستاون	be1d5045-4201-4c31-a5d6-24103db7f8d9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.948059	2026-07-19 13:56:33.647
c5dc06c8-7aef-4449-ac95-8e7e2a2c1087	egypt.new-cairo.fifth-settlement.la-mirada	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	La Mirada	لا ميرادا	\N	la-mirada	[]	["La Mirada", "لا ميرادا"]	la mirada لا ميرادا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.952977	2026-07-19 13:56:33.654
ddb384b5-d135-4100-b7a2-183d1d2e77d3	egypt.new-cairo.fifth-settlement.azad	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Azad	أزاد	\N	azad	[]	["Azad", "ازاد"]	azad أزاد ازاد	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.956499	2026-07-19 13:56:33.663
cb5f3d01-cd6c-4f6b-be37-3053d2ac50f4	egypt.new-cairo.fifth-settlement.galleria-moon-valley	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Galleria Moon Valley	جاليريا مون فالي	\N	galleria-moon-valley	[]	["Galleria", "جاليريا"]	galleria moon valley جاليريا مون فالي galleria جاليريا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.960206	2026-07-19 13:56:33.672
8f5a930f-a583-42ce-93a2-1cf10edf7e37	egypt.new-cairo.fifth-settlement.al-marasem	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	Al Marasem	المراسم	\N	al-marasem	[]	["Marasem", "المراسم"]	al marasem المراسم marasem	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.964099	2026-07-19 13:56:33.679
f4cb9712-6e76-4b50-a3e8-e6bdb8ed5b72	egypt.new-cairo.fifth-settlement.the-brooks	6b0bfca0-dc58-4346-b852-3bc5b43c95af	compound	EG	The Brooks	ذا بروكس	\N	the-brooks	[]	["Brooks", "بروكس"]	the brooks ذا بروكس brooks بروكس	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.969728	2026-07-19 13:56:33.687
bb87b7c1-6809-4098-a70c-938447331808	egypt.new-cairo.sixth-settlement	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	community	EG	Sixth Settlement	التجمع السادس	\N	sixth-settlement	[]	["Sixth Settlement", "التجمع السادس"]	sixth settlement التجمع السادس	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.974556	2026-07-19 13:56:33.697
41abb582-1c93-46ab-ad7a-a74c497736c8	egypt.new-cairo.sixth-settlement.el-patio-jade	bb87b7c1-6809-4098-a70c-938447331808	compound	EG	El Patio Jade	الباتيو جيد	\N	el-patio-jade	[]	[]	el patio jade الباتيو جيد	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.978248	2026-07-19 13:56:33.704
2a573f77-c185-4010-8cf8-a8b33acdc7d7	egypt.new-cairo.sixth-settlement.via	bb87b7c1-6809-4098-a70c-938447331808	compound	EG	Via	فيا	\N	via	[]	[]	via فيا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.982092	2026-07-19 13:56:33.712
3b1636c0-7c3a-49a6-a989-d1ae89382e63	egypt.new-cairo.sixth-settlement.new-lush-valley	bb87b7c1-6809-4098-a70c-938447331808	compound	EG	New Lush Valley	لاش فالي	\N	new-lush-valley	[]	[]	new lush valley لاش فالي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.990566	2026-07-19 13:56:33.727
07550cba-5cea-4335-9521-359d21bcb1d9	egypt.new-cairo.sixth-settlement.vx-golden-square	bb87b7c1-6809-4098-a70c-938447331808	compound	EG	VX Golden Square	في إكس جولدن سكوير	\N	vx-golden-square	[]	[]	vx golden square في إكس جولدن سكوير	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.997783	2026-07-19 13:56:33.734
a9c66422-2836-41c3-afce-68b0824e8e6e	egypt.new-cairo.sixth-settlement.mayan	bb87b7c1-6809-4098-a70c-938447331808	compound	EG	Mayan	مايان	\N	mayan	[]	[]	mayan مايان	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.001805	2026-07-19 13:56:33.742
69b30d65-ed44-4b70-8b35-d477616468ce	egypt.new-cairo.beit-al-watan	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	community	EG	Beit Al Watan	بيت الوطن	\N	beit-al-watan	[]	["Beit Al Watan", "بيت الوطن"]	beit al watan بيت الوطن	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.005047	2026-07-19 13:56:33.748
307ac8bd-4c20-49b5-a7e7-8f6b2c9ffdc5	egypt.new-cairo.south-investors	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	community	EG	Southern Investors	المستثمرين الجنوبية	\N	south-investors	[]	["المستثمرين الجنوبية"]	southern investors المستثمرين الجنوبية south investors	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.012231	2026-07-19 13:56:33.762
4e30f35a-2d73-4719-bf5d-67359fed622e	egypt.new-cairo.south-academy	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	community	EG	South Academy	جنوب الأكاديمية	\N	south-academy	[]	["جنوب الأكاديمية", "الاكاديمية"]	south academy جنوب الأكاديمية الاكاديمية	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.016166	2026-07-19 13:56:33.77
edcaa211-5e0b-4f9d-8fd2-d5f24b80dca2	egypt.new-cairo.lotus	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	neighborhood	EG	Lotus	اللوتس	\N	lotus	[]	["Lotus", "اللوتس"]	lotus اللوتس	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.020627	2026-07-19 13:56:33.777
fd0239c4-e8f7-4b18-8f18-38d7d62b3f23	egypt.new-cairo.andalus	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	neighborhood	EG	Andalus	الأندلس	\N	andalus	[]	["Andalus", "الاندلس"]	andalus الأندلس الاندلس	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.0244	2026-07-19 13:56:33.785
2b3219a1-7da5-4613-b998-9aa17291a12d	egypt.new-cairo.narges	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	neighborhood	EG	Narges	النرجس	\N	narges	[]	["Narges", "النرجس"]	narges النرجس	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.028253	2026-07-19 13:56:33.792
f2773b00-c408-4659-bd5f-05864d6dec63	egypt.new-cairo.banafseg	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	neighborhood	EG	Banafseg	البنفسج	\N	banafseg	[]	["Banafseg", "البنفسج"]	banafseg البنفسج	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.035851	2026-07-19 13:56:33.799
c27aa8e2-ae2a-406e-a96b-37d3a5bc53ae	egypt.new-cairo.qrnfl	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	neighborhood	EG	Qrnfl	القرنفل	\N	qrnfl	[]	["القرنفل"]	qrnfl القرنفل	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.03911	2026-07-19 13:56:33.817
d5004ed0-6294-490b-bb01-f89251625fde	egypt.new-cairo.yasmine	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	neighborhood	EG	Yasmine	الياسمين	\N	yasmine	[]	["Yasmine", "الياسمين"]	yasmine الياسمين	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.044919	2026-07-19 13:56:33.824
9ea7e7dd-8f41-4ef8-9f40-1158fd8ff5c6	egypt.new-cairo.diplomaseyeen	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	neighborhood	EG	Diplomats	الدبلوماسيين	\N	diplomaseyeen	[]	["الدبلوماسيين"]	diplomats الدبلوماسيين diplomaseyeen	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.048137	2026-07-19 13:56:33.831
6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	egypt.new-administrative-capital	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Administrative Capital	العاصمة الإدارية الجديدة	\N	new-administrative-capital	["NAC", "New Capital"]	["العاصمة", "العاصمة الإدارية", "NAC", "New Capital", "العاصمة الجديدة", "new capital"]	new administrative capital العاصمة الإدارية الجديدة nac new capital العاصمة العاصمة الإدارية العاصمة الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	95	t	curated	\N	\N	active	2026-07-18 21:27:24.052126	2026-07-19 13:56:33.838
4d87ab54-41f6-40b8-a2b4-9b4149cc1d84	egypt.new-administrative-capital.r1	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	R1	آر 1	\N	r1	[]	["R1"]	r1 آر 1	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.05653	2026-07-19 13:56:33.845
7fd7156d-fd18-4a0c-af66-ebb8e01bd087	egypt.new-administrative-capital.r2	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	R2	آر 2	\N	r2	[]	["R2"]	r2 آر 2	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.05958	2026-07-19 13:56:33.853
c0d80ea7-c0f9-4ce8-a450-2d7a7d0642a5	egypt.new-administrative-capital.r3	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	R3	آر 3	\N	r3	[]	["R3"]	r3 آر 3	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.064138	2026-07-19 13:56:33.86
7b3b48b0-3eca-4fcb-939d-710d06c64d71	egypt.new-administrative-capital.r5	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	R5	آر 5	\N	r5	[]	["R5"]	r5 آر 5	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.067608	2026-07-19 13:56:33.869
b4f99366-e5fb-442e-994d-0e354bc68ea0	egypt.new-administrative-capital.r7	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	R7	آر 7	\N	r7	[]	["R7"]	r7 آر 7	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.070973	2026-07-19 13:56:33.876
92a8d60f-0c69-465a-87ca-89efe04143a6	egypt.new-administrative-capital.r8	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	R8	آر 8	\N	r8	[]	["R8"]	r8 آر 8	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.074601	2026-07-19 13:56:33.885
7128fd8a-46a2-4b67-8b4c-33b93ef7b1b4	egypt.new-administrative-capital.diplomatic-district	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	Diplomatic District	الحي الدبلوماسي	\N	diplomatic-district	[]	["الحي الدبلوماسي"]	diplomatic district الحي الدبلوماسي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.078048	2026-07-19 13:56:33.892
869d9b5b-137a-43f0-a3b0-6c4ec5f9a5f1	egypt.new-administrative-capital.government-district	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	Government District	الحي الحكومي	\N	government-district	[]	["الحي الحكومي"]	government district الحي الحكومي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.081799	2026-07-19 13:56:33.901
7b0a32ac-a8dd-4498-8bf3-a093cb570a86	egypt.new-administrative-capital.financial-district	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	Financial District	الحي المالي	\N	financial-district	[]	["الحي المالي"]	financial district الحي المالي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.08571	2026-07-19 13:56:33.913
515d9efd-fb09-4dd5-be42-f8b0acc95ec8	egypt.new-administrative-capital.cbd	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	Central Business District	منطقة الأعمال المركزية	\N	cbd	[]	["CBD", "الأعمال المركزية"]	central business district منطقة الأعمال المركزية cbd الأعمال المركزية	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.08946	2026-07-19 13:56:33.924
34341d04-aaaa-4bd2-a1f6-5407db1d40eb	egypt.new-administrative-capital.green-river	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	district	EG	Green River	النهر الأخضر	\N	green-river	[]	["Green River", "النهر الأخضر"]	green river النهر الأخضر	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.093522	2026-07-19 13:56:33.936
9ec839de-1154-4dbc-a8b9-d9e223f88048	egypt.new-administrative-capital.village-de-la-capitale	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Village de la Capitale	فيلاج دي لا كابيتال	\N	village-de-la-capitale	[]	[]	village de la capitale فيلاج دي لا كابيتال	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.098135	2026-07-19 13:56:33.945
1771b38b-fa51-4be6-a97c-d1044c9f01a7	egypt.new-administrative-capital.la-vista-city	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	La Vista City	لافيستا سيتي	\N	la-vista-city	[]	["La Vista City", "لافيستا سيتي"]	la vista city لافيستا سيتي	824b28cf-ea9e-494a-af71-dae840f905b9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.10175	2026-07-19 13:56:33.954
3df97fd5-5ffa-472d-9b9d-47517ab69df4	egypt.new-administrative-capital.lumia-lagoon	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Lumia Lagoon	لوميا لاجون	\N	lumia-lagoon	[]	[]	lumia lagoon لوميا لاجون	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.118715	2026-07-19 13:56:33.972
2eca0d9a-1800-45d0-8af7-96af9baafa7c	egypt.new-administrative-capital.right-nac	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Right	رايت	\N	right-nac	[]	[]	right رايت right nac	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.124443	2026-07-19 13:56:33.983
202547cf-1049-4ccd-915f-8b1307282ce6	egypt.new-administrative-capital.the-island-nac	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	The Island	ذا آيلاند	\N	the-island-nac	[]	[]	the island ذا آيلاند the island nac	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.128643	2026-07-19 13:56:33.991
94111f10-73bd-40a8-a4c6-f23298489a98	egypt.new-administrative-capital.qamari	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Qamari	قمري	\N	qamari	[]	[]	qamari قمري	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.132948	2026-07-19 13:56:34.003
ba543aca-c96c-4315-9f10-f6e8bf8fc3a3	egypt.new-administrative-capital.midtown-condo	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Midtown Condo	ميدتاون كوندو	\N	midtown-condo	[]	[]	midtown condo ميدتاون كوندو	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.136979	2026-07-19 13:56:34.012
1649bb8a-5362-4ce0-8003-4adf69587563	egypt.new-administrative-capital.midtown-sky	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Midtown Sky	ميدتاون سكاي	\N	midtown-sky	[]	[]	midtown sky ميدتاون سكاي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.141207	2026-07-19 13:56:34.023
a082d49d-ef84-47b4-921b-2509cf999f2f	egypt.new-administrative-capital.capital-heights	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Capital Heights	كابيتال هايتس	\N	capital-heights	[]	[]	capital heights كابيتال هايتس	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.144799	2026-07-19 13:56:34.031
97e547ff-1571-4f3f-809b-15f77644acc8	egypt.new-administrative-capital.de-joya	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	De Joya	دي جويا	\N	de-joya	[]	[]	de joya دي جويا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.151822	2026-07-19 13:56:34.039
2c8b62ca-ae1f-42dd-9110-de3b094bdc61	egypt.new-administrative-capital.il-bosco	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Il Bosco	إل بوسكو	\N	il-bosco	[]	["Il Bosco", "بوسكو"]	il bosco إل بوسكو بوسكو	1b5acfcf-fc19-4960-bfb4-2b9ea3faa5b4	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.156423	2026-07-19 13:56:34.051
ffdafab4-027e-4bf1-bd8a-0af1d140e3c4	egypt.new-administrative-capital.scenario	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Scenario	سيناريو	\N	scenario	[]	[]	scenario سيناريو	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.163096	2026-07-19 13:56:34.063
5547d8ee-70d6-477f-9a37-ae912dc11d96	egypt.new-administrative-capital.serrano	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Serrano	سيرانو	\N	serrano	[]	[]	serrano سيرانو	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.167089	2026-07-19 13:56:34.079
54ef81f1-689e-434b-9886-214920801756	egypt.new-administrative-capital.castle-landmark	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Castle Landmark	كاسل لاندمارك	\N	castle-landmark	[]	[]	castle landmark كاسل لاندمارك	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.170159	2026-07-19 13:56:34.087
61cf6dfa-b351-4bb3-aba6-42c17531e252	egypt.new-administrative-capital.entrada	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Entrada	إنترادا	\N	entrada	[]	[]	entrada إنترادا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.174415	2026-07-19 13:56:34.095
2bc022ae-f293-40fc-ad16-425cfc992c12	egypt.new-administrative-capital.sueno	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Sueno	سوينو	\N	sueno	[]	[]	sueno سوينو	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.178709	2026-07-19 13:56:34.103
75ae1b6d-9927-41cf-9b93-4f2dd0735b6a	egypt.new-administrative-capital.celia	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Celia	سيليا	\N	celia	[]	["Celia", "سيليا"]	celia سيليا	8867ee3e-c70a-4584-b464-0febbbd4047a	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.182414	2026-07-19 13:56:34.111
d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	egypt.sheikh-zayed	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	Sheikh Zayed	الشيخ زايد	\N	sheikh-zayed	[]	["Sheikh Zayed", "الشيخ زايد", "زايد", "zayed"]	sheikh zayed الشيخ زايد زايد zayed	\N	\N	\N	\N	\N	\N	\N	\N	90	t	curated	\N	\N	active	2026-07-18 21:27:24.186853	2026-07-19 13:56:34.119
261fde40-1b68-424f-bd16-aa92affb0197	egypt.sheikh-zayed.zed-west	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Zed West	زيد ويست	\N	zed-west	[]	["Zed West", "زد ويست"]	zed west زيد ويست زد ويست	7f947c27-fd9d-4157-bd01-d9155fdf94f0	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.191328	2026-07-19 13:56:34.127
51758f5b-4022-4022-be03-7725d2cbcdbf	egypt.sheikh-zayed.beverly-hills	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Beverly Hills	بيفرلي هيلز	\N	beverly-hills	[]	["Beverly Hills", "بيفرلي"]	beverly hills بيفرلي هيلز بيفرلي	be1d5045-4201-4c31-a5d6-24103db7f8d9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.195862	2026-07-19 13:56:34.135
dc7d84e5-c730-476f-bde8-d69721353418	egypt.sheikh-zayed.allegria	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Allegria	أليجريا	\N	allegria	[]	["Allegria", "اليجريا"]	allegria أليجريا اليجريا	be1d5045-4201-4c31-a5d6-24103db7f8d9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.199919	2026-07-19 13:56:34.145
fdf8e0ce-29e8-4f19-8651-b9a7d3fd131a	egypt.sheikh-zayed.karma	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Karma	كارما	\N	karma	[]	[]	karma كارما	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.204726	2026-07-19 13:56:34.155
e0e43751-6bea-4f08-b4b8-2870fc9ecbb2	egypt.sheikh-zayed.belle-vie	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Belle Vie	بيل في	\N	belle-vie	[]	["Belle Vie", "بيل في"]	belle vie بيل في	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.209029	2026-07-19 13:56:34.162
00e4005a-cf50-43d7-9723-58a30310341b	egypt.sheikh-zayed.cairo-gate	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Cairo Gate	كايرو جيت	\N	cairo-gate	[]	["Cairo Gate", "كايرو جيت"]	cairo gate كايرو جيت	936bb484-ddf1-4bfa-b4fb-d45519af4142	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.216939	2026-07-19 13:56:34.17
6d3be99c-ae88-4863-9bce-a146d9e798ca	egypt.sheikh-zayed.rivers	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Rivers	ريفرز	\N	rivers	[]	[]	rivers ريفرز	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.223501	2026-07-19 13:56:34.177
964b2f05-914c-4362-8ff6-9f41cd040fb5	egypt.sheikh-zayed.solana	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Solana	سولانا	\N	solana	[]	["Solana", "سولانا"]	solana سولانا	7f947c27-fd9d-4157-bd01-d9155fdf94f0	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.227173	2026-07-19 13:56:34.185
d72b1a31-4e65-4ec1-be84-661d29a354da	egypt.sheikh-zayed.vye	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	Vye	فاي	\N	vye	[]	["Vye"]	vye فاي	be1d5045-4201-4c31-a5d6-24103db7f8d9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.230007	2026-07-19 13:56:34.193
e296a1c3-ea75-46c2-a87a-90fa2c2b1b0f	egypt.sheikh-zayed.the-estates	d3a3d7bd-47a9-4b4c-80c5-9e686a6a7662	compound	EG	The Estates	ذا استيتس	\N	the-estates	[]	["Estates", "استيتس"]	the estates ذا استيتس estates استيتس	be1d5045-4201-4c31-a5d6-24103db7f8d9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.236143	2026-07-19 13:56:34.201
caf38136-363e-4701-b8ce-5cc78f411e9b	egypt.new-zayed	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Zayed	نيو زايد	\N	new-zayed	[]	["New Zayed", "نيو زايد", "زايد الجديدة"]	new zayed نيو زايد زايد الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.239986	2026-07-19 13:56:34.208
0a350ad9-9a5a-4c8c-92e3-76b789fdca08	egypt.new-zayed.solana-new-zayed	caf38136-363e-4701-b8ce-5cc78f411e9b	compound	EG	Solana New Zayed	سولانا نيو زايد	\N	solana-new-zayed	[]	[]	solana new zayed سولانا نيو زايد	7f947c27-fd9d-4157-bd01-d9155fdf94f0	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.244134	2026-07-19 13:56:34.221
32e11d01-21f0-40e4-b2b5-443e3e990e6c	egypt.new-zayed.belle-vie-new-zayed	caf38136-363e-4701-b8ce-5cc78f411e9b	compound	EG	Belle Vie	بيل في	\N	belle-vie-new-zayed	[]	[]	belle vie بيل في belle vie new zayed	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.258037	2026-07-19 13:56:34.228
9fb7cdc7-4a83-46f6-bc59-7085535e1a92	egypt.new-zayed.de-joya-new-zayed	caf38136-363e-4701-b8ce-5cc78f411e9b	compound	EG	De Joya New Zayed	دي جويا	\N	de-joya-new-zayed	[]	[]	de joya new zayed دي جويا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.264463	2026-07-19 13:56:34.235
fa2c0382-fc1c-472d-9586-db2167b2337d	egypt.new-zayed.karmell	caf38136-363e-4701-b8ce-5cc78f411e9b	compound	EG	Karmell	كارميل	\N	karmell	[]	[]	karmell كارميل	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.267913	2026-07-19 13:56:34.246
cf140d57-2a56-44d0-ae57-0991e7401a2a	egypt.new-zayed.hills-of-one	caf38136-363e-4701-b8ce-5cc78f411e9b	compound	EG	Hills of One	هيلز أوف وان	\N	hills-of-one	[]	[]	hills of one هيلز أوف وان	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.275908	2026-07-19 13:56:34.263
74e462e1-09ed-456c-894f-58339982a1a0	egypt.6th-of-october.badya	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	Badya	بادية	\N	badya	[]	["Badya", "بادية"]	badya بادية	936bb484-ddf1-4bfa-b4fb-d45519af4142	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.284257	2026-07-19 13:56:34.279
bb4e1d7d-f2fd-4abe-8a7a-d80416aae2d1	egypt.6th-of-october.mountain-view-chillout-park	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	Mountain View Chillout Park	ماونتن فيو تشيل أوت	\N	mountain-view-chillout-park	[]	[]	mountain view chillout park ماونتن فيو تشيل أوت	e4630408-0674-4f8b-bf20-2964bdd8b104	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.289199	2026-07-19 13:56:34.29
a0976503-0348-4f24-9c8e-14c87a598fc2	egypt.6th-of-october.palm-parks	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	Palm Parks	بالم باركس	\N	palm-parks	[]	[]	palm parks بالم باركس	936bb484-ddf1-4bfa-b4fb-d45519af4142	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.292743	2026-07-19 13:56:34.299
2188a6d9-4779-4687-838b-a83f08431a4f	egypt.6th-of-october.palm-valley	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	Palm Valley	بالم فالي	\N	palm-valley	[]	[]	palm valley بالم فالي	936bb484-ddf1-4bfa-b4fb-d45519af4142	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.299591	2026-07-19 13:56:34.307
71151513-c018-4fe1-9106-1fc68ce2aebe	egypt.6th-of-october.o-west	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	O West	أو ويست	\N	o-west	[]	["O West", "او ويست"]	o west أو ويست او ويست	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.303462	2026-07-19 13:56:34.319
154af441-cfb6-404f-91c5-ee0da9423240	egypt.6th-of-october.october-plaza	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	October Plaza	أكتوبر بلازا	\N	october-plaza	[]	[]	october plaza أكتوبر بلازا	be1d5045-4201-4c31-a5d6-24103db7f8d9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.30809	2026-07-19 13:56:34.327
c598ad1f-d908-460c-9bec-24ce5413bbdc	egypt.6th-of-october.mountain-view-giza-plateau	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	Mountain View Giza Plateau	ماونتن فيو هضبة الأهرام	\N	mountain-view-giza-plateau	[]	[]	mountain view giza plateau ماونتن فيو هضبة الأهرام	e4630408-0674-4f8b-bf20-2964bdd8b104	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.311813	2026-07-19 13:56:34.334
2cb35d07-36d9-428f-b2b1-431486d40fa2	egypt.6th-of-october.sun-capital	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	Sun Capital	صن كابيتال	\N	sun-capital	[]	[]	sun capital صن كابيتال	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.315083	2026-07-19 13:56:34.343
99c3a36b-fbe0-43b9-bb02-e282b0c7aba1	egypt.6th-of-october.green-5	d3daa846-3dbd-460e-b8ac-cb19a5cb3708	compound	EG	Green 5	جرين 5	\N	green-5	[]	[]	green 5 جرين 5	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.32238	2026-07-19 13:56:34.355
fd6ee55b-fb5c-4a3f-8730-4dd33e70317a	egypt.new-october	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New October	أكتوبر الجديدة	\N	new-october	[]	["أكتوبر الجديدة", "new october"]	new october أكتوبر الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.32659	2026-07-19 13:56:34.365
da6a9467-5879-4778-be83-ede9477ff337	egypt.october-gardens	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	October Gardens	حدائق أكتوبر	\N	october-gardens	[]	["حدائق أكتوبر", "october gardens"]	october gardens حدائق أكتوبر	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.330197	2026-07-19 13:56:34.372
b47e8659-ad9d-42c3-b2af-2482bee3c89a	egypt.mostakbal-city	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	Mostakbal City	مدينة المستقبل	\N	mostakbal-city	["Future City", "مدينة المستقبل"]	["Mostakbal", "Mostakbal City", "المستقبل", "Future City", "مستقبل سيتي"]	mostakbal city مدينة المستقبل future city mostakbal المستقبل مستقبل سيتي	\N	\N	\N	\N	\N	\N	\N	\N	85	t	curated	\N	\N	active	2026-07-18 21:27:24.333783	2026-07-19 13:56:34.382
ada4605f-5e1d-4cca-80e9-3a016d5c566b	egypt.mostakbal-city.bloomfields	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	Bloomfields	بلوم فيلدز	\N	bloomfields	[]	["Bloomfields", "بلوم فيلدز"]	bloomfields بلوم فيلدز	94c09d1c-c8d5-42f1-8a57-cd0418c26a38	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.336947	2026-07-19 13:56:34.389
65631f8d-131c-4a79-a076-0e0622356357	egypt.mostakbal-city.sarai	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	Sarai	سراي	\N	sarai	[]	["Sarai", "سراي"]	sarai سراي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.340102	2026-07-19 13:56:34.397
d50aa6de-b36f-4e03-8aab-09bdec8b46ac	egypt.mostakbal-city.the-city-of-odyssia	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	The City of Odyssia	أوديسيا	\N	the-city-of-odyssia	[]	[]	the city of odyssia أوديسيا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.343553	2026-07-19 13:56:34.408
11e0f389-1a52-4712-afe5-f012f0b8feaa	egypt.mostakbal-city.il-bosco-city	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	Il Bosco City	إل بوسكو سيتي	\N	il-bosco-city	[]	["Il Bosco City", "بوسكو سيتي"]	il bosco city إل بوسكو سيتي بوسكو سيتي	1b5acfcf-fc19-4960-bfb4-2b9ea3faa5b4	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.347375	2026-07-19 13:56:34.415
7b8bfc0e-8965-4787-bdb8-ac225394bc32	egypt.mostakbal-city.aria	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	Aria	آريا	\N	aria	[]	[]	aria آريا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.351763	2026-07-19 13:56:34.423
3be744f3-70d3-4303-90f8-b691e5466a4a	egypt.mostakbal-city.the-rift	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	The Rift	ذا ريفت	\N	the-rift	[]	[]	the rift ذا ريفت	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.463225	2026-07-19 13:56:34.437
19df22ca-4bcb-40cd-899b-7219ae3363b5	egypt.mostakbal-city.green-square	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	Green Square	جرين سكوير	\N	green-square	[]	[]	green square جرين سكوير	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.46798	2026-07-19 13:56:34.447
0b0ca5a7-0d5f-4a70-8904-5d0546579bf5	egypt.mostakbal-city.haptown	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	Haptown	هاب تاون	\N	haptown	[]	["Haptown", "هاب تاون"]	haptown هاب تاون	d80fa520-2473-44a4-9d7b-d912f04b76e9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.472001	2026-07-19 13:56:34.455
6f23db5a-1472-48f6-a4ab-1dd74fcea13f	egypt.mostakbal-city.beta-greens	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	Beta Greens	بيتا جرينز	\N	beta-greens	[]	[]	beta greens بيتا جرينز	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.475484	2026-07-19 13:56:34.467
8f81e894-0600-45eb-84b7-62f2d420f306	egypt.mostakbal-city.midtown	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	Midtown	ميدتاون	\N	midtown	[]	[]	midtown ميدتاون	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.479462	2026-07-19 13:56:34.476
8812688f-eb02-4ea5-9830-56eba25e6704	egypt.mostakbal-city.cityzen	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	CityZen	سيتي زن	\N	cityzen	[]	[]	cityzen سيتي زن	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.482733	2026-07-19 13:56:34.641
19581360-1ab6-4379-acae-65be9c2599aa	egypt.mostakbal-city.new-lakes	b47e8659-ad9d-42c3-b2af-2482bee3c89a	compound	EG	New Lakes	نيو ليكس	\N	new-lakes	[]	[]	new lakes نيو ليكس	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.48649	2026-07-19 13:56:34.673
26e7b267-ea0d-4dec-baf9-83645fc8c840	egypt.madinaty	6c25bca7-b72f-4837-979b-44440c99739a	community	EG	Madinaty	مدينتي	\N	madinaty	[]	["مدينتي", "madinaty", "madinty", "madinati", "مدينة طلعت مصطفى"]	madinaty مدينتي madinty madinati مدينة طلعت مصطفى	8867ee3e-c70a-4584-b464-0febbbd4047a	\N	\N	\N	\N	\N	\N	\N	92	t	curated	\N	\N	active	2026-07-18 21:27:24.490499	2026-07-19 13:56:34.68
a06df027-ef11-41f0-a2ec-c5257cbceb9b	egypt.al-rehab	6c25bca7-b72f-4837-979b-44440c99739a	community	EG	Al Rehab	الرحاب	\N	al-rehab	[]	["الرحاب", "rehab", "al rehab", "مدينة الرحاب"]	al rehab الرحاب rehab مدينة الرحاب	8867ee3e-c70a-4584-b464-0febbbd4047a	\N	\N	\N	\N	\N	\N	\N	88	t	curated	\N	\N	active	2026-07-18 21:27:24.493715	2026-07-19 13:56:34.687
5f3d2cf0-2ee3-4d01-9f5c-cea970a7f03c	egypt.shorouk	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	El Shorouk	الشروق	\N	shorouk	[]	["Shorouk", "الشروق", "el shorouk"]	el shorouk الشروق shorouk	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.497532	2026-07-19 13:56:34.697
a3e690da-5880-42ac-93f9-89aee6c506dc	egypt.badr	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	Badr City	بدر	\N	badr	[]	["Badr", "بدر", "مدينة بدر"]	badr city بدر badr مدينة بدر	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.505008	2026-07-19 13:56:34.717
a217c79e-6808-4a02-b72a-ddf1a0047ca0	egypt.badr-new	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Badr	بدر الجديدة	\N	badr-new	[]	["بدر الجديدة"]	new badr بدر الجديدة badr new	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.508856	2026-07-19 13:56:34.726
afbd7f47-ca2d-48e0-b287-922c135578e3	egypt.obour	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	El Obour	العبور	\N	obour	[]	["Obour", "العبور"]	el obour العبور obour	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.511561	2026-07-19 13:56:34.733
c744b14d-c1b4-4461-8c37-a7057ee8bc0c	egypt.new-obour	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Obour	العبور الجديدة	\N	new-obour	[]	["العبور الجديدة", "new obour"]	new obour العبور الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.515099	2026-07-19 13:56:34.74
b5bbd823-d85b-41df-8cab-f8c6ccae4538	egypt.nasr-city	6c25bca7-b72f-4837-979b-44440c99739a	district	EG	Nasr City	مدينة نصر	\N	nasr-city	[]	["Nasr City", "مدينة نصر", "نصر"]	nasr city مدينة نصر نصر	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.522072	2026-07-19 13:56:34.763
da7e93b5-4268-4e15-9331-6b138ee2a20b	egypt.heliopolis	6c25bca7-b72f-4837-979b-44440c99739a	district	EG	Heliopolis	مصر الجديدة	\N	heliopolis	[]	["Heliopolis", "مصر الجديدة", "هليوبوليس"]	heliopolis مصر الجديدة هليوبوليس	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.525613	2026-07-19 13:56:34.771
8e35f84a-7887-461f-9a27-02f4f7621cef	egypt.new-heliopolis	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Heliopolis	هليوبوليس الجديدة	\N	new-heliopolis	[]	["هليوبوليس الجديدة"]	new heliopolis هليوبوليس الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.530553	2026-07-19 13:56:34.779
49798bfb-5669-4307-aa19-2878deaa53bd	egypt.new-alamein	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Alamein	العلمين الجديدة	\N	new-alamein	[]	["New Alamein", "العلمين الجديدة", "العلمين", "alamein"]	new alamein العلمين الجديدة العلمين alamein	\N	\N	\N	\N	\N	\N	\N	\N	85	t	curated	\N	\N	active	2026-07-18 21:27:24.535757	2026-07-19 13:56:34.787
ded29eab-3b97-4184-b65f-e17b06bcb23b	egypt.new-alamein.north-edge	49798bfb-5669-4307-aa19-2878deaa53bd	compound	EG	North Edge Towers	نورث إيدج	\N	north-edge	[]	["North Edge", "نورث ايدج"]	north edge towers نورث إيدج north edge نورث ايدج	97b1750e-4dc8-4437-9d8a-905b83dc601c	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.541975	2026-07-19 13:56:34.796
4d3ff0f9-04e5-42ad-a95d-26e2cf028517	egypt.new-alamein.mazarine	49798bfb-5669-4307-aa19-2878deaa53bd	compound	EG	Mazarine	مازارين	\N	mazarine	[]	["Mazarine", "مازارين"]	mazarine مازارين	97b1750e-4dc8-4437-9d8a-905b83dc601c	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.54523	2026-07-19 13:56:34.804
bf7932fb-f72b-46b6-99df-5048cfa3fece	egypt.new-alamein.downtown-new-alamein	49798bfb-5669-4307-aa19-2878deaa53bd	compound	EG	Downtown New Alamein	داون تاون العلمين	\N	downtown-new-alamein	[]	[]	downtown new alamein داون تاون العلمين	97b1750e-4dc8-4437-9d8a-905b83dc601c	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.549133	2026-07-19 13:56:34.814
92d40cb3-d7aa-44b8-a624-f854384baafc	egypt.new-alamein.the-gate-alamein	49798bfb-5669-4307-aa19-2878deaa53bd	compound	EG	The Gate	ذا جيت	\N	the-gate-alamein	[]	[]	the gate ذا جيت the gate alamein	97b1750e-4dc8-4437-9d8a-905b83dc601c	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.553091	2026-07-19 13:56:34.821
63b2311a-8f2a-42e5-9677-679dc743b651	egypt.new-alamein.latin-district	49798bfb-5669-4307-aa19-2878deaa53bd	compound	EG	Latin District	الحي اللاتيني	\N	latin-district	[]	["Latin District", "الحي اللاتيني"]	latin district الحي اللاتيني	97b1750e-4dc8-4437-9d8a-905b83dc601c	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.5579	2026-07-19 13:56:34.83
0461c7cf-610d-44c0-b479-6b726605e555	egypt.north-coast	6c25bca7-b72f-4837-979b-44440c99739a	region	EG	North Coast	الساحل الشمالي	\N	north-coast	[]	["North Coast", "الساحل", "الساحل الشمالي", "sahel", "الساحل الشمالى"]	north coast الساحل الشمالي الساحل sahel الساحل الشمالى	\N	\N	\N	\N	\N	\N	\N	\N	90	t	curated	\N	\N	active	2026-07-18 21:27:24.562573	2026-07-19 13:56:34.837
b672543a-167b-4f8c-902e-37f4979f00ca	egypt.north-coast.hacienda	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Hacienda	هاسيندا	\N	hacienda	[]	["Hacienda", "هاسيندا"]	hacienda هاسيندا	936bb484-ddf1-4bfa-b4fb-d45519af4142	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.566535	2026-07-19 13:56:34.847
67e6e719-a50b-4ceb-8c6c-48813b4a7da4	egypt.north-coast.marassi	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Marassi	مراسي	\N	marassi	[]	["Marassi", "مراسي"]	marassi مراسي	417247e3-ace9-4828-981e-df5d1d312263	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.56984	2026-07-19 13:56:34.855
40f6a0ad-08bf-47d1-a3c3-c991122ccf59	egypt.north-coast.fouka-bay	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Fouka Bay	فوكا باي	\N	fouka-bay	[]	["Fouka Bay", "فوكا باي", "فوكا"]	fouka bay فوكا باي فوكا	94c09d1c-c8d5-42f1-8a57-cd0418c26a38	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.573763	2026-07-19 13:56:34.864
d7425a8c-d58d-4c9f-9e87-93f3e1cf92c4	egypt.north-coast.la-vista-bay	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	La Vista Bay	لافيستا باي	\N	la-vista-bay	[]	["La Vista Bay", "لافيستا باي"]	la vista bay لافيستا باي	824b28cf-ea9e-494a-af71-dae840f905b9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.576984	2026-07-19 13:56:34.875
f9d4e2ba-7056-4a4e-ad79-c737e9ec1b30	egypt.north-coast.seashell	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Seashell	سي شيل	\N	seashell	[]	["Seashell", "سي شل"]	seashell سي شيل سي شل	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.580843	2026-07-19 13:56:34.885
17bb058e-28e6-4704-a370-992a84721f36	egypt.north-coast.gaia	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Gaia	جايا	\N	gaia	[]	[]	gaia جايا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.584957	2026-07-19 13:56:34.896
4a47ee6c-490d-485b-b20a-8f46f0fbea23	egypt.north-coast.june	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	June	چون	\N	june	[]	["June", "چون"]	june چون	be1d5045-4201-4c31-a5d6-24103db7f8d9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.588771	2026-07-19 13:56:34.905
08310ede-5b28-456e-8a77-574bc16e45ee	egypt.north-coast.azha	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Azha	أزها	\N	azha	[]	["Azha", "ازها"]	azha أزها ازها	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.592963	2026-07-19 13:56:34.914
fa56a772-58ef-4484-a6e3-209b8584068d	egypt.north-coast.direction-white	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Direction White	دايركشن وايت	\N	direction-white	[]	[]	direction white دايركشن وايت	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.596939	2026-07-19 13:56:34.923
e984544f-1e08-4375-9757-ae342133321e	egypt.north-coast.silver-sands	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Silver Sands	سيلفر ساندز	\N	silver-sands	[]	["Silver Sands", "سيلفر ساندز"]	silver sands سيلفر ساندز	7f947c27-fd9d-4157-bd01-d9155fdf94f0	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.600136	2026-07-19 13:56:34.932
e9337df7-c03c-45ee-bea4-f977efb7d6b3	egypt.north-coast.salt	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Salt	سولت	\N	salt	[]	["Salt", "سولت"]	salt سولت	94c09d1c-c8d5-42f1-8a57-cd0418c26a38	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.604254	2026-07-19 13:56:34.943
5ca6ff95-868f-4dc3-92b1-2674bc9ac431	egypt.north-coast.mountain-view-ras-el-hekma	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Mountain View Ras El Hekma	ماونتن فيو رأس الحكمة	\N	mountain-view-ras-el-hekma	[]	[]	mountain view ras el hekma ماونتن فيو رأس الحكمة	e4630408-0674-4f8b-bf20-2964bdd8b104	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.607582	2026-07-19 13:56:34.951
513386c2-bd20-48ca-b3bc-6fe676883288	egypt.north-coast.telal	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Telal	تلال	\N	telal	[]	["Telal", "تلال"]	telal تلال	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.611847	2026-07-19 13:56:34.959
2b10dad0-bd91-4143-b0a2-407a7cbe26c8	saudi-arabia.riyadh.diriyah	b4b9d621-743a-4e95-848d-96a93716cec1	district	SA	Diriyah	الدرعية	\N	diriyah	[]	["Diriyah", "الدرعية"]	diriyah الدرعية	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.740579	2026-07-19 13:56:35.259
fdc114b2-f938-4e95-bfb8-307c0674d5fc	egypt.ras-el-hekma	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	Ras El Hekma	رأس الحكمة	\N	ras-el-hekma	[]	["Ras El Hekma", "رأس الحكمة", "راس الحكمة"]	ras el hekma رأس الحكمة راس الحكمة	\N	\N	\N	\N	\N	\N	\N	\N	80	t	curated	\N	\N	active	2026-07-18 21:27:24.620717	2026-07-19 13:56:34.977
772c1019-8b2b-4a37-a8eb-c64f4f39aa39	egypt.new-mansoura	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Mansoura	المنصورة الجديدة	\N	new-mansoura	[]	["New Mansoura", "المنصورة الجديدة"]	new mansoura المنصورة الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.624607	2026-07-19 13:56:34.986
28b92b52-cd70-49e8-9c52-1b05ce1df0c7	egypt.capital-gardens	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	Capital Gardens	حدائق العاصمة	\N	capital-gardens	[]	["حدائق العاصمة", "capital gardens"]	capital gardens حدائق العاصمة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.628662	2026-07-19 13:56:35.003
0421c057-445b-444c-825c-666f919c48bd	egypt.15-may	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	15th of May	15 مايو	\N	15-may	[]	["15 مايو", "15 may"]	15th of may 15 مايو 15 may	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.633179	2026-07-19 13:56:35.011
cf0cc6b6-ab17-4e37-a27f-a4ed443c21b8	egypt.sphinx-new	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Sphinx	سفنكس الجديدة	\N	sphinx-new	[]	["سفنكس الجديدة", "sphinx"]	new sphinx سفنكس الجديدة sphinx sphinx new	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.637042	2026-07-19 13:56:35.02
ad8fe6ab-6a36-40fc-9d68-8567f983b6a7	egypt.sadat-city	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	Sadat City	مدينة السادات	\N	sadat-city	[]	["Sadat", "السادات"]	sadat city مدينة السادات sadat السادات	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.640513	2026-07-19 13:56:35.031
f4fc0b20-f81c-4fd1-87df-5226c6ceba82	egypt.new-salhia	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Salhia	الصالحية الجديدة	\N	new-salhia	[]	["الصالحية الجديدة"]	new salhia الصالحية الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.645606	2026-07-19 13:56:35.04
02e18333-aaf2-42a0-b094-6f811a30302c	egypt.new-borg-el-arab	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Borg El Arab	برج العرب الجديدة	\N	new-borg-el-arab	[]	["برج العرب الجديدة", "borg el arab"]	new borg el arab برج العرب الجديدة borg el arab	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.650018	2026-07-19 13:56:35.048
5bc1e1e4-0e75-41a5-a804-d1288b775d3f	egypt.new-damietta	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Damietta	دمياط الجديدة	\N	new-damietta	[]	["دمياط الجديدة"]	new damietta دمياط الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.653453	2026-07-19 13:56:35.056
4a00c0b5-c03e-4537-91e0-d825d75e0465	egypt.new-aswan	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Aswan	أسوان الجديدة	\N	new-aswan	[]	["أسوان الجديدة"]	new aswan أسوان الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.659617	2026-07-19 13:56:35.063
613833d3-4fab-47da-b84f-26b0e7877053	egypt.east-port-said	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	East Port Said (Salam)	شرق بورسعيد	\N	east-port-said	[]	["شرق بورسعيد", "سلام"]	east port said (salam) شرق بورسعيد سلام east port said	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.663198	2026-07-19 13:56:35.071
0fc4059f-35c2-4b20-a409-2725474376fd	egypt.new-toshka	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Toshka	توشكى الجديدة	\N	new-toshka	[]	["توشكى الجديدة"]	new toshka توشكى الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.667811	2026-07-19 13:56:35.082
27357748-826c-46f4-b579-4f7abefad37c	egypt.new-tiba	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Tiba	طيبة الجديدة	\N	new-tiba	[]	["طيبة الجديدة"]	new tiba طيبة الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.672899	2026-07-19 13:56:35.089
47709c54-1f23-43fe-90d2-344fa8a9288a	egypt.new-minya	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Minya	المنيا الجديدة	\N	new-minya	[]	["المنيا الجديدة", "غرب المنيا"]	new minya المنيا الجديدة غرب المنيا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.676187	2026-07-19 13:56:35.118
8332cb28-29d6-4f8c-af4e-529605dbe82d	egypt.new-assiut	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Assiut (Nasser)	أسيوط الجديدة (ناصر)	\N	new-assiut	[]	["ناصر", "غرب أسيوط", "أسيوط الجديدة"]	new assiut (nasser) أسيوط الجديدة (ناصر) ناصر غرب أسيوط أسيوط الجديدة new assiut	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.680328	2026-07-19 13:56:35.145
2b7420e6-3fc8-4e6b-b2cb-63e69c38319e	egypt.new-fashn	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Fashn	الفشن الجديدة	\N	new-fashn	[]	["الفشن الجديدة"]	new fashn الفشن الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.686268	2026-07-19 13:56:35.154
44496d2d-c877-425a-b512-7c5f7dfeaea6	egypt.new-mallawi	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Mallawi	ملوي الجديدة	\N	new-mallawi	[]	["ملوي الجديدة"]	new mallawi ملوي الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.690219	2026-07-19 13:56:35.161
0a355e94-bbaa-4822-a9e3-7fc29d6c8888	egypt.new-akhmim	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Akhmim	أخميم الجديدة	\N	new-akhmim	[]	["أخميم الجديدة"]	new akhmim أخميم الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.694815	2026-07-19 13:56:35.168
d8ab301d-cee2-49af-b60a-47bf725db77d	egypt.new-rashid	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Rashid	رشيد الجديدة	\N	new-rashid	[]	["رشيد الجديدة"]	new rashid رشيد الجديدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.69986	2026-07-19 13:56:35.176
26765518-f62c-4d82-a3ef-13556409c846	egypt.west-qena	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	West Qena	غرب قنا	\N	west-qena	[]	["غرب قنا"]	west qena غرب قنا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.703805	2026-07-19 13:56:35.183
f796c96b-0335-4b3b-a06a-c494a78788b1	egypt.east-oweinat	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	East Oweinat	شرق العوينات	\N	east-oweinat	[]	["شرق العوينات"]	east oweinat شرق العوينات	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.708686	2026-07-19 13:56:35.195
8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	saudi-arabia	\N	country	SA	Saudi Arabia	السعودية	\N	saudi-arabia	[]	["Saudi", "السعودية", "KSA", "المملكة"]	saudi arabia السعودية saudi ksa المملكة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.712273	2026-07-19 13:56:35.202
b4b9d621-743a-4e95-848d-96a93716cec1	saudi-arabia.riyadh	8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	city	SA	Riyadh	الرياض	\N	riyadh	[]	["Riyadh", "الرياض"]	riyadh الرياض	\N	\N	\N	\N	\N	\N	\N	\N	95	t	curated	\N	\N	active	2026-07-18 21:27:24.716549	2026-07-19 13:56:35.21
b83aab24-b9bd-48ba-b69b-adfc1ac242f5	saudi-arabia.riyadh.al-olaya	b4b9d621-743a-4e95-848d-96a93716cec1	district	SA	Al Olaya	العليا	\N	al-olaya	[]	["Olaya", "العليا"]	al olaya العليا olaya	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.720486	2026-07-19 13:56:35.217
80480b19-ca16-486b-aa72-0e012e612082	saudi-arabia.riyadh.kafd	b4b9d621-743a-4e95-848d-96a93716cec1	district	SA	King Abdullah Financial District	المركز المالي (كافد)	\N	kafd	[]	["KAFD", "كافد", "المركز المالي"]	king abdullah financial district المركز المالي (كافد) kafd كافد المركز المالي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.724263	2026-07-19 13:56:35.226
b7774021-3f7f-4636-94fb-b780ecfe4163	saudi-arabia.riyadh.al-malqa	b4b9d621-743a-4e95-848d-96a93716cec1	district	SA	Al Malqa	الملقا	\N	al-malqa	[]	["Malqa", "الملقا"]	al malqa الملقا malqa	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.728959	2026-07-19 13:56:35.233
d4e34805-4dfa-45b2-a1ac-05da77767e1a	saudi-arabia.riyadh.hittin	b4b9d621-743a-4e95-848d-96a93716cec1	district	SA	Hittin	حطين	\N	hittin	[]	["Hittin", "حطين"]	hittin حطين	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.733242	2026-07-19 13:56:35.245
63246307-a43e-4369-90e2-ea2fb62cd21c	saudi-arabia.riyadh.al-narjis	b4b9d621-743a-4e95-848d-96a93716cec1	district	SA	Al Narjis	النرجس	\N	al-narjis	[]	["Narjis", "النرجس"]	al narjis النرجس narjis	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.736669	2026-07-19 13:56:35.252
3b2636e9-dd44-4408-a074-aa37db7d1cdb	saudi-arabia.riyadh.sedra	b4b9d621-743a-4e95-848d-96a93716cec1	compound	SA	Sedra	سدرة	\N	sedra	[]	["Sedra", "سدرة"]	sedra سدرة	5eb4415f-2181-4bee-b88c-fa443a6ecd3f	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.74768	2026-07-19 13:56:35.276
d34ea09f-339f-45c5-9212-80b2a934df84	saudi-arabia.jeddah	8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	city	SA	Jeddah	جدة	\N	jeddah	[]	["Jeddah", "جدة"]	jeddah جدة	\N	\N	\N	\N	\N	\N	\N	\N	90	t	curated	\N	\N	active	2026-07-18 21:27:24.751854	2026-07-19 13:56:35.347
478ca13d-ea61-4165-869f-0f0d79ea3665	saudi-arabia.jeddah.al-hamra	d34ea09f-339f-45c5-9212-80b2a934df84	district	SA	Al Hamra	الحمراء	\N	al-hamra	[]	["Hamra", "الحمراء"]	al hamra الحمراء hamra	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.755007	2026-07-19 13:56:35.355
43e97fa8-d328-412c-821f-2aae28f2b457	saudi-arabia.jeddah.obhur	d34ea09f-339f-45c5-9212-80b2a934df84	district	SA	Obhur	أبحر	\N	obhur	[]	["Obhur", "ابحر"]	obhur أبحر ابحر	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.75886	2026-07-19 13:56:35.362
d139fd46-242d-4589-8d16-e5b30db3371a	saudi-arabia.jeddah.al-shati	d34ea09f-339f-45c5-9212-80b2a934df84	district	SA	Al Shati	الشاطئ	\N	al-shati	[]	["Shati", "الشاطئ"]	al shati الشاطئ shati	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.7629	2026-07-19 13:56:35.369
ac644f1b-3205-4d31-81d9-319cae671c5e	saudi-arabia.jeddah.jeddah-central	d34ea09f-339f-45c5-9212-80b2a934df84	compound	SA	Jeddah Central	وسط جدة	\N	jeddah-central	[]	["Jeddah Central", "وسط جدة"]	jeddah central وسط جدة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.766752	2026-07-19 13:56:35.377
5b13a7d9-4588-4e24-be00-fefdc825dd2a	saudi-arabia.dammam	8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	city	SA	Dammam	الدمام	\N	dammam	[]	["Dammam", "الدمام"]	dammam الدمام	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.770958	2026-07-19 13:56:35.385
ac85cad2-3ea2-400c-8c39-dedaaae5ca17	saudi-arabia.al-khobar	8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	city	SA	Al Khobar	الخبر	\N	al-khobar	[]	["Khobar", "الخبر"]	al khobar الخبر khobar	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.775596	2026-07-19 13:56:35.392
8004ddba-0bf8-489c-b6cc-3eaa6785831f	saudi-arabia.mecca	8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	city	SA	Mecca	مكة	\N	mecca	[]	["Mecca", "Makkah", "مكة"]	mecca مكة makkah	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.779964	2026-07-19 13:56:35.399
760995dc-b03d-474a-a535-3e55231dcb0b	saudi-arabia.medina	8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	city	SA	Medina	المدينة المنورة	\N	medina	[]	["Medina", "Madinah", "المدينة"]	medina المدينة المنورة madinah المدينة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.785541	2026-07-19 13:56:35.407
f3be0544-9eaa-4d0b-8ead-cafbf91d618a	saudi-arabia.neom	8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	region	SA	NEOM	نيوم	\N	neom	[]	["NEOM", "نيوم"]	neom نيوم	\N	\N	\N	\N	\N	\N	\N	\N	80	t	curated	\N	\N	active	2026-07-18 21:27:24.789503	2026-07-19 13:56:35.415
6482c5c4-1296-4f7b-8e7c-091abc753355	saudi-arabia.neom.the-line	f3be0544-9eaa-4d0b-8ead-cafbf91d618a	compound	SA	The Line	ذا لاين	\N	the-line	[]	["The Line", "ذا لاين"]	the line ذا لاين	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.793195	2026-07-19 13:56:35.422
824326d6-a36c-47c8-82c4-b992d5e4ba5d	saudi-arabia.neom.oxagon	f3be0544-9eaa-4d0b-8ead-cafbf91d618a	compound	SA	Oxagon	أوكساجون	\N	oxagon	[]	[]	oxagon أوكساجون	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.798462	2026-07-19 13:56:35.429
dfe48495-8928-4045-a5ab-ac1fcdfdd48d	saudi-arabia.neom.trojena	f3be0544-9eaa-4d0b-8ead-cafbf91d618a	compound	SA	Trojena	تروجينا	\N	trojena	[]	[]	trojena تروجينا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.808557	2026-07-19 13:56:35.437
2288072b-8a97-4a62-823c-7a774150b62c	uae	\N	country	AE	United Arab Emirates	الإمارات	\N	uae	[]	["UAE", "Emirates", "الإمارات", "الامارات"]	united arab emirates الإمارات uae emirates الامارات	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.81668	2026-07-19 13:56:35.452
c10ddd81-c808-44b2-a01f-66c4c45674ef	uae.dubai	2288072b-8a97-4a62-823c-7a774150b62c	city	AE	Dubai	دبي	\N	dubai	[]	["Dubai", "دبي"]	dubai دبي	\N	\N	\N	\N	\N	\N	\N	\N	96	t	curated	\N	\N	active	2026-07-18 21:27:24.825264	2026-07-19 13:56:35.46
2211089d-bdaa-4121-ab36-97169c1c35a8	uae.dubai.downtown-dubai	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Downtown Dubai	وسط مدينة دبي	\N	downtown-dubai	[]	["Downtown", "وسط دبي", "برج خليفة"]	downtown dubai وسط مدينة دبي downtown وسط دبي برج خليفة	d6805422-9168-4fd1-b54b-d6578ab6621b	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.831922	2026-07-19 13:56:35.469
16c8470a-123e-40be-bf14-e596baafe08d	uae.dubai.dubai-marina	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Dubai Marina	دبي مارينا	\N	dubai-marina	[]	["Marina", "مارينا"]	dubai marina دبي مارينا marina مارينا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.836613	2026-07-19 13:56:35.481
97e2fc36-dfd2-447c-bfcb-f4862d5f57b8	uae.dubai.palm-jumeirah	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Palm Jumeirah	نخلة جميرا	\N	palm-jumeirah	[]	["Palm", "النخلة", "نخلة"]	palm jumeirah نخلة جميرا palm النخلة نخلة	76047228-37c9-4005-aa68-21f7ee34e9b2	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.840939	2026-07-19 13:56:35.488
d1132fd8-6635-4fad-8a6c-69485fb00131	uae.dubai.business-bay	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Business Bay	الخليج التجاري	\N	business-bay	[]	["Business Bay", "الخليج التجاري"]	business bay الخليج التجاري	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.845197	2026-07-19 13:56:35.501
8113abcd-2e71-40af-b50e-495c27db65d5	uae.dubai.jvc	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Jumeirah Village Circle	قرية جميرا الدائرية	\N	jvc	[]	["JVC", "جميرا فيلدج"]	jumeirah village circle قرية جميرا الدائرية jvc جميرا فيلدج	76047228-37c9-4005-aa68-21f7ee34e9b2	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.84939	2026-07-19 13:56:35.508
dcf64c40-ae57-458d-8b8b-a067abc92612	uae.dubai.dubai-hills-estate	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Dubai Hills Estate	دبي هيلز	\N	dubai-hills-estate	[]	["Dubai Hills", "دبي هيلز"]	dubai hills estate دبي هيلز dubai hills	d6805422-9168-4fd1-b54b-d6578ab6621b	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.854086	2026-07-19 13:56:35.523
f622d378-cb97-4b46-a6c3-f3361b16bced	uae.dubai.arabian-ranches	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Arabian Ranches	المرابع العربية	\N	arabian-ranches	[]	["Arabian Ranches", "المرابع"]	arabian ranches المرابع العربية المرابع	d6805422-9168-4fd1-b54b-d6578ab6621b	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.862451	2026-07-19 13:56:35.536
54ccb3f0-b2a7-4151-8938-f9bef66a6f69	uae.dubai.emirates-hills	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Emirates Hills	تلال الإمارات	\N	emirates-hills	[]	["Emirates Hills", "تلال الامارات"]	emirates hills تلال الإمارات تلال الامارات	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.867404	2026-07-19 13:56:35.546
6a250936-d0c5-4daa-83e7-dbae3791bf2d	uae.dubai.jbr	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Jumeirah Beach Residence	جي بي آر	\N	jbr	[]	["JBR", "جي بي ار"]	jumeirah beach residence جي بي آر jbr جي بي ار	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.871828	2026-07-19 13:56:35.553
24f08d6e-35fe-48bf-92e8-52e7e58a9185	uae.dubai.dubai-creek-harbour	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Dubai Creek Harbour	مرسى خور دبي	\N	dubai-creek-harbour	[]	["Creek Harbour", "خور دبي"]	dubai creek harbour مرسى خور دبي creek harbour خور دبي	d6805422-9168-4fd1-b54b-d6578ab6621b	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.876507	2026-07-19 13:56:35.582
54310550-ef75-4083-a23e-72446497a543	uae.dubai.damac-hills	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	DAMAC Hills	داماك هيلز	\N	damac-hills	[]	["Damac Hills", "داماك هيلز"]	damac hills داماك هيلز	e6982af0-9e96-4f0e-aaaa-eb34fd9d33dd	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.880894	2026-07-19 13:56:35.589
2840f557-b0ba-418c-a7fe-ab174ad1e320	uae.dubai.dubai-south	c10ddd81-c808-44b2-a01f-66c4c45674ef	compound	AE	Dubai South	دبي الجنوب	\N	dubai-south	[]	["Dubai South", "دبي الجنوب"]	dubai south دبي الجنوب	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.887589	2026-07-19 13:56:35.598
75789d1c-fb38-4bc3-ab0b-635ed8ce9660	uae.abu-dhabi.yas-island	c5f52d89-6aff-4c08-aaab-8daabf39b2d8	compound	AE	Yas Island	جزيرة ياس	\N	yas-island	[]	["Yas", "ياس"]	yas island جزيرة ياس yas ياس	5756f4f7-1f30-4d82-bb95-b4ad9b2d1276	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.896496	2026-07-19 13:56:35.612
438deb7c-3652-44e7-a00f-5bdee61a990e	uae.abu-dhabi.saadiyat-island	c5f52d89-6aff-4c08-aaab-8daabf39b2d8	compound	AE	Saadiyat Island	جزيرة السعديات	\N	saadiyat-island	[]	["Saadiyat", "السعديات"]	saadiyat island جزيرة السعديات saadiyat السعديات	5756f4f7-1f30-4d82-bb95-b4ad9b2d1276	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.899784	2026-07-19 13:56:35.625
11cc434e-0159-4999-9ffa-a898feee4af2	uae.abu-dhabi.al-reem-island	c5f52d89-6aff-4c08-aaab-8daabf39b2d8	compound	AE	Al Reem Island	جزيرة الريم	\N	al-reem-island	[]	["Reem", "الريم"]	al reem island جزيرة الريم reem الريم	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.903074	2026-07-19 13:56:35.632
4337b9f3-3fc3-421a-b19e-b78011cf132a	uae.abu-dhabi.al-raha-beach	c5f52d89-6aff-4c08-aaab-8daabf39b2d8	compound	AE	Al Raha Beach	شاطئ الراحة	\N	al-raha-beach	[]	["Al Raha", "الراحة"]	al raha beach شاطئ الراحة al raha الراحة	5756f4f7-1f30-4d82-bb95-b4ad9b2d1276	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.906627	2026-07-19 13:56:35.64
1751327e-071f-41b4-81c3-13ab1ac4fb2e	uae.abu-dhabi.khalifa-city	c5f52d89-6aff-4c08-aaab-8daabf39b2d8	district	AE	Khalifa City	مدينة خليفة	\N	khalifa-city	[]	["Khalifa City", "مدينة خليفة"]	khalifa city مدينة خليفة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.909816	2026-07-19 13:56:35.649
7bdb19af-2e85-49ce-ae4a-0a2a258f0b0e	uae.sharjah	2288072b-8a97-4a62-823c-7a774150b62c	city	AE	Sharjah	الشارقة	\N	sharjah	[]	["Sharjah", "الشارقة"]	sharjah الشارقة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.913857	2026-07-19 13:56:35.656
9ef2c9bf-242d-4abe-a01f-f40b5feec942	uae.ajman	2288072b-8a97-4a62-823c-7a774150b62c	city	AE	Ajman	عجمان	\N	ajman	[]	["Ajman", "عجمان"]	ajman عجمان	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.918459	2026-07-19 13:56:35.663
2e1b9fc0-7515-4bc9-b665-568ce6091f41	uae.ras-al-khaimah	2288072b-8a97-4a62-823c-7a774150b62c	city	AE	Ras Al Khaimah	رأس الخيمة	\N	ras-al-khaimah	[]	["Ras Al Khaimah", "RAK", "رأس الخيمة"]	ras al khaimah رأس الخيمة rak	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.92381	2026-07-19 13:56:35.671
270b017e-09f8-4cd1-85d7-bc682c0dc328	uae.ras-al-khaimah.al-marjan-island	2e1b9fc0-7515-4bc9-b665-568ce6091f41	compound	AE	Al Marjan Island	جزيرة المرجان	\N	al-marjan-island	[]	["Marjan", "المرجان"]	al marjan island جزيرة المرجان marjan المرجان	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.927803	2026-07-19 13:56:35.681
863a560e-cb6c-412f-8dad-4f3eefd4f8d3	uae.fujairah	2288072b-8a97-4a62-823c-7a774150b62c	city	AE	Fujairah	الفجيرة	\N	fujairah	[]	["Fujairah", "الفجيرة"]	fujairah الفجيرة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.931479	2026-07-19 13:56:35.687
bfce696c-ccb8-4533-9f7d-623504cb7190	qatar	\N	country	QA	Qatar	قطر	\N	qatar	[]	["Qatar", "قطر"]	qatar قطر	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.107084	2026-07-19 13:56:35.695
ecfdfc55-c0df-49d8-90f2-6c39a390af93	qatar.doha	bfce696c-ccb8-4533-9f7d-623504cb7190	city	QA	Doha	الدوحة	\N	doha	[]	["Doha", "الدوحة"]	doha الدوحة	\N	\N	\N	\N	\N	\N	\N	\N	88	t	curated	\N	\N	active	2026-07-18 21:27:25.112709	2026-07-19 13:56:35.702
5f831491-b1c2-46c2-aca4-edef3581afd7	qatar.doha.the-pearl	ecfdfc55-c0df-49d8-90f2-6c39a390af93	compound	QA	The Pearl	اللؤلؤة	\N	the-pearl	[]	["Pearl", "اللؤلؤة", "لؤلؤة قطر"]	the pearl اللؤلؤة pearl لؤلؤة قطر	2e54f11d-15c8-485e-bfdc-34eaa433cae9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.117621	2026-07-19 13:56:35.709
f5163c3f-cdd4-422a-b981-51472c905e57	qatar.doha.west-bay	ecfdfc55-c0df-49d8-90f2-6c39a390af93	compound	QA	West Bay	الخليج الغربي	\N	west-bay	[]	["West Bay", "الخليج الغربي"]	west bay الخليج الغربي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.123042	2026-07-19 13:56:35.716
8509e0de-73d6-485e-96f7-ad6c237ce62f	qatar.doha.msheireb	ecfdfc55-c0df-49d8-90f2-6c39a390af93	compound	QA	Msheireb Downtown	مشيرب	\N	msheireb	[]	["Msheireb", "مشيرب"]	msheireb downtown مشيرب msheireb	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.127562	2026-07-19 13:56:35.723
0cd3e112-97e1-4ddf-b15e-dfb95464f107	qatar.doha.al-sadd	ecfdfc55-c0df-49d8-90f2-6c39a390af93	district	QA	Al Sadd	السد	\N	al-sadd	[]	["Al Sadd", "السد"]	al sadd السد	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.131466	2026-07-19 13:56:35.729
ab49ea42-1555-4077-a5e3-b62b0be2e04b	qatar.doha.al-waab	ecfdfc55-c0df-49d8-90f2-6c39a390af93	district	QA	Al Waab	الوعب	\N	al-waab	[]	["Al Waab", "الوعب"]	al waab الوعب	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.135575	2026-07-19 13:56:35.737
29ac9c89-e822-4b46-be01-b260bded3fe4	qatar.lusail	bfce696c-ccb8-4533-9f7d-623504cb7190	city	QA	Lusail	لوسيل	\N	lusail	[]	["Lusail", "لوسيل"]	lusail لوسيل	726f6bbf-1d60-4d90-ac1d-bd9a4d30b38a	\N	\N	\N	\N	\N	\N	\N	70	t	curated	\N	\N	active	2026-07-18 21:27:25.139031	2026-07-19 13:56:35.744
924a4de4-4390-4f27-a8b9-ac0a479a2b9d	qatar.al-rayyan	bfce696c-ccb8-4533-9f7d-623504cb7190	city	QA	Al Rayyan	الريان	\N	al-rayyan	[]	["Al Rayyan", "الريان"]	al rayyan الريان	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.143601	2026-07-19 13:56:35.751
8c007d15-9365-491d-b538-7d9d4ab74ab3	kuwait	\N	country	KW	Kuwait	الكويت	\N	kuwait	[]	["Kuwait", "الكويت"]	kuwait الكويت	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.14854	2026-07-19 13:56:35.761
1a100932-46d3-433c-84fa-9f23a7ecbfe6	kuwait.kuwait-city	8c007d15-9365-491d-b538-7d9d4ab74ab3	city	KW	Kuwait City	مدينة الكويت	\N	kuwait-city	[]	["Kuwait City", "مدينة الكويت"]	kuwait city مدينة الكويت	\N	\N	\N	\N	\N	\N	\N	\N	80	t	curated	\N	\N	active	2026-07-18 21:27:25.15366	2026-07-19 13:56:35.769
58bafa54-86a2-4546-97f0-d5ee34f9eb4e	kuwait.salmiya	8c007d15-9365-491d-b538-7d9d4ab74ab3	city	KW	Salmiya	السالمية	\N	salmiya	[]	["Salmiya", "السالمية"]	salmiya السالمية	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.158188	2026-07-19 13:56:35.775
ac713422-01d8-4bc0-b58a-18bb84e43b5d	kuwait.hawalli	8c007d15-9365-491d-b538-7d9d4ab74ab3	city	KW	Hawalli	حولي	\N	hawalli	[]	["Hawalli", "حولي"]	hawalli حولي	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.161916	2026-07-19 13:56:35.784
be8f9fe3-0f2b-4cf0-9cc2-e22e4cf40115	kuwait.al-ahmadi	8c007d15-9365-491d-b538-7d9d4ab74ab3	city	KW	Al Ahmadi	الأحمدي	\N	al-ahmadi	[]	["Ahmadi", "الأحمدي"]	al ahmadi الأحمدي ahmadi	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.165066	2026-07-19 13:56:35.79
c4208d11-9a21-4735-a287-3c8f9ba4afc4	kuwait.al-jahra	8c007d15-9365-491d-b538-7d9d4ab74ab3	city	KW	Al Jahra	الجهراء	\N	al-jahra	[]	["Jahra", "الجهراء"]	al jahra الجهراء jahra	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.168738	2026-07-19 13:56:35.801
d6e68b53-49c7-40a3-9ed7-9d109f15f77a	kuwait.sabah-al-salem	8c007d15-9365-491d-b538-7d9d4ab74ab3	city	KW	Sabah Al Salem	صباح السالم	\N	sabah-al-salem	[]	["Sabah Al Salem", "صباح السالم"]	sabah al salem صباح السالم	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.171962	2026-07-19 13:56:35.808
a1428274-397d-45a7-ab04-56ae3fa72275	bahrain	\N	country	BH	Bahrain	البحرين	\N	bahrain	[]	["Bahrain", "البحرين"]	bahrain البحرين	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.175931	2026-07-19 13:56:35.815
aa1269f2-5ea7-40fa-ab1d-a876e0609e1e	bahrain.manama	a1428274-397d-45a7-ab04-56ae3fa72275	city	BH	Manama	المنامة	\N	manama	[]	["Manama", "المنامة"]	manama المنامة	\N	\N	\N	\N	\N	\N	\N	\N	78	t	curated	\N	\N	active	2026-07-18 21:27:25.179863	2026-07-19 13:56:35.822
9c043add-1cd5-4350-a8db-2cc84cbd7a5c	bahrain.manama.seef	aa1269f2-5ea7-40fa-ab1d-a876e0609e1e	district	BH	Seef	السيف	\N	seef	[]	["Seef", "السيف"]	seef السيف	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.187855	2026-07-19 13:56:35.831
5c2c3edf-b53e-4e2c-8daa-e219421d49bb	bahrain.riffa	a1428274-397d-45a7-ab04-56ae3fa72275	city	BH	Riffa	الرفاع	\N	riffa	[]	["Riffa", "الرفاع"]	riffa الرفاع	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.199768	2026-07-19 13:56:35.838
04652a66-232f-47e8-9899-7b85c73ddc5b	bahrain.muharraq	a1428274-397d-45a7-ab04-56ae3fa72275	city	BH	Muharraq	المحرق	\N	muharraq	[]	["Muharraq", "المحرق"]	muharraq المحرق	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.205618	2026-07-19 13:56:35.845
6c25bca7-b72f-4837-979b-44440c99739a	egypt	\N	country	EG	Egypt	مصر	\N	egypt	[]	["Egypt", "مصر", "EG", "egypt"]	egypt مصر eg	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.852362	2026-07-19 13:56:33.431
c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	egypt.new-cairo	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Cairo	القاهرة الجديدة	\N	new-cairo	[]	["New Cairo", "القاهرة الجديدة", "نيو كايرو", "new cairo"]	new cairo القاهرة الجديدة نيو كايرو	\N	\N	\N	\N	\N	\N	\N	\N	90	t	curated	\N	\N	active	2026-07-18 21:27:23.855911	2026-07-19 13:56:33.466
750ca68c-e93d-4745-8164-5600c98684a0	egypt.new-cairo.sixth-settlement.grand-lane	bb87b7c1-6809-4098-a70c-938447331808	compound	EG	Grand Lane	جراند لين	\N	grand-lane	[]	[]	grand lane جراند لين	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:23.986742	2026-07-19 13:56:33.719
123f172b-220b-47d9-bf4a-2b82464a2b16	egypt.new-cairo.north-investors	c96e73c2-e705-4ce2-a1ab-e3f09c1c61b6	community	EG	Northern Investors	المستثمرين الشمالية	\N	north-investors	[]	["المستثمرين الشمالية"]	northern investors المستثمرين الشمالية north investors	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.008889	2026-07-19 13:56:33.755
0d80ad3c-52d0-40d0-b5ff-27be3a005ae8	egypt.new-administrative-capital.winter-park	6ba98411-06c4-4152-ada2-2a7fe4a1c9dc	compound	EG	Winter Park	وينتر بارك	\N	winter-park	[]	[]	winter park وينتر بارك	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.110655	2026-07-19 13:56:33.963
51f0a84a-71df-4dff-b8db-9697d98c248b	egypt.new-zayed.naia-west	caf38136-363e-4701-b8ce-5cc78f411e9b	compound	EG	Naia West	نايا ويست	\N	naia-west	[]	[]	naia west نايا ويست	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.271466	2026-07-19 13:56:34.253
d3daa846-3dbd-460e-b8ac-cb19a5cb3708	egypt.6th-of-october	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	6th of October	السادس من أكتوبر	\N	6th-of-october	[]	["6 October", "6 أكتوبر", "السادس من أكتوبر", "october", "اكتوبر"]	6th of october السادس من أكتوبر 6 october 6 أكتوبر october اكتوبر	\N	\N	\N	\N	\N	\N	\N	\N	88	t	curated	\N	\N	active	2026-07-18 21:27:24.279965	2026-07-19 13:56:34.271
c57623b2-fd84-4bf9-b0f3-af8a9fe2f84e	egypt.shorouk-new	6c25bca7-b72f-4837-979b-44440c99739a	city	EG	New Shorouk	الشروق الجديدة	\N	shorouk-new	[]	["الشروق الجديدة"]	new shorouk الشروق الجديدة shorouk new	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.501496	2026-07-19 13:56:34.704
ed3bcde1-836a-48e6-b928-f1b6a71c5431	egypt.gardenia-city	6c25bca7-b72f-4837-979b-44440c99739a	community	EG	Gardenia City	جاردنيا سيتي	\N	gardenia-city	[]	["Gardenia", "جاردنيا"]	gardenia city جاردنيا سيتي gardenia جاردنيا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.519024	2026-07-19 13:56:34.753
487c67d9-e6ad-48a7-a6d5-2e7e19a7571f	egypt.north-coast.swan-lake-north-coast	0461c7cf-610d-44c0-b479-6b726605e555	compound	EG	Swan Lake North Coast	سوان ليك الساحل	\N	swan-lake-north-coast	[]	["Swan Lake", "سوان ليك"]	swan lake north coast سوان ليك الساحل swan lake سوان ليك	d80fa520-2473-44a4-9d7b-d912f04b76e9	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.616716	2026-07-19 13:56:34.968
0f73a977-5419-484b-b23c-3fcf7eee3f35	saudi-arabia.riyadh.new-murabba	b4b9d621-743a-4e95-848d-96a93716cec1	compound	SA	New Murabba	المربع الجديد	\N	new-murabba	[]	["Murabba", "المربع"]	new murabba المربع الجديد murabba المربع	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.744139	2026-07-19 13:56:35.267
a6fd7aa2-f6ea-4b36-9f84-e865716bdb5e	saudi-arabia.kaec	8e3d2a3a-4afb-41b0-b65d-b01d7f45c145	city	SA	King Abdullah Economic City	مدينة الملك عبدالله الاقتصادية	\N	kaec	[]	["KAEC", "عبدالله الاقتصادية"]	king abdullah economic city مدينة الملك عبدالله الاقتصادية kaec عبدالله الاقتصادية	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:24.813004	2026-07-19 13:56:35.445
c5f52d89-6aff-4c08-aaab-8daabf39b2d8	uae.abu-dhabi	2288072b-8a97-4a62-823c-7a774150b62c	city	AE	Abu Dhabi	أبوظبي	\N	abu-dhabi	[]	["Abu Dhabi", "أبوظبي", "ابوظبي"]	abu dhabi أبوظبي ابوظبي	\N	\N	\N	\N	\N	\N	\N	\N	90	t	curated	\N	\N	active	2026-07-18 21:27:24.89252	2026-07-19 13:56:35.604
b0cac617-b096-45d1-8200-31d1e7c7859d	bahrain.amwaj-islands	a1428274-397d-45a7-ab04-56ae3fa72275	city	BH	Amwaj Islands	جزر أمواج	\N	amwaj-islands	[]	["Amwaj", "أمواج"]	amwaj islands جزر أمواج amwaj أمواج	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.208978	2026-07-19 13:56:35.854
a5be5c5a-4263-4739-8114-6ab4477a61dc	oman	\N	country	OM	Oman	عُمان	\N	oman	[]	["Oman", "عمان", "سلطنة عمان"]	oman عُمان عمان سلطنة عمان	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.216072	2026-07-19 13:56:35.871
6c6e7a69-77dd-411b-a4a0-ac0b3406e0bb	oman.muscat	a5be5c5a-4263-4739-8114-6ab4477a61dc	city	OM	Muscat	مسقط	\N	muscat	[]	["Muscat", "مسقط"]	muscat مسقط	\N	\N	\N	\N	\N	\N	\N	\N	76	t	curated	\N	\N	active	2026-07-18 21:27:25.220551	2026-07-19 13:56:35.88
2c4af1d1-d941-4986-9071-4f8b900d15a7	oman.muscat.al-mouj	6c6e7a69-77dd-411b-a4a0-ac0b3406e0bb	compound	OM	Al Mouj	الموج	\N	al-mouj	[]	["Al Mouj", "الموج"]	al mouj الموج	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.224704	2026-07-19 13:56:35.886
a9a37f66-1e3c-47c6-b30e-469552c80bee	oman.salalah	a5be5c5a-4263-4739-8114-6ab4477a61dc	city	OM	Salalah	صلالة	\N	salalah	[]	["Salalah", "صلالة"]	salalah صلالة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.228497	2026-07-19 13:56:35.896
4b22a052-b642-4476-b0de-76d64c90150c	oman.sohar	a5be5c5a-4263-4739-8114-6ab4477a61dc	city	OM	Sohar	صحار	\N	sohar	[]	["Sohar", "صحار"]	sohar صحار	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.331537	2026-07-19 13:56:35.903
984dd15e-59c1-4abd-92bd-19ae22c8d0c9	oman.nizwa	a5be5c5a-4263-4739-8114-6ab4477a61dc	city	OM	Nizwa	نزوى	\N	nizwa	[]	["Nizwa", "نزوى"]	nizwa نزوى	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.336954	2026-07-19 13:56:35.914
fd3d9537-bd2f-405f-b720-1f6dc308e863	jordan	\N	country	JO	Jordan	الأردن	\N	jordan	[]	["Jordan", "الأردن", "الاردن"]	jordan الأردن الاردن	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.342018	2026-07-19 13:56:35.92
fbd3f051-daf6-430d-84cb-097d1f76db02	jordan.amman	fd3d9537-bd2f-405f-b720-1f6dc308e863	city	JO	Amman	عمّان	\N	amman	[]	["Amman", "عمان", "عمّان"]	amman عمّان عمان	\N	\N	\N	\N	\N	\N	\N	\N	82	t	curated	\N	\N	active	2026-07-18 21:27:25.346072	2026-07-19 13:56:35.928
d296910c-3c43-45e9-8363-74514cc7f2a8	jordan.amman.abdoun	fbd3f051-daf6-430d-84cb-097d1f76db02	district	JO	Abdoun	عبدون	\N	abdoun	[]	["Abdoun", "عبدون"]	abdoun عبدون	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.349303	2026-07-19 13:56:35.935
e551569c-8472-4ab6-b2a7-5bd388ff634b	jordan.amman.dabouq	fbd3f051-daf6-430d-84cb-097d1f76db02	district	JO	Dabouq	دابوق	\N	dabouq	[]	["Dabouq", "دابوق"]	dabouq دابوق	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.353098	2026-07-19 13:56:35.942
86efda92-4c87-4f17-88b1-e7b3512bf633	jordan.amman.khalda	fbd3f051-daf6-430d-84cb-097d1f76db02	district	JO	Khalda	خلدا	\N	khalda	[]	["Khalda", "خلدا"]	khalda خلدا	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.357368	2026-07-19 13:56:35.948
93d35c96-9ddb-4888-8180-746d9ea2f370	jordan.amman.deir-ghbar	fbd3f051-daf6-430d-84cb-097d1f76db02	district	JO	Deir Ghbar	دير غبار	\N	deir-ghbar	[]	["Deir Ghbar", "دير غبار"]	deir ghbar دير غبار	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.361009	2026-07-19 13:56:35.956
a8ac3493-bb3d-4661-8a5f-39dda3690022	jordan.amman.jabal-amman	fbd3f051-daf6-430d-84cb-097d1f76db02	district	JO	Jabal Amman	جبل عمان	\N	jabal-amman	[]	["Jabal Amman", "جبل عمان"]	jabal amman جبل عمان	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.367844	2026-07-19 13:56:35.963
590f4c61-9046-4696-8b7b-ac13ce141a2f	jordan.zarqa	fd3d9537-bd2f-405f-b720-1f6dc308e863	city	JO	Zarqa	الزرقاء	\N	zarqa	[]	["Zarqa", "الزرقاء"]	zarqa الزرقاء	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.372558	2026-07-19 13:56:35.975
1dab768f-193d-42b8-bd91-9093ae4feede	jordan.irbid	fd3d9537-bd2f-405f-b720-1f6dc308e863	city	JO	Irbid	إربد	\N	irbid	[]	["Irbid", "اربد"]	irbid إربد اربد	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.376565	2026-07-19 13:56:35.982
7f02cd63-2c77-4917-9ebb-e0b9c828a859	jordan.aqaba	fd3d9537-bd2f-405f-b720-1f6dc308e863	city	JO	Aqaba	العقبة	\N	aqaba	[]	["Aqaba", "العقبة"]	aqaba العقبة	\N	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.383876	2026-07-19 13:56:35.989
cef7db57-913e-4ae5-baed-14295b5ddecc	bahrain.diyar-al-muharraq	a1428274-397d-45a7-ab04-56ae3fa72275	city	BH	Diyar Al Muharraq	ديار المحرق	\N	diyar-al-muharraq	[]	["Diyar Al Muharraq", "ديار المحرق"]	diyar al muharraq ديار المحرق	b1853876-bea8-4f21-a8d6-1aa8d9530b58	\N	\N	\N	\N	\N	\N	\N	0	t	curated	\N	\N	active	2026-07-18 21:27:25.212924	2026-07-19 13:56:35.864
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reports (id, listing_id, reporter_user_id, reason, details, status, resolved_by_user_id, resolution_note, created_at, resolved_at) FROM stdin;
f4c25ead-5a74-4b0b-8414-936bf95959c3	fc570df0-e974-4c5a-abbe-d2df329e8ae3	267d8854-2d0d-4988-89b2-bca9de35e789	fake_price	السعر غير حقيقي، أقل من السوق بكثير ويبدو احتيالاً.	open	\N	\N	2026-07-18 21:27:26.70136	\N
cc776b33-d7ec-40c3-9dc0-60df8aab5315	afb9180b-6d35-4e8f-9858-897749ccb3d3	00ba65f0-e746-4c79-8026-09723e0a59f0	scam	البائع يطلب تحويل عربون قبل المعاينة.	open	\N	\N	2026-07-18 21:27:26.70136	\N
adc12b6b-23fc-41d1-a362-df1eca686812	5c396975-c3f2-4970-b281-f8db7cfca1bf	1b06f035-4e8a-4dd7-86e3-95299957f2b8	wrong_data	الموديل والسنة غير مطابقين للصور.	open	\N	\N	2026-07-18 21:27:26.70136	\N
613b63e4-6879-43da-8490-b458218ec588	25130e61-f0ac-4a2f-ab46-91ce6f54649f	267d8854-2d0d-4988-89b2-bca9de35e789	duplicate	نفس الإعلان منشور أكثر من مرة.	reviewing	\N	\N	2026-07-18 21:27:26.70136	\N
bb23d29a-fe95-46bd-b8cd-8ad9e7a16cf8	85c4c348-d4f0-44ed-b814-60c0a881559e	760eca0f-df82-4102-9263-2cc82898272b	other	صور غير لائقة.	open	\N	\N	2026-07-18 21:27:26.70136	\N
\.


--
-- Data for Name: rfq_offers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfq_offers (id, rfq_id, supplier_id, price_quote, currency, lead_time_days, moq, message, status, created_at, updated_at) FROM stdin;
d747a62a-49a0-4b91-8b28-a550b726d312	6cd1b93e-1020-4d83-8ce9-a009de13fe43	0f04b82a-797d-4bc6-afa3-b1857fca6608	1420000	EGP	14	5	خامة بكر بشهادة مطابقة، تسليم خلال أسبوعين.	pending	2026-07-18 21:27:21.071962	2026-07-18 21:27:21.071962
44c28419-d5de-4c57-9024-0fb9667024fb	6cd1b93e-1020-4d83-8ce9-a009de13fe43	1b06f035-4e8a-4dd7-86e3-95299957f2b8	1380000	EGP	21	3	سعر تنافسي مع إمكانية التوريد الدوري.	pending	2026-07-18 21:27:21.071962	2026-07-18 21:27:21.071962
b3b7cbb9-03e8-4a4d-8af4-4e3c95ecbb29	0cf0796f-fe14-4988-97e9-83855b6613a2	0f04b82a-797d-4bc6-afa3-b1857fca6608	2750000	EGP	30	1	ماكينة جديدة مع ضمان سنتين وتدريب التشغيل.	accepted	2026-07-18 21:27:21.081785	2026-07-18 21:27:21.081785
24a2f83d-38f8-4adf-99a1-58342021aa47	0cf0796f-fe14-4988-97e9-83855b6613a2	1b06f035-4e8a-4dd7-86e3-95299957f2b8	2900000	EGP	25	1	تسليم أسرع مع خدمة صيانة مجانية أول سنة.	rejected	2026-07-18 21:27:21.081785	2026-07-18 21:27:21.081785
\.


--
-- Data for Name: rfqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfqs (id, buyer_id, category, title, description, quantity, unit, target_price_max, destination_country, industry, industrial_type, status, deadline, created_at, updated_at) FROM stdin;
6cd1b93e-1020-4d83-8ce9-a009de13fe43	267d8854-2d0d-4988-89b2-bca9de35e789	industrial	مطلوب 5 طن حبيبات بلاستيك PP	مطلوب توريد 5 طن حبيبات بولي بروبيلين بكر، تسليم القاهرة الكبرى، الدفع عند الاستلام.	5	طن	1500000	Egypt	plastic	raw_material	open	\N	2026-07-18 21:27:21.067173	2026-07-18 21:27:21.067173
0cf0796f-fe14-4988-97e9-83855b6613a2	00ba65f0-e746-4c79-8026-09723e0a59f0	industrial	مطلوب ماكينة تعبئة وتغليف أوتوماتيك	مطلوب ماكينة تعبئة وتغليف أوتوماتيكية للسوائل، طاقة 2000 وحدة/ساعة.	1	وحدة	3000000	Egypt	engineering	machine	awarded	\N	2026-07-18 21:27:21.078714	2026-07-18 21:27:21.078714
\.


--
-- Data for Name: saved_listings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_listings (id, user_id, listing_id, created_at) FROM stdin;
9c894c3e-a2e8-48f1-b3bb-afe9d58a8bce	f787718d-27d8-4877-82fd-b4ff2a25bdee	9322a87e-6899-4b8a-8399-280801afaff0	2026-07-21 13:33:19.163351
\.


--
-- Data for Name: saved_searches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_searches (id, user_id, name, query, category, filters, price_min, price_max, alerts_enabled, last_notified_listing_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seller_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seller_reviews (id, seller_id, author_id, rating, body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stories (id, user_id, listing_id, media_url, caption, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: story_views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.story_views (id, story_id, viewer_id, created_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, user_id, plan_id, status, price_paid, starts_at, expires_at, auto_renew, transaction_id, cancelled_at, created_at) FROM stdin;
\.


--
-- Data for Name: support_ticket_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_ticket_messages (id, ticket_id, author_user_id, is_admin, body, created_at) FROM stdin;
e5d6b08f-af22-42ab-b312-dd0dd6b654d6	129dd2b6-b57b-4a82-83dc-25c52c626e22	267d8854-2d0d-4988-89b2-bca9de35e789	f	كل ما أحاول رفع الصور تظهر رسالة خطأ. ممكن المساعدة؟	2026-07-18 21:27:26.71285
b19bd9e9-37a2-4174-bba9-28ffbad035bd	b60a49fb-2259-4538-b337-2b47dc57b5ee	00ba65f0-e746-4c79-8026-09723e0a59f0	f	خصمت المبلغ ولم يتم تفعيل الإعلان الممول.	2026-07-18 21:27:26.723047
aba24f36-5afc-495b-a58d-064dd67e9a8c	d1019152-d399-4466-96b9-60bb752a9d90	1b06f035-4e8a-4dd7-86e3-95299957f2b8	f	أريد شارة التوثيق، ما هي المستندات المطلوبة؟	2026-07-18 21:27:26.73128
93a65094-16c4-490c-b227-4fa29e0a80da	c1f1b1f1-b015-41cc-812d-a7987bf6de57	760eca0f-df82-4102-9263-2cc82898272b	f	I keep receiving fake WhatsApp leads.	2026-07-18 21:27:26.739857
8407e973-4d20-4491-be1a-9db408e7ef24	c1f1b1f1-b015-41cc-812d-a7987bf6de57	\N	t	تم حظر الحسابات المسيئة. شكراً لإبلاغنا.	2026-07-18 21:27:26.743809
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, user_id, subject, category, status, last_reply_at, created_at, updated_at) FROM stdin;
129dd2b6-b57b-4a82-83dc-25c52c626e22	267d8854-2d0d-4988-89b2-bca9de35e789	لم أستطع رفع صور الإعلان	listings	open	2026-07-18 21:27:26.707793	2026-07-18 21:27:26.707793	2026-07-18 21:27:26.707793
b60a49fb-2259-4538-b337-2b47dc57b5ee	00ba65f0-e746-4c79-8026-09723e0a59f0	مشكلة في الدفع عند تفعيل الإعلان الممول	billing	open	2026-07-18 21:27:26.717894	2026-07-18 21:27:26.717894	2026-07-18 21:27:26.717894
d1019152-d399-4466-96b9-60bb752a9d90	1b06f035-4e8a-4dd7-86e3-95299957f2b8	كيف أوثّق حسابي كتاجر؟	account	open	2026-07-18 21:27:26.727456	2026-07-18 21:27:26.727456	2026-07-18 21:27:26.727456
c1f1b1f1-b015-41cc-812d-a7987bf6de57	760eca0f-df82-4102-9263-2cc82898272b	Spam leads on my listing	other	closed	2026-07-18 21:27:26.74943	2026-07-18 21:27:26.735648	2026-07-18 21:27:26.74943
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, user_id, type, amount, balance_after, payment_method, reference_type, reference_id, description, idempotency_key, metadata, created_at) FROM stdin;
c1928d97-cca5-4881-b256-2d96e11738ca	1b06f035-4e8a-4dd7-86e3-95299957f2b8	adjustment	10000	10000	\N	\N	\N	Opening balance (seed)	seed_opening_1b06f035-4e8a-4dd7-86e3-95299957f2b8	\N	2026-07-18 21:27:18.606902
538a9532-5a4b-4c0e-9d02-27e3280a8ac7	760eca0f-df82-4102-9263-2cc82898272b	adjustment	10000	10000	\N	\N	\N	Opening balance (seed)	seed_opening_760eca0f-df82-4102-9263-2cc82898272b	\N	2026-07-18 21:27:18.618694
c73650ab-b7a0-4278-b447-f1505ca2c2ff	0f04b82a-797d-4bc6-afa3-b1857fca6608	adjustment	10000	10000	\N	\N	\N	Opening balance (seed)	seed_opening_0f04b82a-797d-4bc6-afa3-b1857fca6608	\N	2026-07-18 21:27:18.62641
d3fa5a74-0527-493f-b8c2-e151ec240c24	7a1f2488-111c-445b-9169-35e6b7eb37b4	adjustment	10000	10000	\N	\N	\N	Opening balance (seed)	seed_opening_7a1f2488-111c-445b-9169-35e6b7eb37b4	\N	2026-07-18 21:27:18.638692
3ab4f42a-349c-4b63-9271-242ec9eba05c	fac3fd7b-ee18-4d9f-9870-2193567e3d5e	adjustment	10000	10000	\N	\N	\N	Opening balance (seed)	seed_opening_fac3fd7b-ee18-4d9f-9870-2193567e3d5e	\N	2026-07-18 21:27:18.645237
f3c15de5-17c5-4e59-9dae-b0db2ca8386b	7a1f2488-111c-445b-9169-35e6b7eb37b4	lead_charge	-30.00	9970.00	\N	lead	11294434-f541-484a-9ea1-9c771610bf39	Lead charge (finance_request)	\N	\N	2026-07-21 13:33:10.197495
d9eb4b3d-4080-4834-9802-d039fd0d9ff1	760eca0f-df82-4102-9263-2cc82898272b	lead_charge	-10.00	9990.00	\N	lead	5824c17b-4eb4-4462-ad5a-383aca96c077	Lead charge (chat)	\N	\N	2026-07-21 13:34:27.076949
\.


--
-- Data for Name: upload_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.upload_claims (object_path, clerk_id, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_behavior; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_behavior (id, user_id, session_id, listing_id, action, created_at) FROM stdin;
\.


--
-- Data for Name: user_social_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_social_links (id, user_id, platform, value, created_at, updated_at) FROM stdin;
397cf2ac-3b4d-4bfe-89de-e7ddf94c26c5	0ffba2c6-38af-4255-9a68-a7bc909c6b70	instagram	https://instagram.com/gggg	2026-07-19 20:40:32.948203	2026-07-19 20:40:32.948203
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, clerk_id, name, email, phone, role, is_admin, staff_role, is_verified, wallet_balance, promo_ad_balance, promo_ad_balance_expires_at, is_shadow_banned, quality_score, company_details, created_at, deleted_at) FROM stdin;
267d8854-2d0d-4988-89b2-bca9de35e789	seed_individual_1	Ahmed Hassan	seed_individual_1@banco-seed.com	+201053690093	individual	f	user	f	0	0.00	\N	f	\N	\N	2026-07-18 21:27:18.598612	\N
00ba65f0-e746-4c79-8026-09723e0a59f0	seed_individual_2	Mohamed Khalil	seed_individual_2@banco-seed.com	+201030285654	individual	f	user	f	0	0.00	\N	f	\N	\N	2026-07-18 21:27:18.602107	\N
1b06f035-4e8a-4dd7-86e3-95299957f2b8	seed_dealer_1	مجموعة النور للسيارات	seed_dealer_1@banco-seed.com	+201099470978	dealer	f	user	t	10000	0.00	\N	f	\N	\N	2026-07-18 21:27:18.579193	\N
0f04b82a-797d-4bc6-afa3-b1857fca6608	seed_dealer_3	الأمل للصناعات	seed_dealer_3@banco-seed.com	+201070285902	dealer	f	user	t	10000	0.00	\N	f	\N	\N	2026-07-18 21:27:18.588384	\N
fac3fd7b-ee18-4d9f-9870-2193567e3d5e	seed_dealer_5	Cairo Real Estate Group	seed_dealer_5@banco-seed.com	+201032999429	enterprise	f	user	t	10000	0.00	\N	f	\N	\N	2026-07-18 21:27:18.594803	\N
f787718d-27d8-4877-82fd-b4ff2a25bdee	user_3GoXXJRSlm8kv8y3yZFITYNCIW3	BANCO User	wael_zeed@yahoo.com	\N	individual	t	owner	f	0	0.00	\N	f	\N	\N	2026-07-21 13:32:46.409643	\N
7a1f2488-111c-445b-9169-35e6b7eb37b4	seed_dealer_4	Delta Motors	seed_dealer_4@banco-seed.com	+201088543923	dealer	f	user	t	9970.00	0.00	\N	f	\N	\N	2026-07-18 21:27:18.591835	\N
0ffba2c6-38af-4255-9a68-a7bc909c6b70	user_3Eu3h1SF97XjZwUSzTuCzhjiBYG	Wael Zaid	waelzaid66@gmail.com	01005806658	individual	t	owner	f	0	0.00	\N	f	\N	\N	2026-07-19 09:47:08.026696	\N
760eca0f-df82-4102-9263-2cc82898272b	seed_dealer_2	الصفوة العقارية	seed_dealer_2@banco-seed.com	+201032332665	company	f	user	t	9990.00	0.00	\N	f	\N	\N	2026-07-18 21:27:18.584011	\N
\.


--
-- Name: ads ads_boost_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ads
    ADD CONSTRAINT ads_boost_idempotency_key_unique UNIQUE (boost_idempotency_key);


--
-- Name: ads ads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ads
    ADD CONSTRAINT ads_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: brands brands_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_slug_unique UNIQUE (slug);


--
-- Name: candidate_attribute_seen candidate_attribute_seen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.candidate_attribute_seen
    ADD CONSTRAINT candidate_attribute_seen_pkey PRIMARY KEY (id);


--
-- Name: candidate_attributes candidate_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.candidate_attributes
    ADD CONSTRAINT candidate_attributes_pkey PRIMARY KEY (id);


--
-- Name: car_variants car_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.car_variants
    ADD CONSTRAINT car_variants_pkey PRIMARY KEY (id);


--
-- Name: car_variants car_variants_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.car_variants
    ADD CONSTRAINT car_variants_slug_unique UNIQUE (slug);


--
-- Name: company_follows company_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_follows
    ADD CONSTRAINT company_follows_pkey PRIMARY KEY (id);


--
-- Name: company_profiles company_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_profiles
    ADD CONSTRAINT company_profiles_pkey PRIMARY KEY (id);


--
-- Name: company_profiles company_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_profiles
    ADD CONSTRAINT company_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: dedup_keys dedup_keys_store_name_dedup_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dedup_keys
    ADD CONSTRAINT dedup_keys_store_name_dedup_key_pk PRIMARY KEY (store_name, dedup_key);


--
-- Name: email_provider_config email_provider_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_provider_config
    ADD CONSTRAINT email_provider_config_pkey PRIMARY KEY (provider);


--
-- Name: financing_branches financing_branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_branches
    ADD CONSTRAINT financing_branches_pkey PRIMARY KEY (id);


--
-- Name: financing_intermediaries financing_intermediaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_intermediaries
    ADD CONSTRAINT financing_intermediaries_pkey PRIMARY KEY (id);


--
-- Name: financing_requests financing_requests_lead_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_requests
    ADD CONSTRAINT financing_requests_lead_id_unique UNIQUE (lead_id);


--
-- Name: financing_requests financing_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_requests
    ADD CONSTRAINT financing_requests_pkey PRIMARY KEY (id);


--
-- Name: financing_seats financing_seats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_seats
    ADD CONSTRAINT financing_seats_pkey PRIMARY KEY (id);


--
-- Name: finishing_types finishing_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finishing_types
    ADD CONSTRAINT finishing_types_pkey PRIMARY KEY (id);


--
-- Name: finishing_types finishing_types_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finishing_types
    ADD CONSTRAINT finishing_types_slug_unique UNIQUE (slug);


--
-- Name: global_supply_requests global_supply_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_supply_requests
    ADD CONSTRAINT global_supply_requests_pkey PRIMARY KEY (id);


--
-- Name: global_supply_responses global_supply_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_supply_responses
    ADD CONSTRAINT global_supply_responses_pkey PRIMARY KEY (id);


--
-- Name: industrial_types industrial_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.industrial_types
    ADD CONSTRAINT industrial_types_pkey PRIMARY KEY (id);


--
-- Name: industrial_types industrial_types_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.industrial_types
    ADD CONSTRAINT industrial_types_slug_unique UNIQUE (slug);


--
-- Name: industries industries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.industries
    ADD CONSTRAINT industries_pkey PRIMARY KEY (id);


--
-- Name: industries industries_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.industries
    ADD CONSTRAINT industries_slug_unique UNIQUE (slug);


--
-- Name: interactions interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_pkey PRIMARY KEY (listing_id);


--
-- Name: investment_interests investment_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_interests
    ADD CONSTRAINT investment_interests_pkey PRIMARY KEY (id);


--
-- Name: investment_opportunities investment_opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_opportunities
    ADD CONSTRAINT investment_opportunities_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_unique UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_transaction_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_transaction_id_unique UNIQUE (transaction_id);


--
-- Name: lead_billing lead_billing_lead_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_billing
    ADD CONSTRAINT lead_billing_lead_id_unique UNIQUE (lead_id);


--
-- Name: lead_billing lead_billing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_billing
    ADD CONSTRAINT lead_billing_pkey PRIMARY KEY (id);


--
-- Name: lead_history lead_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_history
    ADD CONSTRAINT lead_history_pkey PRIMARY KEY (id);


--
-- Name: lead_tokens lead_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_tokens
    ADD CONSTRAINT lead_tokens_pkey PRIMARY KEY (id);


--
-- Name: listing_attributes listing_attributes_listing_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_listing_id_unique UNIQUE (listing_id);


--
-- Name: listing_attributes listing_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_pkey PRIMARY KEY (id);


--
-- Name: listing_comments listing_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_comments
    ADD CONSTRAINT listing_comments_pkey PRIMARY KEY (id);


--
-- Name: listing_links listing_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_links
    ADD CONSTRAINT listing_links_pkey PRIMARY KEY (id);


--
-- Name: listing_media listing_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_media
    ADD CONSTRAINT listing_media_pkey PRIMARY KEY (id);


--
-- Name: listings listings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: locations locations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_slug_unique UNIQUE (slug);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: models models_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_slug_unique UNIQUE (slug);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: ownership_types ownership_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ownership_types
    ADD CONSTRAINT ownership_types_pkey PRIMARY KEY (id);


--
-- Name: ownership_types ownership_types_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ownership_types
    ADD CONSTRAINT ownership_types_slug_unique UNIQUE (slug);


--
-- Name: payment_intents payment_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_pkey PRIMARY KEY (id);


--
-- Name: payment_options payment_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_options
    ADD CONSTRAINT payment_options_pkey PRIMARY KEY (id);


--
-- Name: payment_provider_config payment_provider_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_provider_config
    ADD CONSTRAINT payment_provider_config_pkey PRIMARY KEY (provider);


--
-- Name: pending_locations pending_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_locations
    ADD CONSTRAINT pending_locations_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: plans plans_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_slug_unique UNIQUE (slug);


--
-- Name: price_observations price_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT price_observations_pkey PRIMARY KEY (id);


--
-- Name: promo_ad_campaign_config promo_ad_campaign_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_ad_campaign_config
    ADD CONSTRAINT promo_ad_campaign_config_pkey PRIMARY KEY (id);


--
-- Name: promo_ad_grants promo_ad_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_ad_grants
    ADD CONSTRAINT promo_ad_grants_pkey PRIMARY KEY (id);


--
-- Name: promo_ad_transactions promo_ad_transactions_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_ad_transactions
    ADD CONSTRAINT promo_ad_transactions_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: promo_ad_transactions promo_ad_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_ad_transactions
    ADD CONSTRAINT promo_ad_transactions_pkey PRIMARY KEY (id);


--
-- Name: property_types property_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_pkey PRIMARY KEY (id);


--
-- Name: property_types property_types_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_slug_unique UNIQUE (slug);


--
-- Name: push_tokens push_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_pkey PRIMARY KEY (id);


--
-- Name: rate_events rate_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_events
    ADD CONSTRAINT rate_events_pkey PRIMARY KEY (id);


--
-- Name: reference_developers reference_developers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_developers
    ADD CONSTRAINT reference_developers_pkey PRIMARY KEY (id);


--
-- Name: reference_developers reference_developers_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_developers
    ADD CONSTRAINT reference_developers_slug_unique UNIQUE (slug);


--
-- Name: reference_places reference_places_global_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_places
    ADD CONSTRAINT reference_places_global_id_unique UNIQUE (global_id);


--
-- Name: reference_places reference_places_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_places
    ADD CONSTRAINT reference_places_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: rfq_offers rfq_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_offers
    ADD CONSTRAINT rfq_offers_pkey PRIMARY KEY (id);


--
-- Name: rfqs rfqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_pkey PRIMARY KEY (id);


--
-- Name: saved_listings saved_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_listings
    ADD CONSTRAINT saved_listings_pkey PRIMARY KEY (id);


--
-- Name: saved_searches saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_pkey PRIMARY KEY (id);


--
-- Name: seller_reviews seller_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seller_reviews
    ADD CONSTRAINT seller_reviews_pkey PRIMARY KEY (id);


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_pkey PRIMARY KEY (id);


--
-- Name: story_views story_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.story_views
    ADD CONSTRAINT story_views_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: support_ticket_messages support_ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_ticket_messages
    ADD CONSTRAINT support_ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: upload_claims upload_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_claims
    ADD CONSTRAINT upload_claims_pkey PRIMARY KEY (object_path);


--
-- Name: user_behavior user_behavior_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_behavior
    ADD CONSTRAINT user_behavior_pkey PRIMARY KEY (id);


--
-- Name: user_social_links user_social_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_social_links
    ADD CONSTRAINT user_social_links_pkey PRIMARY KEY (id);


--
-- Name: users users_account_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_account_number_unique UNIQUE (account_number);


--
-- Name: users users_clerk_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_clerk_id_unique UNIQUE (clerk_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_ads_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ads_active ON public.ads USING btree (is_active);


--
-- Name: idx_ads_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ads_expires ON public.ads USING btree (expires_at);


--
-- Name: idx_ads_seller; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ads_seller ON public.ads USING btree (seller_id);


--
-- Name: idx_audit_actor_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_actor_user ON public.audit_log USING btree (actor_user_id);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_created ON public.audit_log USING btree (created_at);


--
-- Name: idx_audit_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_event ON public.audit_log USING btree (event_type);


--
-- Name: idx_audit_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_listing ON public.audit_log USING btree (listing_id);


--
-- Name: idx_audit_subject_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_subject_user ON public.audit_log USING btree (subject_user_id);


--
-- Name: idx_behavior_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_behavior_created ON public.user_behavior USING btree (created_at);


--
-- Name: idx_behavior_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_behavior_listing ON public.user_behavior USING btree (listing_id);


--
-- Name: idx_behavior_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_behavior_user ON public.user_behavior USING btree (user_id);


--
-- Name: idx_bookings_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_dates ON public.bookings USING btree (check_in, check_out);


--
-- Name: idx_bookings_guest; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_guest ON public.bookings USING btree (guest_id);


--
-- Name: idx_bookings_listing_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_listing_status ON public.bookings USING btree (listing_id, status);


--
-- Name: idx_brands_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_brands_active ON public.brands USING btree (is_active);


--
-- Name: idx_brands_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_brands_category ON public.brands USING btree (category);


--
-- Name: idx_brands_popularity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_brands_popularity ON public.brands USING btree (popularity);


--
-- Name: idx_brands_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_brands_slug ON public.brands USING btree (slug);


--
-- Name: idx_candidate_attr_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_candidate_attr_status ON public.candidate_attributes USING btree (status);


--
-- Name: idx_comment_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comment_created ON public.listing_comments USING btree (created_at);


--
-- Name: idx_comment_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comment_listing ON public.listing_comments USING btree (listing_id);


--
-- Name: idx_comment_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comment_parent ON public.listing_comments USING btree (parent_id);


--
-- Name: idx_company_follow_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_company_follow_company ON public.company_follows USING btree (company_user_id);


--
-- Name: idx_company_follow_follower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_company_follow_follower ON public.company_follows USING btree (follower_id);


--
-- Name: idx_company_profiles_country; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_company_profiles_country ON public.company_profiles USING btree (hq_country);


--
-- Name: idx_company_profiles_industry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_company_profiles_industry ON public.company_profiles USING btree (industry);


--
-- Name: idx_company_profiles_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_company_profiles_user ON public.company_profiles USING btree (user_id);


--
-- Name: idx_conversation_buyer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversation_buyer ON public.conversations USING btree (buyer_id);


--
-- Name: idx_conversation_last_msg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversation_last_msg ON public.conversations USING btree (last_message_at);


--
-- Name: idx_conversation_seller; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversation_seller ON public.conversations USING btree (seller_id);


--
-- Name: idx_dedup_keys_seen_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dedup_keys_seen_at ON public.dedup_keys USING btree (seen_at);


--
-- Name: idx_financing_branches_intermediary; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financing_branches_intermediary ON public.financing_branches USING btree (intermediary_id);


--
-- Name: idx_financing_intermediaries_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financing_intermediaries_active ON public.financing_intermediaries USING btree (is_active);


--
-- Name: idx_financing_intermediaries_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financing_intermediaries_owner ON public.financing_intermediaries USING btree (owner_user_id);


--
-- Name: idx_financing_requests_intermediary; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financing_requests_intermediary ON public.financing_requests USING btree (intermediary_id);


--
-- Name: idx_financing_requests_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financing_requests_status ON public.financing_requests USING btree (status);


--
-- Name: idx_financing_seats_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financing_seats_user ON public.financing_seats USING btree (user_id);


--
-- Name: idx_global_supply_buyer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_global_supply_buyer ON public.global_supply_requests USING btree (buyer_id);


--
-- Name: idx_global_supply_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_global_supply_created ON public.global_supply_requests USING btree (created_at);


--
-- Name: idx_global_supply_response_request; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_global_supply_response_request ON public.global_supply_responses USING btree (request_id);


--
-- Name: idx_global_supply_response_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_global_supply_response_status ON public.global_supply_responses USING btree (status);


--
-- Name: idx_global_supply_response_supplier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_global_supply_response_supplier ON public.global_supply_responses USING btree (supplier_id);


--
-- Name: idx_global_supply_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_global_supply_status ON public.global_supply_requests USING btree (status);


--
-- Name: idx_interactions_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_interactions_listing ON public.interactions USING btree (listing_id);


--
-- Name: idx_investment_interest_investment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investment_interest_investment ON public.investment_interests USING btree (investment_id);


--
-- Name: idx_investment_interest_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investment_interest_user ON public.investment_interests USING btree (user_id);


--
-- Name: idx_investments_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investments_created ON public.investment_opportunities USING btree (created_at);


--
-- Name: idx_investments_flagged; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investments_flagged ON public.investment_opportunities USING btree (is_flagged);


--
-- Name: idx_investments_industry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investments_industry ON public.investment_opportunities USING btree (industry);


--
-- Name: idx_investments_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investments_owner ON public.investment_opportunities USING btree (owner_id);


--
-- Name: idx_investments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investments_status ON public.investment_opportunities USING btree (status);


--
-- Name: idx_investments_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_investments_type ON public.investment_opportunities USING btree (investment_type);


--
-- Name: idx_invoices_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_created ON public.invoices USING btree (created_at);


--
-- Name: idx_invoices_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_user ON public.invoices USING btree (user_id);


--
-- Name: idx_lead_billing_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_billing_created ON public.lead_billing USING btree (created_at);


--
-- Name: idx_lead_billing_seller; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_billing_seller ON public.lead_billing USING btree (seller_id);


--
-- Name: idx_lead_billing_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_billing_status ON public.lead_billing USING btree (status);


--
-- Name: idx_lead_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_created ON public.lead_history USING btree (created_at);


--
-- Name: idx_lead_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_listing ON public.lead_history USING btree (listing_id);


--
-- Name: idx_lead_seller; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_seller ON public.lead_history USING btree (seller_id);


--
-- Name: idx_lead_tokens_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_tokens_expires ON public.lead_tokens USING btree (expires_at);


--
-- Name: idx_lead_tokens_viewer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_tokens_viewer ON public.lead_tokens USING btree (viewer_clerk_id, listing_id);


--
-- Name: idx_listing_attributes_brand; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listing_attributes_brand ON public.listing_attributes USING btree (brand_id);


--
-- Name: idx_listing_attributes_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listing_attributes_model ON public.listing_attributes USING btree (model_id);


--
-- Name: idx_listing_attributes_property_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listing_attributes_property_type ON public.listing_attributes USING btree (property_type);


--
-- Name: idx_listing_attributes_specs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listing_attributes_specs ON public.listing_attributes USING gin (specs);


--
-- Name: idx_listing_link_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listing_link_from ON public.listing_links USING btree (from_listing_id);


--
-- Name: idx_listing_link_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listing_link_to ON public.listing_links USING btree (to_listing_id);


--
-- Name: idx_listings_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_category ON public.listings USING btree (category);


--
-- Name: idx_listings_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_created_at ON public.listings USING btree (created_at);


--
-- Name: idx_listings_description_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_description_trgm ON public.listings USING gin (description public.gin_trgm_ops);


--
-- Name: idx_listings_duplicate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_duplicate ON public.listings USING btree (is_duplicate);


--
-- Name: idx_listings_feed_filter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_feed_filter ON public.listings USING btree (status, category, base_price_cash);


--
-- Name: idx_listings_flagged; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_flagged ON public.listings USING btree (is_flagged);


--
-- Name: idx_listings_is_request; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_is_request ON public.listings USING btree (is_request);


--
-- Name: idx_listings_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_location ON public.listings USING btree (location_id);


--
-- Name: idx_listings_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_price ON public.listings USING btree (base_price_cash);


--
-- Name: idx_listings_recency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_recency ON public.listings USING btree (status, bumped_at, created_at);


--
-- Name: idx_listings_saves; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_saves ON public.listings USING btree (saves_count);


--
-- Name: idx_listings_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_status ON public.listings USING btree (status);


--
-- Name: idx_listings_title_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_title_trgm ON public.listings USING gin (title public.gin_trgm_ops);


--
-- Name: idx_listings_trust; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_trust ON public.listings USING btree (trust_score);


--
-- Name: idx_listings_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_user ON public.listings USING btree (user_id);


--
-- Name: idx_locations_city; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_locations_city ON public.locations USING btree (city);


--
-- Name: idx_locations_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_locations_slug ON public.locations USING btree (slug);


--
-- Name: idx_media_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_media_listing ON public.listing_media USING btree (listing_id);


--
-- Name: idx_message_conversation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_conversation ON public.messages USING btree (conversation_id);


--
-- Name: idx_message_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_created ON public.messages USING btree (created_at);


--
-- Name: idx_models_brand; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_models_brand ON public.models USING btree (brand_id);


--
-- Name: idx_models_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_models_slug ON public.models USING btree (slug);


--
-- Name: idx_notif_pref_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notif_pref_user ON public.notification_preferences USING btree (user_id);


--
-- Name: idx_notification_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_created ON public.notifications USING btree (created_at);


--
-- Name: idx_notification_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_user ON public.notifications USING btree (user_id);


--
-- Name: idx_payment_intents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_intents_status ON public.payment_intents USING btree (status);


--
-- Name: idx_payment_intents_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_intents_user ON public.payment_intents USING btree (user_id);


--
-- Name: idx_payment_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_listing ON public.payment_options USING btree (listing_id);


--
-- Name: idx_pending_locations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pending_locations_status ON public.pending_locations USING btree (status);


--
-- Name: idx_plans_audience; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_plans_audience ON public.plans USING btree (audience);


--
-- Name: idx_plans_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_plans_slug ON public.plans USING btree (slug);


--
-- Name: idx_price_observations_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_observations_category ON public.price_observations USING btree (category);


--
-- Name: idx_price_observations_observed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_observations_observed ON public.price_observations USING btree (observed_at);


--
-- Name: idx_price_observations_segment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_observations_segment ON public.price_observations USING btree (segment_key);


--
-- Name: idx_promo_ad_tx_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_ad_tx_campaign ON public.promo_ad_transactions USING btree (campaign_version, created_at);


--
-- Name: idx_promo_ad_tx_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_ad_tx_user_created ON public.promo_ad_transactions USING btree (user_id, created_at);


--
-- Name: idx_push_token_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_push_token_user ON public.push_tokens USING btree (user_id);


--
-- Name: idx_rate_events_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_events_at ON public.rate_events USING btree (event_at);


--
-- Name: idx_rate_events_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_events_lookup ON public.rate_events USING btree (counter_name, bucket_key, event_at);


--
-- Name: idx_reference_developers_blob_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_developers_blob_trgm ON public.reference_developers USING gin (search_blob public.gin_trgm_ops);


--
-- Name: idx_reference_developers_country; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_developers_country ON public.reference_developers USING btree (iso_country_code);


--
-- Name: idx_reference_developers_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_developers_status ON public.reference_developers USING btree (status);


--
-- Name: idx_reference_places_blob_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_places_blob_trgm ON public.reference_places USING gin (search_blob public.gin_trgm_ops);


--
-- Name: idx_reference_places_country; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_places_country ON public.reference_places USING btree (iso_country_code);


--
-- Name: idx_reference_places_developer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_places_developer ON public.reference_places USING btree (developer_id);


--
-- Name: idx_reference_places_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_places_parent ON public.reference_places USING btree (parent_id);


--
-- Name: idx_reference_places_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_places_status ON public.reference_places USING btree (status);


--
-- Name: idx_reference_places_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_places_type ON public.reference_places USING btree (place_type);


--
-- Name: idx_reports_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_created ON public.reports USING btree (created_at);


--
-- Name: idx_reports_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_listing ON public.reports USING btree (listing_id);


--
-- Name: idx_reports_reporter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_reporter ON public.reports USING btree (reporter_user_id);


--
-- Name: idx_reports_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_status ON public.reports USING btree (status);


--
-- Name: idx_review_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_review_created ON public.seller_reviews USING btree (created_at);


--
-- Name: idx_review_seller; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_review_seller ON public.seller_reviews USING btree (seller_id);


--
-- Name: idx_rfq_offers_rfq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rfq_offers_rfq ON public.rfq_offers USING btree (rfq_id);


--
-- Name: idx_rfq_offers_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rfq_offers_status ON public.rfq_offers USING btree (status);


--
-- Name: idx_rfq_offers_supplier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rfq_offers_supplier ON public.rfq_offers USING btree (supplier_id);


--
-- Name: idx_rfqs_buyer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rfqs_buyer ON public.rfqs USING btree (buyer_id);


--
-- Name: idx_rfqs_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rfqs_category ON public.rfqs USING btree (category);


--
-- Name: idx_rfqs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rfqs_created ON public.rfqs USING btree (created_at);


--
-- Name: idx_rfqs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rfqs_status ON public.rfqs USING btree (status);


--
-- Name: idx_saved_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saved_listing ON public.saved_listings USING btree (listing_id);


--
-- Name: idx_saved_search_alerts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saved_search_alerts ON public.saved_searches USING btree (alerts_enabled);


--
-- Name: idx_saved_search_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saved_search_user ON public.saved_searches USING btree (user_id);


--
-- Name: idx_story_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_story_created ON public.stories USING btree (created_at);


--
-- Name: idx_story_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_story_expires ON public.stories USING btree (expires_at);


--
-- Name: idx_story_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_story_user ON public.stories USING btree (user_id);


--
-- Name: idx_story_view_story; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_story_view_story ON public.story_views USING btree (story_id);


--
-- Name: idx_subscriptions_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_expires ON public.subscriptions USING btree (expires_at);


--
-- Name: idx_subscriptions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_status ON public.subscriptions USING btree (status);


--
-- Name: idx_subscriptions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_user ON public.subscriptions USING btree (user_id);


--
-- Name: idx_ticket_messages_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ticket_messages_created ON public.support_ticket_messages USING btree (created_at);


--
-- Name: idx_ticket_messages_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ticket_messages_ticket ON public.support_ticket_messages USING btree (ticket_id);


--
-- Name: idx_tickets_last_reply; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_last_reply ON public.support_tickets USING btree (last_reply_at);


--
-- Name: idx_tickets_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_status ON public.support_tickets USING btree (status);


--
-- Name: idx_tickets_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_user ON public.support_tickets USING btree (user_id);


--
-- Name: idx_transactions_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_reference ON public.transactions USING btree (reference_type, reference_id);


--
-- Name: idx_transactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_type ON public.transactions USING btree (type);


--
-- Name: idx_transactions_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_user_created ON public.transactions USING btree (user_id, created_at);


--
-- Name: idx_user_social_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_social_user ON public.user_social_links USING btree (user_id);


--
-- Name: idx_variants_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_variants_model ON public.car_variants USING btree (model_id);


--
-- Name: uniq_candidate_attr; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_candidate_attr ON public.candidate_attributes USING btree (category, attr_key);


--
-- Name: uniq_candidate_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_candidate_seen ON public.candidate_attribute_seen USING btree (candidate_id, user_id);


--
-- Name: uniq_company_follow; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_company_follow ON public.company_follows USING btree (follower_id, company_user_id);


--
-- Name: uniq_conversation_tuple; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_conversation_tuple ON public.conversations USING btree (listing_id, buyer_id, seller_id);


--
-- Name: uniq_global_supply_response_supplier; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_global_supply_response_supplier ON public.global_supply_responses USING btree (request_id, supplier_id);


--
-- Name: uniq_investment_interest; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_investment_interest ON public.investment_interests USING btree (investment_id, user_id);


--
-- Name: uniq_listing_link; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_listing_link ON public.listing_links USING btree (from_listing_id, to_listing_id, relation);


--
-- Name: uniq_notif_pref; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_notif_pref ON public.notification_preferences USING btree (user_id, type);


--
-- Name: uniq_push_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_push_token ON public.push_tokens USING btree (token);


--
-- Name: uniq_rfq_offer_supplier; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_rfq_offer_supplier ON public.rfq_offers USING btree (rfq_id, supplier_id);


--
-- Name: uniq_saved_user_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_saved_user_listing ON public.saved_listings USING btree (user_id, listing_id);


--
-- Name: uniq_seller_review_author; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_seller_review_author ON public.seller_reviews USING btree (seller_id, author_id);


--
-- Name: uniq_story_view; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_story_view ON public.story_views USING btree (story_id, viewer_id);


--
-- Name: uniq_user_social_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_user_social_platform ON public.user_social_links USING btree (user_id, platform);


--
-- Name: upload_claims_clerk_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_claims_clerk_id_idx ON public.upload_claims USING btree (clerk_id);


--
-- Name: upload_claims_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_claims_expires_at_idx ON public.upload_claims USING btree (expires_at);


--
-- Name: uq_financing_seats_member; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_financing_seats_member ON public.financing_seats USING btree (intermediary_id, user_id);


--
-- Name: uq_pending_locations_norm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_pending_locations_norm ON public.pending_locations USING btree (normalized, iso_country_code);


--
-- Name: uq_price_observations_listing_source; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_price_observations_listing_source ON public.price_observations USING btree (listing_id, source);


--
-- Name: uq_promo_grant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_promo_grant ON public.promo_ad_grants USING btree (user_id, campaign_version, month_index);


--
-- Name: uq_reports_open_reporter_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_reports_open_reporter_listing ON public.reports USING btree (listing_id, reporter_user_id) WHERE (status = 'open'::public.report_status);


--
-- Name: uq_subscriptions_active_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_subscriptions_active_user ON public.subscriptions USING btree (user_id) WHERE (status = 'active'::public.subscription_status);


--
-- Name: ads ads_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ads
    ADD CONSTRAINT ads_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: ads ads_seller_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ads
    ADD CONSTRAINT ads_seller_id_users_id_fk FOREIGN KEY (seller_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_actor_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_users_id_fk FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_ad_id_ads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_ad_id_ads_id_fk FOREIGN KEY (ad_id) REFERENCES public.ads(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_subject_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_subject_user_id_users_id_fk FOREIGN KEY (subject_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_guest_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_guest_id_users_id_fk FOREIGN KEY (guest_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: candidate_attribute_seen candidate_attribute_seen_candidate_id_candidate_attributes_id_f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.candidate_attribute_seen
    ADD CONSTRAINT candidate_attribute_seen_candidate_id_candidate_attributes_id_f FOREIGN KEY (candidate_id) REFERENCES public.candidate_attributes(id) ON DELETE CASCADE;


--
-- Name: candidate_attribute_seen candidate_attribute_seen_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.candidate_attribute_seen
    ADD CONSTRAINT candidate_attribute_seen_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: car_variants car_variants_model_id_models_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.car_variants
    ADD CONSTRAINT car_variants_model_id_models_id_fk FOREIGN KEY (model_id) REFERENCES public.models(id) ON DELETE CASCADE;


--
-- Name: company_follows company_follows_company_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_follows
    ADD CONSTRAINT company_follows_company_user_id_users_id_fk FOREIGN KEY (company_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: company_follows company_follows_follower_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_follows
    ADD CONSTRAINT company_follows_follower_id_users_id_fk FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: company_profiles company_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_profiles
    ADD CONSTRAINT company_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_buyer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_buyer_id_users_id_fk FOREIGN KEY (buyer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_seller_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_seller_id_users_id_fk FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_provider_config email_provider_config_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_provider_config
    ADD CONSTRAINT email_provider_config_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: financing_branches financing_branches_intermediary_id_financing_intermediaries_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_branches
    ADD CONSTRAINT financing_branches_intermediary_id_financing_intermediaries_id_ FOREIGN KEY (intermediary_id) REFERENCES public.financing_intermediaries(id) ON DELETE CASCADE;


--
-- Name: financing_intermediaries financing_intermediaries_owner_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_intermediaries
    ADD CONSTRAINT financing_intermediaries_owner_user_id_users_id_fk FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: financing_requests financing_requests_branch_id_financing_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_requests
    ADD CONSTRAINT financing_requests_branch_id_financing_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.financing_branches(id) ON DELETE SET NULL;


--
-- Name: financing_requests financing_requests_intermediary_id_financing_intermediaries_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_requests
    ADD CONSTRAINT financing_requests_intermediary_id_financing_intermediaries_id_ FOREIGN KEY (intermediary_id) REFERENCES public.financing_intermediaries(id) ON DELETE SET NULL;


--
-- Name: financing_requests financing_requests_lead_id_lead_history_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_requests
    ADD CONSTRAINT financing_requests_lead_id_lead_history_id_fk FOREIGN KEY (lead_id) REFERENCES public.lead_history(id) ON DELETE CASCADE;


--
-- Name: financing_seats financing_seats_branch_id_financing_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_seats
    ADD CONSTRAINT financing_seats_branch_id_financing_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.financing_branches(id) ON DELETE SET NULL;


--
-- Name: financing_seats financing_seats_intermediary_id_financing_intermediaries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_seats
    ADD CONSTRAINT financing_seats_intermediary_id_financing_intermediaries_id_fk FOREIGN KEY (intermediary_id) REFERENCES public.financing_intermediaries(id) ON DELETE CASCADE;


--
-- Name: financing_seats financing_seats_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financing_seats
    ADD CONSTRAINT financing_seats_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: global_supply_requests global_supply_requests_buyer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_supply_requests
    ADD CONSTRAINT global_supply_requests_buyer_id_users_id_fk FOREIGN KEY (buyer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: global_supply_responses global_supply_responses_request_id_global_supply_requests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_supply_responses
    ADD CONSTRAINT global_supply_responses_request_id_global_supply_requests_id_fk FOREIGN KEY (request_id) REFERENCES public.global_supply_requests(id) ON DELETE CASCADE;


--
-- Name: global_supply_responses global_supply_responses_supplier_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_supply_responses
    ADD CONSTRAINT global_supply_responses_supplier_id_users_id_fk FOREIGN KEY (supplier_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: interactions interactions_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: investment_interests investment_interests_investment_id_investment_opportunities_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_interests
    ADD CONSTRAINT investment_interests_investment_id_investment_opportunities_id_ FOREIGN KEY (investment_id) REFERENCES public.investment_opportunities(id) ON DELETE CASCADE;


--
-- Name: investment_interests investment_interests_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_interests
    ADD CONSTRAINT investment_interests_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: investment_opportunities investment_opportunities_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_opportunities
    ADD CONSTRAINT investment_opportunities_location_id_locations_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: investment_opportunities investment_opportunities_owner_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_opportunities
    ADD CONSTRAINT investment_opportunities_owner_id_users_id_fk FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_transaction_id_transactions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_transaction_id_transactions_id_fk FOREIGN KEY (transaction_id) REFERENCES public.transactions(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lead_billing lead_billing_buyer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_billing
    ADD CONSTRAINT lead_billing_buyer_id_users_id_fk FOREIGN KEY (buyer_id) REFERENCES public.users(id);


--
-- Name: lead_billing lead_billing_lead_id_lead_history_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_billing
    ADD CONSTRAINT lead_billing_lead_id_lead_history_id_fk FOREIGN KEY (lead_id) REFERENCES public.lead_history(id) ON DELETE CASCADE;


--
-- Name: lead_billing lead_billing_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_billing
    ADD CONSTRAINT lead_billing_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE SET NULL;


--
-- Name: lead_billing lead_billing_seller_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_billing
    ADD CONSTRAINT lead_billing_seller_id_users_id_fk FOREIGN KEY (seller_id) REFERENCES public.users(id);


--
-- Name: lead_history lead_history_buyer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_history
    ADD CONSTRAINT lead_history_buyer_id_users_id_fk FOREIGN KEY (buyer_id) REFERENCES public.users(id);


--
-- Name: lead_history lead_history_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_history
    ADD CONSTRAINT lead_history_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: lead_history lead_history_seller_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_history
    ADD CONSTRAINT lead_history_seller_id_users_id_fk FOREIGN KEY (seller_id) REFERENCES public.users(id);


--
-- Name: lead_tokens lead_tokens_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_tokens
    ADD CONSTRAINT lead_tokens_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: listing_attributes listing_attributes_brand_id_brands_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_brand_id_brands_id_fk FOREIGN KEY (brand_id) REFERENCES public.brands(id);


--
-- Name: listing_attributes listing_attributes_finishing_type_id_finishing_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_finishing_type_id_finishing_types_id_fk FOREIGN KEY (finishing_type_id) REFERENCES public.finishing_types(id);


--
-- Name: listing_attributes listing_attributes_industrial_type_id_industrial_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_industrial_type_id_industrial_types_id_fk FOREIGN KEY (industrial_type_id) REFERENCES public.industrial_types(id);


--
-- Name: listing_attributes listing_attributes_industry_id_industries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_industry_id_industries_id_fk FOREIGN KEY (industry_id) REFERENCES public.industries(id);


--
-- Name: listing_attributes listing_attributes_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: listing_attributes listing_attributes_model_id_models_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_model_id_models_id_fk FOREIGN KEY (model_id) REFERENCES public.models(id);


--
-- Name: listing_attributes listing_attributes_ownership_type_id_ownership_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_ownership_type_id_ownership_types_id_fk FOREIGN KEY (ownership_type_id) REFERENCES public.ownership_types(id);


--
-- Name: listing_attributes listing_attributes_property_type_id_property_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_property_type_id_property_types_id_fk FOREIGN KEY (property_type_id) REFERENCES public.property_types(id);


--
-- Name: listing_attributes listing_attributes_variant_id_car_variants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_attributes
    ADD CONSTRAINT listing_attributes_variant_id_car_variants_id_fk FOREIGN KEY (variant_id) REFERENCES public.car_variants(id);


--
-- Name: listing_comments listing_comments_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_comments
    ADD CONSTRAINT listing_comments_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: listing_comments listing_comments_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_comments
    ADD CONSTRAINT listing_comments_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: listing_comments listing_comments_parent_id_listing_comments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_comments
    ADD CONSTRAINT listing_comments_parent_id_listing_comments_id_fk FOREIGN KEY (parent_id) REFERENCES public.listing_comments(id) ON DELETE CASCADE;


--
-- Name: listing_links listing_links_from_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_links
    ADD CONSTRAINT listing_links_from_listing_id_listings_id_fk FOREIGN KEY (from_listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: listing_links listing_links_to_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_links
    ADD CONSTRAINT listing_links_to_listing_id_listings_id_fk FOREIGN KEY (to_listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: listing_media listing_media_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_media
    ADD CONSTRAINT listing_media_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: listings listings_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_location_id_locations_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: listings listings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: messages messages_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: messages messages_listing_ref_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_listing_ref_id_listings_id_fk FOREIGN KEY (listing_ref_id) REFERENCES public.listings(id) ON DELETE SET NULL;


--
-- Name: messages messages_reply_to_id_messages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_reply_to_id_messages_id_fk FOREIGN KEY (reply_to_id) REFERENCES public.messages(id) ON DELETE SET NULL;


--
-- Name: messages messages_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: models models_brand_id_brands_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_brand_id_brands_id_fk FOREIGN KEY (brand_id) REFERENCES public.brands(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_intents payment_intents_plan_id_plans_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_plan_id_plans_id_fk FOREIGN KEY (plan_id) REFERENCES public.plans(id);


--
-- Name: payment_intents payment_intents_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_options payment_options_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_options
    ADD CONSTRAINT payment_options_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: payment_provider_config payment_provider_config_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_provider_config
    ADD CONSTRAINT payment_provider_config_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: pending_locations pending_locations_merged_into_id_reference_places_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_locations
    ADD CONSTRAINT pending_locations_merged_into_id_reference_places_id_fk FOREIGN KEY (merged_into_id) REFERENCES public.reference_places(id) ON DELETE SET NULL;


--
-- Name: pending_locations pending_locations_suggested_parent_id_reference_places_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_locations
    ADD CONSTRAINT pending_locations_suggested_parent_id_reference_places_id_fk FOREIGN KEY (suggested_parent_id) REFERENCES public.reference_places(id) ON DELETE SET NULL;


--
-- Name: price_observations price_observations_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_observations
    ADD CONSTRAINT price_observations_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE SET NULL;


--
-- Name: promo_ad_campaign_config promo_ad_campaign_config_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_ad_campaign_config
    ADD CONSTRAINT promo_ad_campaign_config_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: promo_ad_grants promo_ad_grants_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_ad_grants
    ADD CONSTRAINT promo_ad_grants_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: promo_ad_transactions promo_ad_transactions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_ad_transactions
    ADD CONSTRAINT promo_ad_transactions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: push_tokens push_tokens_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reference_places reference_places_developer_id_reference_developers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_places
    ADD CONSTRAINT reference_places_developer_id_reference_developers_id_fk FOREIGN KEY (developer_id) REFERENCES public.reference_developers(id) ON DELETE SET NULL;


--
-- Name: reference_places reference_places_parent_id_reference_places_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_places
    ADD CONSTRAINT reference_places_parent_id_reference_places_id_fk FOREIGN KEY (parent_id) REFERENCES public.reference_places(id) ON DELETE SET NULL;


--
-- Name: reports reports_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: reports reports_reporter_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_reporter_user_id_users_id_fk FOREIGN KEY (reporter_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reports reports_resolved_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_resolved_by_user_id_users_id_fk FOREIGN KEY (resolved_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: rfq_offers rfq_offers_rfq_id_rfqs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_offers
    ADD CONSTRAINT rfq_offers_rfq_id_rfqs_id_fk FOREIGN KEY (rfq_id) REFERENCES public.rfqs(id) ON DELETE CASCADE;


--
-- Name: rfq_offers rfq_offers_supplier_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_offers
    ADD CONSTRAINT rfq_offers_supplier_id_users_id_fk FOREIGN KEY (supplier_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rfqs rfqs_buyer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_buyer_id_users_id_fk FOREIGN KEY (buyer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: saved_listings saved_listings_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_listings
    ADD CONSTRAINT saved_listings_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: saved_listings saved_listings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_listings
    ADD CONSTRAINT saved_listings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: saved_searches saved_searches_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: seller_reviews seller_reviews_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seller_reviews
    ADD CONSTRAINT seller_reviews_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: seller_reviews seller_reviews_seller_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seller_reviews
    ADD CONSTRAINT seller_reviews_seller_id_users_id_fk FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stories stories_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE SET NULL;


--
-- Name: stories stories_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: story_views story_views_story_id_stories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.story_views
    ADD CONSTRAINT story_views_story_id_stories_id_fk FOREIGN KEY (story_id) REFERENCES public.stories(id) ON DELETE CASCADE;


--
-- Name: story_views story_views_viewer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.story_views
    ADD CONSTRAINT story_views_viewer_id_users_id_fk FOREIGN KEY (viewer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_plan_id_plans_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_plan_id_plans_id_fk FOREIGN KEY (plan_id) REFERENCES public.plans(id);


--
-- Name: subscriptions subscriptions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_ticket_messages support_ticket_messages_author_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_ticket_messages
    ADD CONSTRAINT support_ticket_messages_author_user_id_users_id_fk FOREIGN KEY (author_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: support_ticket_messages support_ticket_messages_ticket_id_support_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_ticket_messages
    ADD CONSTRAINT support_ticket_messages_ticket_id_support_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_behavior user_behavior_listing_id_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_behavior
    ADD CONSTRAINT user_behavior_listing_id_listings_id_fk FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: user_behavior user_behavior_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_behavior
    ADD CONSTRAINT user_behavior_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_social_links user_social_links_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_social_links
    ADD CONSTRAINT user_social_links_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict jZZSn1FTZZuTivnfhbPqOMz0ZRyU5MTYG0DrfbaKuQT38MJtTRRPjzVGYECeoY4

